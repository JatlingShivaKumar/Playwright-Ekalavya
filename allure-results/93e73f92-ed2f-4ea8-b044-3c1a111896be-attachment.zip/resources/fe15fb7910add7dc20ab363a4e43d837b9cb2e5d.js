projectModule.controller('feeAssignmentController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourse = "";
	$scope.selectedCourseName = "";
	$scope.selectedClassObj = "";
	$scope.selectedClass = "";

	$scope.getCoursesByBranch = function() {

		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedCourseOb = "";
		$scope.selectedClassObj = "";
		$scope.selectedClass = "";

			httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.selectedBranch , function(data) {
			console.log(data);
			if (data.StatusCode == 200){
					$scope.courseList = data.Courses;
					console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function() {

		console.log($scope.selectedCourseOb);
		if($scope.selectedCourseOb == null || $scope.selectedCourseOb == ""){
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse=$scope.selectedCourseObj.courseId;
		$scope.selectedCourseName=$scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
				httpFactory.getResult("getClassByCoursesID?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch + "&courseId="+$scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200){
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);

			} else {
				console.log("No classes found");
			}
		});
	}
	$scope.getAllFeeCategories = function(){
		httpFactory.getResult("getAcademicFeeInformation?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.allFeeCatglist = data.data;
			}
			else{
				$scope.allFeeCatglist = [];
			}

		});
	}

	$scope.getCoursesByBranch();
	$scope.getAllFeeCategories();

	$scope.getStudentsForFeeCategory = function(fcid){
		$scope.selectedClassObjc = JSON.parse($scope.selectedClassObj);
		$scope.fcid = fcid;
			//localhost:9000/getAllStudentsClassCourseFeeDetailsByFeeType?schemaName=coo5293&classId=3&courseId=5&branchId=4&acadFeeType=4
			httpFactory.getResult("getAllStudentsClassCourseFeeDetailsByFeeType?schemaName="+$scope.schemaName+"&classId="+$scope.selectedClassObjc.classId+"&courseId="+$scope.selectedCourse+"&branchId="+$scope.selectedBranch+"&acadFeeTypeId="+$scope.fcid, function(data) {
				console.log(data);
				if(data.StatusCode == 200){
					$scope.allStudentFeeCatglist = data.data;
				}
				else{
					$scope.allStudentFeeCatglist = [];
				}
		});
	}

	$scope.updateFeeForStud = function(){
		var formStudentList = [];
		for(var i=0; i<$scope.sectionStudents.length; i++){
			var studentFeeArrDetails = [];
			var stuObj = {
				"studentId":$scope.sectionStudents[i].studentId,
				"feeStructureId" : $scope.feeStructureDetails.feeStructureId,
				"createdBy" : $scope.user_id,
			    "discount" : document.getElementsByName("discount")[i].value
			}
			for(j=0; j<$scope.feeStructureDetailsArray.length; j++){
				if($scope.feeStructureDetailsArray[j].isOptional == 0){
					var feeObj = {
						"feeStructureDetailId":$scope.feeStructureDetailsArray[j].feeStructureDetailId,
						"feeCategoryName":$scope.feeStructureDetailsArray[j].feeCategoryName,
						"feeAmount":$scope.feeStructureDetailsArray[j].feeCategoryAmount
					};
					studentFeeArrDetails.push(feeObj);
				}
			}
			for(k=0; k<$scope.studentFeeArr.length;k++){
				if($scope.studentFeeArr[k].studentId == $scope.sectionStudents[i].studentId){
					studentFeeArrDetails.push($scope.studentFeeArr[k]);
				}
			}
			stuObj["studentFeeDetailsArr"] = studentFeeArrDetails;
			formStudentList.push(stuObj);
		}
		
		var params = {
			"schemaName":$scope.schemaName,
			"insertRecords":formStudentList
		};
		
		httpFactory.executePost("addStudentFeeByCategory", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				alert("Updated");
				//$scope.allStudentFeeCatglist = data.data;
			}else{
				//$scope.allFeeCatglist = [];
			}
		});
	}
	
	$scope.studentFeeArr = [];
	$scope.updateStudentFeeCategory = function(ss, fsd){
		if($scope.studentFeeArr.length > 0){
			var stuFeeArrLen = $scope.studentFeeArr.length;
			for(i = 0;i<stuFeeArrLen;i++){
	    		if($scope.studentFeeArr[i].studentId == ss.studentId && $scope.studentFeeArr[i].feeStructureDetailId == fsd.feeStructureDetailId){
	    			if(document.getElementsByName("feeCategoryName")[i].checked == false){
	        			const index = $scope.studentFeeArr.findIndex(x => x.feeStructureDetailId == fsd.feeStructureDetailId);
						if (index !== -1) {
							$scope.studentFeeArr.splice(index, 1);
			 			}else{
			  
		     			}
	      			}
	      		}else{
	        		var feeObj = {
	        			"studentId":ss.studentId,
						"feeStructureDetailId":fsd.feeStructureDetailId,
						"feeCategoryName":fsd.feeCategoryName,
						"feeAmount":fsd.feeCategoryAmount
					};
					if($scope.studentFeeArr.findIndex((x =>(x.feeStructureDetailId == fsd.feeStructureDetailId)&&(x.studentId == ss.studentId)))>-1){
						
					}else{
						$scope.studentFeeArr.push(feeObj);
					}
		   			
	     		}
	   		}
		}else{
			var feeObj = {
				"studentId":ss.studentId,
				"feeStructureDetailId":fsd.feeStructureDetailId,
				"feeCategoryName":fsd.feeCategoryName,
				"feeAmount":fsd.feeCategoryAmount
			};
			$scope.studentFeeArr.push(feeObj);
		}
	 }
	
	$scope.getSectionByClassId = function(selectedClassObj){
		if(typeof selectedClassObj === "string"){
			$scope.classObj = JSON.parse(selectedClassObj);
		}else{
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName="+$scope.schemaName+"&classCourseId="+$scope.classObj.classCourseId+"&branchId="+$scope.selectedBranch, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.sectionList = data.Sections;
			}
			else{
				alert("Got Error");
			}
		});
	}
	
	$scope.updateCrsClsSec = function(selectedSectionObj){
		if(typeof selectedSectionObj === "string"){
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		}else{
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}
	
	$scope.getStudentsBySection = function(){
    	httpFactory.getResult("selectStudentsBySection?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&sectionId=" + $scope.sectionId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
            	$scope.showStudents = true;
                $scope.sectionStudents = data.sectionStudents;
            } else {

            }
        });
        $scope.getFeeStructureDetails();
    }
    
    $scope.getFeeStructureDetails = function(){
		$scope.feeStructureDetailsArray = [];
		httpFactory.getResult("getFeeStructureDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse + "&classId=" + $scope.classObj.classId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
            	$scope.structureName = false;
            	$scope.feeStructureDetails = data.data;
            	if(Object.keys($scope.feeStructureDetails).length !== 0){
            		$scope.structureName = true;
            		$scope.feeStructureDetailsArray = $scope.feeStructureDetails.feeStructureDetailsArr;
            	}
            	
            } else {

            }
        });
	}
	
	

});
