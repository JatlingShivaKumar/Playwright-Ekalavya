projectModule.controller('testCategoriesController', function($scope, $location, $timeout, $routeParams, httpFactory) {
  $scope.$ = $;
  $scope.instituteId = parseInt(localStorage.getItem("inst_id"));
  $scope.instituteTypes = [];
  $scope.latestCurrentInstTab = "";
  $scope.schemaName = localStorage.getItem("sname");
  $scope.userRoleId = localStorage.getItem("RD");
  $scope.bnchId=localStorage.getItem("bnchId");
  
  
  
  $scope.testSectionsArr = [{
	    "examType": "",
	    "sectionName": "",
	    "totalQuestions": "",
	    "correctMarks": "",
	    "wrongMarks": "",
		 "unansweredMarks": ""

	  }];
  
  
  $scope.addNewSection=function() {
	    $scope.testSectionsArr.push({
	    	  "examType": "",
	  	    "sectionName": "",
	  	    "totalQuestions": "",
	  	    "correctMarks": "",
	  	    "wrongMarks": "",
	  		 "unansweredMarks": ""
	    });
	    
	    console.log($scope.testSectionsArr);
	    $scope.$apply();
  }
  
  $scope.removeSection=function(ind){
	  alert(ind);
	  $scope.testSectionsArr.splice(ind,1);
	    $scope.$apply();

  }
  
  $scope.getBranchClassCourse = function(){
		httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName+"&branchId="+$scope.bnchId, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				// $scope.categoryList = data.TestCategories;
				$scope.courseList = data.Courses;
				 console.log($scope.courseList);
			}
			 else { 
			}
		});
	}
//  alert("testcategories");
  $scope.getBranchClassCourse();
  
  
  $scope.selectedCourseMethod=function(selectedCourse){
	  console.log(selectedCourse);
	  
	  if(typeof selectedCourse == 'string')
		  $scope.selectedCourseOb=JSON.parse(selectedCourse);
	  else
		  $scope.selectedCourseOb=selectedCourse;
	  
	  console.log($scope.selectedCourseOb);
	  
	  $scope.selectedCourseId=$scope.selectedCourseOb.courseId;
	  
	  $scope.getTestCategories();
	
}
  
  $scope.getTestCategories = function() {
	   $scope.selectedCategoryObj = "";
	   $scope.subjectList =[];
	   httpFactory.getResult("getTestCategories?instId=" +$scope.instituteId + "&schemaName="+$scope.schemaName +"&courseId=" + $scope.selectedCourseId, function(data) {
	     console.log(data);
	     if (data.STATUS == 'SUCCESS') {
	       $scope.categoryList = data.TestCategories;
	       console.log($scope.categoryList);
	     }
	      else {
	     }
	   });
	 }
  

//suresh testing purpose code

function getSelectionText() {
    var text = "";
    var activeEl = document.activeElement;
    var activeElTagName = activeEl ? activeEl.tagName.toLowerCase() : null;
    if (
      (activeElTagName == "textarea") || (activeElTagName == "input" &&
      /^(?:text|search|password|tel|url)$/i.test(activeEl.type)) &&
      (typeof activeEl.selectionStart == "number")
    ) {
        text = activeEl.value.slice(activeEl.selectionStart, activeEl.selectionEnd);
    } else if (window.getSelection) {
        text = window.getSelection().toString();
    }
    return text;
}

document.onmouseup = document.onkeyup = document.onselectionchange = function() {
  //document.getElementById("sel").value = getSelectionText();
//	alert("suresh");
//	  document.getElementById("usr").value = getSelectionText();

};



//suresh word search

$scope.defaultWordlist=[
	"HELLO",
	"CHALO",
	"POLO",
	"HOLO"
];

function randomString(charSet) {
    
    var randomString = '';
    for (var i = 0; i < 1; i++) {
        var randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz,randomPoz+1);
    }
    return randomString;
}

function Cell(x, y) {
	alert("cell");
    this.solvedColorClasses = [],
    this.isSelected = false,
    this.onPath = false,
    this.onCorrectPath = false,
    this.willFitLetter = function (letter) {
        return letter;
    };
    this.randomFill = function () {
        return randomString($scope.ALPHABET);
    };
}

function LetterGrid(width,height,maxWords,wordlist) {
//    this.solvedColorClasses = [],
//    this.isSelected = false,
//    this.onPath = false,
//    this.onCorrectPath = false,
    
	console.log(width);
	console.log(height);
    var cells = (new Cell(width,height));
    
    $scope.words = [];
    
    $scope.shuffle($scope.defaultWordlist);
    
}

$scope.levels = [
    { "width": 8, "height": 8 },
    { "width": 9, "height": 9 },
    { "width": 10, "height": 10 },
    { "width": 11, "height": 11 }
  ]

$scope.shuffle=function(array) {
	  var currentIndex = array.length, temporaryValue, randomIndex;

	  // While there remain elements to shuffle...
	  while (0 !== currentIndex) {

	    // Pick a remaining element...
	    randomIndex = Math.floor(Math.random() * currentIndex);
	    currentIndex -= 1;

	    // And swap it with the current element.
	    temporaryValue = array[currentIndex];
	    array[currentIndex] = array[randomIndex];
	    array[randomIndex] = temporaryValue;
	  }

	  return array;
	}
$scope.NUM_COLORS = 5
$scope.ALPHABET = 'AABBCCDDEEFFGGHHIIJKLLMMNNOOPPQRSSTTUUVWXYZ';

// Directions words can be placed along, shuffled to avoid repeating patterns
$scope.DIRECTIONS = $scope.shuffle([ [1, 0], [0, 1], [-1, 0], [0, -1],
                         [1, 1], [1, -1], [-1, 1], [-1, -1] ]);

                         
   // Helper function to join the letters from a path to form its word
	$scope.wordFromPath = function(path){
	  var word = '';
	   if(path){
	     for (var cell in path){
	       word += cell.letter;
	   }
	   }
	  return word;
}
	
	  $scope.loadLevel = function(level){
	    $scope.currentLevel = level;
	    alert("in");
	    console.log(level);
	    $scope.grid = new LetterGrid(level.width, level.height);
	    console.log($scope.grid);
	    $scope.words = $scope.grid.words;
	    
	    console.log($scope.words);
	    $scope.foundWords = [];

	    $scope.enableInput = true;
	    $scope.colorIndex = 1;
	    $scope.colorClass = 'color1';
	  }
	  $scope.loadLevel($scope.levels[0]);

	  
	  
      $scope.matrix = [
          ['N', 'I', 'G', 'O', 'R', 'Y', 'G', 'S', 'T', 'T', 'A', 'N'],
          ['O', 'G', 'G', 'U', 'L', 'C', 'O', 'E', 'P', 'E', 'A', 'S'],
          ['I', 'N', 'N', 'R', 'M', 'N', 'O', 'R', 'I', 'M', 'E', 'C'],
          ['T', 'I', 'A', 'I', 'O', 'E', 'G', 'V', 'R', 'P', 'V', 'E'],
          ['C', 'T', 'T', 'E', 'D', 'D', 'L', 'I', 'C', 'L', 'I', 'N'],
          ['E', 'S', 'J', 'P', 'U', 'N', 'E', 'C', 'S', 'A', 'T', 'A'],
          ['J', 'E', 'O', 'O', 'L', 'E', 'I', 'E', 'A', 'T', 'C', 'R'],
          ['N', 'T', 'V', 'C', 'E', 'P', 'J', 'B', 'V', 'E', 'E', 'I'],
          ['I', 'S', 'I', 'S', 'S', 'E', 'S', 'A', 'A', 'W', 'R', 'O'],
          ['O', 'K', 'S', 'I', 'M', 'D', 'E', 'S', 'J', 'O', 'I', 'M'],
          ['R', 'E', 'L', 'L', 'O', 'R', 'T', 'N', 'O', 'C', 'D', 'E']
      ];
      $scope.words = [
          'BINDING', 'CONTROLLER', 'DEPENDENCY', 'DIRECTIVE', 'GOOGLE', 'IGOR', 'INJECTION', 'JAVASCRIPT',
          'MISKO', 'MODULES', 'SCENARIO', 'SCOPE', 'SERVICE', 'TEMPLATE', 'TESTING', 'VOJTA'
      ];

});