/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

// CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
// };

CKEDITOR.editorConfig = function( config ) {

        config.extraPlugins = 'eqneditor,imagebrowser,imagepaste,imageuploader,symbol,tabletoolsbar';

	config.toolbar = [
		{ name: 'document', items: [ 'Source', '-', 'Save', 'NewPage', 'Preview', 'Print', '-', 'Templates' ] },
		{ name: 'clipboard', items: [ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ] },
		{ name: 'editing', items: [ 'Find', 'Replace', '-', 'SelectAll', '-', 'Scayt' ] },
		{ name: 'forms', items: [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField'] },
		'/',
		{ name: 'basicstyles', items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat' ] },
		{ name: 'paragraph', items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language' ] },
		{ name: 'links', items: [ 'Link', 'Unlink', 'Anchor' ] },
		{ name: 'insert', items: [ 'Image', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe' ] },
		'/',
		{ name: 'styles', items: [ 'Styles', 'Format', 'Font', 'FontSize' ] },
		{ name: 'colors', items: [ 'TextColor', 'BGColor' ] },
		{ name: 'tools', items: [ 'Maximize', 'ShowBlocks' ] },
		{ name: 'about', items: [ 'About' ] }
	];

	config.keystrokes = [
	       [ CKEDITOR.ALT + 81 /*Q*/, 'subscript'  ],
	       [ CKEDITOR.ALT + 87 /*W*/, 'superscript'  ],
	       [ CKEDITOR.ALT + 65 /*A*/, 'pastefromword'  ],
	       [ CKEDITOR.CTRL + 74 /*J*/, 'justifyblock' ],
	       [ CKEDITOR.CTRL + 69 /*E*/, 'justifycenter' ],
	       [ CKEDITOR.CTRL + 76 /*L*/, 'justifyleft' ],
	       [ CKEDITOR.CTRL + 82 /*R*/, 'justifyright' ],
	       [ CKEDITOR.CTRL + 83 /*S*/, 'save' ]
	    ];

      config.specialChars = config.specialChars.concat( [ [ '&alpha;', 'alpha' ],
              [ '&beta;', 'beta' ],
              [ '&Gamma;', 'gamma' ],
              [ '&gamma;', 'gamma' ],
              [ '&Delta;', 'delta' ],
              [ '&delta;', 'delta' ],
              [ '&epsilon;', 'epsilon' ],
              [ '&Epsilon;', 'epsilon' ],
              [ '&zeta;', 'zeta' ],
              [ '&eta;', 'eta' ],
              [ '&theta;', 'theta' ],
              [ '&iota;', 'iota' ],
              [ '&kappa;', 'kappa' ],
              [ '&lambda;', 'lambda' ],
              [ '&mu;', 'mu' ],
              [ '&nu;', 'nu' ],
              [ '&xi;', 'xi' ],
              [ '&omicron;', 'omicron' ],
              [ '&pi;', 'pi' ],
              [ '&rho;', 'rho' ],
              [ '&Sigma;', 'sigma' ],
              [ '&tau;', 'tau' ],
              [ '&upsilon;', 'upsilon' ],
              [ '&phi;', 'phi' ],
              [ '&chi;', 'chi' ],
              [ '&psi;', 'psi' ],
              [ '&omega;', 'omega' ],
              [ '&Omega;', 'omega' ]
              ] );
            }
