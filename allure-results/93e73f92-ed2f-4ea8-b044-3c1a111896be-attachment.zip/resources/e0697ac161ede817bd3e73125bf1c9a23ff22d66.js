projectModule.controller('adminMessagesController', function($scope, $window, $location, commonFactory, httpFactory, $routeParams,$route) {
  $scope.$ = $;
  $scope.instituteId = parseInt(localStorage.getItem("inst_id"));
  $scope.branchId=localStorage.getItem("bnchId");
  $scope.adminRoleId=localStorage.getItem("RD");
  $scope.userId=localStorage.getItem("userId");
  $scope.schemaName=localStorage.getItem("sname");
  $scope.userList=[];
  $scope.messageCounter=0;
  $scope.threadCount=0;
  if ($scope.adminRoleId==4) {
    $scope.branchId=localStorage.getItem("stbrnchid");
  }
  $scope.threadMessages=[];
  $scope.messagesInit=function(){
	  // $scope.getAllUsers();
	  $scope.getAllMessages();
	  //    $scope.getMessageDetails();
	  $scope.userSelect($scope.userList[0]);



	  $scope.interval=setInterval(function() {
		  $scope.getMessageDetails();
		  // $scope.messageCounter++;
	  }, 5000);

	  $scope.currentpath=JSON.stringify(localStorage.getItem('location'));
	  localStorage.setItem('location', JSON.stringify($location.path("messages/yes")));
  }
  $scope.getAllUsers = function(){
		httpFactory.getResult("getAllUsersDetails?branchId=" +$scope.branchId+"&schemaName="+$scope.schemaName+"&roleId="+$scope.adminRoleId+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				//$scope.userList = data.UserObject;
				$scope.searchList = data.UserObject;
			}
		});
	}
  $scope.getMessageDetails=function(){
   /* console.log($scope.messageCounter);
    if ($scope.messageCounter>10) {
      if ($routeParams.messages!='yes') {
        clearInterval($scope.interval);
      }else{
      }
    }*/
    httpFactory.getResult("getMessageDetails?threadId=" +$scope.threadId+"&schemaName="+$scope.schemaName+"&userId="+$scope.userId, function(data) {
      console.log(data);
      if(data.StatusCode == "200"){
        if ($scope.threadCount!=data.messageDetails.length) {
          $scope.threadMessages = data.messageDetails;
          $scope.threadCount=$scope.threadMessages.length;
          console.log($scope.threadMessages);
         /* $scope.$apply();
          if ($scope.messageCounter==0) {
          setTimeout(function(){
            $scope.$apply();
            var elmnt = document.getElementById("messageListBox");
            elmnt.scrollTop = elmnt.scrollHeight+100;
          }, 1000);
        }*/
        

        }
      }else{
        $scope.threadMessages=[];
      }
    });
  }
  $scope.userSelect=function(user,ind){
    console.log(user);
    $scope.selIndex = ind;
    
    if(user){
    $scope.selectedUser=user;
    }
       
      $scope.selectedUserId=$scope.selectedUser.userId;
      if($scope.selectedRole == 'S'){
         $scope.selectedUserId=$scope.selectedUser.studentId;
      }
      $scope.threadId=$scope.selectedUser.threadId;
      $scope.messageCounter=0;
      $scope.getMessageDetails();

  }

  var inputComment = document.getElementById("comment");
  inputComment.addEventListener("keyup", function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();

      $scope.sendMessage();
    }
  });

  $scope.selectedRoleMethod=function(role){
    console.log($scope.selectedRole);
    console.log($scope.userName);
    $scope.searchMember();
  }

$scope.sendMessage=function(){
  $scope.messageText = document.getElementById("comment").value;
  if($scope.messageText.trim() == ''){
	   return true;
  }
  if($scope.selectedRole == "E"){
     $scope.fromRoleId = 2;
     $scope.toRoleId = 3;
  }else if($scope.selectedRole == "S"){
     $scope.fromRoleId = 2;
     $scope.toRoleId = 0;
  }
  
  var params = {  
    "fromRoleId":$scope.fromRoleId,
    "toRoleId":$scope.toRoleId,
 	"schemaName":$scope.schemaName,
 	"createdBy":$scope.userId,
 	"MessageTo":$scope.selectedUserId,
 	"messageDetails":$scope.messageText
 }
 $scope.messageCounter=0;
 httpFactory.executePost("createNewMessage", params, function(data) {
  console.log("data: "+data);
   if (data.StatusCode == "200") {
    	   if(!$scope.threadId){
    		   for(var i=0;i<$scope.userList.length;i++){
    			   if($scope.userList[i].userId==$scope.selectedUserId){
    				   $scope.userList[i]["threadId"]=data.threadId;
    				   $scope.threadId=data.threadId;
    				   break;
    			   }
    		   }
    		   $scope.getAllMessages();
    		    }
   
	   moveObjectAtIndex($scope.userList,$scope.selIndex,0);

     //$scope.$apply();
     var elmnt = document.getElementById("messageListBox");
     elmnt.scrollTop = elmnt.scrollHeight+100;
     document.getElementById("comment").value="";
     setTimeout(function(){$scope.$apply(); }, 3000);
   } else {
     alert("Something went wrong.try again!");
   }
 });
 
  }

function moveObjectAtIndex(array, sourceIndex, destIndex) {
    var placeholder = {};
    // remove the object from its initial position and
    // plant the placeholder object in its place to
    // keep the array length constant
    var objectToMove = array.splice(sourceIndex, 1, placeholder)[0];
    console.log(objectToMove);

    // place the object in the desired position
    array.splice(destIndex, 0, objectToMove);
    // take out the temporary object
    array.splice(array.indexOf(placeholder), 1);
    console.log(array);
}

  $scope.getAllMessages=function(){
    httpFactory.getResult("getAllMessages?branchId=" +$scope.branchId+"&schemaName="+$scope.schemaName+"&userId="+$scope.userId+"&roleId="+$scope.adminRoleId, function(data) {
      console.log(data);
      if(data.StatusCode == "200"){
        $scope.userList = data.Messages;
        console.log($scope.userList);
      $scope.userSelect($scope.userList[0]);
    }
    });
  }

  $scope.searchUsers=function(){
    $scope.searchMember();
  }

  $scope.searchMember=function(){
	  /*if($scope.selSec)
		  $scope.msgSecId=$scope.selSec.sectionId;
	  else
		  $scope.msgSecId="";*/
		  if($scope.selectedRole == 'E'){
		     $scope.classCourseId = "";
		     $scope.msgSecId = "";
		     if($scope.userSearch == undefined){
		     	$scope.getAllUsers();
		     }else if($scope.userSearch != undefined){
		        httpFactory.getResult("searchMember?userTag="+$scope.selectedRole+"&schemaName="+$scope.schemaName+"&userName="+$scope.userSearch+"&userId="+$scope.userId+"&classCourseId="+$scope.classCourseId+"&sectionId="+$scope.msgSecId+"&branchId="+$scope.branchId, function(data) {
            		console.log(data);
            		if(data.StatusCode == "200"){
               			$scope.searchList = data.userDetails;
               			console.log($scope.searchList);
//             			$("#userSelect").modal("show");
            		}else{
               			alert("No users found");
            		}
        		});
		     }
		  }else if($scope.selectedRole == 'S'){
		      $scope.classCourseId = $scope.allCls.classCourseId;
		      $scope.msgSecId = $scope.selSec.sectionId;
		       if($scope.userSearch == undefined){
		     	$scope.selectStudentsBySection();
		     }else if($scope.userSearch != undefined){
		        httpFactory.getResult("searchMember?userTag="+$scope.selectedRole+"&schemaName="+$scope.schemaName+"&userName="+$scope.userSearch+"&userId="+$scope.userId+"&classCourseId="+$scope.classCourseId+"&sectionId="+$scope.msgSecId+"&branchId="+$scope.branchId, function(data) {
            		console.log(data);
            		if(data.StatusCode == "200"){
               			$scope.searchList = data.userDetails;
               			console.log($scope.searchList);
//             			$("#userSelect").modal("show");
            		}else{
               			alert("No users found");
            		}
        		});
		     }
		  }
  }

  $scope.searchUserSelect=function(user){
    console.log(user);
    if($scope.userList.length > 0){
      var found = 0;
      for(var i=0; i<$scope.userList.length; i++){
        if(user.userId == $scope.userList[i].userId){
          found++;
          $scope.userSelect($scope.userList[i]);
          break;
        }
      }
      if(found == 0){

        $scope.userList.splice($scope.userList.length, 0, user);
        $scope.userSelect(user);

      }
    }else{
      $scope.userList.splice($scope.userList.length, 0, user);
      $scope.userSelect(user);
    }

    console.log($scope.userList);
    $("#userSelect").modal("hide");
    $('#advanceSearch').modal('hide');

  }

  $scope.advanceSearch = function(){
    $scope.getCoursesByBranch();
    $('#advanceSearch').modal('show');
  }

  $scope.getCoursesByBranch = function() {
 	  $scope.selectedCourse = "";
 	  $scope.courseList = [];
 	  $scope.courseClasses = [];
 	  $scope.selectedClassCourseId = "";
 	  $scope.showSection = false;
 	  $scope.allSectionslist = [];
 	    httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.branchId , function(data) {
       console.log(data);
       if (data.StatusCode == 200){
           $scope.courseList = data.Courses;
           if($scope.courseList.length==1) {
           $scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
           }
           $scope.getClassesByCourse($scope.selectedCourseOb);
           console.log($scope.courseList);
           if($scope.navCourseId){
             for (var i = 0; i < $scope.courseList.length; i++) {
               if($scope.courseList[i].courseId==$scope.navCourseId){
                 console.log(JSON.stringify($scope.courseList[i]));
                 $scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
                 $scope.selectedCourse=$scope.courseList[i].courseId;
                 $scope.getClassesByCourse($scope.courseList[i]);
                 break;
             }
           }
         }
       } else {
 		console.log("No courses");
       }
     });
   }

 	$scope.getClassesByCourse = function(course) {
     console.log(course);
     if (typeof course == 'string')
     $scope.selCourseObj = JSON.parse(course);
     else
     $scope.selCourseObj=course;

     $scope.selectedCourse=$scope.selCourseObj.courseId;
     $scope.selectedCourseName=$scope.selCourseObj.courseName;
 		//$scope.selectedCourse = "";
 		$scope.showSection = false;
 		$scope.selectedClassCourseId = "";
 		$scope.courseClasses = [];
 		$scope.allSectionslist = [];
 		httpFactory.getResult("getClassByCoursesID?schemaName="+$scope.schemaName+"&branchId=" + $scope.branchId + "&courseId="+$scope.selectedCourse, function(data) {
 			console.log(data);
 			if (data.StatusCode == 200){
 				$scope.courseClasses = data.Classes;
 				console.log($scope.courseClasses);
//                $scope.getSectionsByClass();
 			} else {
 				console.log("No classes found");
 			}
 		});
 	}
 	$scope.allSectionslist = new Array();
 	$scope.showSection = false;

 	$scope.getSectionsByClass = function(classOb){
 	console.log(classOb);
 		if(typeof classOb=='string')
 			$scope.allCls=JSON.parse(classOb);
 		else
 			$scope.allCls=classOb;
 	
 		$scope.allSectionslist = [];
 		$scope.sectionStudents = [];
 		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName="+$scope.schemaName+"&branchId=" + $scope.branchId +"&classCourseId="+$scope.allCls.classCourseId, function(data) {
 			console.log(data);
 			if (data.StatusCode == 200){
 				$scope.allSectionslist = data.Sections;
         console.log($scope.allSectionslist[0]);
// 				$scope.getSectionStudents($scope.allSectionslist[0]);
 			} else {

 			}
 		});
 	}
 	
 	$scope.getSelSec=function(selectedSec){
 		console.log(selectedSec);
 		if(typeof selectedSec=='string')
 			$scope.selSec=JSON.parse(selectedSec);
 		else
 			$scope.selSec=selectedSec;
 	}
 	
 	$scope.getSearchMembers=function(){
 	    $scope.searchMember();

 	}
 	
 	$scope.selectStudentsBySection = function(){
 	$scope.searchList = [];
    	httpFactory.getResult("selectStudentsBySection?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + $scope.msgSecId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
            	$scope.sectionStudents = data.sectionStudents;
            	for(i=0;i<$scope.sectionStudents.length;i++){
            		var tmpStuObj = {};
            		tmpStuObj["userName"] = $scope.sectionStudents[i].studentName;
            		tmpStuObj["studentId"] = $scope.sectionStudents[i].studentId;
            		tmpStuObj["sectionName"] = $scope.sectionStudents[i].sectionName;
            		tmpStuObj["classCourseSectionId"] = $scope.sectionStudents[i].classCourseSectionId;
            		
            		$scope.searchList.push(tmpStuObj);
            	}
                /*  for (var i = 0; i < $scope.sectionStudents.length; i++) {
                    if ($scope.sectionStudents[i].profilePic == 'NA') {
                        $scope.sectionStudents[i].profilePicPath = "";
                    } else {
                        $scope.sectionStudents[i].profilePicPath = "http://" + localStorage.getItem("domain") + "/studentProfileDownload?filePath=" + $scope.sectionStudents[i].profilePic;
                    }
                }*/
            } else {

            }
        });
    }
 	
	$scope.goToMessaging = function(){
		$location.path("messaging");
	}
	$scope.goToHome = function(){
		$location.path("home");
	}
 	
});
