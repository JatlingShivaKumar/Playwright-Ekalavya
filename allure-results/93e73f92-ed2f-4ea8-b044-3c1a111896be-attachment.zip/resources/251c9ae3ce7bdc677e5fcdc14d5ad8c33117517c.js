projectModule.controller('timeTableController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {

  $scope.$ = $;
  $scope.instituteId = 1;
  $scope.userId = localStorage.getItem("userId");
  var requestParams = {
    "m_inst_id": $scope.instituteId
  };
  $scope.schemaName = localStorage.getItem("sname");
  $scope.branchId = localStorage.getItem("bnchId");
  $scope.timeTable=true;
  $scope.timeTableView=false;
  $scope.ttTemplateList  = [];
  $scope.ttSectionName = "";
	$scope.sectionId = "";
  $scope.selectedCourse = "";
  $scope.selectedCourseOb = "";
  $scope.checkTeacherAvailabilty = checkTeacherAvailabilty;

  $scope.navCourseId=sessionStorage.getItem("navCourseId");
	$scope.navClassId=sessionStorage.getItem("navClassId");
	$scope.myClasses=sessionStorage.getItem("myClasses");
	$scope.navSectionId=sessionStorage.getItem("navSectionId");

	sessionStorage.removeItem("navCourseId");
	sessionStorage.removeItem("navClassId");
	sessionStorage.removeItem("navSectionId");
	sessionStorage.removeItem("myClasses");
	
	$scope.gotoLoc = function(loc) {
        $location.path(loc);
    }

$scope.getCollegeTimeTable = function(){
  httpFactory.getResult("getGenericWDPT?schemaName="+$scope.schemaName+"&templateId="+$scope.selectedTemplate, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.workingDaysObj = data.workingDays.slice();
      $scope.periods=data.periodArray.slice();
      console.log($scope.workingDaysObj);
      console.log($scope.periods);
	  $scope.regeneratTimeTableData();
    }
  });
}

  $scope.getCourseByBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.courseListOb = data.Courses;
	      if($scope.courseListOb.length==1) {
	    	  $scope.selectedCourseOb = JSON.stringify($scope.courseListOb[0]);
	      }
	      
	      $scope.courseSelect($scope.selectedCourseOb);
        $scope.courseList=[];
        for(var i=0;i<$scope.courseListOb.length;i++){
          //if($scope.courseListOb[i].isDefault==0)
          $scope.courseList.push($scope.courseListOb[i]);

        }
        if($scope.navCourseId){
          for (var i = 0; i < $scope.courseList.length; i++) {
            if($scope.courseList[i].courseId==$scope.navCourseId){
              console.log(JSON.stringify($scope.courseList[i]));
              $scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
              $scope.selectedCourse=$scope.courseList[i].courseId;
              $scope.courseSelect($scope.selectedCourseOb);
              break;

          }
        }
      }
	    }
	  });
	}

	$scope.courseSelect = function(crsob){
    $scope.selectedCourseOb = crsob;
    if (crsob) {
    try {
    var doopcrsob = JSON.parse(crsob);
    $scope.selectedCourse = doopcrsob.courseId;
    $scope.classList=[];
    $scope.sectionList=[];
		httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
        if($scope.navCourseId){
          for (var i = 0; i < $scope.classList.length; i++) {
            if($scope.classList[i].classId==$scope.navClassId){
              console.log(JSON.stringify($scope.classList[i]));
              $scope.selectedClasOb=JSON.stringify($scope.classList[i]);
              $scope.selectedCCId=$scope.classList[i].classCourseId;
              $scope.courseClassSelect($scope.selectedClasOb);
              break;
          }
        }
      }

			}
		});
		}catch (e) {
                         console.error("Error parsing JSON:", e);
                     }

		}
	}

  $scope.goToMyClasses=function(){
    sessionStorage.setItem("navCourseId",$scope.selectedCourse);
    sessionStorage.setItem("navClassId",$scope.selectedClassId);
    $location.path("/rankrClasses");
   }

  $scope.backMethod=function(){
    window.history.back();

  }

	$scope.courseClassSelect = function(selectedClass){
    console.log(selectedClass);
    $scope.selectedClassOb = JSON.parse(selectedClass);
    console.log($scope.selectedClasOb);
    $scope.selectedCCId=$scope.selectedClassOb.classCourseId;
    $scope.selectedClassId = $scope.selectedClassOb.classId;

		httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
      $scope.sectionList=[];
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
        console.log($scope.myClasses);
        if ($scope.myClasses) {

          for (var i = 0; i < $scope.sectionList.length; i++) {
            if($scope.sectionList[i].sectionId==$scope.navSectionId){
              $scope.sectionOb=$scope.sectionList[i];
              break;
            }
          }
        }else{
          $scope.sectionOb=$scope.sectionList[0];
        }
        $scope.timeTableForSection($scope.sectionOb);
			}else{
        $scope.sectionList=[];
        $scope.sectionTimeTable=[];
        $scope.allWorkingDays=[];
        $scope.timeTableView=false;
        $scope.timeTable=true;
        $scope.ttSectionName="";
      }
		});
	}
	$scope.getTTTemplateNames = function(){
		httpFactory.getResult("getTimeTableTemplateNames?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.ttTemplateList = data.timeTableTemplate.slice();
			}
		});
	}


	$scope.getTemplateToUse = function(stempl){
    $scope.selectedTemplate = stempl;
    console.log($scope.selectedTemplate);
    $scope.getCollegeTimeTable();
		// if($scope.selectedTemplate != null){
		// 	httpFactory.getResult("getTimeTableTemplate?templateId="+$scope.selectedTemplate+"&schemaName="+$scope.schemaName, function(data) {
		// 		console.log(data);
		// 		if (data.StatusCode == 200) {
		// 			$scope.ttTemplateToUse = data.timeTableTemplate.slice();
		// 		}
		// 	});
		// }
	}
	$scope.chckADDorEdit = function(){
		$scope.ttSectionName = localStorage.getItem('ttSectionName');
		$scope.getTTTemplateNames();
		var section={
			"sectionId":localStorage.getItem("ttSectionId"),
			"sectionName":localStorage.getItem("ttSectionName")
		}
		$scope.timeTableForSection(section);
		// if($scope.allWorkingDays.length ==0){
		// 	$scope.getCollegeTimeTable();
		// }
	}
	$scope.timeTableForSection = function(section){
		$scope.ttSectionName = section.sectionName;
		localStorage.setItem('ttSectionName',section.sectionName);
		$scope.sectionId = section.sectionId;
		httpFactory.getResult("getSectionTimeTable?schemaName="+$scope.schemaName+"&sectionId="+$scope.sectionId, function(data) {
			console.log(data);
			$scope.mainTimeTableObj=[];
			if (data.StatusCode == 200) {
				if(data.sectionTimeTable.length > 0){
					$scope.allWorkingDays = data.sectionTimeTable;
					$scope.timeTableView=true;
					$scope.timeTable=false;
				}
				else{
					$scope.allWorkingDays = [];
					$scope.timeTable=true;
					$scope.timeTableView=false;

				}
			}
			else{
			  $scope.allWorkingDays = [];
			  $scope.timeTable=true;
			  $scope.timeTableView=false;
			}
		});
		localStorage.setItem("ttSectionId",$scope.sectionId);
	}



	$scope.createTimeTable=function(){
		localStorage.setItem("ttSelectedCourse",$scope.selectedCourse);
		localStorage.setItem("ttSelectedCCID",$scope.selectedCCId);
    localStorage.setItem("ttSelectedClsId",$scope.selectedClassId);

		// $scope.getCollegeTimeTable();
		$location.path("newTimeTable");
	}

	$scope.updateTimeTable = function(){
		localStorage.setItem("ttSelectedCourse",$scope.selectedCourse);
		localStorage.setItem("ttSelectedCCID",$scope.selectedCCId);
		// $scope.getCollegeTimeTable();
		$location.path("newTimeTable");
	}

  $scope.insertTTChck = true;
  $scope.insertTimeTable=function(){
	  var params={
			"schemaName" : $scope.schemaName,
			"branchId":$scope.branchId,
			"sectionId":localStorage.getItem("ttSectionId"),
      "createdBy":localStorage.getItem("userId")
		};
		if(ttRecordAdded == false){
			params.createdBy = $scope.userId;
			params.insertRecords = [];
			for(var i=0; i<$scope.workingDaysObj.length; i++){
				for(var j=0; j<$scope.workingDaysObj[i].periods.length; j++){
					if($scope.workingDaysObj[i].periods[j].subjectTeacher!=undefined && $scope.workingDaysObj[i].periods[j].subjectTeacher.length > 0){
						var recd = {
							"periodId":$scope.workingDaysObj[i].periods[j].periodId,
							"workingDayId":$scope.workingDaysObj[i].workingDayId,
							"periodStartTime" : $scope.workingDaysObj[i].periods[j].periodStartTime,
							"periodEndTime" : $scope.workingDaysObj[i].periods[j].periodEndTime,
							"isBreak":$scope.workingDaysObj[i].periods[j].isBreak,
              "isElective":$scope.isElective,
              "electiveGroupId":$scope.electiveGroupId,
              "subjectTeacher":$scope.workingDaysObj[i].periods[j].subjectTeacher,
              "breakDesc":$scope.workingDaysObj[i].periods[j].breakDesc
						};

						params.insertRecords.push(recd);
            console.log(params);
					}
					else{
						var recd = {
							"periodId": $scope.workingDaysObj[i].periods[j].periodId,
							"workingDayId": $scope.workingDaysObj[i].workingDayId,
							"periodStartTime" : $scope.workingDaysObj[i].periods[j].periodStartTime,
							"periodEndTime" : $scope.workingDaysObj[i].periods[j].periodEndTime,
							"isBreak":$scope.workingDaysObj[i].periods[j].isBreak,
              "breakDesc":$scope.workingDaysObj[i].periods[j].breakDesc
            };
						params.insertRecords.push(recd);
            console.log(params);
					}
				}
			}
      console.log(params);
      $scope.insertTTChck = false;
			httpFactory.executePost("insertTimeTable", params, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
          $scope.insertTTChck = true;
					$scope.chckADDorEdit();
					alert("successfully updated");
					ttRecordAdded = true;
					$("#assignTeacher").modal("hide");
				} else {
          $scope.insertTTChck = true;
					//TODO : Show Error
					$scope.errorMsg = data.message;
				}
			});
		}
		console.log(JSON.stringify(params));
		console.log($scope.workingDaysObj);
  }
$scope.newtemplateName ="";
	$scope.saveAsTemplate = function(tname){
		var ttTemplate = {
			"schemaName":$scope.schemaName,
			"templateName":tname,
			"createdBy":$scope.userId,
			"branchId":$scope.branchId,
			"workingDays":[]
		};
		if($scope.allWorkingDays.length ==0){
			for(var i=0; i<$scope.workingDaysObj.length; i++){
				for(var j=0; j<$scope.workingDaysObj[i].periods.length; j++){
					var recd = {
						"periodId":$scope.workingDaysObj[i].periods[j].periodId,
						"workingDayId":$scope.workingDaysObj[i].workingDayId,
						"startTime" : $scope.workingDaysObj[i].periods[j].periodStartTime,
						"endTime" : $scope.workingDaysObj[i].periods[j].periodEndTime,
					};
					if($scope.workingDaysObj[i].periods[j].isBreak == '1'){
						recd.isBreak = 1;
						// recd.breakDesc =
            recd["breakDesc"]=$scope.workingDaysObj[i].periods[j].breakDesc;

					}
					else{
						recd.isBreak = 0;
						recd.breakDesc = '';
					}
					ttTemplate.workingDays.push(recd);
				}
			}
		}
		else{
			for(var i=0; i<$scope.allWorkingDays.length; i++){
				for(var j=0; j<$scope.allWorkingDays[i].periods.length; j++){
					var recd = {
						"periodId":$scope.allWorkingDays[i].periods[j].periodId,
						"workingDayId":$scope.allWorkingDays[i].workingDayId,
						"startTime" : $scope.allWorkingDays[i].periods[j].periodStartTime,
						"endTime" : $scope.allWorkingDays[i].periods[j].periodEndTime,
					};
					if($scope.allWorkingDays[i].periods[j].isBreak == '1'){
						recd.isBreak = 1;
            recd["breakDesc"]=$scope.workingDaysObj[i].periods[j].breakDesc;
					}
					else{
						recd.isBreak = 0;
            recd["breakDesc"]="";
					}
					ttTemplate.workingDays.push(recd);
				}
			}
		}
		console.log(ttTemplate);
		httpFactory.executePost("saveTimeTableTemplate", ttTemplate, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("successfully saved");

			} else {
				//TODO : Show Error
				$scope.errorMsg = data.message;
			}
		});
	}

  //createTimeTable
  	$scope.timeTableData = [];

	//getCourseClassSubjects
	$scope.getCourseClassSubjects = function(){
		$scope.selectedCourse = localStorage.getItem("ttSelectedCourse");
		$scope.selectedCCId = localStorage.getItem("ttSelectedCCID");
    $scope.selectedClassId = localStorage.getItem("ttSelectedClsId");
		httpFactory.getResult("getAllCourseClassSubjects?schemaName="+$scope.schemaName+"&classId="+$scope.selectedClassId+"&courseId="+$scope.selectedCourse+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
        $scope.generalSubj = [];
				$scope.electiveSubj = [];
					$scope.subjList = data.Subjects;

					for (var i = 0; i < $scope.subjList.length; i++) {
						if ($scope.subjList[i].electiveGroupId == 0) {
							$scope.generalSubj = $scope.subjList[i].subjects;
						}else{
							$scope.electiveSubj.push($scope.subjList[i]);
						}
					}
					console.log($scope.generalSubj);
					console.log($scope.electiveSubj);
			}
		});
	}



	$scope.regeneratTimeTableData = function(){
		for(var i=0; i<$scope.workingDaysObj.length; i++){
			$scope.workingDaysObj[i].periods = [];
			$scope.workingDaysObj[i].periods = angular.copy($scope.periods);
		}
		console.log($scope.workingDaysObj);
	}


	$scope.openAssignTeacherPopup = function(wekId, wekday, prd){
		$scope.getCourseClassSubjects();
    console.log(prd);
    $scope.selectedDay = wekday;
    $scope.selectedDayID = wekId;
    $scope.selectedPrdId = prd.periodId;
    $scope.ttId = prd.timeTableId;
    $scope.prdStartTime = prd.periodStartTime;
    $scope.prdEndTime = prd.periodEndTime;

    if (prd.subjectId) {
      $scope.subId = prd.subjectId;
    }
    console.log($scope.selectedDay);
    console.log($scope.selectedDayID);
    console.log($scope.selectedPrdId);
    console.log($scope.ttId);
    console.log($scope.subId);
   		$("#assignTeacher").modal("show");
  	};

	$scope.openUpdateTeacherPopup = function(wekId, wekday, prd){
    $scope.selectedSubjId="";
    $scope.teacherList=[];
    $scope.selectedTeacher="";
		$scope.getCourseClassSubjects();
    console.log(prd);
  	$scope.selectedDay = wekday;
		$scope.selectedDayID = wekId;
		$scope.selectedPrdId = prd.periodId;
		$scope.ttId = prd.timeTableId;
    $scope.prdStartTime = prd.periodStartTime;
    $scope.prdEndTime = prd.periodEndTime;

    if (prd.subjectId) {
      $scope.subId = prd.subjectId;
    }
    console.log($scope.selectedDay);
    console.log($scope.selectedDayID);
    console.log($scope.selectedPrdId);
    console.log($scope.ttId);
    console.log($scope.subId);
  		$("#updateTeacher").modal("show");
  	};

	var ttRecordAdded = false;
  $scope.isassignBreakprd = false;

  $scope.checkIsBreakStatus = function(){
    if(document.getElementById(isassignBreakprd).checked == true){
      $scope.isassignBreakprd = true;
    }else{
      $scope.isassignBreakprd = false;
    }
  }

	$scope.saveChangesForPeriod = function(){
		var params={
			"schemaName" : $scope.schemaName,
			"branchId":$scope.branchId,
			"sectionId":localStorage.getItem("ttSectionId"),
      "createdBy":localStorage.getItem("userId")
		};

		for(var k=0; k<document.getElementsByName("subjects").length; k++){
      console.log(document.getElementsByName("subjects"));
			if(document.getElementsByName("subjects")[k].checked == true){
				$scope.selectedSubj = JSON.parse(document.getElementsByName("subjects")[k].value);
			}
		}
		var records = [];
    if(typeof $scope.selectedTeacherOb=='string')
		$scope.selectedTeacherOb = JSON.parse($scope.selectedTeacher);
    else
    $scope.selectedTeacherOb=$scope.selectedTeacher;
    console.log($scope.selectedDayID);

    console.log($scope.selectedPrdId);

		for(var i=0; i<$scope.workingDaysObj.length; i++){
      console.log($scope.workingDaysObj[i]);
			if($scope.selectedDayID == $scope.workingDaysObj[i].workingDayId){
				for(var j=0; j<$scope.workingDaysObj[i].periods.length; j++){
					if($scope.selectedPrdId == $scope.workingDaysObj[i].periods[j].periodId){
						// $scope.workingDaysObj[i].periods[j].teacherId = $scope.selectedTeacher.teacherId;
						// $scope.workingDaysObj[i].periods[j].teacherName = $scope.selectedTeacher.teacherName;
						$scope.workingDaysObj[i].periods[j].subjectId = $scope.selSubjOb.subjectId;
						$scope.workingDaysObj[i].periods[j].subjectName = $scope.selSubjOb.subjectName;
            $scope.workingDaysObj[i].periods[j].subjectTeacher = $scope.subjectTeacherArr;
						console.log($scope.workingDaysObj[i].periods[j]);
					}
				}
			}
		}
    console.log($scope.workingDaysObj);
		$scope.insertTimeTable();
	}

  $scope.uttChck = true;
	$scope.updateChangesForPeriod = function(){
		var params={
			"schemaName" : $scope.schemaName,
			"branchId":$scope.branchId,
			"sectionId":localStorage.getItem("ttSectionId"),
      "createdBy":localStorage.getItem("userId")
		};
		params.updatedBy = $scope.userId;
		params.updateTimeTable = [];
		var recd = {
			"periodId":$scope.selectedPrdId,
			"workingDayId":$scope.selectedDayID,
			"isElective" : $scope.isElective
		};
		for(var k=0; k<document.getElementsByName("subjects").length; k++){
			if(document.getElementsByName("subjects")[k].checked == true){
				$scope.selectedSubj = JSON.parse(document.getElementsByName("subjects")[k].value);
			}
		}
		var records = [];
		// $scope.selectedTeacher = JSON.parse($scope.selectedTeacher);
    console.log($scope.subjectTeacherArr);
		for(var i=0; i<$scope.allWorkingDays.length; i++){
			if($scope.selectedDayID == $scope.allWorkingDays[i].workingDayId){
				for(var j=0; j<$scope.allWorkingDays[i].periods.length; j++){
					if($scope.selectedPrdId == $scope.allWorkingDays[i].periods[j].periodId){
						// $scope.allWorkingDays[i].periods[j].teacherId = $scope.selectedTeacher.userId;
						// $scope.allWorkingDays[i].periods[j].teacherName = $scope.selectedTeacher.userName;
						// $scope.allWorkingDays[i].periods[j].subjectId = $scope.selectedSubj.subjectId;
						// $scope.allWorkingDays[i].periods[j].subjectName = $scope.selectedSubj.subjectName;
						recd.periodStartTime = $scope.allWorkingDays[i].periods[j].periodStartTime;
						recd.periodEndTime = $scope.allWorkingDays[i].periods[j].periodEndTime;
						recd.subjectId = $scope.selSubjOb.subjectId;
						recd.isBreak = $scope.allWorkingDays[i].periods[j].isBreak;
            console.log($scope.allWorkingDays[i].periods[j].isBreak);
            recd.electiveGroupId=$scope.electiveGroupId;
						recd.breakDesc = "";
            recd.subjectTeacher = $scope.subjectTeacherArr;
						recd.sectiontimeTableId = $scope.allWorkingDays[i].periods[j].timeTableId;
					}
				}
			}
		}
		params.updateTimeTable.push(recd);
    console.log(params);
    $scope.uttChck = false;
		httpFactory.executePost("updateTimeTable", params, function(data) {
			console.log(data);
      $scope.uttChck = true;
			if (data.StatusCode == 200) {
				alert("successfully updated");
        $scope.selSubjOb={};
        $scope.selectedTeacher="";
        $scope.selectedSubjId="";
				ttRecordAdded = true;
				$("#updateTeacher").modal("hide");
        $scope.chckADDorEdit();
        $scope.teacherList=[];
        $scope.selectedTeacher="";
			} else {
				//TODO : Show Error
				$scope.errorMsg = data.message;
			}
		});
	}

    $scope.selectedSubjectMethod=function(selectedSubj,elecGrpId){
      console.log(selectedSubj);
      $scope.selectedTeacher=null;
      if(elecGrpId>0){
        if ($scope.isElective==0) {
          $scope.subjectTeacherArr=[];
        }
        $scope.isElective=1;
        $scope.electiveGroupId=elecGrpId;
        console.log($scope.subjectTeacherArr);
      }else{
        $scope.isElective=0;
        $scope.subjectTeacherArr=[];
        $scope.electiveGroupId=0;
        console.log($scope.subjectTeacherArr);
      }
      console.log($scope.isElective);
      console.log($scope.electiveGroupId);
      console.log(selectedSubj);
      if(typeof selectedSubj == 'string')
      $scope.selSubjOb = JSON.parse(selectedSubj);
      else
      $scope.selSubjOb=selectedSubj;
      $scope.selectedSubjId = selectedSubj.subjectId;
      console.log($scope.selSubjOb);
      console.log($scope.selectedSubjId);
      $scope.getTeacherBySubjectGroup();
    }
    $scope.getTeacherBySubjectGroup = function(){
      httpFactory.getResult("getUsersForSubject?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&subGroup="+$scope.selSubjOb.subjectGroup, function(data) {
        console.log(data);
        if (data.StatusCode == 200) {
          $scope.teacherList = data.teacherDetails;
        }else{
          $scope.teacherList = [];
          console.log("no records");
        }
      });
    }
    $scope.subjectTeacherArr = [];
    $scope.selectedTeacherMethod=function(teacherOb){
        if (typeof teacherOb == 'string') {
          $scope.selectedTeacherOb=JSON.parse(teacherOb);
        }else{
          $scope.selectedTeacherOb=teacherOb;
        }
        if ($scope.selectedTeacherOb) {
          checkTeacherAvailabilty();
        }
         if ($scope.isTeacherAvailable==1) {
      if($scope.selectedTeacherOb){
        console.log($scope.selectedTeacherOb);
        var obj ={
          "teacherId":$scope.selectedTeacherOb.userId,
          "subjectId":$scope.selectedSubjId,
          "electiveGroupId":$scope.electiveGroupId
        }
        if ($scope.isElective>0) {
          $scope.subjectTeacherArr.push(obj);
        }else {
          $scope.subjectTeacherArr=[];
          $scope.subjectTeacherArr.push(obj);
        }
        console.log($scope.subjectTeacherArr);
    }
  }else{

  }
}

  function checkTeacherAvailabilty (){
    console.log("inside");
    httpFactory.getResult("checkTeacherAvailabilty?schemaName="+$scope.schemaName+"&startTime="+$scope.prdStartTime+"&endTime="+$scope.prdEndTime+"&teacherId="+$scope.selectedTeacherOb.userId+"&workingDayId="+$scope.selectedDayID, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.isTeacherAvailable = data.isAvailable;
        if ($scope.isTeacherAvailable==1) {

        }else{
          var str = 'Teacher already assigned for Section '+data.sectionName+ ' from '+data.periodStartTime+ ' To ' + data.periodEndTime;
          alert(str);
          $scope.selectedTeacher=[];
        }
      }else if(data.StatusCode == 300){

        $scope.isTeacherAvailable = data.isAvailable;
      }else{
        // $scope.teacherList = [];
        console.log("no records");
      }
    });
  }


  $scope.deleteTimetablePopUp = function(){
    var r = confirm("Do you really want to delete?!");
    if (r == true) {
       $scope.deleteTimetable();
    } else {
      return;
    }
}
$scope.deleteTimetable = function(){
    	var params ={
    			"schemaName":$scope.schemaName,
    			"sectionId": localStorage.getItem("ttSectionId")	
    	}
    	httpFactory.executePost("deleteTimeTable", params , function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("successfully Deleted");
				$scope.timeTableForSection(localStorage.getItem("ttSectionId"))
			} else {
				alert(data.message);
				
			}
		});
    }

$scope.goToDashbord = function(){
	$location.path("rankrPlus");
}


});
