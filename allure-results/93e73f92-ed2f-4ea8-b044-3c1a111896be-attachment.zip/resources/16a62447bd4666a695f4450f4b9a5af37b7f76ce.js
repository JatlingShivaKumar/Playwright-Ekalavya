projectModule.controller('hallTicketAllocationController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");

	$scope.goToFeeStructure = function () {
		$location.path("feeStructure");
	}

	$scope.getCoursesByBranch = function () {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedCourseOb = "";
		$scope.selectedClassObj = "";
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function () {
		console.log($scope.selectedCourseOb);
		if ($scope.selectedCourseOb == null || $scope.selectedCourseOb == "") {
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.selectedCourseObj.courseId;
		$scope.selectedCourseName = $scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();

	$scope.goToDashbord = function () {
		$location.path("hallticket");
	}

	$scope.getSectionByClassId = function (selectedClassObj) {
		$scope.hallTicketList = [];
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("Got Error");
			}
		});
	}

	$scope.hallTicketList = [];
	$scope.getHallTicketNameBySectionId = function (selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
		httpFactory.getResult("getHallTicketName?schemaName=" + $scope.schemaName + "&courseId=" + $scope.selectedCourse + "&branchId= " + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.hallTicketList = data.hallTicketList;
			} else {

			}
		});
	}

	$scope.updateHallTicketAllocation = function () {
		$scope.hallTicketStudentsArray = [];
		if (document.getElementById("isAllChecked").checked == true) {
			for (i = 0; i < $scope.studentHallTicketAllocatedDetails.length; i++) {
				for (j = 0; j < $scope.tempStudentHallTicketAllocatedDetails.length; j++) {
					if ($scope.studentHallTicketAllocatedDetails[i].selected == true) {
						$scope.studentHallTicketAllocatedDetails[i].isAllocated = 1;
					} else {
						$scope.studentHallTicketAllocatedDetails[i].isAllocated = 0;
					}
					if ($scope.tempStudentHallTicketAllocatedDetails[j].studentId == $scope.studentHallTicketAllocatedDetails[i].studentId) {
						if ($scope.studentHallTicketAllocatedDetails[i].rollNumber == "" || $scope.studentHallTicketAllocatedDetails[i].rollNumber == null) {
							$scope.studentHallTicketAllocatedDetails[i].rollNumber = $scope.tempStudentHallTicketAllocatedDetails[i].rollNumber;
							alert("Roll number can't be empty");
							return;
						} else if ($scope.studentHallTicketAllocatedDetails[i].studentName == "" || $scope.studentHallTicketAllocatedDetails[i].studentName == null) {
							$scope.studentHallTicketAllocatedDetails[i].studentName = $scope.tempStudentHallTicketAllocatedDetails[i].studentName;
							alert("Student name can't be empty");
							return;
						} else if ($scope.studentHallTicketAllocatedDetails[i].admissionNumber == "" || $scope.studentHallTicketAllocatedDetails[i].admissionNumber == null) {
							$scope.studentHallTicketAllocatedDetails[i].admissionNumber = $scope.tempStudentHallTicketAllocatedDetails[i].admissionNumber;
							alert("Admission number can't be empty");
							return;
						} else if (($scope.studentHallTicketAllocatedDetails[i].hallticketNumber === "" || $scope.studentHallTicketAllocatedDetails[i].hallticketNumber == null) && $scope.tempStudentHallTicketAllocatedDetails[i].hallticketNumber !== "") {
							$scope.studentHallTicketAllocatedDetails[i].hallticketNumber = $scope.tempStudentHallTicketAllocatedDetails[i].hallticketNumber;
							alert("Hallticket number can't be removed once updated");
							return;
						} else if (($scope.studentHallTicketAllocatedDetails[i].parentName === "" || $scope.studentHallTicketAllocatedDetails[i].parentName == null) && $scope.studentHallTicketAllocatedDetails[j].isAllocated == 1) {
							if ($scope.tempStudentHallTicketAllocatedDetails[i].parentName !== "" && $scope.tempStudentHallTicketAllocatedDetails[i].parentName != undefined) {
								$scope.studentHallTicketAllocatedDetails[i].parentName = $scope.tempStudentHallTicketAllocatedDetails[i].parentName;
								alert("Father name can't be removed if it's allocated");
								return;
							}
							alert("Enter Father Name");
							return;
						} else if (($scope.tempStudentHallTicketAllocatedDetails[j].isAllocated != $scope.studentHallTicketAllocatedDetails[i].isAllocated) || $scope.tempStudentHallTicketAllocatedDetails[j].parentName !== $scope.studentHallTicketAllocatedDetails[i].parentName || $scope.tempStudentHallTicketAllocatedDetails[j].hallticketNumber !== $scope.studentHallTicketAllocatedDetails[i].hallticketNumber || $scope.tempStudentHallTicketAllocatedDetails[j].studentName !== $scope.studentHallTicketAllocatedDetails[i].studentName || $scope.tempStudentHallTicketAllocatedDetails[j].admissionNumber !== $scope.studentHallTicketAllocatedDetails[i].admissionNumber || $scope.tempStudentHallTicketAllocatedDetails[j].rollNumber !== $scope.studentHallTicketAllocatedDetails[i].rollNumber) {
							$scope.hallTicketStudentsArray.push(angular.copy($scope.studentHallTicketAllocatedDetails[i]));
							break;
						}
					}
				}
			}
		} else {
			for (i = 0; i < $scope.studentHallTicketAllocatedDetails.length; i++) {
				for (j = 0; j < $scope.tempStudentHallTicketAllocatedDetails.length; j++) {
					if ($scope.studentHallTicketAllocatedDetails[i].selected == true) {
						$scope.studentHallTicketAllocatedDetails[i].isAllocated = 1;
					} else {
						$scope.studentHallTicketAllocatedDetails[i].isAllocated = 0;
					}
					if ($scope.tempStudentHallTicketAllocatedDetails[j].studentId == $scope.studentHallTicketAllocatedDetails[i].studentId) {
						if ($scope.studentHallTicketAllocatedDetails[i].rollNumber === "" || $scope.studentHallTicketAllocatedDetails[i].rollNumber == null) {
							$scope.studentHallTicketAllocatedDetails[i].rollNumber = $scope.tempStudentHallTicketAllocatedDetails[i].rollNumber;
							alert("Roll number can't be empty");
							return;
						} else if ($scope.studentHallTicketAllocatedDetails[i].studentName === "" || $scope.studentHallTicketAllocatedDetails[i].studentName == null) {
							$scope.studentHallTicketAllocatedDetails[i].studentName = $scope.tempStudentHallTicketAllocatedDetails[i].studentName;
							alert("Student name can't be empty");
							return;
						} else if ($scope.studentHallTicketAllocatedDetails[i].admissionNumber === "" || $scope.studentHallTicketAllocatedDetails[i].admissionNumber == null) {
							$scope.studentHallTicketAllocatedDetails[i].admissionNumber = $scope.tempStudentHallTicketAllocatedDetails[i].admissionNumber;
							alert("Admission number can't be empty");
							return;
						} else if (($scope.studentHallTicketAllocatedDetails[i].hallticketNumber === "" || $scope.studentHallTicketAllocatedDetails[i].hallticketNumber == null) && $scope.tempStudentHallTicketAllocatedDetails[i].hallticketNumber !== "") {
							$scope.studentHallTicketAllocatedDetails[i].hallticketNumber = $scope.tempStudentHallTicketAllocatedDetails[i].hallticketNumber;
							alert("Hallticket number can't be removed once updated");
							return;
						} else if (($scope.studentHallTicketAllocatedDetails[i].parentName === "" || $scope.studentHallTicketAllocatedDetails[i].parentName == null) && $scope.studentHallTicketAllocatedDetails[j].isAllocated == 1) {
							if ($scope.tempStudentHallTicketAllocatedDetails[i].parentName !== "" && $scope.tempStudentHallTicketAllocatedDetails[i].parentName != undefined) {
								$scope.studentHallTicketAllocatedDetails[i].parentName = $scope.tempStudentHallTicketAllocatedDetails[i].parentName;
								alert("Father name can't be removed if it's allocated");
								return;
							}
							alert("Enter Father Name");
							return;
						} else if (($scope.tempStudentHallTicketAllocatedDetails[j].isAllocated != $scope.studentHallTicketAllocatedDetails[i].isAllocated) || $scope.tempStudentHallTicketAllocatedDetails[j].parentName !== $scope.studentHallTicketAllocatedDetails[i].parentName || $scope.tempStudentHallTicketAllocatedDetails[j].hallticketNumber !== $scope.studentHallTicketAllocatedDetails[i].hallticketNumber || $scope.tempStudentHallTicketAllocatedDetails[j].studentName !== $scope.studentHallTicketAllocatedDetails[i].studentName || $scope.tempStudentHallTicketAllocatedDetails[j].admissionNumber !== $scope.studentHallTicketAllocatedDetails[i].admissionNumber || $scope.tempStudentHallTicketAllocatedDetails[j].rollNumber !== $scope.studentHallTicketAllocatedDetails[i].rollNumber) {
							$scope.hallTicketStudentsArray.push(angular.copy($scope.studentHallTicketAllocatedDetails[i]));
							break;
						}
					}
				}
			}
		}
		if ($scope.hallTicketStudentsArray.length == 0) {
			alert("No new update found");
			return;
		}
		var params = {
			"hallTicketId": $scope.hallTicketId,
			"schemaName": $scope.schemaName,
			"studentArray": $scope.hallTicketStudentsArray,
			"userId": $scope.user_id,
			"branchId": $scope.selectedBranch
		}
		httpFactory.executePost("updateHallTicketAllocation", params, function (data) {
			console.log(data);
			if (data.StatusCode == "200") {
				alert(data.MESSAGE);
				$scope.updateHT = true;
				$scope.getStudentsForHallTicket();
				$scope.hallTicketStudentsArray = [];
			}
			else if (data.StatusCode == "302") {
				alert(data.MESSAGE);
			} else {
				alert(data.MESSAGE);
			}
		});
	}


	$scope.getStudentsForHallTicket = function () {
		if (typeof $scope.hallTicketObj === "string") {
			$scope.hallTicketObj2 = JSON.parse($scope.hallTicketObj);
		} else {
			$scope.hallTicketObj2 = $scope.hallTicketObj;
		}
		$scope.hallTicketId = $scope.hallTicketObj2.hallTicketId;
		$scope.feeStructureDetailsArray = [];
		$scope.studentHallTicketAllocatedDetails = [];
		$scope.tempStudentHallTicketAllocatedDetails = [];
		httpFactory.getResult("getStudentsForHallTicketAllocation?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId + "&branchId=" + $scope.selectedBranch + "&classCourseId=" + $scope.classObj.classCourseId + "&hallTicketId=" + $scope.hallTicketId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.updateHT = false;
				$scope.studentHallTicketAllocatedDetails = data.hallTicketStudentsList;
				$scope.tempStudentHallTicketAllocatedDetails = (angular.copy($scope.studentHallTicketAllocatedDetails));
				$scope.showStudents = true;
				var countIsSelected = 0;
				for (j = 0; j < $scope.studentHallTicketAllocatedDetails.length; j++) {
					if ($scope.studentHallTicketAllocatedDetails[j].isAllocated == 1 && $scope.studentHallTicketAllocatedDetails[j].hallTicketId == $scope.hallTicketId) {
						$scope.studentHallTicketAllocatedDetails[j].selected = true;
						countIsSelected++;
					}
					else if ($scope.studentHallTicketAllocatedDetails[j].isAllocated == 0 && $scope.studentHallTicketAllocatedDetails[j].hallTicketId == $scope.hallTicketId) {
						$scope.studentHallTicketAllocatedDetails[j].selected = false;
					}
				}
				if (countIsSelected == $scope.studentHallTicketAllocatedDetails.length) {
					$scope.isAllChecked = true;
				} else {
					$scope.isAllChecked = false;
				}
			} else if (data.StatusCode == 300) {
				$scope.sectionStudents = [];
			} else {
				alert("Error while retrieving the data");
			}
		});
	}

	$scope.selectAll = function (index) {
		if (document.getElementsByTagName("tr")[0].getElementsByTagName("th")[index].getElementsByTagName("input").selectAll.checked == true) {
			for (j = 1; j < document.getElementsByTagName("tr").length; j++) {
				document.getElementsByTagName("tr")[j].getElementsByTagName("td")[index].getElementsByTagName("input").feeCategoryName.checked = true;
			}
		} else if (document.getElementsByTagName("tr")[0].getElementsByTagName("th")[index].getElementsByTagName("input").selectAll.checked == false) {
			for (j = 1; j < document.getElementsByTagName("tr").length; j++) {
				document.getElementsByTagName("tr")[j].getElementsByTagName("td")[index].getElementsByTagName("input").feeCategoryName.checked = false;
			}
		}
	}

	$scope.selectedStudentsArray = [];
	$scope.selectStudents = function (studentDetail, studentIndex) {
		if (studentDetail == "" || studentDetail == undefined) {
			if (document.getElementById("isAllChecked").checked == true) {
				for (i = 0; i < $scope.studentHallTicketAllocatedDetails.length; i++) {
					if ($scope.studentHallTicketAllocatedDetails[i].selected == false || $scope.studentHallTicketAllocatedDetails[i].selected == undefined)
						$scope.studentHallTicketAllocatedDetails[i].selected = true;
				}
				$scope.selectedStudentsCount = $scope.studentHallTicketAllocatedDetails.length;
			} else if (document.getElementById("isAllChecked").checked == false) {
				for (i = 0; i < $scope.studentHallTicketAllocatedDetails.length; i++) {
					if ($scope.studentHallTicketAllocatedDetails[i].selected == true || $scope.studentHallTicketAllocatedDetails[i].selected == undefined)
						$scope.studentHallTicketAllocatedDetails[i].selected = false;
				}
				$scope.selectedStudentsCount = 0;
			}
		} else {
			if ($scope.studentHallTicketAllocatedDetails[studentIndex].selected == true) {
				$scope.studentHallTicketAllocatedDetails[studentIndex].selected = false;
				$scope.selectedStudentsCount--;
				document.getElementById("isAllChecked").checked = false;
			} else {
				$scope.studentHallTicketAllocatedDetails[studentIndex].selected = true;
				$scope.selectedStudentsCount++;
			}
		}
		var countIsSelected = 0;
		for (i = 0; i < $scope.studentHallTicketAllocatedDetails.length; i++) {
			if ($scope.studentHallTicketAllocatedDetails[i].selected == true)
				countIsSelected++;
		}
		if (countIsSelected == $scope.studentHallTicketAllocatedDetails.length)
			$scope.isAllChecked = true;
		else
			$scope.isAllChecked = false;
	}

	$scope.mySearchFunction = function () {
		// Declare variables
		var input, filter, table, tr, td, i, txtValue;
		input = document.getElementById("searchHallTicketDetails");
		filter = input.value.toUpperCase();
		table = document.getElementById("searchstudentdetails");
		tr = table.getElementsByTagName("tr");

		for (i = 1; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[2].getElementsByTagName("input")[0];
			var match = false;
			if (td.value.toUpperCase().startsWith(filter)) {
				match = true;
			}
			tr[i].style.display = match ? "" : "none";
		}
	}
	$scope.getBranchDetailsForHalltickets = function () {
		httpFactory.getResult("getBranchDetailsForHalltickets?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.branchHallticketData = data.hallticketData;
				$scope.branchName = $scope.branchHallticketData.branchName;
				$scope.branchAddress = $scope.branchHallticketData.branchAddress;
				$scope.academicYear = $scope.branchHallticketData.academicYear;
				if ($scope.branchHallticketData.principleSignature !== '') {
					$scope.principleSignature = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.branchHallticketData.principleSignature;
				} else {
					$scope.principleSignature = '';
				}
			} else {
				$scope.branchHallticketData = undefined;
				$scope.principleSignature = '';
			}
		});
	}

	$scope.saveBranchDetailsForHallTicket = function () {
		var fd = new FormData();
		if (document.getElementById("branchName").value != undefined) {
			fd.append("branchName", document.getElementById("branchName").value);
		}
		else {
			alert("Enter Branch Name")
			return true
		}
		if (document.getElementById("branchAddress").value != undefined) {
			fd.append("branchAddress", document.getElementById("branchAddress").value);
		}
		else {
			alert("Enter Branch Address")
			return true
		}
		if (document.getElementById("academicYear").value != undefined) {
			fd.append("academicYear", document.getElementById("academicYear").value);
		}
		else {
			alert("Enter acedamicYear")
			return true
		}
		if (document.getElementById("principleSignature").files.length != 0 || $scope.principleSignature !== '') {
			var logo = document.getElementById("principleSignature").files;
			fd.append("principleSignature", logo[0]);
		}
		else if (document.getElementById("principleSignature").files.length == 0 || $scope.principleSignature === '') {
			alert("Upload Principle Signature");
			return true
		}
		if (document.getElementById("phoneNumber").value != undefined) {
			fd.append("phoneNumber", document.getElementById("phoneNumber").value);
		}
		else {
			alert("Enter Phone Number")
			return true
		}
		if (document.getElementById("emailId").value != undefined) {
			fd.append("emailId", document.getElementById("emailId").value);
		}
		else {
			alert("Enter email id")
			return true
		}
		fd.append("branchId", $scope.selectedBranch);
		fd.append("createdBy", $scope.user_id);
		fd.append("schemaName", $scope.schemaName);
		httpFactory.executeFileUpload("saveBranchDetailsForHallTicket", fd, function (data) {
			console.log(data);
			if (data.StatusCode == '200') {
				alert("Details Updated Successfully");
				$("#addBranchDetails").modal("hide");
			} else {
				alert("Error while updating");
			}
		});
	}

	$scope.addBranchDetailsForHallTicket = function () {
		if ($scope.branchHallticketData == undefined) {
			$("#addBranchDetails").modal("show");

		} else {
			if ($scope.branchHallticketData != undefined) {
				$("#addBranchDetails").modal("show");
			}
		}
		$scope.getBranchDetailsForHalltickets();
	}

	$scope.previewkHallticket = function (type, studentId) {
		$scope.allStudentsHallTicketDetailsList = [];
		if (type == "bulk") {
			$scope.studentsToPrint = $scope.studentHallTicketAllocatedDetails.filter(function (student) {
				return student.isAllocated == 1 && student.hallTicketId == $scope.hallTicketId;
			});
			if ($scope.studentsToPrint.length == 0) {
				alert("No students are allocated to hallticket");
				return;
			}
			else {
				for (let i = 0; i < $scope.studentsToPrint.length; i++) {
					let student = $scope.studentsToPrint[i];
					$scope.allStudentsHallTicketDetailsList.push($scope.getHallTicketDetails(student.studentId));
				}
				$("#printReceiptPreviewModal").modal("show");
			}
		}
		else {
			$scope.allStudentsHallTicketDetailsList.push($scope.getHallTicketDetails(studentId));
			$("#printReceiptPreviewModal").modal("show");
		}

	}

	$scope.getHallTicketDetails = function (studentId) {
		$scope.studentId = studentId;
		httpFactory.getResult("getHallTickeDetails?schemaName=" + $scope.schemaName + "&studentId=" + $scope.studentId + "&hallticketId=" + $scope.hallTicketId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				var subDetails = {
					"subjectName": "Subjects",
					"startTime": "Timing",
					"endTime": "",
					"subjectDate": "Date"
				}
				$scope.hallTicketDetails = angular.copy(data.hallTicketDetails);
				$scope.hallTicketDetails.hallTicketSubsId = [];
				$scope.hallTicketDetails.hallTicketSubsId.push(subDetails);
				for (i = 0; i < data.hallTicketDetails.hallTicketSubsId.length; i++) {
					$scope.hallTicketDetails.hallTicketSubsId.push(data.hallTicketDetails.hallTicketSubsId[i]);
				}
				$scope.widthPercentage = 0;
				$scope.widthPercentage = (100 / ($scope.hallTicketDetails.hallTicketSubsId.length + 1)) - 1;
				$scope.widthPercentageforTiming = (100 / ($scope.hallTicketDetails.hallTicketSubsId.length + 1)) + 5;
				$scope.hallTicketDetails["widthPercentage"] = $scope.widthPercentage;
				$scope.hallTicketDetails["widthPercentageforTiming"] = $scope.widthPercentageforTiming;
				if ($scope.hallTicketDetails.principleSignature == "") {
					document.getElementById("principleSignature").style.visibility = "hidden";
				} else {
					$scope.hallTicketDetails.principleSignature = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.hallTicketDetails.principleSignature + "&embedded=true";
				}
			} else {
				alert("Please Add Branch Details")
				$scope.addBranchDetailsForHallTicket();
			}
		});
		return $scope.hallTicketDetails;
	}

	$scope.makeBulkHallTicketPDF = function () {
		var mywindow = window.open('', '', '', '');
		mywindow.document.write('<!doctype html> <html border:1px solid;height: 171%;"><head><title></title>');
		mywindow.document.write('</head><body>');
	
		var modalDialogs = document.querySelectorAll('#bulkHallTicketReceipt .modal-dialog');
		var dialogsPerPage = 2;
	
		for (var i = 0; i < modalDialogs.length; i += dialogsPerPage) {
			mywindow.document.write('<div style="page-break-before: always;">'); // Add this line to start a new page
	
			mywindow.document.write('<div class="modal-dialog">');
			for (var j = 0; j < dialogsPerPage && (i + j) < modalDialogs.length; j++) {
				var modalDialog = modalDialogs[i + j];
	
				// Split each hallticket into top and bottom halves
				var content = modalDialog.innerHTML;
				var contentArray = content.split('</div>');
				var halfIndex = Math.ceil(contentArray.length / 2);
				var topHalf = contentArray.slice(0, halfIndex).join('</div>');
				var bottomHalf = contentArray.slice(halfIndex).join('</div>');
	
				mywindow.document.write('<div style="height: 50%;">');
				mywindow.document.write(topHalf);
				mywindow.document.write('</div>');
	
				mywindow.document.write('<div style="height: 50%;">');
				mywindow.document.write(bottomHalf);
				mywindow.document.write('</div>');
	
				// Insert some space between halltickets, except for the last one
				if (j < dialogsPerPage - 1 && (i + j + 1) < modalDialogs.length) {
					mywindow.document.write('<div style="margin-bottom: 20px;"></div>');
				}
			}
			mywindow.document.write('</div>');
		}
	
		mywindow.document.write('</body></html>');
	
		var is_chrome = Boolean(mywindow.chrome);
		mywindow.document.close();
	
		if (is_chrome) {
			mywindow.onload = function () {
				mywindow.focus();
				mywindow.print();
			};
		} else {
			mywindow.document.close();
			mywindow.focus();
			mywindow.print();
		}
	
		$("#printReceiptPreviewModal").modal("hide");
	}
	
	
		
	
});
