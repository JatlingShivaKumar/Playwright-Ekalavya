projectModule.controller('examGenerationController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
 $scope.$ = $;
 $scope.instituteId = 1;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };

 $scope.schemaName = localStorage.getItem("sname");
 $scope.setTotalQuestions = setTotalQuestions;
 // $scope.getSubjectChapters = getSubjectChapters;
 $scope.showClassSelection = true;
 $scope.showSubjectSelection = false;
 $scope.showQuestionSlection = false;
 $scope.configCompleteCustom = false;
 $scope.showCustomPreview = false;
 //show hide tabs
 $scope.configComplete = false;
 $scope.showFirst = false;
 $scope.showCategory = true;
 $scope.showPreview = false;
 $scope.showQuestions=false;
 $scope.showAssignment = false;
 $scope.showManual = false;
 $scope.showEdit = false;
 $scope.testId = "";
 $scope.questionMap = "";
 $scope.testMode = "";

 // show hide for edit questionStart
 $scope.showTestChapters = false;
 $scope.showTestTopics = false;
 $scope.showTestEditor = false;

 $scope.totalQuestions = 0;
 $scope.rightMarks = 0;
 $scope.wrongMarks = 0;
 $scope.totalMarks = 0;
 $scope.generate = false;
 $scope.progress = 0;

 $scope.practiceClass = 0;
 $scope.practiceSubject = 0;
 $scope.practiceChapter = 0;
 $scope.practiceTopic = 0;

 $scope.selectedSubject = [];
 $scope.selectedSection = [];
 $scope.selectedGroup = [];
 $scope.yearWiseArray = [];

 $scope.question = "";
 $scope.option1 = "";
 $scope.option2 = "";
 $scope.option3 = "";
 $scope.option4 = "";
 $scope.explanation = "";

 $scope.categoryView = false;
 $scope.testView = false;

 $scope.selectedTestSubject = "";

 $scope.addedQuestions = [];

 $scope.redirectToCustomGenerateTestView = function() {
   //$location.path("/examCategory/" + $scope.testName + "/" + $scope.selectedBranch + "/" + $scope.selectedCourse);
   $location.path("/customGenerateTestView/"+ $scope.testName + "/" + $scope.selectedBranch + "/" + $scope.selectedCourse);
 }

 $scope.examCategoryInit = function(){
   $scope.getSchemas();
   $scope.getTestCategories();
   $scope.getCourses();
   $scope.getSubjectsByCourse();
 }
 $scope.getTestCategories = function() {
   $scope.courseId=1;
   httpFactory.getResult("getTestCategories?courseId=" + $scope.courseId + "&instId=" + localStorage.getItem("inst_id") + "&schemaName="+localStorage.getItem("sname"), function(data) {
     console.log(data);
     if (data.STATUS == 'SUCCESS') {
       $scope.categoryList = data.TestCategories;
     }
      else {
     }
   });
 }

 $scope.getSubjectsByCourse = function() {

   $scope.classId=1;
   $scope.course=1;

   httpFactory.getResult("getCourseClassSubjects?schemaName=" + localStorage.getItem("sname") + "&classId=" + $scope.classId + "&courseId="+ $scope.courseId+ "&branchId=" + $scope.selectedBranch , function(data) {
     console.log(data);
     if (data.STATUS == 200) {
       $scope.subjectList = data;
       console.log($scope.subjectList);
       var tmp = []
       for (i = 0; i < data.length; i++) {
         tmp[i] = data[i];
       }
       $scope.yearWiseArray = groupBy(tmp, function(item) {
         return [item.class_id];
       });
       console.log($scope.yearWiseArray);
     } else {}
   });
 }
 $scope.selectingSchema = function(){
   $scope.selectedSchema = $("#selectedSchema").val();
 }

 $scope.checkSubjects = function(subject) {
   var found = false;
   if ($scope.selectedSubject.length == 0) {
     $scope.selectedSubject[$scope.selectedSubject.length] = subject;
   } else {
     for (i = 0; i < $scope.selectedSubject.length; i++) {
       if ($scope.selectedSubject[i].subject_id == subject.subject_id) {
         $scope.selectedSubject.splice(i, 1);
         found = true;
       }
     }
     if (!found) {
       $scope.selectedSubject[$scope.selectedSubject.length] = subject;
     }
   }
 }

 $scope.checkSections = function(section) {
   var found = false;
   if ($scope.selectedSection.length == 0) {
     $scope.selectedSection[$scope.selectedSection.length] = section;
     console.log($scope.selectedSection);
   } else {
     console.log($scope.selectedSection);
     for (i = 0; i < $scope.selectedSection.length; i++) {
       if ($scope.selectedSection[i].classCourseSectionId == section.classCourseSectionId) {
         $scope.selectedSection.splice(i, 1);
         found = true;
       }
     }
     if (!found) {
       $scope.selectedSection[$scope.selectedSection.length] = section;
     }
   }
 }

 $scope.checkGroups = function(group) {
   console.log(group);
   var found = false;
   if ($scope.selectedGroup.length == 0) {
     $scope.selectedGroup[$scope.selectedGroup.length] = group;
   } else {
     for (i = 0; i < $scope.selectedGroup.length; i++) {
       if ($scope.selectedGroup[i].groupId == group.groupId) {
         $scope.selectedGroup.splice(i, 1);
         found = true;
       }
     }
     if (!found) {
       $scope.selectedGroup[$scope.selectedGroup.length] = group;
     }
   }
 }

 $scope.showQuestionOptions = function() {
   $scope.totalQuestions = $("#tQ").val();
   $scope.selectedCategory = $("#selCat").val();
   $scope.selectedCategoryName = $("#selCat option:selected").text();
   $scope.correctAnswer = $("#rM").val();
   $scope.wrongAnswer = $("#wM").val();
   $scope.duration = $("#duration").val();

   var valid = true;

   if ($("#tQ").val() == 0) {
     alert('Please Enter Total Questions')
     $("#tQ").focus();
     valid = false;
   }
   if (valid && $("#rM").val() == 0) {
     alert('Please Enter Marks for Correct Answers')
     $("#rM").focus();
     valid = false;
   }
   if (valid && $scope.selectedSubject.length == 0) {
     alert('Please select at least one subject');
     valid = false;
   }
   if (valid) {
     $scope.showFirst = true;
     $scope.showCategory = false;
     $scope.showPreview = false;
     $scope.showAssignment = false;
     $scope.showManual = false;
     $scope.showEdit = false;
     $scope.saveTest();
   }
 }

 function setTotalQuestions() {
   // alert('h9');
   $scope.correctAnswer = "";
   $scope.totalMarks = 0;
   $("#rM").val(0);
   $("#tM").val(0);
   console.log($scope.categoryListById);
   for (i = 0; i < $scope.categoryListById.length; i++) {
     if ($scope.categoryListById[i].catId == $("#selCat").val()) {
       $scope.totalQuestions = $scope.categoryListById[i].totalQuestions;
       $("#tQ").val($scope.totalQuestions);
     }
   }
 }

 $scope.getBranchCourseClassForTestAssignement = function(){

   httpFactory.getResult("getAllBranchClassCourseSections?schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id") , function(data) {
     console.log(data);
     if (data.STATUS == 'SUCCESS') {
       $scope.sectionList = data;
       console.log($scope.sectionList);
     } else {
     }
   });
 }

 $scope.editQuestionPaper = function() {
   $scope.showFirst = false;
   $scope.showCategory = false;
   $scope.showPreview = false;
   $scope.showAssignment = false;
   $scope.showManual = false;
   $scope.showEdit = true;
   $scope.getSchemas();
   $scope.testMode = "OWN";
 }

 $scope.saveQuestion = function() {

   $scope.question = CKEDITOR.instances['question'].getData();
   $scope.option1 = CKEDITOR.instances['option1'].getData();
   $scope.option2 = CKEDITOR.instances['option2'].getData();
   $scope.option3 = CKEDITOR.instances['option3'].getData();
   $scope.option4 = CKEDITOR.instances['option4'].getData();
   $scope.explanation = CKEDITOR.instances['explanation'].getData();
   $scope.correctAnswer = $("#correctAnswer").val();
   $scope.questionCat = $("#questionCat").val();
   $scope.diffLevel = $("#diffLevel").val();
   var questionArr = {};


   console.log($scope.question);
   console.log($scope.option1);
   console.log($scope.option2);
   console.log($scope.option3);
   console.log($scope.option4);
   console.log($scope.correctAnswer);


   if ($scope.selectedTestChapterId == "" || $scope.selectedTestTopicId == "" || $scope.question == "" || $scope.option1 == "" || $scope.option2 == "" || $scope.option3 == "" || $scope.option4 == "" || $scope.correctAnswer == "") {
     alert("Please Select All Fields");
     return true;
   }
   questionArr.question = $scope.question;
   questionArr.option1 = $scope.option1;
   questionArr.option2 = $scope.option2;
   questionArr.option3 = $scope.option3;
   questionArr.option4 = $scope.option4;
   questionArr.explanation = $scope.explanation;
   questionArr.correct_answer = $scope.correctAnswer;
   questionArr.question_type = $scope.questionCat;
   questionArr.diff_level = $scope.diffLevel;
   questionArr.topic_id = $scope.selectedTestTopicId;
   questionArr.chapter_id = $scope.selectedTestChapterId;
   questionArr.difficulty_level = $scope.diffLevel;
   questionArr.inst_question = "Y";
   questionArr.created_by = $scope.user_id;
   questionArr.subject_name = $scope.selectedTestSubjectName;
   questionArr.subject_group = $scope.selectedTestSubjectGroup;
   questionArr.chapter_name = $scope.selectedTestChapterName;
   questionArr.topic_name = $scope.selectedTestTopicName;
   console.log(questionArr);
   $scope.addedQuestions[$scope.addedQuestions.length] = questionArr;
   console.log($scope.addedQuestions);
   questionArr = {};
   console.log($scope.addedQuestions);

   var testParams = {
     "insertRecords": [{
       "question": $scope.question,
       "option1": $scope.option1,
       "option2": $scope.option2,
       "option3": $scope.option3,
       "option4": $scope.option4,
       "explanation": $scope.explanation,
       "correct_answer": $scope.correctAnswer,
       "question_type": $scope.questionCat,
       "diff_level": $scope.diffLevel,
       "topic_id": $scope.selectedTestTopicId,
       "chapter_id": $scope.selectedTestChapterId,
       "difficulty_level": $scope.diffLevel,
       "inst_question": "Y",
       "created_by": $scope.user_id,
       "test_id": $scope.testId,
       "contentOwner":$scope.selectedSchema
     }]
   };
   console.log(testParams);
   httpFactory.executePost("addQuestion", testParams, function(data) {
     console.log(data);
     if (data.status == 'SUCCESS') {
       $scope.questionMap += data.id + "~";
       console.log($scope.questionMap);

       if ($scope.checkVar != "1") {
         $scope.question = CKEDITOR.instances['question'].setData('');
         $scope.option1 = CKEDITOR.instances['option1'].setData('');
         $scope.option2 = CKEDITOR.instances['option2'].setData('');
         $scope.option3 = CKEDITOR.instances['option3'].setData('');
         $scope.option4 = CKEDITOR.instances['option4'].setData('');
         $scope.explanation = CKEDITOR.instances['explanation'].setData('');
         $('#correctAnswer').prop('selectedIndex', 0);
         // $('#questionCat').prop('selectedIndex',0);
         $('#diffLevel').prop('selectedIndex', 0);
         window.scrollTo(0, 0);
       }
       else {
         if ($scope.checkVar == "1") {
           $scope.showEdit = false;
           if ($scope.editTestStatus == "TRUE") {
             $scope.showPreviewPageEditTest();
           }
           else{
           $scope.showPreviewPage();
         }
          console.log($scope.questionList);
           var tmp = []
           for (i = 0; i < $scope.questionList.length; i++) {
             tmp[i] = $scope.questionList[i];
           }
           $scope.subjectWiseArray = groupBy(tmp, function(item) {
             return [item.subject_group];
           });
           console.log($scope.subjectWiseArray);
         }
       }
     } else {
       alert('There was a problem saving Question. Please try again later.');

     }
   });
 }


 $scope.saveQuestionEdit = function() {

   $scope.diffLevel = $("#diffLevel").val();
   var questionArr = {};

   if ($scope.selectedTestChapterId == "" || $scope.selectedTestTopicId == "" || $scope.question == "" || $scope.option1 == "" || $scope.option2 == "" || $scope.option3 == "" || $scope.option4 == "" || $scope.correctAnswer == "") {
     alert("Please Select All Fields");
     return true;
   }
   questionArr.question = $scope.question;
   questionArr.option1 = $scope.option1;
   questionArr.option2 = $scope.option2;
   questionArr.option3 = $scope.option3;
   questionArr.option4 = $scope.option4;
   questionArr.explanation = $scope.explanation;
   questionArr.correct_answer = $scope.correctAnswer;
   questionArr.question_type = $scope.questionCat;
   questionArr.diff_level = $scope.diffLevel;
   questionArr.topic_id = $scope.selectedTestTopicId;
   questionArr.chapter_id = $scope.selectedTestChapterId;
   questionArr.difficulty_level = $scope.diffLevel;
   questionArr.inst_question = "Y";
   questionArr.created_by = $scope.user_id;
   questionArr.subject_name = $scope.selectedTestSubjectName;
   questionArr.subject_group = $scope.selectedTestSubjectGroup;
   questionArr.chapter_name = $scope.selectedTestChapterName;
   questionArr.topic_name = $scope.selectedTestTopicName;
   console.log(questionArr);
   $scope.addedQuestions[$scope.addedQuestions.length] = questionArr;
   console.log($scope.addedQuestions);
   questionArr = {};
   console.log($scope.addedQuestions);

   var testParams = {
     "insertRecords": [{
       "question": $scope.question,
       "option1": $scope.option1,
       "option2": $scope.option2,
       "option3": $scope.option3,
       "option4": $scope.option4,
       "explanation": $scope.explanation,
       "correct_answer": $scope.correctAnswer,
       "question_type": $scope.questionCat,
       "diff_level": $scope.diffLevel,
       "topic_id": $scope.selectedTestTopicId,
       "chapter_id": $scope.selectedTestChapterId,
       "difficulty_level": $scope.diffLevel,
       "inst_question": "Y",
       "created_by": $scope.user_id,
       "test_id": $scope.testId,
       "contentOwner":$scope.selectedSchema
     }]
   };
   console.log(testParams);
   httpFactory.executePost("addQuestion", testParams, function(data) {
     console.log(data);
     if (data.status == 'SUCCESS') {
       $scope.questionMap += data.id + "~";
       console.log($scope.questionMap);

       if ($scope.checkVar != "1") {
         $scope.question = CKEDITOR.instances['question'].setData('');
         $scope.option1 = CKEDITOR.instances['option1'].setData('');
         $scope.option2 = CKEDITOR.instances['option2'].setData('');
         $scope.option3 = CKEDITOR.instances['option3'].setData('');
         $scope.option4 = CKEDITOR.instances['option4'].setData('');
         $scope.explanation = CKEDITOR.instances['explanation'].setData('');
         $('#correctAnswer').prop('selectedIndex', 0);
         // $('#questionCat').prop('selectedIndex',0);
         $('#diffLevel').prop('selectedIndex', 0);
         window.scrollTo(0, 0);
       }
       else {
         if ($scope.checkVar == "1") {
           $scope.showEdit = false;
           if ($scope.editTestStatus == "TRUE") {
             $scope.showPreviewPageEditTest();
           }
           else{
           $scope.showPreviewPage();
         }
          console.log($scope.questionList);
           var tmp = []
           for (i = 0; i < $scope.questionList.length; i++) {
             tmp[i] = $scope.questionList[i];
           }
           $scope.subjectWiseArray = groupBy(tmp, function(item) {
             return [item.subject_group];
           });
           console.log($scope.subjectWiseArray);
         }
       }
     } else {
       alert('There was a problem saving Question. Please try again later.');

     }
   });
 }


 $scope.saveAndExit = function() {
   if (CKEDITOR.instances['question'].getData() != '') {
     $scope.questionList = $scope.addedQuestions;
     $scope.checkVar = "1";
     $scope.saveQuestion();
   }
 }

 $scope.saveAndExitEditTest =function (){
      $scope.questionList = $scope.addedQuestions;
     $scope.checkVar = "1";       //check var to check the last question or not in save question
     $scope.editTestStatus = "TRUE"; // to check last question for edit testquestions
     $scope.saveQuestionEdit();
   }

 $scope.autoGenerate = function() {
   $scope.generate = true;
   // $scope.progress = 50;
   var subjectString = "";
   var selectedSubjectGroup = ""
   console.log($scope.selectedSubject);
   for (i = 0; i < $scope.selectedSubject.length; i++) {
     subjectString += $scope.selectedSubject[i].subject_id + "~";
     selectedSubjectGroup += $scope.selectedSubject[i].subject_group + "~";
   }

   var branchString = "";
   for (i = 0; i < $scope.selectedBranch.length; i++) {
     branchString += $scope.selectedBranch[i] + "~";
   }

   var selectedCourseString = "";
   for (i = 0; i < $scope.selectedCourse.length; i++) {
     if (i == $scope.selectedCourse.length - 1)
       selectedCourseString += $scope.selectedCourse[i]
     else
       selectedCourseString += $scope.selectedCourse[i] + "~";
   }

   var questionParams = {
     "m_inst_id": $scope.instituteId,
     "branch": branchString,
     "course": selectedCourseString,
     "class": $scope.selectedClass,
     "subjects": subjectString,
     "subjectGroups": selectedSubjectGroup,
     "category": $scope.selectedCategory,
     "nQuestions": $scope.totalQuestions
   };
   console.log(questionParams);
   // $scope.progress = 70;
   httpFactory.executePost("generateQuestions", questionParams, function(data) {
     // $scope.progess = 75;
     console.log(data);
     if (data.length > 0) {
       $scope.questionList = data;
       $scope.subjectWiseList = [];
       $scope.subjectArr = {}
       counter = 0;
       var subjectCount = 0;
       var tmp = []
       for (i = 0; i < $scope.questionList.length; i++) {
         tmp[i] = $scope.questionList[i];
       }
       $scope.subjectWiseArray = groupBy(tmp, function(item) {
         return [item.subject_group];
       });

       $scope.showPreviewPage();

       $("#divLoading").removeClass('show').addClass('hide');

       //create subject-wise arrays
     } else {
       alert('Questions not available for selected combination');
     }
   });
 }

 $scope.showPreviewPage = function() {
   $scope.showFirst = false;
   $scope.showCategory = false;
   $scope.showAssignment = false;
   $scope.showManual = false;
   $scope.generate = false;
   $scope.configComplete = true;
   $scope.showPreview = true;
   // $("#divLoading").removeClass('show').addClass('hide');

 }

 $scope.showPreviewPageEditTest = function(){
   $scope.showFirst = false;
   $scope.showCategory = false;
   $scope.showAssignment = false;
   $scope.showManual = false;
   $scope.generate = false;
   $scope.configComplete = true;
   $scope.showPreview = true;
   $scope.showQuestions=false;
   $scope.addQuestionsView = false;


   $scope.selectedCourse=$routeParams.course;
   $scope.selectedBranch = $routeParams.branchId;
   $scope.selectedClass = $routeParams.classId;
   $scope.selectedCategoryName= $routeParams.testType;
   $scope.testId = $routeParams.testId;

   // $scope.getSections();
   // alert("reloading");
   // $route.reload();

 }

 $scope.getSections = function() {

   httpFactory.getResult("selectSectionsByBranchCourseClass?courseId=" + $scope.selectedCourse + "&branchId=" + $scope.selectedBranch + "&classId=" + $scope.selectedClass, function(data) {
     console.log(data);
     if (data.length > 0) {
       $scope.sectionList = data;
       console.log($scope.sectionList);
     } else {
     }
   });
 }

 $scope.getCourses = function() {
   httpFactory.getResult("getAllCourses?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname"), function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
         $scope.courseList = data.Courses;
         console.log($scope.courseList);
     } else {
       console.log("No courses");
     }
   });
 }

 $scope.getGroups = function() {
   httpFactory.getResult("selectGroups?branchId=" + $scope.selectedBranch, function(data) {
     console.log(data)
     if (data.length > 0) {
       $scope.groupList = data;
       //$scope.$apply();
       console.log(data)
     } else {
       // alert('No Groups Defined')
     }
   });
 }

 $scope.saveTest = function() {

   var testParams = {
       "testName": "test test test",
       "testCreationType": "auto",
       "testCategory": "Chapter",
       "testType": "CLASS-WISE",
       "numQuestions": 180,
       "diffLevel":'1',
       "duration":180,
       "courseId":1,
       "correctMarks": 1,
       "wrongMarks": 1,
       "createdBy": $scope.user_id,
       "schemaName":localStorage.getItem("sname"),
        "isActive": 1,
        "totalMarks":$scope.totalMarks,
       "testDetails": [{
         "branchId":1,
         "classId":1,
         "subjectId":1,
         "numQuestions":180,
         "createdBy":1,
         "isActive":1
     }]
 };

   console.log(testParams);
   httpFactory.executePost("createTest", testParams, function(data) {
     console.log(data);
     if (data.STATUS == 'SUCCESS') {
       $scope.selectedCategoryName="CLASS-WISE";
       $scope.examFlagType="auto";
       $scope.testId = data.testId;
       if ($scope.selectedCategoryName == "CLASS-WISE") {
         $scope.testType = "Y";
         $scope.practiceSubject = 0;
         $scope.practiceChapter = 0;
         $scope.practiceTopic = 0;
       } else {
         $scope.testType = $scope.selectedCategoryName[0];
       }
       if ($scope.examFlagType == "auto") {
         $scope.getTestQuestions();
       } else {
       }
     } else {
       alert('There was a problem saving test. Please try again later.');
       // $location.path("/exams");
     }
   });
 }

 $scope.publishTest = function() {
   var questionList='';
   var sectionList = "";
   var groupList = "";
   var tDate = $("#testDate").val();
   var tTime = $("#testTime").val();
   var dataAndTime = tDate + ' ' + tTime;
   console.log(dataAndTime);

   var isValid = true;
   console.log($scope.selectedSection);
   // for (i = 0; i < $scope.selectedSection.length; i++) {
   //   sectionList += $scope.selectedSection[i].classCourseSectionId + "~";
   // }
   // for (i = 0; i < $scope.selectedGroup.length; i++) {
   //   groupList += $scope.selectedGroup[i].groupId + "~";
   // }

   // if (sectionList == "" && groupList == "") {
   //   alert('Please assign Sections / Groups to Publish the test.')
   //   isValid = false;
   // }

   // console.log('-' + tDate + "-" + tTime + "-");
   // if (isValid == true && (tDate == '' || tTime == '')) {
   //   alert("Test Date & Time are Mandatory")
   //   isValid = false;
   // }

   isValid=true;
   if (isValid == true) {
     if ($scope.testMode == 'OWN') {
       // questionList = $scope.questionMap;
       // console.log(questionList);
     } else {
       // for (i = 0; i < $scope.questionList.length; i++) {
       //   questionList += $scope.questionList[i].question_id + "~";
       // }
     }

     // console.log(questionList);
     var testParams = {
   	  "testId":18,//test_id
      "schemaName":localStorage.getItem("sname"),
   	   	"testStartDate":dataAndTime,
   	    	"testEndDate":dataAndTime,
   	    	"updatedBy":"1",
   	    	"isActive":1,
   	 insertRecords : [{
   	 	"classId":1,
   	    	"courseId":"1",
   	    	"branchId":"6",
   	    	"sectionId":1,
          "createdBy":localStorage.getItem("userId"),

   	    	"groupId":1
   	    	}
   	 	]
     };
     console.log(testParams);
     httpFactory.executePost("publishTest", testParams, function(data) {
       console.log(data);
       if (data.status == 'SUCCESS') {
         alert('Test Published')
         $location.path("exams");
       } else {
         //alert('There was a problem saving test. Please try again later.');
       }
     });
   }
 }

  $scope.publishTestEditQuestions = function() {
    var questionList='';
    var sectionList = "";
    var groupList = "";
    var tDate = $("#testDate").val();
    var tTime = $("#testTime").val();
    var isValid = true;

    console.log($scope.selectedSection);
    for (i = 0; i < $scope.selectedSection.length; i++) {
      sectionList += $scope.selectedSection[i].classCourseSectionId + "~";
    }
    for (i = 0; i < $scope.selectedGroup.length; i++) {
      groupList += $scope.selectedGroup[i].groupId + "~";
    }

    if (sectionList == "" && groupList == "") {
      alert('Please assign Sections / Groups to Publish the test.')
      isValid = false;
    }

    console.log('-' + tDate + "-" + tTime + "-");
    if (isValid == true && (tDate == '' || tTime == '')) {
      alert("Test Date & Time are Mandatory")
      isValid = false;
    }

    if (isValid == true) {
      if ($scope.testMode == 'OWN') {
        questionList = $scope.questionMap;
        // for (i = 0; i < $scope.questionList.length; i++) {
        //   console.log($scope.questionList);
        //   questionList += $scope.questionList[i].question_id + "~";
        // }
        console.log(questionList);
      } else {
        $scope.questionList=$scope.addedQuestions;

        console.log($scope.addedQuestions);
        console.log($scope.questionList);
        questionList = $scope.questionMap;
        //
        // for (i = 0; i < $scope.questionList.length; i++) {
        //   questionList += $scope.questionList[i].question_id + "~";
        // }
      }
      console.log(questionList);
      var testParams = {
        "insertRecords": [{
          "test_id": $scope.testId,
          "test_date": tDate,
          "test_time": tTime,
          "question_map": questionList,
          "section_id": sectionList,
          "group_id": groupList,
          "test_type": $scope.selectedCategoryName,
          "branch_id": $scope.selectedBranch
        }]
      };
      console.log(testParams);
      httpFactory.executePost("saveAndPublishTest", testParams, function(data) {
        console.log(data);
        if (data.status == 'SUCCESS') {
          alert('Test Published')
          $location.path("exams");
        } else {
          //alert('There was a problem saving test. Please try again later.');
        }
      });
    }
  }


 $scope.showPreviewForView = function() {
   $("#previewSectionPopup").modal("show");
   console.log($scope.questionList);
   console.log($scope.subjectWiseArray);
 }

 function groupBy(array, f) {
   console.log(array);
   var groups = {};
   array.forEach(function(o) {
     var group = JSON.stringify(f(o));
     groups[group] = groups[group] || [];
     groups[group].push(o);
   });
   return Object.keys(groups).map(function(group) {
     return groups[group];
   })
 }


 //********suresh added methods ********

 $scope.selectCategory = function(flag) {
   $scope.categoryView = true;
   $scope.testView = true;
   $scope.getSchemas();
 }

 $scope.schemaChange = function(){
   // alert($scope.selectedSchema);
 }

 $scope.categoryChange = function() {
   // console.log(category);
   if ($scope.selectedCategory < 5) {
     $scope.showBox = true;
     $scope.getClasses();
     if ($scope.selectedCategory == 1) {
       $scope.duration = 7;
       $scope.showClass = true;
       $scope.showSubject = true;
       $scope.showChapter = true;
       $scope.showTopic = true;
     } else if ($scope.selectedCategory == 2) {
       $scope.duration = 30;
       $scope.showClass = true;
       $scope.showSubject = true;
       $scope.showChapter = true;
       $scope.showTopic = false;
   $scope.practiceClass = 0;
   $scope.practiceSubject = 0;
   $scope.practiceChapter = 0;
       $scope.practiceTopic = 0;

     } else if ($scope.selectedCategory == 3) {
       $scope.duration = 50;
       $scope.showClass = true;
       $scope.showSubject = true;
       $scope.showChapter = false;
       $scope.showTopic = false;
   $scope.practiceClass = 0;
   $scope.practiceSubject = 0;
       $scope.practiceChapter = 0;
       $scope.practiceTopic = 0;
     } else if ($scope.selectedCategory == 4) {
       $scope.duration = 180;
       $scope.showClass = true;
       $scope.showSubject = false;
       $scope.showChapter = false;
       $scope.showTopic = false;
   $scope.practiceClass = 0;
     }
   }else if ($scope.selectedCategory == 8) {
     $scope.duration = 120;
     $scope.showClass = true;
     $scope.showSubject = false;
     $scope.showChapter = false;
     $scope.showTopic = false;
   } else {
     $scope.duration = 180;
     $scope.showClass = false;
     $scope.showSubject = false;
     $scope.showChapter = false;
     $scope.showTopic = false;
     $scope.showBox = true;
     $scope.practiceChapter = 0;
     $scope.practiceTopic = 0;
     $scope.practiceSubject = 0;
   }
   for(i=0;i<$scope.categoryListById.length;i++){
     if ($scope.selectedCategory == $scope.categoryListById[i].catId) {
       $scope.categoryName = $scope.categoryListById[i].catName;
       $scope.categoryQuestions = $scope.categoryListById[i].totalQuestions;
       $scope.correctMarks = $scope.categoryListById[i].correctMarks;
       $scope.wrongAnswer = $scope.categoryListById[i].wrongMarks;
       $scope.duration = $scope.categoryListById[i].duration;
     }
   }
 }

 $scope.getClassSubjects1 = function() {
   // $scope.practiceClass = $("#class2").val();

   $scope.practiceCourse = $routeParams.course;
   $scope.getSubjectsbyClassCourse();
   // $scope.showSubject = true;
   // $scope.selectedSubject="";
   // $scope.practiceChapter="";
   // $scope.practiceTopic="";
 }

 $scope.getSubjectChapters1 = function() {
   $scope.selectedSubject = $scope.practiceSubject;
   $scope.getChapterTopics1()
 }

 $scope.getChapterTopics1 = function() {
   $scope.practiceChapter = $scope.practiceChapter;
   $scope.getChaptersBySubject();
   // $scope.showTopic = true;
 }

 $scope.setTopicId1 = function() {
   $scope.practiceTopic = $scope.practiceTopic;
 }


 //suresh -classes by branch_id
 $scope.getClassbyCourseBranchID = function() {
   $scope.selectedBranch = $routeParams.branch;
   $scope.selectedCourse = $routeParams.course;

   var branch = '';
   httpFactory.getResult("getClassbyCourseBranchID?branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse + "&contentOwner="+ $scope.selectedSchema , function(data) {
     console.log(data);
     if (data.length > 0) {
       $scope.classList = data;
       for (i = 0; i < $scope.classList.length; i++) {
         $scope.selectedClassId = $scope.classList[i].classCourseId;
       }
     } else {

     }
   });
   $scope.getTestCategoriesById();
 }


//getdynamic schemas
 $scope.getSchemas = function() {
   //$scope.selectedChapter=chapter.chapterId;
   httpFactory.getResult("getDatabases?schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data != undefined && data.length > 0) {

       $scope.schemaObject = data;
     } else {
       // alert('No Courses Defined. ');
     }
   });
 }

 $scope.createTest = function() {

 if($scope.showClass == true && ($scope.practiceClass == 0 || $scope.practiceClass == null)){
   alert("Select Year");
   return true;
 }
 if($scope.showSubject == true && ($scope.practiceSubject == 0 || $scope.practiceSubject == null)){
   alert("Select Subject");
   return true;
 }
 if($scope.showChapter == true && ($scope.practiceChapter == 0 || $scope.practiceChapter == null)){
   alert("Select Chapter");
   return true;
 }

   $scope.examFlagType = "auto";
   $scope.testName = $routeParams.testName;
   $scope.selectedBranch = $routeParams.branch;
   $scope.testClass = $scope.practiceClass;
   $scope.testCourse = $routeParams.course;
   $scope.testSubject = $scope.practiceSubject;
   $scope.testChapter = $scope.practiceChapter;
   $scope.testTopic = $scope.practiceTopic;
   $scope.selectedCourse = $routeParams.course;
   $scope.selectedClass = $scope.practiceClass;
   $scope.selectedSubject = $scope.practiceSubject;
   $scope.selectedCategory = $scope.selectedCategory;
   $scope.selectedCategoryName = $scope.categoryName;
   $scope.totalQuestions = $scope.categoryQuestions;
   $scope.studentId=0;

   $scope.user_id = localStorage.getItem("userId");
   $scope.studentId = 0;
   $scope.diffLevel = 1;
   $scope.isActive = 1;

   if ($scope.categoryName == "CLASS-WISE") {
     $scope.testType = "Y";
     $scope.practiceSubject = 0;
     $scope.practiceChapter = 0;
     $scope.practiceTopic = 0;
   } else {
     $scope.testType = "EAMCET";
   }
   if ($scope.selectedCategory > 4 && $scope.selectedCategory!=8) {
     $scope.practiceClass = 2;
     $scope.testClass = $scope.practiceClass;
     $scope.selectedClass = $scope.practiceClass;
   }


   $scope.testParams = {

     "test_type": $scope.testType,
     "test_class": $scope.testClass,
     "test_course": $scope.testCourse,
     "test_subject": $scope.testSubject,
     "test_chapter": $scope.testChapter,
     "test_topic": $scope.testTopic,
     "student_id": $scope.studentId
   }
   console.log($scope.testParams);
   $scope.saveTest();
 }

 $scope.getTestQuestions = function() {

   $scope.testType="C";
   $scope.testClass=1;
   $scope.testCourse=1;
   $scope.testSubject=1;
   $scope.testChapter=1;
   $scope.testTopic=0;
   $scope.studentId=0;
   $scope.schemaName=localStorage.getItem("sname");
   $scope.selectedSchema = "RANKR1";

   $scope.testParams = {
     "testId":$scope.testId,
     "testType": $scope.testType,
     "testClass": $scope.testClass,
     "testCourse": $scope.testCourse,
     "testSubject": $scope.testSubject,
     "testChapter": $scope.testChapter,
     "testTopic": $scope.testTopic,
     "studentId": $scope.studentId,
     "contentOwner":$scope.selectedSchema,
     "schemaName":$scope.schemaName
      }

   console.log($scope.testParams);
   httpFactory.executePost("autoGeneratePracticeTestQuestions", $scope.testParams, function(data) {
     $("#divLoading").removeClass('hide').addClass('show');
console.log("in sutogenreation testtkjgjdsvksdvjhsjkjhsdjkdjncvjsjh");

     console.log(data);
     if (data.STATUS=='SUCCESS') {
       $scope.testView = false;
       $scope.questionList = data.TestQuestions;
       $scope.subjectWiseList = [];
       $scope.subjectArr = {}
       counter = 0;
       var subjectCount = 0;

       var tmp = []
       for (i = 0; i < $scope.questionList.length; i++) {
         tmp[i] = $scope.questionList[i];
       }
       $scope.subjectWiseArray = groupBy(tmp, function(item) {
         return [item.subject_group];
       });

       if ($scope.examFlagType == "auto") {
         $scope.showPreviewPage();
       }
       $scope.getBranchCourseClassForTestAssignement();
     } else {
       alert('No Data Found.')
       $scope.closeModal();
      // $location.path("");
       $("#divLoading").removeClass('show').addClass('hide');

     }
   });
   $scope.getSections();
 }
 $scope.cancelCreateTest = function() {
   $location.path("exams");
 }

 var checkPDFCounter = 1;
 $scope.clearPDFCanvas = function() {
   var canvasElements = document.body.getElementsByTagName("canvas");

   for (var i = 0; i < canvasElements.length; i++) {
     if (canvasElements[i].childNodes.length == 0) {
       var parenCanvasNode = canvasElements[i].parentNode;

       //
       parenCanvasNode.removeChild(canvasElements[i]);
       i--;
     } else {
       console.log(canvasElements[i]);
     }
   }
   $("#previewSectionPopup").modal("hide");
 }

$scope.makePDF = function(previewFilename) {
   var pdf , PDF_Width, PDF_Height, HTML_Width, HTML_Height;
   PDF_Width = $("#preivewPDFPaperFirst").width();

   let mywindow = window.open('', 'PRINT', 'width='+PDF_Width+',top=100,left=150');
    mywindow.document.write('<html><head><title>'+previewFilename+'</title>');
    mywindow.document.write('</head><body >');

    mywindow.document.write(document.getElementById('preivewPDFPaperFirst').innerHTML);
    mywindow.document.write(document.getElementById('preivewPDFPaperSecond').innerHTML);
    mywindow.document.write(document.getElementById('preivewPDFPaperThree').innerHTML);
    mywindow.document.write(document.getElementById('preivewPDFPaperFour').innerHTML);
    mywindow.document.write('</body></html>');
    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus();
    mywindow.print();
    mywindow.close();
 }

 $scope.getExamQuestionsEdit = function() {
   $scope.showQuestions = true;
 $scope.addQuestionsView=false;
 $scope.questionCountShow = $routeParams.count;
   $scope.getTestQuestionsBytestId();
   $scope.getSchemas();
 }

 $scope.getTestQuestionsBytestId = function() {
   httpFactory.getResult("getTestQuestions?test_id=" + $routeParams.testId, function(data) {
     console.log(data);

     if (data.length > 0) {

       if(data[0].question_map<=0){
       $scope.questionList = [];
       $scope.addedQuestions = $scope.questionList;
     }else{
       $scope.questionList = data;
       $scope.addedQuestions = $scope.questionList;
     }
       console.log($scope.addedQuestions);
       if ($scope.questionList.length<$routeParams.count) {
         $scope.addQuestionButton=true;
         $scope.publishTestSectionView = false;

       }else{
         $scope.addQuestionButton=false;
         $scope.publishTestSectionView = true;

       }
       $scope.totalQuestions = $scope.questionList.length;
       $scope.notVisited = $scope.totalQuestions - 1;
       $scope.not_answered = $scope.totalQuestions;

       $scope.subjectWiseList = [];
       $scope.subjectArr = {}
       counter = 0;
       var subjectCount = 0;

       var tmp = []
       for (i = 0; i < $scope.questionList.length; i++) {
         tmp[i] = $scope.questionList[i];
         $scope.questionMap += $scope.questionList[i].question_id + "~";
       }

       console.log($scope.questionMap);


       $scope.subjectWiseArray = groupBy(tmp, function(item) {
         return [item.subject_group];
       });
     }
     else
     {
     }
   });
 }


 //get subjects by tempClassSecId
 $scope.getSubjectsbyClassCourse = function() {

   httpFactory.getResult("getSubjectsbyClassCourse?classId=" + $scope.practiceClass + "&courseId=" + $scope.practiceCourse + "&contentOwner="+ $scope.selectedSchema , function(data) {
     console.log(data);
     if (data.length > 0) {
       $scope.subjectListByCourseClass = data;
   $scope.chapterListByClassSubject = [];
     } else {
       // alert('No Courses Defined. ');
     }
   });
 }

 //get chapters by subject_id
 $scope.getChaptersBySubject = function() {
   //			$scope.selectedsubjectTopic=subject.subjectId;
 if($scope.practiceSubject != null ){
   httpFactory.getResult("getChaptersSubjectBranchId?subjectId=" + $scope.practiceSubject + "&classId=" + $scope.practiceClass + "&contentOwner="+ $scope.selectedSchema , function(data) {
     console.log(data);
     if (data.SubjectRecord != undefined && data.SubjectRecord.length > 0) {
       $scope.chapterListByClassSubject = data.SubjectRecord;

     } else {
       // alert('No Courses Defined. ');
     }
   });
 }
 }

 $scope.getTopicsByChapter = function(){
   //$scope.selectedChapter=chapter.chapterId;
 if($scope.practiceChapter != null){
   httpFactory.getResult("getTopicByChapterId?chapterId=" + $scope.practiceChapter + "&contentOwner="+ $scope.selectedSchema , function(data) {
     console.log(data);
     if (data.SubjectRecord != undefined && data.SubjectRecord.length > 0) {
       $scope.subChapterListByChapter = data.SubjectRecord;
     } else {
       // alert('No Courses Defined. ');
     }
   });
 }
 }

 //for edit questions functionality
 $scope.addQuestions = function() {
   $scope.selectedClass = $routeParams.classId;
   $scope.selectedCourse = $routeParams.course;
   $scope.testId = $routeParams.testId;
   $scope.getSubjects();
   $scope.showQuestions = false;
   $scope.addQuestionsView = true;
   $scope.totalQuestions=$routeParams.count;
 }

// anils custom generate test view code

 $scope.allSubjects = [];
 $scope.CustomTotalQues = "";
 $scope.customRightMarksAllocation = "";
 $scope.customWrongMarksAllocation = "";
 $scope.customTotalmarks = "";
 $scope.customTotaltestDuration = "";

 $scope.getClassbyCourseBranchIDForCustom = function() {
   $scope.selectedBranch = $routeParams.branch;
   $scope.selectedCourse = $routeParams.course;

   var branch = '';
   httpFactory.getResult("getClassbyCourseBranchID?branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse, function(data) {
     console.log(data);
     if (data.length > 0) {
       $scope.classList = data;
     } else {

     }
   });

 }
 $scope.selectedClassForCustom = [];
 $scope.checkClassesForCustom = function(class1) {
   console.log(class1);
   var found = false;
   if ($scope.selectedClassForCustom.length == 0) {
     $scope.selectedClassForCustom[$scope.selectedClassForCustom.length] = class1;
   } else {
     for (i = 0; i < $scope.selectedClassForCustom.length; i++) {
       console.log($scope.selectedClassForCustom[i].classId + "==" + class1.classId)
       if ($scope.selectedClassForCustom[i].classId == class1.classId) {
         $scope.selectedClassForCustom.splice(i, 1);
         found = true;
       }
     }
     if (!found) {
       $scope.selectedClassForCustom[$scope.selectedClassForCustom.length] = class1;
     }
   }
   console.log($scope.selectedClassForCustom);
 }

$scope.renderTestAndSubjectDetails = function(){
  if($scope.selectedClassForCustom.length > 0){
 $scope.showClassSelection = false;
 $scope.showSubjectSelection = true;
 $scope.getSchemas();
 $scope.getTestCategoriesByIdForCustom();
 $scope.getSubjectsForCustom();
  }
  else
  {
    alert("Please select at-least one Class");
  }
}


 $scope.getTestCategoriesByIdForCustom = function() {

   var requestParams = {
     "m_inst_id": localStorage.getItem("inst_id"),
     "courseId": $routeParams.course
   }
   console.log(requestParams);
   httpFactory.executePost("getTestCategoriesById", requestParams, function(data) {
     console.log(data);

     if (data.length > 0) {
       data.splice(0, 1);
       $scope.categoryListById = data;
       console.log($scope.categoryListById);
     } else {
       alert("Oops something went wrong..");
     }
   });
 }

 $scope.getSubjectsForCustom = function() {
   var selectedClass = "";
   for (i = 0; i < $scope.selectedClassForCustom.length; i++) {
     if (i == $scope.selectedClassForCustom.length - 1) {
       selectedClass += $scope.selectedClassForCustom[i].classId;
     } else {
       selectedClass += $scope.selectedClassForCustom[i].classId + ",";
     }
   }
console.log($scope.selectedCourse)
   httpFactory.getResult("getSubjectsbyClassCourse?classId=" + selectedClass + "&courseId=" + $scope.selectedCourse, function(data) {
     console.log(data);
   if (data.length > 0) {
       $scope.subjectList = data;
       console.log($scope.subjectList);
   for(var i=0; i<$scope.subjectList.length; i++){
     $scope.subjectList[i].allocatedQuess = "";
   }
   console.log($scope.subjectList);
     } else {}
   });
 }

 $scope.getSectionsForCustom = function() {
   var selectedClass = "";
   for (i = 0; i < $scope.selectedClassForCustom.length; i++) {
     if (i == $scope.selectedClassForCustom.length - 1) {
       selectedClass += $scope.selectedClassForCustom[i].classId;
     } else {
       selectedClass += $scope.selectedClassForCustom[i].classId + ",";
     }
   }
   httpFactory.getResult("getSectionsForTest?courseId=" + $scope.selectedCourse + "&branchId=" + $scope.selectedBranch + "&classId=" + selectedClass, function(data) {
     console.log(JSON.stringify(data));
     if (data.StatusCode == "200") {
       $scope.sectionList = data.instArray;
       console.log($scope.sectionList);
     } else {}
   });
 }

 $scope.manageSubjectsToAllocation = function(subj){
 if($scope.allSubjects.length == 0)
 {
   $scope.allSubjects.push(subj);
 }
 else
 {
   if($scope.allSubjects.indexOf(subj) == -1)
   {
     $scope.allSubjects.push(subj);
   }
   else
   {
     $scope.allSubjects.splice($scope.allSubjects.indexOf(subj), 1);
   }
 }
 }


 $scope.selectedSubjectsTotalDetails = [];
 $scope.selectedSubjectsQuestionTotalDetails = [];
 $scope.selectedTotalQuestions = [];
 $scope.questionCustomList = [];
 $scope.selectedChapterDetails = [];
 $scope.selectedChapterDetailsSubjectId = 1;
 $scope.selectedChapterDetailsChapterId = "";
 $scope.selectedChapterDetailsTopicId = "";
 $scope.subjIDs = [];
 $scope.selectableQuesForSubject = 0;
 $scope.selectedSubjlabelActive = "";

 $scope.getChapterTopicBySubject = function(subjectID,subjectName,allocatedQuess) {
   if($scope.subjIDs.indexOf(subjectID) == -1){
     $("#divLoading").removeClass('hide').addClass('show');
     httpFactory.getResult("getChapterTopicBySubject?subjectId=" + subjectID + "&contentOwner=" + $scope.selectedSchema, function(data) {
       console.log(JSON.stringify(data));
       if (data.chapters.length > 0) {
         $scope.subjIDs.push(subjectID);
         //$scope.selectedChapterDetails = data.chapters;
         //$scope.selectedChapterDetailsSubjectId = subjectID;
         var subOBj = {
           "subject":subjectID,
           "subjectName":subjectName,
           "allocatedQuess":allocatedQuess,
           "questions":[]
         }
         $scope.selectedSubjectsQuestionTotalDetails.push(subOBj);
         var requestparams = {
           "subject":subjectID,
           "details":data.chapters
         };
         $scope.selectedSubjectsTotalDetails.push(requestparams);

         $("#divLoading").removeClass('show').addClass('hide');
       } else {
         alert('Oops. Something went wrong.')
         $("#divLoading").removeClass('show').addClass('hide');
       }
     });

   }
   else
   {
     $scope.selectedSubjlabelActive = subjectID;
     for(var i=0; i<$scope.selectedSubjectsTotalDetails.length; i++)
     {
       if($scope.selectedSubjectsTotalDetails[i].subject == subjectID)
       {

         $scope.questionCustomList = [];
         $scope.topicSelectedQuestionslength = 0;
         $scope.customSelecteTopicName = "";
         $scope.selectedChapterDetails = $scope.selectedSubjectsTotalDetails[i].details;
         $scope.selectedChapterDetailsSubjectId = subjectID;
         $scope.selectableQuesForSubject = allocatedQuess;
         $scope.subjSelectedQuestionslength = 0;

         for(var j=0; j<$scope.selectedSubjectsQuestionTotalDetails.length; j++)
         {
           if($scope.selectedSubjectsQuestionTotalDetails[j].subject == $scope.selectedChapterDetailsSubjectId)
           {
             $scope.subjSelectedQuestionslength = $scope.selectedSubjectsQuestionTotalDetails[j].questions.length;
           }
         }
         console.log(JSON.stringify($scope.subjSelectedQuestionslength));
         //$scope.subjSelectedQuestionslength = $scope.selectedSubjectsQuestionTotalDetails.questions.length;
         console.log($scope.selectableQuesForSubject);


       }
     }
   }
 }
 $scope.renderSubjectsDetsils = function(){
   for(var i=0; i<$scope.allSubjects.length;i++)
   {
     $scope.getChapterTopicBySubject($scope.allSubjects[i].subject_id,$scope.allSubjects[i].subject_name,$scope.allSubjects[i].allocatedQuess);
     if(i == $scope.allSubjects.length-1)
     {
       $scope.getChapterTopicBySubject($scope.allSubjects[0].subject_id, $scope.allSubjects[0].subject_name, $scope.allSubjects[0].allocatedQuess);
     }
   }
 }
 $scope.goToExamSetupForCustom = function(){
   var allowcatedNumQues = 0;
   for(var i=0; i<$scope.allSubjects.length; i++)
   {
     allowcatedNumQues = parseInt(allowcatedNumQues)+parseInt($scope.allSubjects[i].allocatedQuess);
   }

   if($scope.selectedCategory != "" && $scope.selectedCategory != undefined && $scope.CustomTotalQues != "" && $scope.customRightMarksAllocation != "" && $scope.customWrongMarksAllocation != "" && $scope.customTotalmarks != "" && $scope.customTotaltestDuration != "" && $scope.allSubjects.length > 0 && allowcatedNumQues == $scope.CustomTotalQues)
   {	$scope.renderSubjectsDetsils();
     $scope.showQuestionSlection = true;
     $scope.showSubjectSelection = false;
     $scope.selectedCategoryName = $("#selCat option:selected").text();
   //console.log($scope.selectedSubjectsQuestionTotalDetails);
   }
   else
   {
     alert("Please Select/Add All Details correctly");
   }
 }

 $scope.selectedQuestionsForChapter = [];
 $scope.customSelecteTopicName = "";
 $scope.getChapterTopicQuestions = function(selecteTopicId, selecteTopicName, selecteChapterId) {
   $scope.selectedChapterDetailsChapterId = selecteChapterId;
   $scope.customSelecteTopicName = selecteTopicName;
   $scope.selectedChapterDetailsTopicId = selecteTopicId;
   $scope.questionCustomList = [];
   $("#divLoading").removeClass('hide').addClass('show');
   httpFactory.getResult("getTopicQuestions?topicId=" + selecteTopicId, function(data) {
       console.log(data);
       if (data.StatusCode == 200) {

       $scope.questionCustomList = data.questionsArray;

       for(var i=0; i<$scope.selectedChapterDetails.length; i++)
       {
         if($scope.selectedChapterDetails[i].chapterId == $scope.selectedChapterDetailsChapterId ){

           for(var j=0; j<$scope.selectedChapterDetails[i].Topics.length; j++ )
           {
             if($scope.selectedChapterDetails[i].Topics[j].topicId == $scope.selectedChapterDetailsTopicId)
             {
               if($scope.selectedChapterDetails[i].Topics[j].selectedQuestions != undefined){
                 $scope.selectedQuestionsForChapter = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions;
                 $scope.topicSelectedQuestionslength = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length;
               }
               else
               {
                 $scope.topicSelectedQuestionslength = 0;
               }
             }
           }
         }

       }




       $("#divLoading").removeClass('show').addClass('hide');
       } else {
       alert('Oops. Something went wrong.')
       $("#divLoading").removeClass('show').addClass('hide');
       }
   });
   //$scope.apply();
 }
 $scope.topicSelectedQuestionslength = 0;
 $scope.subjSelectedQuestionslength = 0;
 $scope.updateSelectedTopicStatus = function(questionIndex,question) {
   var limitreached = 0;

   if(parseInt($scope.subjSelectedQuestionslength) == parseInt($scope.selectableQuesForSubject))
   {
     if($scope.selectedTotalQuestions.indexOf(questionIndex) == -1){
       for(var j=0; j<document.getElementsByName("questionustomlistQue").length; j++)
       {
         if(document.getElementsByName("questionustomlistQue")[j].value == questionIndex)
         {
           document.getElementsByName("questionustomlistQue")[j].checked = false;
         }
       }
       alert("Hi you have selected maximum number of questions in this subject -  "+$scope.selectableQuesForSubject+"")

       return true;
     }
   }

   for(var i=0; i<$scope.selectedChapterDetails.length; i++)
   {
     if($scope.selectedChapterDetails[i].chapterId == $scope.selectedChapterDetailsChapterId ){
       var chapterSelectedStatus = 0;
       var quesSelectedInChapterlevel = 0;
       for(var j=0; j<$scope.selectedChapterDetails[i].Topics.length; j++ )
       {
         if($scope.selectedChapterDetails[i].Topics[j].topicId == $scope.selectedChapterDetailsTopicId)
         {
           if($scope.selectedChapterDetails[i].Topics[j].selectedQuestions == undefined || $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length == 0)
           {
             $scope.selectedChapterDetails[i].Topics[j].selectedQuestions = [];
             $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.push(questionIndex);
             $scope.selectedChapterDetails[i].Topics[j].selected = true;
             $scope.selectedChapterDetails[i].selected = true;
             $scope.topicSelectedQuestionslength = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length;

           }
           else
           {
             var queIndex = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.indexOf(questionIndex);
             if(queIndex == -1)
             {
               $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.push(questionIndex);
               $scope.topicSelectedQuestionslength = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length;
             }
             else
             {
               $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.splice(queIndex,1);
               $scope.topicSelectedQuestionslength = $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length;
               if($scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length == 0)
               {
                 $scope.selectedChapterDetails[i].Topics[j].selected = false;
               }
             }

           }

         }

         if($scope.selectedChapterDetails[i].Topics[j].selected == true)
         {
           chapterSelectedStatus++;
         }

         if($scope.selectedChapterDetails[i].Topics[j].selectedQuestions != undefined && $scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length > 0)
         {
           quesSelectedInChapterlevel = parseInt(quesSelectedInChapterlevel) + parseInt($scope.selectedChapterDetails[i].Topics[j].selectedQuestions.length);
         }
       }
       if(chapterSelectedStatus > 0)
       {
         $scope.selectedChapterDetails[i].selected = true;
       }
       else
       {
         $scope.selectedChapterDetails[i].selected = false;
       }
       $scope.selectedChapterDetails[i].selectedQuestionsLength = quesSelectedInChapterlevel;
       console.log(quesSelectedInChapterlevel+" quesSelectedInChapterlevel");
       console.log($scope.selectedChapterDetails[i].selectedQuestionsLength+" selectedQuestionsLength chapter")
     }

   }

   for(var i=0; i<$scope.selectedSubjectsTotalDetails.length; i++)
   {
     if($scope.selectedSubjectsTotalDetails[i].subject == $scope.selectedChapterDetailsSubjectId)
     {
       $scope.selectedSubjectsTotalDetails[i].details = $scope.selectedChapterDetails;
     }
   }
   if($scope.selectedTotalQuestions.indexOf(questionIndex) == -1)
   {
     $scope.selectedTotalQuestions.push(questionIndex);
     for(var i=0; i<$scope.selectedSubjectsQuestionTotalDetails.length; i++)
     {
       if($scope.selectedSubjectsQuestionTotalDetails[i].subject == $scope.selectedChapterDetailsSubjectId)
       {
         $scope.selectedSubjectsQuestionTotalDetails[i].questions.push(question);
         $scope.subjSelectedQuestionslength = $scope.selectedSubjectsQuestionTotalDetails[i].questions.length;
       }

     }
   }
   else
   {
     $scope.selectedTotalQuestions.splice($scope.selectedTotalQuestions.indexOf(questionIndex),1);
     for(var i=0; i<$scope.selectedSubjectsQuestionTotalDetails.length; i++)
     {
       if($scope.selectedSubjectsQuestionTotalDetails[i].subject == $scope.selectedChapterDetailsSubjectId)
       {
         $scope.selectedSubjectsQuestionTotalDetails[i].questions.splice($scope.selectedSubjectsQuestionTotalDetails[i].questions.indexOf(question),1);;
         $scope.subjSelectedQuestionslength = $scope.selectedSubjectsQuestionTotalDetails[i].questions.length;
       }
       console.log(JSON.stringify($scope.selectedSubjectsQuestionTotalDetails[i].subject));
       console.log(JSON.stringify($scope.selectedSubjectsQuestionTotalDetails[i].questions.length));
     }

   }

 }

 $scope.generateCustomPreview = function(){
   if($scope.selectedTotalQuestions.length ==  $scope.CustomTotalQues){
   $scope.showQuestionSlection = false;
   $scope.configCompleteCustom = true;
   $scope.showCustomPreview = true;
   //$scope.getTopicQuestionsBySubject($scope.selectedSubjectsQuestionTotalDetails[0].subject);
   $scope.displayAllSubjectsQues();
   $scope.getSectionsForCustom();
   $scope.getGroups();
   $scope.questionList = $scope.selectedTotalQuestions;
   }
   else{
    alert("You have not selected enough questions");
   }
 }
 $scope.previewSubjectwiseQuesList = [];
 $scope.sbjCustomSel = "ALL";
 $scope.getTopicQuestionsBySubject = function(subjectID){
   $scope.sbjCustomSel = subjectID;
   for(var i=0; i<$scope.selectedSubjectsQuestionTotalDetails.length; i++)
   {
     if($scope.selectedSubjectsQuestionTotalDetails[i].subject == subjectID)
     {
       $scope.previewSubjectwiseQuesList = $scope.selectedSubjectsQuestionTotalDetails[i].questions;

     }

   }
 }
 $scope.displayAllSubjectsQues = function(){
   $scope.previewSubjectwiseQuesList = [];
   $scope.sbjCustomSel = "ALL";
   for(var i=0; i<$scope.selectedSubjectsQuestionTotalDetails.length; i++){
     for(var j=0;j<$scope.selectedSubjectsQuestionTotalDetails[i].questions.length; j++){
       $scope.previewSubjectwiseQuesList.push($scope.selectedSubjectsQuestionTotalDetails[i].questions[j]);
     }
   }
 }
 $scope.previewAllSubjectQuesList = [];
 $scope.showPreviewForCustomView = function(){
   $scope.previewAllSubjectQuesList = [];
   for(var i=0; i<$scope.selectedSubjectsQuestionTotalDetails.length; i++)
   {
     for(var j=0; j<$scope.selectedSubjectsQuestionTotalDetails[i].questions.length; j++)
     {
       $scope.previewAllSubjectQuesList.push($scope.selectedSubjectsQuestionTotalDetails[i].questions[j]);
     }
   }
   console.log($scope.previewAllSubjectQuesList);
   $("#previewSectionPopup").modal("show");
 }


 $scope.saveTestCustom = function() {
   var tDate = $("#testDate").val();
   var tTime = $("#testTime").val();
 if($scope.selectedSection.length > 0 && tDate != "" && tTime != "")	{
   var classList = "";
   var subjectList = "";
   var sectionList = "";
   var groupList = "";
   var questionList = "";
   var branchList = "";
 var selectedClass = "";
 var branchString = $scope.selectedBranch;
   var selectedCourseString = $scope.selectedCourse;

   for (i = 0; i < $scope.selectedClassForCustom.length; i++) {
     if (i == $scope.selectedClassForCustom.length - 1) {
       selectedClass += $scope.selectedClassForCustom[i].classId;
     } else {
       selectedClass += $scope.selectedClassForCustom[i].classId + ",";
     }
   }
   for (i = 0; i < $scope.selectedSection.length; i++) {
     sectionList += $scope.selectedSection[i].classCourseSectionId + "~";
   }
   for (i = 0; i < $scope.selectedGroup.length; i++) {
     groupList += $scope.selectedGroup[i].groupId + "~";
   }
 for(i=0;i<$scope.selectedTotalQuestions.length; i++){
   questionList += $scope.selectedTotalQuestions[i]+"~";
 }


   var subjectString = "";
   for (i = 0; i < $scope.selectedSubjectsQuestionTotalDetails.length; i++) {
     subjectString += $scope.selectedSubjectsQuestionTotalDetails[i].subject + "~";
   }



 $scope.correctMarks = $scope.customRightMarksAllocation;
   $scope.wrongAnswer = $scope.customWrongMarksAllocation

   // $scope.testDate = new Date($scope.testDate).toJSON().slice(0, 10)
 var testParams = {
     "insertRecords": [{
       "test_name": $scope.testName,
       "branch_id": branchString,
       "course_id": selectedCourseString,
       "class_id": selectedClass,
       "subject_id": subjectString,
       "test_category": $scope.selectedCategory,
       "test_type": $scope.selectedCategoryName,
       "test_date": '',
       "test_time": '',
       "num_questions": $scope.selectedTotalQuestions.length,
       "diff_level": '1',
       "duration": $scope.customTotaltestDuration,
       "correct_marks": $scope.correctMarks,
       "wrong_marks": $scope.wrongAnswer,
       "test_instructions": "Test Rules",
       "question_map": '',
       "section_id": '',
       "group_id": '',
       "is_active": 1,
       "created_by": $scope.user_id
     }]
   };

   console.log(testParams);
   httpFactory.executePost("saveTest", testParams, function(data) {
     console.log(data);

     if (data.status == 'SUCCESS') {

       $scope.testId = data.id;

   var testParams2 = {
       "insertRecords": [{
         "test_id": $scope.testId,
         "test_date": tDate,
         "test_time": tTime,
         "question_map": questionList,
         "section_id": sectionList,
         "group_id": groupList,
         "test_type": $scope.selectedCategoryName,
         "branch_id": $scope.selectedBranch
       }]
     };
     console.log(testParams2);
     httpFactory.executePost("saveAndPublishTest", testParams2, function(data) {
       console.log(data);
       if (data.status == 'SUCCESS') {
         alert('Test Published')
         $location.path("exams");
       } else {
         alert('There was a problem publishing test. Please try again later.');
       }
     });
     } else {
       alert('There was a problem saving test. Please try again later.');
     }
   });
 }
 else
 {
   alert("Please must have to select atleast one section , date & time. ");
 }
 }

 $scope.addValue = function (value,maxValue){

   if(parseInt(value) < parseInt(maxValue)){
     return parseInt(value) + 1;
   }
   else{
     return parseInt(value);
   }
 }

 $scope.subtractValue = function (value){
   if(parseInt(value) > 0){
     return parseInt(value) - 1;
   }
   else{
     return 0;
   }
 }
$scope.edQues = {};
 $scope.editQuestionForIncompleteTest = function (ques){
	 httpFactory.getResult("getQuestionById?questionId=" + ques.question_id, function(data) {
		$scope.edQues = {};
		//console.log(ques);
	if (data.StatusCode == 200) {
		var quesDetails = data.questionsArray[0];
		$scope.edQues['question_id'] = ques.question_id
		$scope.edQues['question'] = quesDetails.question;
		$scope.edQues['option1'] = quesDetails.option1;
		$scope.edQues['option2'] = quesDetails.option2;
		$scope.edQues['option3'] = quesDetails.option3;
		$scope.edQues['option4'] = quesDetails.option4;
		$scope.edQues['explanation'] = quesDetails.explanation;
		$scope.edQues['questionCat'] = quesDetails.questionType;
		$scope.edQues['correctAnswer'] = quesDetails.correctAnswer;
		$scope.edQues['diffLevel'] = quesDetails.difficultyLevel;
		$scope.getTestCategoriesById();
		$("#editSectionPopup").modal('show');
	 }
	 else{
		 alert("Error while retrieving Question Details");
	 }
 });
 }
 $scope.editOrUpdateQuestion = function(){
	 var requestParams = {
		      "updatedRecords": [{
		        "where": {
		          "questionId": $scope.edQues.question_id
		        },
		        "values": {
		          "question": $scope.edQues.question,
		          "option1": $scope.edQues.option1,
		          "option2": $scope.edQues.option2,
		          "option3": $scope.edQues.option3,
		          "option4": $scope.edQues.option4,
		          "explanation": $scope.edQues.explanation,
		          "correctAnswer": $scope.edQues.correctAnswer,
		          "questionType": $scope.edQues.questionCat,
		          "difficultyLevel": $scope.edQues.diffLevel,
		          "contentOwner": "$scope.schemaName",
		          "questionAppearedIn": "",
		          "createdBy": localStorage.getItem("userId")
		        }
		      }]
		    }
		    console.log(requestParams);
		    httpFactory.executePost("updateQuestion", requestParams, function(data) {
		      console.log(data);
		      if (data.StatusCode == 200) {
		        window.scrollTo(0, 0);
		        alert("Question updated succesfully");

		        $scope.edQues.question = CKEDITOR.instances['question'].setData('');
		        $scope.edQues.option1 = CKEDITOR.instances['option1'].setData('');
		        $scope.edQues.option2 = CKEDITOR.instances['option2'].setData('');
		        $scope.edQues.option3 = CKEDITOR.instances['option3'].setData('');
		        $scope.edQues.option4 = CKEDITOR.instances['option4'].setData('');
		        $scope.edQues.explanation = CKEDITOR.instances['explanation'].setData('');
		        $('#correctAnswer').prop('selectedIndex', 0);
		        // $('#questionCat').prop('selectedIndex',0);
		        $('#diffLevel').prop('selectedIndex', 0);
				$scope.getTestQuestionsBytestId();
				$("#editSectionPopup").modal('hide');
		      } else {
		        // if($scope.courseList.length>0)
		        // 	alert("No Classes Defined.  Please complete institute setup");
		      }
		    });
 }

 $scope.redirectToEditQuestion = function(questionId){
   $location.path("/updateTestQuestion/" + questionId + "/" + $routeParams.testId + "/" + $routeParams.branchId + "/" + $routeParams.classId + "/" + $routeParams.course + "/" + $routeParams.count + "/" + $routeParams.testType );
 }

});
