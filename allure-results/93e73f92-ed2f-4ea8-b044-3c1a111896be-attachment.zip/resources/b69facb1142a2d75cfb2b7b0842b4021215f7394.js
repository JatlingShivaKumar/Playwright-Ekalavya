projectModule.controller('certificatesController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.branchName
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourseOb = {};
	$scope.selectedClassObj = {};
	$scope.selectedClass = "";
	 $scope.CurrentDate = new Date();
	
	$scope.getBranchDetails = function(){
		httpFactory.getResult("getBranchDetails?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
    		console.log(data);
    		if (data.statusCode == 200) {
      			$scope.branchData = data.data;
      			$scope.branchDescription = "";
      			$scope.branchAddress = $scope.branchData.branchAddress;
      			$scope.branchContactNumber = $scope.branchData.branchContactNumber;
      			$scope.branchName = $scope.branchData.branchName;
  			}else{
  				alert("Something Went Wrong");
  			}
  		});
	}
	
	$scope.getCoursesByBranch = function() {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if($scope.courseList.length==1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					$scope.getClassesByCourse();
				}
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}
	
	$scope.getClassesByCourse = function() {
		console.log($scope.selectedCourseOb);
		if ($scope.selectedCourseOb == null) {
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.selectedCourseObj.courseId;
		$scope.selectedCourseName = $scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + $scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
			     console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();

	$scope.getSectionByClass = function(selectedClassObj) {
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("Got Error");
			}
		});
	}
	
	$scope.updateCrsClsSec = function(selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}
	
	$scope.getStudentsBySection = function() {
		httpFactory.getResult("selectStudentsBySection?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId+ "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionStudents = data.sectionStudents;
			} else if(data.StatusCode == 300){
				$scope.sectionStudents = [];
			}else{
				alert(data.MESSAGE);
			}
		});
	}
	
	$scope.addBranchDetailsForCertificates = function(){
		$scope.getBranchDetailsForCertificates();
		if($scope.branchData != undefined){
			$("#addBranchDetails").modal("show");
		}
		else{
			$scope.getBranchDetails();
			$("#addBranchDetails").modal("show");
		}
	}
	
	$scope.makeCertificatePDF = function() {
		$scope.logo = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.BranchCertificateLogo+"&embedded=true";

		if(document.getElementById("certificate").value == "STUDY CUM CONDUCT CERTIFICATE"){
			$scope.model = "printStudyCUMCertificatePreviewModel"
				document.getElementById("branchProfileModelS").src = $scope.logo;
		}
		else if(document.getElementById("certificate").value == "BONAFIDE CERTIFICATE"){
			$scope.model = "printBonafideCertificatePreviewModel";
			document.getElementById("branchProfileModelB").src = $scope.logo;
		}
		else if(document.getElementById("certificate").value == "CERTIFICATE OF APPRECIATION"){
			$scope.model = "printCertificateofAppreciationModel";
			document.getElementById("branchProfileModelC").src = $scope.logo;
		}
		var mywindow = window.open('', '', '','');
    	mywindow.document.write('<!doctype html> <html style="border:1px solid; height:97%;"><head><title></title>');
    	mywindow.document.write('</head><body>');
    	mywindow.document.write(document.getElementById($scope.model).innerHTML);
    	mywindow.document.write('<br><br><br><br><br><br><br>');
    	mywindow.document.write('</body></html>');
    	var is_chrome = Boolean(mywindow.chrome);
		mywindow.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
		if (is_chrome) {
        	mywindow.onload = function() { // wait until all resources loaded 
            	mywindow.focus(); // necessary for IE >= 10
            	mywindow.print();  // change window to mywindow
//            	mywindow.close();// change window to mywindow
        	};
    	}
    	else {
    		mywindow.document.close(); // necessary for IE >= 10
        	mywindow.focus(); // necessary for IE >= 10
        	mywindow.print();
//        	mywindow.close();
       	}
    	$($scope.model).modal("hide");
    	//$scope.model = " ";
    	$scope.getStudentsBySection();
	}
	

	$scope.getStudentDetailsForCertificate = function(studentDetails){
				$scope.studentName = studentDetails.studentName;
				$scope.studentAdmissionNumber = studentDetails.studentAdmissionNumber;
				$scope.getBranchDetailsForCertificates();
				if($scope.hasBranchDetails)
					$("#certificatesModal").modal("show");
				else{
					alert("Add your School Details");
					$("#addBranchDetails").modal("show");
				}
	}
	
	$scope.closePopUp = function(){
		document.getElementById("studentprefix").value = "";
		document.getElementById("fatherprefix").value = "";
		document.getElementById("fatherName").value = "";
		$scope.studentprefix = "";
		$scope.fatherprefix = "";
		$scope.fatherName = "";
		if(document.getElementById("certificate").value == "BONAFIDE CERTIFICATE"){
			document.getElementById("studentAcademicYear").value = "";
			document.getElementById("classNumber").value = "";
			document.getElementById("DOB").value = "";
			$scope.studentAcademicYear = "";
			$scope.classNumber = "";
			$scope.DOB = "";
		}else if(document.getElementById("certificate").value == "STUDY CUM CONDUCT CERTIFICATE"){
			document.getElementById("studentAcademicYearFrom").value = "";
			document.getElementById("studentAcademicYearTo").value = "";
			document.getElementById("studentClassFrom").value = "";
			document.getElementById("studentClassTo").value = "";
			$scope.studentAcademicYearFrom = "";
			$scope.studentAcademicYearTo = "";
			$scope.studentClassFrom = "";
			$scope.studentClassTo = "";
		}else if(document.getElementById("certificate").value == "CERTIFICATE OF APPRECIATION"){
			document.getElementById("studentAcademicYear").value = "";
			document.getElementById("classNumber").value = "";
			document.getElementById("awardName").value = "";
			document.getElementById("certificateNumber").value = "";
			document.getElementById("awardYear").value = "";
			$scope.studentAcademicYear = "";
			$scope.classNumber = "";
			$scope.awardName = "";
			$scope.certificateNumber = "";
			$scope.awardYear = "";
		}
		document.getElementById("certificate").value = "";
		$scope.certificate = "";
		$("#certificatesModal").modal("hide");
		$scope.getStudentsBySection();
	}
	
	$scope.getBranchDetailsForCertificates = function(){
		httpFactory.getResult("getBranchDetailsForCertificate?schemaName="+$scope.schemaName + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.branchData = data.data;
				$scope.BranchCertificateName= data.data.branchName;
				$scope.BranchCertificateAddress= data.data.branchAddress;
				$scope.BranchDescription= data.data.branchDescription;
				$scope.BranchCertificateContact= data.data.branchContactNumber;
				$scope.BranchCertificateLogo= data.data.branchLogo;
				$scope.branchDescription = data.data.branchDescription;
				$scope.branchAddress = data.data.branchAddress;
				$scope.branchContactNumber = data.data.branchContactNumber;
				$scope.branchName = data.data.branchName;
				$scope.hasBranchDetails = true;
				$scope.value = true;
			}else {
				$scope.branchData = undefined;
			}
		});
	}
	
	
   $scope.generateCertificate = function() {
	   if(document.getElementById("fatherprefix").value == "S/O"){
		   $scope.genderPronoun= "He";
	   }
	   else{
		   $scope.genderPronoun = "She";
	   }
	   
		$scope.getBranchDetailsForCertificates();
			if ((document.getElementById("studentName").value != "")
					&& (document.getElementById("fatherName").value != "")
					   && (document.getElementById("studentAdmissionNumber").value != null)) {
							if (document.getElementById("certificate").value == "STUDY CUM CONDUCT CERTIFICATE") {
								if(document.getElementById("studentClassTo").value == ""){
									   $scope.to = "";
								   }else{
								   $scope.to = "to ";}
								$scope.Studentprefix = document
								.getElementById("studentprefix").value;
								$scope.Fatherprefix = document
								.getElementById("fatherprefix").value;
								$scope.certificate = document
										.getElementById("certificate").value;
								$scope.studentName = document
										.getElementById("studentName").value;
								$scope.fatherName = document
										.getElementById("fatherName").value;
								$scope.admissionNumber = document
										.getElementById("studentAdmissionNumber").value;
								$scope.studentAcademicYearFrom = document
										.getElementById("studentAcademicYearFrom").value;
								$scope.studentAcademicYearTo = document
										.getElementById("studentAcademicYearTo").value;
								$scope.studentClassFrom = document
								 		.getElementById("studentClassFrom").value;
								$scope.studentClassTo = $scope.to +  document
								  		.getElementById("studentClassTo").value;
								if($scope.studentClassTo == "")
									$scope.fromIn = "in";
								else
									$scope.fromIn = "from";
								document.getElementById("branchProfileS").src = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.BranchCertificateLogo+"&embedded=true";
								$("#printStudyCUMCertificatePreview").modal(
										"show");
								

							} else if (document.getElementById("certificate").value == "BONAFIDE CERTIFICATE") {
								if(document.getElementById("fatherprefix").value == "S/O"){
									   $scope.genderPronoun= "His";
								   }
								   else{
									   $scope.genderPronoun = "Her";
								   }
								$scope.Studentprefix = document
								.getElementById("studentprefix").value;
								$scope.Fatherprefix = document
								.getElementById("fatherprefix").value;
								$scope.certificate = document
										.getElementById("certificate").value;
								$scope.studentName = document
										.getElementById("studentName").value;
								$scope.fatherName = document
										.getElementById("fatherName").value;
								$scope.admissionNumber = document
										.getElementById("studentAdmissionNumber").value;
								$scope.studentAcademicYear = document
										.getElementById("studentAcademicYear").value;
								$scope.classNumber = document
						           .getElementById("classNumber").value;
						$scope.DOB = document
						           .getElementById("DOB").value;
								document.getElementById("branchProfileB").src = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.BranchCertificateLogo+"&embedded=true";
								$("#printBonafideCertificatePreview").modal("show");
						   } 
							else if (document.getElementById("certificate").value == "CERTIFICATE OF APPRECIATION") {
								$scope.Studentprefix = document
								.getElementById("studentprefix").value;
								$scope.Fatherprefix = document
								.getElementById("fatherprefix").value;
								$scope.certificate = document
										.getElementById("certificate").value;
								$scope.studentName = document
										.getElementById("studentName").value;
								$scope.fatherName = document
										.getElementById("fatherName").value;
								$scope.admissionNumber = document
										.getElementById("studentAdmissionNumber").value;
								$scope.studentAcademicYear = document
										.getElementById("studentAcademicYear").value;
								$scope.classNumber = document
						           .getElementById("classNumber").value;
						$scope.awardName = document
						           .getElementById("awardName").value;
						$scope.awardYear = document
				           .getElementById("awardYear").value;
						$scope.certificateNumber = document
				           .getElementById("certificateNumber").value;
								document.getElementById("branchProfileC").src = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.BranchCertificateLogo+"&embedded=true";
								$("#printCertificateofAppreciation").modal(
										"show");
						   }
							else {
						      alert("Select the Certificate");
					       }
			} else {
				alert("Enter all Details");
				}
	}
	$scope.setBranchDetailsForCertificate=function(){
		var fd = new FormData();
		if($scope.value){
		if(($scope.branchData.branchName == $scope.branchName)&&($scope.branchData.branchDescription == $scope.branchDescription)&&($scope.branchData.branchAddress == $scope.branchAddress)&&($scope.branchData.branchContactNumber == $scope.branchContactNumber)&&(document.getElementById("logo").files.length == 0)){
			alert("Nothing Changed");
		}
		else{
			if(($scope.branchName != undefined)&&($scope.branchData.branchName != $scope.branchName)){
				fd.append("branchName", $scope.branchName);
			}
			if(($scope.branchDescription != undefined)&&($scope.branchData.branchDescription != $scope.branchDescription)){
				fd.append("branchDescription", $scope.branchDescription);
			}
			if(($scope.branchAddress != undefined)&&($scope.branchData.branchAddress != $scope.branchAddress)){
				fd.append("branchAddress", $scope.branchAddress);
			}
			if(($scope.branchContactNumber != undefined)&&($scope.branchData.branchContactNumber != $scope.branchContactNumber)){
				fd.append("branchContactNumber", $scope.branchContactNumber);
			}
			if(document.getElementById("logo").files.length != 0){
				var logo = document.getElementById("logo").files;
				fd.append("logo", logo[0]);
			}
			
			fd.append("branchId",$scope.branchId);
	  		fd.append("schemaName",$scope.schemaName);
	  		httpFactory.executeFileUpload("setBranchDetailsForCertificate", fd, function(data) {
	    		console.log(data);
	    		if (data.StatusCode== '200') {
	      			alert("Details Updated Successfully");
	      			$("#addBranchDetails").modal("hide");
	    		}else{
	      			alert("Error while updating");
	    		}
	  		});
		}
		}
		else{
			if($scope.branchName != undefined){
				fd.append("branchName", $scope.branchName);
			}
			else{
				alert("Enter Branch Name")
			}
			if($scope.branchDescription != undefined){
				fd.append("branchDescription", $scope.branchDescription);
			}
			else{
				alert("Enter Branch Description")
			}
			if($scope.branchAddress != undefined){
				fd.append("branchAddress", $scope.branchAddress);
			}
			else{
				alert("Enter Branch Address")
			}
			if($scope.branchContactNumber != undefined){
				fd.append("branchContactNumber", $scope.branchContactNumber);
			}
			else{
				alert("Enter Branch Number")
			}
			if(document.getElementById("logo").files.length != 0){
				var logo = document.getElementById("logo").files;
				fd.append("logo", logo[0]);
			}
			else{
				alert("Give Branch Logo")
			}
			fd.append("branchId",$scope.branchId);
	  		fd.append("schemaName",$scope.schemaName);
	  		httpFactory.executeFileUpload("setBranchDetailsForCertificate", fd, function(data) {
	    		console.log(data);
	    		if (data.StatusCode== '200') {
	      			alert("Details Updated Successfully");
	      			$("#addBranchDetails").modal("hide");
	    		}else{
	      			alert("Error while updating");
	    		}
	  		});
		}
	}
	
	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	
});
