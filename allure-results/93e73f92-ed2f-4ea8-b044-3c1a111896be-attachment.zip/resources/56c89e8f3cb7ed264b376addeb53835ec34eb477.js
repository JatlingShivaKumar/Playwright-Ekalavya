
projectModule.controller('choppedController', function($scope, $location, commonFactory, httpFactory, $routeParams,$route) {

	$scope.$ = $;

	
//	$scope.chopArr = ["MS",
//		"IA",
//		"BLE",
//		"SSI",
//		"EXP",
//		"BA",
//		"TA",
//		"NT",
//		"SS",
//		"TER",
//		"CO",
//		"EX",
//		"NT",
//		"ONE",
//		"SE",
//		"VAR",
//		"ON",
//		"PRE",
//		"LE",
//		"NS"];
	
	
	$scope.chopArr = [];
	$scope.tempArr=[];
	$scope.questions = [{
		"question":"In which Citric Acid is Present",
		"answer":"ORANGES",
		"isCorrect":false
	},
	
		{
		"question":"Substance which we can use as a Olfactory Indicators",
		"answer":"ONION",
		"isCorrect":false
		},
	{
		"question":"When a magnesium ribbon is burnt in air, the ash formed is",
		"answer":"WHITE",
		"isCorrect":false

	},
	{
		"question":"Which metal is displaced when lead is put in the solution of copper chloride?",
		"answer":"COPPER",
		"isCorrect":false

	},{
		"question":"Fourth Element of Periodic Table",
		"answer":"BERYLLIUM",
		"isCorrect":false

	}
	]
	
	function shuffle(array) {
		  var currentIndex = array.length, temporaryValue, randomIndex;

		  // While there remain elements to shuffle...
		  while (0 !== currentIndex) {

		    // Pick a remaining element...
		    randomIndex = Math.floor(Math.random() * currentIndex);
		    currentIndex -= 1;

		    // And swap it with the current element.
		    temporaryValue = array[currentIndex];
		    array[currentIndex] = array[randomIndex];
		    array[randomIndex] = temporaryValue;
		  }

		  return array;
		}
	
//	alert($scope.gWord.length%2);
	$scope.getRandomNumber=function(){
		 var min=2; 
		    var max=4;  
		    var random = 
		    Math.floor(Math.random() * (+max - +min)) + +min;
		    for(var j=0;j<$scope.questions.length;j++){
		    	$scope.gWord = $scope.questions[j].answer; 
		    	var counter=0

		   for(var i=0;i<$scope.gWord.length;i++){
		   if((counter+random)>$scope.gWord.length-2){
			  var str = $scope.gWord.slice(counter,$scope.gWord.length);
			   $scope.chopArr.push(str);
			 break;
		   }else{
			   var str = $scope.gWord.slice(counter,counter+random);
			   $scope.chopArr.push(str);
			   console.log(str);
		   }
		   counter=counter+random;
		   }
		   console.log($scope.chopArr);
		   }
			$scope.choppedArr=[];
			
			$scope.chopArr=shuffle($scope.chopArr);
			for(var i=0; i< $scope.chopArr.length;i++){
				
				var obj={
						"value":$scope.chopArr[i],
						"selected":false,
						"index":i
				}
				 $scope.choppedArr.push(obj);
			}
	}
	
	
	$scope.getRandomNumber();
		
	$scope.chopIndex = [];
	$scope.wordClick=function(word){
		if($scope.guessedWord){
			$scope.guessedWord=$scope.guessedWord+""+word.value;
		}else{
			$scope.guessedWord=word.value;
	}
		$scope.choppedArr[word.index].selected=true;
		$scope.chopIndex.push(word.index);
	}
	
	$scope.checkGuess=function(){		
		var checkFlag=0;
		for(var i=0;i<$scope.questions.length;i++){
			
			if($scope.guessedWord == $scope.questions[i].answer){
				alert("correct");
				$scope.questions[i].isCorrect=true;
				checkFlag=1;
				break;
			}
		}
		if(checkFlag==0){
			for(var i=0;i<$scope.chopIndex.length;i++){
				console.log($scope.choppedArr[$scope.chopIndex[i]]);
				$scope.choppedArr[$scope.chopIndex[i]].selected=false;
			}
			alert("wrong");
		}
		$scope.guessedWord="";
		$scope.chopIndex=[];
	}
	
});
