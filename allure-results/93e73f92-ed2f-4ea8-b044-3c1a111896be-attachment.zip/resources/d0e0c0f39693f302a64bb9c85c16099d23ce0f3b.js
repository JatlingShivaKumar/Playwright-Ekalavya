projectModule.controller('feeReceiptController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.branchName
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourseOb = {};
	$scope.selectedClassObj = {};
	$scope.selectedClass = "";


	$scope.getBranchDetails = function () {
		httpFactory.getResult("getBranchDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.statusCode == 200) {
				$scope.branchDetails = data.data;
			} else {

			}
		});
		$scope.getBillingDetails();
	}

	$scope.getCoursesByBranch = function () {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					$scope.getClassesByCourse();
				}
				console.log($scope.courseList)

			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function () {
		console.log($scope.selectedCourseOb);
		if ($scope.selectedCourseOb == null) {
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.selectedCourseObj.courseId;
		$scope.selectedCourseName = $scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();

	$scope.getSectionByClass = function (selectedClassObj) {
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("No sections found");
			}
		});
	}

	$scope.updateCrsClsSec = function (selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}

	$scope.goToDashbord = function () {
		$location.path("feemanagement");
	}

	$scope.getStudentsBySection = function () {
		$scope.fineReceipt = false;
		$scope.oldDueReceipt = false;
		$scope.printOldDueReceipt = false;
		httpFactory.getResult("getStudentsAndStudentFeeReceipts?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId + "&classCourseId=" + $scope.classObj.classCourseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionStudents = data.studentFeeReceiptsArray;
				for (i = 0; i < $scope.sectionStudents.length; i++) {
					if ($scope.sectionStudents[i].fineArray.length > 0)
						$scope.fineReceipt = true;
					if ($scope.sectionStudents[i].oldDueArray.length > 0)
						$scope.oldDueReceipt = true;
					if ($scope.sectionStudents[i].prevReceiptArray.length > 0)
                    	$scope.printOldDueReceipt = true;
				}
			} else if (data.StatusCode == 300) {
				$scope.sectionStudents = [];
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.printOldReceipt = function (receiptId, studentId) {
		httpFactory.getResult("getFeeReceiptDetails?schemaName=" + $scope.schemaName + "&receiptId=" + receiptId + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentId = studentId;
				$scope.feeReceiptDetailsObj = data.feeReceiptDetailsObj;
				$scope.pReceiptNumber = $scope.feeReceiptDetailsObj.receiptId;
				$scope.pReceiptDate = $scope.feeReceiptDetailsObj.receiptDate;
				$scope.pStudentName = $scope.feeReceiptDetailsObj.studentName;
				$scope.pFatherName = $scope.feeReceiptDetailsObj.fatherName;
				$scope.pCourseName = $scope.feeReceiptDetailsObj.courseName;
				$scope.pClassName = $scope.feeReceiptDetailsObj.className;
				$scope.pSectionName = $scope.feeReceiptDetailsObj.sectionName;
				$scope.pTransactionType = $scope.feeReceiptDetailsObj.transactionType;
				$scope.fine = $scope.feeReceiptDetailsObj.fine;
				$scope.totalAmount = $scope.feeReceiptDetailsObj.totalAmount;
				$scope.receiptPaidAmount = $scope.feeReceiptDetailsObj.paidAmount;
				$scope.discount = $scope.feeReceiptDetailsObj.discount;
				$scope.totalDueAmount = $scope.feeReceiptDetailsObj.totalDueAmount;
				$scope.receiptDueAmount = 0;
				$scope.receiptDueAmount = $scope.feeReceiptDetailsObj.dueAmount;
				$scope.netAmount = $scope.feeReceiptDetailsObj.payableAmount;

				$scope.selectedBillDetails = $scope.feeReceiptDetailsObj;
				$scope.receiptBillingName = $scope.feeReceiptDetailsObj.billingName;
				$scope.receiptBillingAddress = $scope.feeReceiptDetailsObj.billingAddress;
				if ($scope.feeReceiptDetailsObj.hasOwnProperty("billingLogo")) {
					document.getElementById("billingProfile1").src = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.feeReceiptDetailsObj.billingLogo + "&embedded=true";
				} else {
					document.getElementById("billingProfile1").style.visibility = "hidden";
				}
				//				document.getElementById("refundAmount").style.display = "block";

				$("#printReceiptPreview").modal("show");
			} else {
				alert("Something went wrong");
			}
		});
	}

	$scope.selectCategoryPayments = function () {
		if ($scope.selectCategoryPayment == false) {
			$scope.tempPaidAmount = $scope.studentFeeDetailsArray[0].netAmount - $scope.studentFeeDetailsArray[0].dueAmount;
			for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
				if ($scope.tempPaidAmount > $scope.studentFeeDetailsArray[i].catDueAmount) {
					$scope.tempPaidAmount = $scope.tempPaidAmount - $scope.studentFeeDetailsArray[i].catDueAmount;
					$scope.studentFeeDetailsArray[i].catDueAmount = 0;
				} else {
					$scope.studentFeeDetailsArray[i].catDueAmount = (($scope.studentFeeDetailsArray[i].isSubCategorised==0)?$scope.studentFeeDetailsArray[i].amount:$scope.studentFeeDetailsArray[i].subCategoryAmount) - $scope.tempPaidAmount;
					$scope.tempPaidAmount = 0;
				}
			}
		} else {
			for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
				$scope.studentFeeDetailsArray[i].catDueAmount = $scope.studentFeeDetailsArray[i].amount - $scope.studentFeeDetailsArray[i].categoryPaidAmount;
			}
		}
		$scope.paidAmount = "";
		for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
			$scope.studentFeeDetailsArray[i].categoryNewPaidAmount = "";
		}
		if ($scope.selectCategoryPayment == false) {
			$scope.selectCategoryPayment = true;
			if ($scope.studentFeeDetailsArray[0].paidAmount > 0)
				alert("Total payment by this student is Rs " + $scope.studentFeeDetailsArray[0].paidAmount + ". As the payment mode is getting changed, so it will be distributed "
					+ "among category due amount in a decending order of category total amount. And once the payment is done through category wise then it can't be reverted.");
			else
				alert("Once the payment is done through category wise then it can't be reverted.");
		} else {
			$scope.selectCategoryPayment = false;
		}
	}

	$scope.viewFeeReceipt = function (studentDetail) {
		$scope.selectCategoryPayment = false;
		$scope.receiptType = 'Fee Receipt';
		$scope.studentDetail = studentDetail;
		$scope.courseName = $scope.selectedCourseName;
		$scope.className = $scope.classObj.className;
		$scope.sectionName = $scope.sectionObj.sectionName;
		$scope.studentName = studentDetail.studentName;
		$scope.fatherName = studentDetail.realfatherName;
		$scope.studentId = studentDetail.studentId;
		$scope.transactionType = [];
		$scope.transactionType.push("Cash");
		$scope.transactionType.push("UPI");
		$scope.transactionType.push("Credit Card");
		httpFactory.getResult("getStudentFeeDetails?schemaName=" + $scope.schemaName + "&studentId=" + $scope.studentId + "&classCourseId=" + $scope.classObj.classCourseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentFeeDetailsArray = data.studentFeeDetailsArray;
				$scope.studentFeeDetailsArray.sort((firstItem, secondItem) => secondItem.amount - firstItem.amount);
				$scope.dueAmount = 0;
				for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
					$scope.studentFeeDetailsArray[i]["categoryNewPaidAmount"] = "";
					if ($scope.studentFeeDetailsArray[i].isCategorised == 1 || $scope.studentFeeDetailsArray[i].categoryPaidAmount > 0) {
						$scope.selectCategoryPayment = true;
					}
				}
				$scope.totalAmount = $scope.studentFeeDetailsArray[0].totalAmount;
				$scope.dueAmount = $scope.studentFeeDetailsArray[0].dueAmount;
				$scope.discount = $scope.studentFeeDetailsArray[0].discount;
				$scope.fine = $scope.studentFeeDetailsArray[0].fine;
				$scope.netAmount = $scope.studentFeeDetailsArray[0].netAmount;
				$scope.getBillingDetails();
				$("#viewFeeReceipt").modal("show");
			} else if (data.StatusCode == 300) {
				alert("Fee has been not allocated for this student \nPlease allocate and come again");
			}
			else {
				alert("Something went wrong");
			}
		});
	}

	$scope.addNewReceipt = function () {
		$scope.feeStructureDetails = [];
		$scope.selectedBillDetails = null;
		if ($scope.selectedBillingName != null) {
			$scope.selectedBillDetails = JSON.parse($scope.selectedBillingName);
		}
		if (($scope.dueAmount < 1 && $scope.receiptType == 'Fee Receipt') || (($scope.studentFeeDetailsArray[0].oldDue == 0 && $scope.studentFeeDetailsArray[0].promotedOldDue == 0) && $scope.receiptType == 'Old Due')) {
			alert("You have already paid total fee");
			return;
		} else if ($scope.fatherName == undefined || $scope.fatherName == "") {
			alert("Enter Father Name");
			return;
		}
		else if ($scope.selectedBillingName == undefined || $scope.selectedBillingName == "") {
			alert("Select Billing Detail");
			return;
		}
		else {
			if ($scope.selectCategoryPayment && $scope.receiptType == 'Fee Receipt') {
				$scope.paidAmount = 0;
				for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
					if ($scope.studentFeeDetailsArray[i].categoryNewPaidAmount == "" || $scope.studentFeeDetailsArray[i].categoryNewPaidAmount == null) {
						$scope.studentFeeDetailsArray[i].categoryNewPaidAmount = 0;
					}
					if ($scope.studentFeeDetailsArray[i].catDueAmount < $scope.studentFeeDetailsArray[i].categoryNewPaidAmount) {
						alert("Category paid amount is greater than category due amount. Please enter valid category paid amount.");
						return;
					}
					$scope.paidAmount += $scope.studentFeeDetailsArray[i].categoryNewPaidAmount;
				}
			}
			if ($scope.paidAmount == "" || $scope.paidAmount == undefined || Number($scope.paidAmount) == 0) {
				alert("Please enter valid paid amount");
				return;
			}
			if ((Number($scope.paidAmount) > $scope.dueAmount && $scope.receiptType == 'Fee Receipt') || ((Number($scope.paidAmount) > $scope.studentFeeDetailsArray[0].oldDue && Number($scope.paidAmount) > $scope.studentFeeDetailsArray[0].promotedOldDue) && $scope.receiptType == 'Old Due')) {
				alert("Total paid amount is greater than the due amount.");
				$scope.paidAmount == "";
				return;
			}
			for (i = 0; i < $scope.studentFeeDetailsArray.length; i++) {
				if ($scope.selectCategoryPayment && $scope.receiptType == 'Fee Receipt') {
					$scope.studentFeeDetailsArray[i].catDueAmount -= $scope.studentFeeDetailsArray[i].categoryNewPaidAmount;
				}
				if ($scope.studentFeeDetailsArray[i].categoryNewPaidAmount == "") {
					$scope.studentFeeDetailsArray[i].categoryNewPaidAmount = 0;
				}
				var tempFeeStructureDetails = {
					"catId": $scope.studentFeeDetailsArray[i].feeStructureDetailId,
					"isSubCategorised": $scope.studentFeeDetailsArray[i].isSubCategorised,
					"catPaidAmount": $scope.studentFeeDetailsArray[i].categoryNewPaidAmount,
					"catDueAmount": $scope.studentFeeDetailsArray[i].catDueAmount
				}
				if($scope.studentFeeDetailsArray[i].isSubCategorised==1){
				    tempFeeStructureDetails["subCategoryId"]=$scope.studentFeeDetailsArray[i].subCategoryId;
				}
				$scope.feeStructureDetails.push(tempFeeStructureDetails);
			}
			$scope.receiptPaidAmount = $scope.paidAmount;
			$scope.totalDueAmount = $scope.dueAmount;
			var params = {
				"schemaName": $scope.schemaName,
				"studentId": $scope.studentId,
				"classCourseId": $scope.classObj.classCourseId,
				"netAmount": $scope.netAmount,
				"totalAmount": ($scope.receiptType == 'Fee Receipt') ? $scope.totalAmount : ($scope.studentFeeDetailsArray[0].promotedOldDue > 0) ? $scope.studentFeeDetailsArray[0].promotedOldDue : $scope.studentFeeDetailsArray[0].oldDue,
				"discount": $scope.discount,
				"totalPaidAmount": ($scope.receiptType == 'Fee Receipt') ? (Number($scope.netAmount) - Number($scope.dueAmount) + Number($scope.paidAmount)) : ($scope.studentFeeDetailsArray[0].promotedOldDue > 0) ? ($scope.studentFeeDetailsArray[0].promotedOldPaidAmount + Number($scope.paidAmount)) : ($scope.studentFeeDetailsArray[0].oldPaidAmount + Number($scope.paidAmount)),
				"paidAmount": Number($scope.paidAmount),
				"totalDueAmount": ($scope.receiptType == 'Fee Receipt') ? $scope.totalDueAmount : ($scope.studentFeeDetailsArray[0].promotedOldDue > 0) ? $scope.studentFeeDetailsArray[0].promotedOldDue : $scope.studentFeeDetailsArray[0].oldDue,
				"dueAmount": ($scope.receiptType == 'Fee Receipt') ? (Number($scope.netAmount) - (Number($scope.netAmount) - Number($scope.dueAmount) + Number($scope.paidAmount))) : (($scope.studentFeeDetailsArray[0].promotedOldDue > 0) ? $scope.studentFeeDetailsArray[0].promotedOldDue - Number($scope.paidAmount) : $scope.studentFeeDetailsArray[0].oldDue - Number($scope.paidAmount)),
				"updatedBy": $scope.user_id,
				"transactionType": $scope.selectedTransaction,
				"fatherName": $scope.fatherName,
				"selectedBillingId": $scope.selectedBillDetails.billingDetailId,
				"branchId": $scope.branchId,
				"isCategorised": ($scope.selectCategoryPayment) ? 1 : 0,
				"feeCategoryArray": $scope.feeStructureDetails,
				"receiptType": $scope.receiptType
			}
			if (($scope.receiptType == 'Old Due') && ($scope.studentFeeDetailsArray[0].promotedOldDue > 0)) {
				params["oldDueType"] = 'promoted';
			} else if (($scope.receiptType == 'Old Due') && ($scope.studentFeeDetailsArray[0].promotedOldDue == 0)) {
				params["oldDueType"] = 'manual';
			}
			httpFactory.executePost("addNewReceipt", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.studentDetail.realfatherName = $scope.fatherName;
					$scope.receiptNumber = data.receiptId;
					$scope.printOldReceipt($scope.receiptNumber, $scope.studentId);
					$scope.newReceipt = true;
					document.getElementById("selectedBillingName").value = "";
					document.getElementById("selectedTransaction").value = "";
					document.getElementById("fatherName").value = "";
					$scope.selectedBillingName = null;
					$scope.selectedTransaction = null;
					$scope.fatherName = null;
				}
				else {
					$scope.feeStructureDetails = [];
					alert("Error while inserting records");
				}
			});
		}
	}

	$scope.closePopUp = function () {
		$("#viewFeeReceipt").modal("hide");
		$scope.totalAmount = "";
		$scope.paidAmount = "";
		$scope.discount = "";
		$scope.fine = "";
		$scope.dueAmount = "";
		$scope.netAmount = "";
		$scope.selectedBillingName = "";
		$scope.getStudentsBySection();
		$scope.refund = false;
		$scope.refundAmt = "";
		$scope.refundReason = "";
		$scope.refundAmount = 0;
	}

	$scope.makeFeePDF = function (selectedBillDetailss) {
		$scope.selectedBillDetails = selectedBillDetailss;
		if ($scope.selectedBillDetails != null) {
			$scope.receiptBillingName = $scope.selectedBillDetails.billingName;
			$scope.receiptBillingAddress = $scope.selectedBillDetails.billingAddress;
			if ($scope.selectedBillDetails.hasOwnProperty("billingLogo")) {
				if ($scope.selectedBillDetails.billingLogo.includes("http://") || $scope.selectedBillDetails.billingLogo.includes("https://")) {
					document.getElementById("billingProfile").src = $scope.selectedBillDetails.billingLogo;
				} else {
					document.getElementById("billingProfile").src = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.selectedBillDetails.billingLogo + "&embedded=true";
				}
			} else {
				document.getElementById("billingProfile").style.visibility = "hidden";
			}
		} else {
			$scope.receiptBillingName = $scope.branchDetails.branchName;
			$scope.receiptBillingAddress = $scope.branchDetails.branchAddress;
			document.getElementById("billingProfile").style.visibility = "hidden";
		}
		//		var mywindow = window.open('', '', '','');
		//    	mywindow.document.write('<!doctype html> <html style="border:1px solid; height:97%;"><head><title></title>');
		//    	mywindow.document.write('</head><body>');
		//    	mywindow.document.write(document.getElementById("printReceipt").innerHTML);
		//    	/*mywindow.document.write('<br>');
		//    	mywindow.document.write(document.getElementById("printReceipt").innerHTML);*/
		//    	mywindow.document.write('</body></html>');
		//    	var is_chrome = Boolean(mywindow.chrome);
		//		mywindow.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
		var mywindow = window.open('', '', '', '');
		mywindow.document.write('<!doctype html> <html style="height:49%;">');
		mywindow.document.write('<body>');
		mywindow.document.write(document.getElementById("printReceipt").innerHTML);
		mywindow.document.write('<br>');
		mywindow.document.write(document.getElementById("printReceipt").innerHTML);
		mywindow.document.write('</body></html>');
		var is_chrome = Boolean(mywindow.chrome);
		mywindow.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
		if (is_chrome) {
			mywindow.onload = function () { // wait until all resources loaded 
				mywindow.focus(); // necessary for IE >= 10
				mywindow.print();  // change window to mywindow
			};
		}
		else {
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10
			mywindow.print();
		}
		$("#printReceiptPreview").modal("hide");s
		$scope.getStudentsBySection();
	}

	$scope.printReceipt = function () {
		$scope.pReceiptNumber = $scope.receiptNumber;
		$scope.pReceiptDate = new Date().toISOString().slice(0, 10);
		$scope.pStudentName = $scope.studentName;
		$scope.pFatherName = $scope.fatherName;
		$scope.pCourseName = $scope.courseName;
		$scope.pClassName = $scope.className;
		$scope.pSectionName = $scope.sectionName;
		$scope.pTransactionType = $scope.selectedTransaction;
		if ($scope.selectedBillDetails != null) {
			$scope.receiptBillingName = $scope.selectedBillDetails.billingName;
			$scope.receiptBillingAddress = $scope.selectedBillDetails.billingAddress;
			if ($scope.selectedBillDetails.billingLogo != null) {
				document.getElementById("billingProfile1").src = $scope.selectedBillDetails.billingLogo;
			} else {
				document.getElementById("billingProfile1").style.visibility = "hidden";
			}
		} else {
			$scope.getBranchDetails();
			$scope.receiptBillingName = $scope.branchDetails.branchName;
			$scope.receiptBillingAddress = $scope.branchDetails.branchAddress;
			document.getElementById("billingProfile1").style.visibility = "hidden";
		}
		if ($scope.newReceipt == true)
			document.getElementById("refundAmount").style.display = "none";
		$("#printReceiptPreview").modal("show");
	}

	$scope.addBillingDetails = function () {
		$("#addBillingDetails").modal("show");
	}

	$scope.getBillingDetails = function () {
		httpFactory.getResult("getBillingDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.statusCode == 200) {
				$scope.billingDetails = data.data;
				if ($scope.billingDetails.length > 0) {
					for (i = 0; i < $scope.billingDetails.length; i++) {
						if ($scope.billingDetails[i].hasOwnProperty("billingLogo")) {
							$scope.billingDetails[i]["billingLogo"] = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.billingDetails[i].billingLogo + "&embedded=true";
						}
					}
				} else {
					alert("No Billing Details");
				}
			} else {
				alert("Error while getting billing details");
			}
		});
	}

	$scope.viewBillingDetails = function () {
		$scope.getBillingDetails();
		$("#viewBillingDetails").modal("show");
	}

	$scope.updateBillingDetails = function () {
		var fd = new FormData();
		if ($scope.billingName == undefined) {
			alert("Billing Name cannot be empty");
		} else {
			fd.append("billingName", $scope.billingName);
			$scope.bgName = true;
		}
		if ($scope.billingAddress != undefined) {
			fd.append("billingAddress", $scope.billingAddress);
			$scope.bgAddress = true;
		}
		if (document.getElementById("logo").files.length != 0) {
			var logo = document.getElementById("logo").files;
			fd.append("logo", logo[0]);
			$scope.bgLogo = true;
		}
		if ($scope.bgName) {
			fd.append("branchId", $scope.branchId);
			fd.append("createdBy", $scope.user_id);
			fd.append("schemaName", $scope.schemaName);
			httpFactory.executeFileUpload("updateBillingDetails", fd, function (data) {
				console.log(data);
				if (data.StatusCode == '200') {
					alert("Details Updated Successfully");
					$("#addBillingDetails").modal("hide");
				} else {
					alert("Error while updating");
				}
				$scope.getBillingDetails();
				document.getElementById("billingName").value = "";
				document.getElementById("address").value = "";
				document.getElementById("logo").value = "";
			});
		} else {
			alert("Nothing Changed");
		}
	}

	$scope.refundAmounta = function () {
		$scope.refund = true;
		$scope.refundAmount = 0;
		if ($scope.feeReceiptDetailsObj.isCategorised == 1) {
			for (i = 0; i < $scope.feeReceiptDetailsObj.feeStructureDetailIds.length; i++) {
				if (!$scope.feeReceiptDetailsObj.feeStructureDetailIds[i].hasOwnProperty("refund")) {
					$scope.feeReceiptDetailsObj.feeStructureDetailIds[i]["refund"] = 0;
				}
			}
		}
		$("#printReceiptPreview").modal("show");
	}

	$scope.calcRefundAmount = function () {
		$scope.refundAmount = 0;
		for (i = 0; i < $scope.feeReceiptDetailsObj.feeStructureDetailIds.length; i++) {
			$scope.refundAmount += $scope.feeReceiptDetailsObj.feeStructureDetailIds[i].refund;
		}
	}

	$scope.updateRefund = function (receiptDetails, refundAmount, refundReason) {
		if (refundAmount > 0) {
			$scope.receiptDetailsObj = receiptDetails;
			$scope.refundAmt = refundAmount;
			if ($scope.refundAmt > $scope.receiptDetailsObj.paidAmount) {
				alert("Refund amount is greater than Paid amount");
				return;
			} else if (refundReason == "" || refundReason == undefined) {
				alert("Enter reason for refund");
				return;
			} else if ($scope.refundAmt == $scope.receiptDetailsObj.paidAmount) {
				$scope.refundingReason = refundReason;
				$("#refundFullAmount").modal("show");
			} else {
				if ($scope.feeReceiptDetailsObj.isCategorised == 1) {
					for (i = 0; i < $scope.receiptDetailsObj.feeStructureDetailIds.length; i++) {
						if ($scope.receiptDetailsObj.feeStructureDetailIds[i].refund > $scope.receiptDetailsObj.feeStructureDetailIds[i].categoryPaidAmount) {
							alert("Refund amount is greater than Paid amount");
							return;
						}
					}
					for (i = 0; i < $scope.receiptDetailsObj.feeStructureDetailIds.length; i++) {
						if ($scope.receiptDetailsObj.feeStructureDetailIds[i].refund == "" || $scope.receiptDetailsObj.feeStructureDetailIds[i].refund == null) {
							$scope.receiptDetailsObj.feeStructureDetailIds[i].refund = 0;
						}
						$scope.receiptDetailsObj.feeStructureDetailIds[i].categoryPaidAmount -= $scope.receiptDetailsObj.feeStructureDetailIds[i].refund;
						$scope.receiptDetailsObj.feeStructureDetailIds[i].catDueAmount += $scope.receiptDetailsObj.feeStructureDetailIds[i].refund;
					}
				}
				var params = {
					"schemaName": $scope.schemaName,
					"studentId": $scope.receiptDetailsObj.studentId,
					"receiptId": $scope.receiptDetailsObj.rId,
					"isCategorised": $scope.receiptDetailsObj.isCategorised,
					"paidAmount": $scope.receiptDetailsObj.paidAmount,
					"updatedPaidAmount": $scope.receiptDetailsObj.paidAmount - $scope.refundAmt,
					"dueAmount": Number($scope.receiptDetailsObj.dueAmount) + $scope.refundAmt,
					//"updatedDueAmount": Number($scope.receiptDetailsObj.dueAmount) + $scope.refundAmt,
					"refundAmount": $scope.refundAmt,
					"refundReason": refundReason,
					"createdBy": $scope.user_id,
					"feeStructureArray": $scope.receiptDetailsObj.feeStructureDetailIds
				}
				httpFactory.executePost("updateRefundAmount", params, function (data) {
					console.log(data);
					if (data.StatusCode == 200) {
						alert("Amount Refunded successfully");
						$scope.refund = false;
						$scope.refundAmt = "";
						$scope.refundReason = "";
						$scope.refundAmount = 0;
						$scope.receiptPaidAmount = $scope.receiptDetailsObj.paidAmount - $scope.refundAmt;
						$scope.receiptDueAmount = Number($scope.receiptDetailsObj.dueAmount) + $scope.refundAmt;
						$("#printReceiptPreview").modal("hide");
						$scope.getStudentsBySection();
					}
					else {
						alert("Something went wrong");
					}
				});
			}
		} else {
			alert("Enter Refund Amount");
		}
	}

	$scope.refundFullAmount = function () {
		var params = {
			"schemaName": $scope.schemaName,
			"studentId": $scope.receiptDetailsObj.studentId,
			"receiptId": $scope.receiptDetailsObj.rId,
			"branchReceiptId": $scope.receiptDetailsObj.receiptId,
			"branchId": $scope.branchId,
			"fatherName": $scope.receiptDetailsObj.fatherName,
			"isCategorised": $scope.receiptDetailsObj.isCategorised,
			"totalAmount": $scope.receiptDetailsObj.totalAmount,
			"discount": $scope.receiptDetailsObj.discount,
			"paidAmount": $scope.receiptDetailsObj.paidAmount,
			"updatedPaidAmount": $scope.receiptDetailsObj.paidAmount - $scope.refundAmt,
			"totalDueAmount": Number($scope.receiptDetailsObj.totalDueAmount),
			"dueAmount": Number($scope.receiptDetailsObj.dueAmount),
			"updatedDueAmount": Number($scope.receiptDetailsObj.dueAmount) + $scope.refundAmt,
			"billingDetailId": $scope.receiptDetailsObj.billingDetailId,
			"refundAmount": $scope.refundAmt,
			"refundReason": $scope.refundingReason,
			"transactionType": $scope.receiptDetailsObj.transactionType,
			"createdBy": $scope.user_id,
			"feeStructureArray": $scope.receiptDetailsObj.feeStructureDetailIds
		}
		httpFactory.executePost("updateRefundAmount", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Amount Refunded successfully");
				$scope.refund = false;
				$scope.refundAmount = 0;
				$scope.receiptPaidAmount = $scope.receiptDetailsObj.paidAmount - $scope.refundAmt;
				$scope.receiptDueAmount = Number($scope.receiptDetailsObj.dueAmount) + $scope.refundAmt;
				$("#refundFullAmount").modal("hide");
				$("#printReceiptPreview").modal("hide");
				$scope.getStudentsBySection();
			}
			else {
				alert("Something went wrong");
			}
		});
	}

	$scope.getFeeRefundDetails = function () {
		httpFactory.getResult("getFeeRefundDetails?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.feeRefund = true;
				$scope.feeRefundDetails = data.feeRefundDetails;
				$scope.totalRefundArray = {
					"totalDiscount": 0,
					"totalPrevDueAmount": 0,
					"totalDueAmount": 0,
					"totalNetAmount": 0,
					"totalPaidAmount": 0,
					"totalRefundAmount": 0,
					"totalUpdatedPaidAmount": 0,
					"totalOfTotalAmounts": 0
				};
				for (i = 0; i < $scope.feeRefundDetails.length; i++) {
					for (j = 0; j < $scope.feeRefundDetails[i].receiptArr.length; j++) {
						//						$scope.totalRefundArray.totalDueAmount+=$scope.feeRefundDetails[i].receiptArr[j].dueAmount;
						if ($scope.feeRefundDetails[i].receiptArr[$scope.feeRefundDetails[i].receiptArr.length - 1].receiptId == $scope.feeRefundDetails[i].receiptArr[j].receiptId) {
							$scope.totalRefundArray.totalPrevDueAmount += $scope.feeRefundDetails[i].receiptArr[j].prevDueAmount;
							$scope.totalRefundArray.totalNetAmount += $scope.feeRefundDetails[i].receiptArr[j].netAmount;
							$scope.totalRefundArray.totalOfTotalAmounts += $scope.feeRefundDetails[i].receiptArr[j].totalAmount;
							$scope.totalRefundArray.totalDiscount += $scope.feeRefundDetails[i].receiptArr[j].discount;
							if($scope.feeRefundDetails[i].receiptArr[j].refundArr[$scope.feeRefundDetails[i].receiptArr[j].refundArr.length - 1].updatedPaidAmount==0)
							    $scope.totalRefundArray.totalDueAmount += $scope.feeRefundDetails[i].receiptArr[j].prevDueAmount;
							else
							    $scope.totalRefundArray.totalDueAmount += $scope.feeRefundDetails[i].receiptArr[j].dueAmount;
						}
						for (k = 0; k < $scope.feeRefundDetails[i].receiptArr[j].refundArr.length; k++) {
							if ($scope.feeRefundDetails[i].receiptArr[j].refundArr[$scope.feeRefundDetails[i].receiptArr[j].refundArr.length - 1].refundId == $scope.feeRefundDetails[i].receiptArr[j].refundArr[k].refundId) {
								$scope.totalRefundArray.totalPaidAmount += $scope.feeRefundDetails[i].receiptArr[j].refundArr[k].paidAmount;
								$scope.totalRefundArray.totalUpdatedPaidAmount += $scope.feeRefundDetails[i].receiptArr[j].refundArr[k].updatedPaidAmount;
							}
							$scope.totalRefundArray.totalRefundAmount += $scope.feeRefundDetails[i].receiptArr[j].refundArr[k].refundAmount;
						}
					}

				}
//				$scope.getBranchDetails();
			} else if (data.StatusCode == 300) {
				alert("No Refund Transactions in this section");
				$scope.feeRefundDetails = [];
			} else {
				alert("Something went wrong");
				$scope.feeRefundDetails = [];
			}
		});
	}

	$scope.shareFeeReceipt = function (socialIcon, lang) {
		if (socialIcon == 'gmail') {
			let url = 'https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=&su=' + $scope.pStudentName + " - Fee Receipt Details - "
				+ $scope.pReceiptNumber + '&body=' + message + '&ui=2&tf=1&pli=1';
			window.open(url, 'sharer', 'toolbar=0,status=0,width=648,height=395');
		}
		else if (socialIcon == 'whatsApp') {
			var Msg = "Greetings From " + $scope.branchName + "\n"
				+ "Dear " + $scope.pStudentName + "\n"
				+ "Thank you for the payment of \n"
				+ "Amount : " + $scope.receiptPaidAmount + "\n"
				+ "Receipt id " + $scope.pReceiptNumber + "\n"
				+ "Date : " + $scope.pReceiptDate + "\n"
				+ "Total Fee: " + $scope.netAmount + "\n"
				+ "Total Paid: " + ($scope.netAmount - $scope.receiptDueAmount) + "\n"
				+ "Total Due : " + $scope.receiptDueAmount + "\n"
				+ "Please Contact School Management For Any Queries."
			const receiptDateFormatted = new Date($scope.pReceiptDate).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");
			var params = {
				"messageValues": [$scope.branchName, $scope.pStudentName, $scope.receiptPaidAmount, $scope.pReceiptNumber, receiptDateFormatted, $scope.netAmount, $scope.netAmount - $scope.receiptDueAmount, $scope.receiptDueAmount],
				"schemaName": localStorage.getItem("sname"),
				"studentId": $scope.studentId,
				"branchId": $scope.branchId,
				"messageType": socialIcon,
				"lang": lang
			}
		} else if (socialIcon == 'SMS') {
			var Msg = "Dear " + $scope.pStudentName + ",\n"
				+ "Thank you for the payment of\n"
				+ "Amount: " + $scope.receiptPaidAmount
				+ "\nReceipt id : " + $scope.pReceiptNumber
				+ "\nDate: " + $scope.pReceiptDate
				+ "\nTotal Fee: " + ($scope.feeReceiptDetailsObj.receiptType == 'Fee Receipt' ? $scope.netAmount : ($scope.feeReceiptDetailsObj.receiptType == 'Old Due' ? $scope.totalAmount : $scope.receiptPaidAmount))
				+ "\nTotal Paid: " + ($scope.feeReceiptDetailsObj.receiptType == 'Fee Receipt' ? $scope.netAmount - $scope.receiptDueAmount : ($scope.feeReceiptDetailsObj.receiptType == 'Old Due' ? $scope.totalAmount - $scope.receiptDueAmount : $scope.receiptPaidAmount))
				+ "\nTotal Due : " + ($scope.feeReceiptDetailsObj.receiptType != 'Fine' ? $scope.receiptDueAmount : 0)
				+ "\nPowered by EkaLavya."
			var params = {
				messages: [],
				"schemaName": localStorage.getItem("sname"),
				"studentId": $scope.studentId,
				"branchId": $scope.branchId,
				"messageType": socialIcon,
				"message": Msg
			}
		}
		httpFactory.executePost("shareFeeReceipt", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE)
			} else if (data.StatusCode == 404) {
				alert("Student Phone Number not found");
			} else {
				alert("Something went wrong");
				$scope.feeRefundDetails = [];
			}
		});
	}

	$scope.excelOnClick = function (feeReport) {
		var link = document.createElement('a');
		link.download = $scope.classObj.className+"-"+$scope.sectionObj.sectionName+"-"+"Refund_History";
		link.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(document.getElementById('feeRefundDetails').outerHTML);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}
});