
projectModule.controller('activitiesController', function($scope, $location, commonFactory, httpFactory, $routeParams,Pubnub) {

	$scope.$ = $;
	
	$scope.redirectToActivity=function(){

	    $location.path("/activities");

  }
	$scope.redirectToSets=function(){

	    $location.path("/sets");

	}

$scope.gotoSet = function(){
        $location.path(sessionStorage.getItem("setbk"));
    }

	$scope.flip = function (event){
  var element = event.currentTarget;
  if (element.className === "flipcard") {
    if(element.style.transform == "rotateY(180deg)") {
      element.style.transform = "rotateY(0deg)";
    }
    else {
      element.style.transform = "rotateY(180deg)";
    }
  }
};


	$scope.theText = "";
  $scope.sayIt = function (txt) {
			$scope.theText = txt;
      window.speechSynthesis.speak(new SpeechSynthesisUtterance($scope.theText));
  };

	//$scope.sayIt();
	$scope.gotoLoc= function(loc){
		$location.path(loc);
	}

	$('.carousel-control').click(function(e){
    e.preventDefault();
  });


});
