projectModule.controller('adminStoreContentManagementController', function($scope, $location, commonFactory, httpFactory, $routeParams, $sce) {
    $scope.$ = $;
    $scope.roleId = localStorage.getItem("RD");
    $scope.localDomain = localStorage.getItem("domain");
    $scope.selSubjId = sessionStorage.getItem("selsubId");
    $scope.classId = sessionStorage.getItem("selclassId");
    $scope.SubjName = sessionStorage.getItem("selsubName");
    $scope.courseName = sessionStorage.getItem("selcourseName");
    $scope.className = sessionStorage.getItem("selclassName");
    $scope.schemaName = "ekalavya_store"; 
    $scope.groupList =[];
    $scope.chapQues=false;
    
    $scope.storeContentInit = function() {
        $scope.getChapterTopicsBySubjectChangeques();
    }
    
    $scope.goBackToSelection = function(){
		$location.path("adminStoreContent");
	}
    
    $scope.getChapterTopicsBySubjectChangeques = function(subjectId) {
        console.log("class ID "+$scope.classId);
        console.log("subject ID "+$scope.selSubjId);
        setTimeout(function() {
            if ($scope.classId > 0 && $scope.selSubjId > 0) {
                httpFactory.getResult("getStoreChapterTopicsBySubId?classId=" + $scope.classId + "&subjectId=" + $scope.selSubjId + "&schemaName=" + $scope.schemaName + "&instId="+$scope.instituteId, function(data) {
                    console.log(data);
                    if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                        $scope.chapterListByClassSubject = data.Chaptertopics;
                        $scope.chapterList = data.Chaptertopics;
                        if ($scope.chapterList.length > 0) {
                        	for(var i = 0; i<$scope.chapterList.length; i++){
                        		for(var j = 0; j<$scope.chapterList[i].Topics.length; j++){
                                   if($scope.chapterList[i].Topics[j].isChapterLevel == 1) {
                                	   $scope.chapterList[i]["chapterLevelTopicId"] = $scope.chapterList[i].Topics[j].topicId;
                                	   $scope.chapterList[i].Topics.splice(j,1);
                                   }
                        		}
                        	}
                            $scope.chapterClick($scope.chapterList[0]);
                            var topic = $scope.chapterList[0].Topics[0];
                            $scope.chapterTopicClick($scope.chapterList[0].chapterschemaName, $scope.chapterList[0].Topics[0]);
                            $scope.activeTpcTab = 'video';
                            console.log($scope.chapterListByClassSubject);
                        } else {
                            alert("No Chapters");
                        }
                    } else {
                        alert("No Chapters");
                    }
                });
            } else {
            }
        }, 100)
    }
    
    $scope.chapterClick = function(chapter) {
        $scope.selChapterId = chapter.chapterId;
        $scope.selChpterName = chapter.chapterName;
    }
    
    $scope.chapterTopicClick = function(chapterSCN, topic) {
        if (topic == undefined) {
            $scope.$apply();
        } else {
        	$scope.ques=[];
            $scope.selTopicId = topic.topicId;
            $scope.seltopicName = topic.topicName;
            setTimeout(function() {
                $scope.getTopicVideos();
                $scope.getChapterAnnexure();
                $scope.getQuestionsGroup();
                $scope.$apply();
            }, 500);
        }
        $scope.chapQues=false;
    }
    
    $scope.lviewexpand = true;

    $scope.toogleSide = function() {
        $('.togglesidebar').toggleClass('is-collapsed');
        $('.togglecontent').toggleClass('is-full-width');
        $scope.lviewexpand = !$scope.lviewexpand;
    }

    $scope.lviewstate = true;
    $scope.expandToggle = function(lview) {
        $scope.lviewstate = lview;
    }

    $scope.closePopUp = function() {
        $scope.getQuestionsByTopicId();
    }
    
    $scope.getChapterAnnexure = function() {
        httpFactory.getResult("getChapterSummaryForStore?chapterId=" + $scope.selChapterId + "&subjectId=" + $scope.selSubjId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = data.chapterAnnexure[0];
                console.log($scope.annexureOb);
                $scope.annexureObEdit = data.chapterAnnexure[0];

                $scope.annexContent = $scope.annexureOb.annexureContent;
            } else {
                $scope.annexureOb = {};
                $scope.annexureObEdit = {};
                $scope.annexContent = '';
            }
        });
    }
    
    $scope.annexureOb = {};
    
    $scope.getTopicVideos = function() {
        $scope.videoContent = [];
        $scope.activeVideosCOTab = "PRIMARY";
        httpFactory.getResult("getTopicVideosForStore?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId+"&chapterId=" + $scope.selChapterId+"&courseName="+$scope.courseName+"&instId="+$scope.instituteId+"&subjectId="+$scope.selSubjId, function(data) {
            console.log(data);
            if (data.StatusCode == 200 && data.TopicVideos.length > 0 ) {
					$scope.videoContent = data.TopicVideos;
                if ($scope.videoContent[0] != undefined && $scope.videoContent[0].videoLink != 'NA') {
                    $scope.getVideoPlay($scope.videoContent[0]);
                }
                console.log($scope.videoContent);
            } else {
                $scope.videoContent = [];
                console.log("No Videos");
            }
        });
    }
    
    $scope.getVideoPlay = function(video) {
        console.log(video);
        $scope.videoLinkToPlay = video.videoLink;
        if($scope.videoLinkToPlay.indexOf('youtu') >= 0) {
        	$scope.videoLinkToPlay = "https://www.youtube-nocookie.com/embed/" + $scope.videoLinkToPlay.substr($scope.videoLinkToPlay.lastIndexOf('/') + 1) + "?rel=0&amp;controls=1&amp&amp;showinfo=0&amp;modestbranding=1";
        }
        console.log($scope.videoLinkToPlay);
    }
    
    $scope.trustSrc = function(src) {
        return $sce.trustAsResourceUrl(src);
    }

    $scope.showOnlineDiv = function(tab) {
        $scope.activeTpcTab = tab;
    }
    
    $scope.questionsArray = [];
    $scope.getQuestionsByTopicId = function(groupId) {
        console.log($scope.contentOwner);
        httpFactory.getResult("getQuestionsForStore?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName + "&groupId=" + groupId, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
            	$scope.ques = data.Questions;
            	$scope.activeCOTab = groupId; 
              $scope.coQues = 0;
            } else {}
        });
    }
    
    $scope.viewAnswerForQues = function(quesId) {
        $scope.viewAnswerForQuesId = quesId;
    }

    $scope.showCODiv = function(tab, indx) {
        $scope.activeCOTab = tab;
        console.log($scope.activeCOTab);
        $scope.coQues = indx;
        	$scope.getQuestionsByTopicId(tab);
    }

    $scope.getQuestionsGroup = function() {
        $scope.groupList = [];
        if( $scope.groupList.length == 0){
	        httpFactory.getResult("getQuestionGroupForStore?schemaName=" + $scope.schemaName + "&topicId=" + $scope.selTopicId, function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.QuestionGroups != undefined) {
	            	$scope.groupList = data.QuestionGroups;
	            	if(Object.keys($scope.groupList[0]).length > 0){
	                $scope.getQuestionsByTopicId($scope.groupList[0].groupId);
	            	}
	            }
	        });
        }
    }

    $scope.getQuestionTypesService = function() {
        httpFactory.getResult("getQuestionTypes?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.questionTypeList = data.questionsArray;
            } else {
            }
        });
    }

    $scope.getQuestionTypesService();
    
    $scope.selectedAnswerForTOF = function(opt) {
        if (opt == '1') {
            $scope.TFOption = 'true';
        } else {
            $scope.TFOption = 'false';
        }
        console.log($scope.TFOption);
    }
    
    $scope.getQuestionDomainForStore = function() {
        $scope.domainList = [];
        if( $scope.domainList.length == 0){
	        httpFactory.getResult("getQuestionDomainForStore?schemaName=" + $scope.schemaName, function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.QuestionDomains != undefined) {
	            	$scope.domainList = data.QuestionDomains;
	            }
	        });
        }
    }
    
    $scope.getQuestionDomainKeywords= function(domain) {
        $scope.keywordList = [];
        if( $scope.keywordList.length == 0){
	        httpFactory.getResult("getQuestionDomainKeywords?schemaName=" + $scope.schemaName + "&domainId=" + domain + "&subjectId=" + $scope.selSubjId , function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.DomainKeywords != undefined) {
	            	$scope.keywordList = data.DomainKeywords;
	            }
	        });
        }
    }
    
});
