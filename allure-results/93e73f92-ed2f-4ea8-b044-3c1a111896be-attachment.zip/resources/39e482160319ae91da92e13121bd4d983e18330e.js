projectModule
		.controller(
				'customPushNotificationsController',
				function($scope, $location, commonFactory, httpFactory,
						$routeParams, $route) {
					$scope.$ = $;
					$scope.instituteId = localStorage.getItem("inst_id");
					$scope.userId = localStorage.getItem("userId");
					$scope.schemaName = localStorage.getItem("sname");
					$scope.branchId = localStorage.getItem("bnchId");
					$scope.roleId = localStorage.getItem("RD");

					$scope.allBCCList = [];

					$scope.getAllBranchClassCourseSections = function() {
						httpFactory
								.getResult(
										"getAllBranchClassCourseSections?schemaName="
												+ $scope.schemaName
												+ "&instId="
												+ $scope.instituteId
												+ "&roleId=" + $scope.roleId
												+ "&branchId="
												+ $scope.branchId,
										function(data) {
											console.log(data);
											if (data.StatusCode == '200') {
												$scope.allBCCList = data.collegesInfo;
												for (var i = 0; i < $scope.allBCCList.length; i++) {
													$scope.allBCCList[i]["selected"] = false;
													for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
														$scope.allBCCList[i].courses[j]["selected"] = false;
														for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
															$scope.allBCCList[i].courses[j].classes[k]["selected"] = false;
															for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
																$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"] = false;
															}
														}
													}
												}
											}
										});
					}

					$scope.getAllBranchClassCourseSections();

					$scope.cancel = function() {
						$location.path("rankrPlus");
					}

					$scope.generateStudentObj = function(ob, brInd, crInd,
							clsInd) {
						if (ob == 'stuAll') {
							if (document.getElementById("selectAll").checked == true) {
								for (var i = 0; i < $scope.allBCCList.length; i++) {
									$scope.allBCCList[i].selected = true;
									for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
										$scope.allBCCList[i].courses[j].selected = true;
										for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
											$scope.allBCCList[i].courses[j].classes[k].selected = true;
											for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
												$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = true;
											}
										}
									}
								}
							} else {
								for (var i = 0; i < $scope.allBCCList.length; i++) {
									$scope.allBCCList[i].selected = false;
									for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
										$scope.allBCCList[i].courses[j].selected = false;
										for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
											$scope.allBCCList[i].courses[j].classes[k].selected = false;
											for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
												$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = false;
											}
										}
									}
								}
							}
						} else if (ob == 'branch') {
							if ($scope.allBCCList[brInd].selected == true) {
								$scope.allBCCList[brInd].selected = false;
								for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
									$scope.allBCCList[brInd].courses[j].selected = false;
									for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
										$scope.allBCCList[brInd].courses[j].classes[k].selected = false;
										for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
											$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = false;
										}
									}
								}
							} else {
								$scope.allBCCList[brInd].selected = true;
								for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
									$scope.allBCCList[brInd].courses[j].selected = true;
									for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
										$scope.allBCCList[brInd].courses[j].classes[k].selected = true;
										for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
											$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = true;
										}
									}
								}
							}
							var isBranchFound = 0;
							for (var i = 0; i < $scope.allBCCList.length; i++) {
								if ($scope.allBCCList[i].selected == false) {
									isBranchFound++;
								}
							}
							if (isBranchFound > 0) {
								document.getElementById("selectAll").checked = false;
							} else {
								document.getElementById("selectAll").checked = true;
							}

						} else if (ob == 'course') {
							if ($scope.allBCCList[brInd].courses[crInd].selected == true) {
								$scope.allBCCList[brInd].courses[crInd].selected = false;
								for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
									$scope.allBCCList[brInd].courses[crInd].classes[k].selected = false;
									for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
										$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = false;
									}
								}
							} else {
								$scope.allBCCList[brInd].courses[crInd].selected = true;
								for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
									$scope.allBCCList[brInd].courses[crInd].classes[k].selected = true;
									for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
										$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = true;
									}
								}
							}
							var isCourseFound = 0;
							for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
								if ($scope.allBCCList[brInd].courses[j].selected == false) {
									isCourseFound++;
								}
							}
							if (isCourseFound > 0) {
								$scope.allBCCList[brInd].selected = false;
								document.getElementById("selectAll").checked = false;
							} else {
								$scope.allBCCList[brInd].selected = true;
								document.getElementById("selectAll").checked = true;
							}

						} else if (ob == 'class') {
							if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected == true) {
								for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
									$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = false;
								}
								$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
							} else {
								for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
									$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = true;
								}
								$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
							}
							var isClassFound = 0;
							for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes.length; j++) {
								if ($scope.allBCCList[brInd].courses[crInd].classes[j].selected == true) {
									isClassFound++;
								}
							}
							if (isClassFound == $scope.allBCCList[brInd].courses[crInd].classes.length) {
								$scope.allBCCList[brInd].courses[crInd].selected = true;
								$scope.allBCCList[brInd].selected = true;
								document.getElementById("selectAll").checked = true;
							} else {
								$scope.allBCCList[brInd].courses[crInd].selected = false;
								$scope.allBCCList[brInd].selected = false;
								document.getElementById("selectAll").checked = false;
							}
						}
					}

					$scope.sendNotification = function() {
						$scope.totalAdminArr = [];
						$scope.totalSectionArr = [];
						if ($scope.roleId == 1) {
							var admincheck = document.getElementById("user").value;
							if (admincheck != undefined || admincheck != "") {
								if (document.getElementById("user").value == "Admin") {
									for (var i = 0; i < $scope.allBCCList.length; i++) {
										if ($scope.allBCCList[i].selected == true) {
											$scope.totalAdminArr
													.push($scope.allBCCList[i].branchId);
										}
									}
								} else {
									for (var i = 0; i < $scope.allBCCList.length; i++) {
										for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
											for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
												if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
													var object = {
														"branchId" : $scope.allBCCList[i].branchId,
														"courseId" : $scope.allBCCList[i].courses[j].courseId,
														"classId" : $scope.allBCCList[i].courses[j].classes[k].classId,
													}
													$scope.totalSectionArr
															.push(object);
												}
											}
										}
									}
								}
							}
						} else {
							for (var i = 0; i < $scope.allBCCList.length; i++) {
								for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
									for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
										if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
											var object = {
												"branchId" : $scope.allBCCList[i].branchId,
												"courseId" : $scope.allBCCList[i].courses[j].courseId,
												"classId" : $scope.allBCCList[i].courses[j].classes[k].classId,
											}
											$scope.totalSectionArr.push(object);
										}
									}
								}
							}
						}

						if ($scope.tag == undefined || $scope.tag == "") {
							alert("Select Notification Type You Want to Send");
							return;
						}
						if ($scope.tag == "Update") {
							$scope.notifTitle = "We're Getting Better!";
							$scope.notifMessage = "Update the app to unlock new features";
							$scope.notifFile = "";
						} else if ($scope.title == undefined
								|| $scope.title == ""
								|| $scope.message == undefined
								|| $scope.message == "") {
							alert("Enter Title and Message");
							return;
						} else {
							$scope.notifTitle = document
									.getElementById("title").value;
							$scope.notifMessage = document
									.getElementById("message").value;
							$scope.notifFile = document
									.getElementById("choosenFile").files;
							if ($scope.notifFile.length > 0) {
								if ($scope.notifFile[0].name.contains(".png")
										|| $scope.notifFile[0].name
												.contains(".jpg")
										|| $scope.notifFile[0].name
												.contains(".jpeg")) {
									if ($scope.notifFile[0].size > 1048576) {
										alert("The file should be less than 1MB");
										return;
									}
								} else {
									alert("File not supported. Upload PNG, JPG, JPEG files only");
									return;
								}
							}
						}
						if ($scope.eventTime != null) {
							var today = new Date();
							var eventTime = new Date($scope.eventTime);
							if (eventTime < today) {
								alert("Select schedule time greater than current time");
								return;
							}
						}

						if ($scope.roleId == 2
								|| ($scope.roleId == 1 && admincheck == "Student/Staff")) {
							var studentcheck = document
									.getElementById("studentcheck").checked;
							var staffcheck = document
									.getElementById("staffcheck").checked;
							if (studentcheck == false && staffcheck == false) {
								alert("Please select either Student or Staff");
								return;
							}
						} else if ($scope.roleId == 1
								&& (admincheck == undefined || admincheck == "")) {
							alert("Please select Notify User");
							return;
						}

						if ($scope.totalSectionArr.length == 0
								&& $scope.totalAdminArr.length == 0) {
							alert("Select to whom it needs to apply");
							return;
						}

						var fd = new FormData();
						fd.append("schemaName", $scope.schemaName);
						fd.append("domainName", localStorage.getItem("domain"));
						fd.append("branchId", $scope.branchId);
						fd.append("instituteId", $scope.instituteId);
						fd.append("title", $scope.notifTitle);
						fd.append("message", $scope.notifMessage);
						fd.append("student", studentcheck);
						fd.append("staff", staffcheck);
						fd.append("tag", document.getElementById("tag").value);
						if ($scope.eventTime == undefined
								|| $scope.eventTime == "") {
							fd.append("eventTime", 'null');
						} else {
							fd.append("eventTime", $scope.eventTime);
						}
						if ($scope.totalSectionArr.length > 0) {
							fd.append("branchArr", JSON
									.stringify($scope.totalSectionArr));
						}
						if ($scope.notifFile.length > 0) {
							fd.append("files", $scope.notifFile[0]);
						}
						if ($scope.totalAdminArr.length > 0) {
							fd.append("admin", JSON
									.stringify($scope.totalAdminArr));
						}

						httpFactory
								.executeFileUpload(
										"sendCustomNotifications",
										fd,
										function(data) {
											console.log(data);
											if (data.StatusCode == 200) {
												alert(data.MESSAGE);
												document.getElementById("tag").value = "";
												document
														.getElementById("title").value = "";
												document
														.getElementById("message").value = "";
												document
														.getElementById("choosenFile").value = "";
												document
														.getElementById("eventTime").value = "";
												/*if ($scope.roleId == 2
														|| ($scope.roleId == 1 && admincheck == "Student/Staff")) {
													document
															.getElementById("studentcheck").checked = false;
													document
															.getElementById("staffcheck").checked = false;
												}*/
												$scope.tag = "";
												$scope.title = "";
												$scope.message = "";
												$scope.eventTime = "";
												$scope.user = "";
												/*for (var i = 0; i < $scope.allBCCList.length; i++) {
													$scope.allBCCList[i]["selected"] = false;
													for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
														$scope.allBCCList[i].courses[j]["selected"] = false;
														for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
															$scope.allBCCList[i].courses[j].classes[k]["selected"] = false;
															for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
																$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"] = false;
															}
														}
													}
												}
												document
														.getElementById("selectAll").checked = false;*/
												$scope.changeNotifyUser();
											} else if (data.StatusCode == 300) {
												alert(data.MESSAGE);
											} else {
												alert(data.MESSAGE);
											}

										});
					}
					
					$scope.changeNotifyUser = function(){
						document.getElementById("studentcheck").checked = false;
						document.getElementById("staffcheck").checked = false;
						document.getElementById("selectAll").checked = false;
						for (var i = 0; i < $scope.allBCCList.length; i++) {
							$scope.allBCCList[i]["selected"] = false;
							for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
								$scope.allBCCList[i].courses[j]["selected"] = false;
								for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
									$scope.allBCCList[i].courses[j].classes[k]["selected"] = false;
									for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
										$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"] = false;
									}
								}
							}
						}
					}

					$scope.goToDashbord = function(){
						$location.path("rankrPlus");
					}
				});
