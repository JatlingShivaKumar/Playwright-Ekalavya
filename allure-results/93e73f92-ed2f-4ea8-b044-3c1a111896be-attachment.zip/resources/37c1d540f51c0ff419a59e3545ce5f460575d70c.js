projectModule.controller('examAutoGenerationController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };

 $scope.branchId = localStorage.getItem("bnchId");

$scope.schemaName = localStorage.getItem("sname");
 $scope.initLoad = function(){
   // $scope.getAllBranches();
   $scope.getInstituteTypes();
   //$scope.getSubjectsByCourse();
 }

 $scope.back=function(){
   $location.path("/examType");
 }

 $scope.selectCategory = function(flag) {
   if (flag==0) {
     $location.path("/autoGenerateExamView");
   }
   else if(flag==1){
     $location.path("/soqExamSetupView");
   }
   else if(flag==2){
     $location.path("/maqExamSetupView");
   }
   else if(flag==3){
	 $location.path("/unqExamSetupView");
	}
 }

/* $scope.getInstituteTypes = function(){
 	httpFactory.getResult("getCollegeInstituteTypes?schemaName="+localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function(data){
 		if(data.statusCode == '200'){
 			$scope.instituteTypes = data.data;
 			console.log($scope.instituteTypes);
 		}
 	});
 }*/
 
 $scope.getInstituteTypes = function(){
	 	httpFactory.getResult("getBranchInstituteTypes?schemaName="+localStorage.getItem("sname") + "&branchId=" + $scope.branchId, function(data){
	 		if(data.statusCode == '200'){
	 			$scope.instituteTypes = data.data;
	 			console.log($scope.instituteTypes);
	 			if($scope.instituteTypes.length==1) {
	 				$scope.selectedInst = $scope.instituteTypes[0].instTypeId;
	 			}
	 			$scope.getCourses($scope.selectedInst);
	 		}
	 	});
	 }	
 $scope.getTestCategories = function() {
   $scope.selectedCategoryObj = "";
   $scope.subjectList =[];
   for(var i = 0;i <  $scope.courseList.length;i++){
	   if($scope.courseList[i].courseId == $scope.selectedCourse){
		   $scope.courseName = $scope.courseList[i].courseName;
	   }
   }
   httpFactory.getResult("getTestCategories?instId=" + localStorage.getItem("inst_id") + "&schemaName="+$scope.schemaName +"&courseId=" + $scope.selectedCourse, function(data) {
     console.log(data);
     if (data.STATUS == 'SUCCESS') {
       $scope.categoryList = data.TestCategories;
       console.log($scope.categoryList);
     }
      else {
     }
   });
 }
  $scope.getAllBranches = function() {
    httpFactory.getResult("getAllBranches?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data.collegeBranches);
      if (data.StatusCode == 200) {
          $scope.branchList = data.collegeBranches;
          console.log($scope.branchList);
      } else {
        console.log("No courses");
      }
    });
  }


  $scope.getCourses = function(tag) {
    if (tag=="1") {
      $scope.selectedBranch=localStorage.getItem("bnchId");
    }
    httpFactory.getResult("getClassCoursesByBId?branchId=" + $scope.selectedBranch + "&instType="  +$scope.selectedInst+ "&schemaName="+localStorage.getItem("sname")+"&instId="+$scope.instituteId, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
          $scope.courseList = data.ClassCourses;
          if($scope.courseList.length==1) {
        	  $scope.selectedCourseNew = JSON.stringify($scope.courseList[0]);
        	  $scope.selectedCourse = $scope.courseList[0].courseId;
          }
          console.log($scope.courseList);
        $scope.getTestCategories();
        $scope.getClasses();
      } else {
        console.log("No courses");
      }
    });
  }

  $scope.showCourseByInstType = function(instType){
  		$scope.instTypeOb=instType;

  	httpFactory.getResult("getAllCoursesByInstType?instType=" + $scope.selectedInst + "&schemaName="+localStorage.getItem("sname"), function(data) {
  		console.log(data);
  		$scope.courseList=[];

  		if (data.StatusCode == 200) {
  			$scope.courseList=data.Courses;
  		} else {
  			console.log("No Courses");
  		}
  	});
  }

  $scope.schemaChange = function(){
    $scope.selectedYear = "";
    $scope.selectedSubject = "";
    $scope.selectedChapter = "";
    $scope.selectedTopic = "";
    console.log($scope.selectedSVal);
    if (typeof $scope.selectedSchemaOb == 'string') {
      $scope.selectedSVal = JSON.parse($scope.selectedSchemaOb);
    }else{
      $scope.selectedSVal = $scope.selectedSchemaOb;
    }
    $scope.selectedContentType = $scope.selectedSVal.contentType;
    console.log($scope.selectedSVal);
    console.log($scope.selectedContentType);
  //   if ($scope.selectedSVal.courseId == 0) {
  //     $scope.selectedContentType = "COLLEGE";
  //     $scope.selectedContentSchema = localStorage.getItem("sname");
  //   }else {
  //   // $scope.selectedContentType=$scope.selectedSVal.contentType;
  //   $scope.selectedContentType="EAMCET";
  //
  //   $scope.selectedContentSchema = $scope.selectedSVal.contentSchema;
  // }
    $scope.selectedContentSchema = $scope.selectedSVal.contentSchema;
    console.log($scope.selectedContentType);
    $scope.getSchemaContentOwner();
  }

  $scope.getSchemas = function() {
    // $scope.selectedContentType="";
    // $scope.selectedContentSchema="";
    // $scope.selectedCategoryObj="";
    $scope.subjectList=[];
    httpFactory.getResult("selectContentOwner?schemaName="+$scope.schemaName, function(data) {
      console.log(data);
    if (data.StatusCode == 200) {
      $scope.contentOwnerList=[];
      $scope.contentList = data.ContentOwner;
      console.log($scope.contentList);
      for (var i = 0; i < $scope.contentList.length; i++) {
        console.log($scope.contentList[i].courseId);
        console.log($scope.selectedCourse);
        if ($scope.contentList[i].courseId == $scope.selectedCourse || $scope.contentList[i].courseId==0) {
          $scope.contentOwnerList.push($scope.contentList[i]);

        }
      }
      // $scope.contentOwnerList=data.ContentOwner;
        console.log($scope.contentOwnerList);
    } else {
      // alert('No Courses Defined. ');
    }
    });
  }
  $scope.getSubjectsByCourse = function() {
    // $scope.classId=1;
    httpFactory.getResult("getCourseClassSubjects?schemaName="+localStorage.getItem("sname")+"&classId=" + $scope.classId + "&courseId="+ $scope.selectedCourse+"&branchId="+localStorage.getItem("bnchId"), function(data) {
      console.log(data);
      if (data.STATUS == "SUCCESS") {
        $scope.subjectList = data;
        console.log($scope.subjectList);
        var tmp = []
        for (i = 0; i < data.length; i++) {
          tmp[i] = data[i];
        }
        $scope.yearWiseArray = groupBy(tmp, function(item) {
          return [item.class_id];
        });
        console.log($scope.yearWiseArray);
      } else {}
    });
  }

  $scope.categoryChange = function(category) {
    $scope.showClass = false;
    $scope.showSubject = false;
    $scope.showChapter = false;
    $scope.showTopic = false;

    $scope.categoryObj = JSON.parse($scope.selectedCategoryObj);
    categoryName=$scope.categoryObj.categoryName;
    $scope.isMultipleSub = $scope.categoryObj.multipleSubjects;
    $scope.isSectionAvailable = $scope.categoryObj.sectionAvailable;

    console.log($scope.isMultipleSub);
 $scope.selCatName=categoryName;
    $scope.duration = $scope.categoryObj.duration;
    $scope.correctMarks = $scope.categoryObj.correctMarks;
    $scope.wrongMarks = $scope.categoryObj.wrongMarks;
    $scope.numQuestions = $scope.categoryObj.totalQuestions;
    $scope.totalMarks = parseInt($scope.numQuestions)*parseInt($scope.correctMarks);
    $scope.selectedCategoryId = $scope.categoryObj.categoryId;
    if (categoryName== 'CLASS-WISE') {
      $scope.testType='Y';
    }else{
      $scope.testType=categoryName[0];
    }
    
    if($scope.isSectionAvailable==1){
    	$scope.getJeeTestSections();
    }
    console.log($scope.selectedCategoryObj);
      $scope.getCourseQuestionType();
    $scope.getSchemas();
    $scope.showCategoryFieldsMethod();
  }
  
  
  $scope.getJeeTestSections=function(){
	    httpFactory.getResult("getJeeTestSections?schemaName="+localStorage.getItem("sname")+ "&catId="+ $scope.selectedCategoryId, function(data) {
	      if (data.StatusCode == 200) {
	        $scope.jeeTestSecArr = data.TestSections;
	        console.log($scope.jeeTestSecArr);
	        }
	       else {
	    	   $scope.jeeTestSecArr=[];
	       }
	    });
	  }
  
  $scope.JEETemplateSelect=function(selectedJeeTemplate){
	  	console.log(selectedJeeTemplate);
	  	
	  	$scope.numQuestions=0;
	  	$scope.totalMarks=0;
	  	
	  	if(typeof selectedJeeTemplate=='string')
	  		$scope.selJeeTemplate = JSON.parse(selectedJeeTemplate);
	  	else
	  		$scope.selJeeTemplate = selectedJeeTemplate;
	  	
	  
	  	console.log($scope.selJeeTemplate);
	  	
	  	for(var i = 0;i<$scope.selJeeTemplate.testSectionDetails.length;i++){
	  		
	  		$scope.numQuestions+=parseInt($scope.selJeeTemplate.testSectionDetails[i].numQuestions);
	  		
	  		$scope.totalMarks += (parseInt($scope.selJeeTemplate.testSectionDetails[i].numQuestions) * parseInt($scope.selJeeTemplate.testSectionDetails[i].correctAnswerMarks));
	  		
	  		console.log($scope.totalMarks);
	  	}
  	}
  
  $scope.jeeInfoTemplateSelect=function(jee){
	  
	  console.log(jee);
	  
	  $scope.jeeTemplateDetail = jee.testSectionDetails;
  }
  
  $scope.jeeTemplateInfo=function(){
	  console.log($scope.selJeeTemplate);
	  $("#jeeTemplateInfo").modal("show");
  }

  $scope.getCourseQuestionType=function(){
    httpFactory.getResult("getCourseQuestionType?schemaName="+localStorage.getItem("sname")+ "&courseId="+ $scope.selectedCourse, function(data) {
      if (data.StatusCode == 200) {
        $scope.qTypeList = data.courseQuestionTypes;
        console.log($scope.qTypeList);
        }
       else {

       }
    });
  }
  $scope.showCategoryFieldsMethod = function(){
    if ($scope.selectedCategoryId < 5) {
      $scope.showBox = true;
      // $scope.getClasses();
      $scope.showClsBycrsInstype();
      if ($scope.selectedCategoryId == 1) {
        $scope.showClass = true;
        $scope.showSubject = true;
        $scope.showChapter = true;
        $scope.showTopic = true;
      } else if ($scope.selectedCategoryId == 2) {
        $scope.showClass = true;
        $scope.showSubject = true;
        $scope.showChapter = true;
        $scope.showTopic = false;
    $scope.practiceClass = 0;
    $scope.practiceSubject = 0;
    $scope.practiceChapter = 0;
        $scope.practiceTopic = 0;

      } else if ($scope.selectedCategoryId == 3) {
        $scope.showClass = true;
        $scope.showSubject = true;
        $scope.showChapter = false;
        $scope.showTopic = false;
    $scope.practiceClass = 0;
    $scope.practiceSubject = 0;
        $scope.practiceChapter = 0;
        $scope.practiceTopic = 0;
      } else if ($scope.selectedCategoryId == 4) {
        $scope.showClass = true;
        $scope.showSubject = false;
        $scope.showChapter = false;
        $scope.showTopic = false;
    $scope.practiceClass = 0;
      }
    }else if ( $scope.selCatName=='IIT-FOUNDATION' || $scope.selCatName=='NEET-Foundation' || $scope.selCatName=='CLASS-WISE') {
     $scope.showClsBycrsInstype();
     $scope.showClass = true;
     $scope.showSubject = false;
      $scope.showChapter = false;
      $scope.showTopic = false;
        } else {
      $scope.showClass = false;
      $scope.showSubject = false;
      $scope.showChapter = false;
      $scope.showTopic = false;
      $scope.showBox = true;
      $scope.practiceChapter = 0;
      $scope.practiceTopic = 0;
      $scope.practiceSubject = 0;
    }
  }

  $scope.createTest = function() {

	if(!$scope.testName || !$scope.selectedInst || !$scope.selectedQType || !$scope.selectedSchemaOb){
       alert("Please enter all fields");
	   return true;
	}
	// $scope.practiceClass=1;
    $scope.examFlagType = "auto";
    $scope.testSubject = $scope.practiceSubject;
    $scope.testChapter = $scope.practiceChapter;
    $scope.testTopic = $scope.practiceTopic;
    // $scope.selectedSubject = $scope.practiceSubject;
    $scope.selectedCategory = $scope.categoryObj.categoryId;
    $scope.selectedCategoryName =$scope.categoryObj.categoryName;
    $scope.totalQuestions = $scope.categoryQuestions;
    $scope.studentId=0;

    $scope.user_id = localStorage.getItem("userId");
    $scope.studentId = 0;
    $scope.diffLevel = 1;
    $scope.isActive = 1;

    if ($scope.selectedCategory > 4  && $scope.selCatName=='CLASS-WISE' || $scope.selCatName=='IIT-FOUNDATION' || $scope.selCatName=='NEET-Foundation') {
      $scope.practiceClass = $scope.selectedYear;
      $scope.practiceSubject = 0;
               $scope.practiceChapter = 0;
              $scope.practiceTopic = 0;
    }

    if($scope.selCatName=='EAMCET' || $scope.selCatName=='JEE' || $scope.selCatName=='NEET'){
    	if($scope.selectedInst==1 || $scope.selectedInst=='1')
              $scope.practiceClass = 2;
    	else
    		$scope.practiceClass=2;
    	
              $scope.practiceSubject = 0;
                       $scope.practiceChapter = 0;
                      $scope.practiceTopic = 0;
    }


    if ($scope.selectedCategory <=4) {

    if ($scope.selectedCategory==1) {
      if(!$scope.selectedYear || !$scope.selectedSubject || !$scope.selectedChapter || !$scope.selectedTopic){
          alert("Please enter all fields");
          return;
        }
        $scope.practiceClass = $scope.selectedYear;
        $scope.practiceSubject = $scope.selectedSubject;
        $scope.practiceChapter = $scope.selectedChapter;
        $scope.practiceTopic = $scope.selectedTopic;
    } else if ($scope.selectedCategory==2) {
        if(!$scope.selectedYear || !$scope.selectedSubject || !$scope.selectedChapter){
            alert("Please enter all fields");
            return;
          }
          $scope.practiceClass = $scope.selectedYear;
          $scope.practiceSubject = $scope.selectedSubject;
          $scope.practiceChapter = $scope.selectedChapter;
          $scope.practiceTopic = 0;
      }else if ($scope.selectedCategory==3) {
          if(!$scope.selectedYear || !$scope.selectedSubject){
              alert("Please enter all fields");
              return;
            }
            $scope.practiceClass = $scope.selectedYear;
            $scope.practiceSubject = $scope.selectedSubject;
            $scope.practiceChapter = 0;
            $scope.practiceTopic = 0;
        }else if ($scope.selectedCategory==4) {
          if(!$scope.selectedYear){
              alert("Please enter all fields");
              return;
            }
          $scope.practiceClass = $scope.selectedYear;
          $scope.practiceSubject = 0;
          $scope.practiceChapter = 0;
          $scope.practiceTopic = 0;
            if(!$scope.practiceClass){
                alert("Please enter all fields");
                return;
              }
          }
          $scope.saveTest();
  }else{
    $scope.saveTest();

  }
// }
}

  $scope.getClasses = function() {
  httpFactory.getResult("getAllClasses?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname"), function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
        $scope.classList = data.Classes;
    } else {
      console.log("No classes");
    }
  });
}

$scope.getClassSubjects=function(){
  $scope.getSubjectsbyClassCourse();
}

//get subjects by tempClassSecId
$scope.getSubjectsbyClassCourse = function() {

  httpFactory.getResult("getCourseClassSubjects?classId=" + $scope.selectedYear + "&courseId=" + $scope.selectedCourse + "&schemaName="+localStorage.getItem("sname")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.subjectListByCourseClass = data.Classes;
      console.log($scope.subjectListByCourseClass);
  $scope.chapterListByClassSubject = [];
    } else {
      // alert('No Courses Defined. ');
    }
  });
}
 //get chapters by subject_id
//
//  $scope.getChaptersBySubjectID = function() {
//  if($scope.selectedSubject != null ){
//    httpFactory.getResult("getChaptersBySubjectID?subjectId=" + $scope.selectedSubject + "&classId=" + $scope.selectedYear + "&chapterOwner="+ $scope.selectedSchema + "&schemaName="+localStorage.getItem("sname") , function(data) {
//      console.log(data);
//      if (data.StatusCode==200) {
//        $scope.chapterListByClassSubject = data.Chapters;
//      } else {
//      }
//    });
//  }
// }
//

	$scope.getChapterTopicsBySubjectChange = function(subjectId){
		var contentType = $scope.courseName+","+$scope.selectedContentType;
		httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selectedYear+ "&subjectId="+$scope.selectedSubject+"&schemaName="+localStorage.getItem("sname")+"&contentOwner=CEDZ,COLLEGE&contentType="+contentType+"&branchId="+localStorage.getItem("bnchId")+"&courseId="+$scope.selectedCourse+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				$scope.chapterListByClassSubject = data.Chaptertopics;
				$scope.chapterOwner = data.Chaptertopics[0].chapterOwner;
				console.log($scope.chapterListByClassSubject);
			}
			 else {
			}
		});
		$scope.selectQuestionRepo();
	}

$scope.cancel = function(){
  $location.path("/examType");
}


  //get topics by chapterid
  $scope.getTopicByChapterId = function() {
  if($scope.selectedSubject != null ){
	  var contentType = $scope.courseName+","+$scope.selectedContentType;
    httpFactory.getResult("getTopicByChapterId?chapterId=" + $scope.selectedChapter + "&schemaName=" +localStorage.getItem("sname") + "&courseId="+$scope.selectedCourse+"&contentType="+contentType , function(data) {
      console.log(data);
      if (data.StatusCode==200) {
        $scope.topicList = data.Topics;

      } else {
        // alert('No Courses Defined. ');
      }
    });
  }
 }
  
  $scope.setTopicId = function() {
	  debugger;
	   $scope.practiceTopic = $scope.practiceTopic;
	   $scope.topicId = $scope.selectedTopic.topicId;
	   $scope.topicOwner = $scope.selectedTopic.topicOwner;
	   $scope.selectQuestionRepo();
	  }
   $scope.selectQuestionRepo = function(){
	  if($scope.topicOwner == undefined)
	       $scope.questionRepo = $scope.selectedContentSchema;
      else if($scope.topicOwner == "CEDZ")
    	  $scope.questionRepo = $scope.selectedContentSchema;
      else
    	  $scope.questionRepo = localStorage.getItem("sname");  
     }

  $scope.saveTest = function() {
	  
	  
	  
    var testParams = {
        "testName": $scope.testName,
        "testCreationType": "AGT",
        "testCategory": $scope.categoryObj.categoryId,
        "testType": $scope.selectedContentType,//questionBank
        "numQuestions": $scope.numQuestions,
        "diffLevel":'1',
        "duration":$scope.duration,
        "courseId":$scope.selectedCourse,
        "correctMarks": $scope.correctMarks,
        "wrongMarks": $scope.wrongMarks,
        "createdBy": $scope.user_id,
        "schemaName":localStorage.getItem("sname"),
         "isActive": 1,
         "repo":$scope.questionRepo,
         // "classId":1,
         "totalMarks":$scope.totalMarks,
         "sectionAvailable":$scope.isSectionAvailable,
         "branchId":localStorage.getItem("bnchId"),
          "isActive": 1,
        "testDetails": [
      ]
	};
    
    console.log(testParams);
    if($scope.isSectionAvailable==1){
//    	testParams["section_marks_available"]=$scope.isSectionAvailable;
    	testParams["jeeSectionTemplateName"]=$scope.selJeeTemplate.templateName;
    }

    console.log(testParams);
    httpFactory.executePost("createTest", testParams, function(data) {
      console.log(data);
      if (data.STATUS == 'SUCCESS') {
        // $scope.selectedCategoryName="CLASS-WISE";
        $scope.examFlagType="auto";
        $scope.testId = data.testId;
        if ($scope.selectedCategoryName == "CLASS-WISE") {
          $scope.testType = "Y";
          $scope.practiceSubject = 0;
          $scope.practiceChapter = 0;
          $scope.practiceTopic = 0;
        } else {
          $scope.testType = $scope.selectedCategoryName[0];
        }
        if ($scope.examFlagType == "auto") {
          $scope.getTestQuestions();
        } else {
        }
      } else {
        alert('There was a problem saving test. Please try again later.');
        // $location.path("/exams");
      }
    });
  }
  $scope.showClsBycrsInstype=function(){
  	httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&courseId="+$scope.selectedCourse+ "&schemaName="+localStorage.getItem("sname"), function(data) {
  		console.log(data);
  		$scope.classList=[];
  		if (data.StatusCode == 200) {
        $scope.classList = data.Classes;
  			// console.log($scope.clsListCrsInstType);
        var classes = data.Classes;
        $scope.classList =[];
         for(var i =0;i<classes.length ;i++){
         	if(classes[i].isActive == 1){
         		$scope.classList.push(classes[i]);
         	}
         }
  		} else {
  			console.log("No Courses");
  		}
  	});
  }

  $scope.questionTypeChange=function(qType){
      console.log(qType);
    $scope.qTypeobj=JSON.parse(qType);
    console.log($scope.qTypeobj);
    console.log($scope.qTypeobj.contentOwnerName);
    $scope.selectedContentOwner = $scope.qTypeobj.contentOwnerName;
    // $scope.selectedContentType = $scope.qType.contentType;
    console.log($scope.selectedContentOwner);
    console.log($scope.selectedContentType);
  }

  $scope.getTestQuestions = function() {
    // $scope.testCourse=$scope.practiceCourse;
    $scope.testCourse=$scope.selectedCourse;
    $scope.testSubject=$scope.practiceSubject;
    $scope.testChapter=$scope.practiceChapter;
    $scope.testTopic=$scope.practiceTopic;
    if($scope.topicId == undefined)
    	$scope.topicId = $scope.testTopic;
    $scope.studentId=0;
    $scope.schemaName=localStorage.getItem("sname");
    // $scope.selectedSchema = "CEDZ";
    //sample branchId
    // $scope.branchId=6;

    console.log($scope.qTypeList);
    console.log($scope.selectedContentOwner);
    $scope.testParams = {
      "testId":$scope.testId,
      "testType": $scope.selectedCategoryId,
      "testClass": $scope.practiceClass,
      "testCourse": $scope.testCourse,
      "testSubject": $scope.testSubject,
      "testChapter": $scope.testChapter,
      "testTopic": $scope.topicId,
      "studentId": $scope.studentId,
      "contentOwner":$scope.selectedContentOwner,
      "schemaName":$scope.schemaName,
      "testCreationType":"AGT",
      "multipleSubjects":$scope.isMultipleSub,
      "questionType":$scope.selectedContentType,
      "collegeSchemaName":$scope.schemaName,
      "branchId":localStorage.getItem("bnchId"),
      "sectionAvailable":$scope.isSectionAvailable,
      "questionRepoObj": [
          {
              "repo":$scope.schemaName
          },
      ]
    }

    console.log($scope.testParams);
    httpFactory.executePost("autoGeneratePracticeTestQuestions", $scope.testParams, function(data) {
      $("#divLoading").removeClass('hide').addClass('show');
      console.log(data);
      if (data.STATUS=='SUCCESS') {
        $scope.testView = false;
        $scope.questionList = data.TestQuestions;
        $scope.subjectWiseList = [];
        $scope.subjectArr = {}
        counter = 0;
        var subjectCount = 0;
        var tmp = []
        for (i = 0; i < $scope.questionList.length; i++) {
          tmp[i] = $scope.questionList[i];
        }
        $scope.subjectWiseArray = groupBy(tmp, function(item) {
          return [item.subject_group];
        });

        if ($scope.examFlagType == "auto") {
          $scope.showPreviewPage();
          $location.path("publishTest/"+ $scope.testId + "/" +localStorage.getItem("bnchId")+"/publish");
        }
        $scope.getBranchCourseClassForTestAssignement();
      } else {
        alert('No Data Found.')
        $scope.closeModal();
       // $location.path("");
        $("#divLoading").removeClass('show').addClass('hide');

      }
    });
    // $scope.getSections();
  }

  $scope.getBranchCourseClassForTestAssignement = function(){
    httpFactory.getResult("getAllBranchClassCourseSections?schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id") , function(data) {
      console.log(data);
      if (data.STATUS == 'SUCCESS') {
        $scope.sectionList = data;
        console.log($scope.sectionList);
      } else {
      }
    });
  }

  $scope.getSchemaContentOwner = function(){
    httpFactory.getResult("getSchemaContentOwner?schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.schemaContent=[];
        $scope.schemaContent = data.schemaContent;
        console.log($scope.schemaContent);
        }
      else {
        console.log("No ContentList");
      }
    });
  }

  $scope.showPreviewPage = function() {
    $scope.showFirst = false;
    $scope.showCategory = false;
    $scope.showAssignment = false;
    $scope.showManual = false;
    $scope.generate = false;
    $scope.configComplete = true;
    $scope.showPreview = true;
    // $("#divLoading").removeClass('show').addClass('hide');
  }

  function groupBy(array, f) {
    console.log(array);
    var groups = {};
    array.forEach(function(o) {
      var group = JSON.stringify(f(o));
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });
    return Object.keys(groups).map(function(group) {
      return groups[group];
    })
  }
  
  
  $scope.showClasssByCoursesInstype=function(){
	  if (typeof $scope.selectedCourseNew=='string')
		  $scope.courses = JSON.parse($scope.selectedCourseNew);
	  else
		  $scope.courses=$scope.selectedCourseNew;
		  $scope.selectedCourse=$scope.courses.courseId;
	  	httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&courseId="+$scope.courses.courseId + "&schemaName="+localStorage.getItem("sname"), function(data) {
	  		console.log(data);
	  		$scope.classList=[];
	  		if (data.StatusCode == 200) {
	        $scope.classList = data.Classes;
	  			// console.log($scope.clsListCrsInstType);
	        var classes = data.Classes;
	        $scope.classList =[];
	         for(var i =0;i<classes.length ;i++){
	         	if(classes[i].isActive == 1){
	         		$scope.classList.push(classes[i]);
	         	}
	         }
	  		} else {
	  			console.log("No Courses");
	  		}
	  	});
	  }
  $scope.getSectionsByClass = function() {
      $scope.allSectionslist = [];
      $scope.sectionStudents = [];
      if (typeof $scope.selectedYear=='string')
  		$scope.classes = JSON.parse($scope.selectedYear);
  		else
  		$scope.classes=$scope.selectedYear;
      httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&classCourseId=" + $scope.classes.classCourseId, function(data) {
          console.log(data);
          if (data.StatusCode == 200) {
              $scope.allSectionslist = data.Sections;
          } else if (data.StatusCode == 300){
              alert("No Sections");
          }
      });
      $scope.getAllCourseClassSubjects();
  }

  
  $scope.getAllCourseClassSubjects=function(){
		httpFactory.getResult("getAllCourseClassSubjects?courseId="+$scope.courses.courseId+"&classId="+$scope.classes.classId+"&schemaName="+$scope.schemaName+ "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.generalSubj = [];
				$scope.electiveSubj = [];
					$scope.subjList = data.Subjects;
					for (var i = 0; i < $scope.subjList.length; i++) {
						if ($scope.subjList[i].electiveGroupId == 0) {
							for (var k = 0; k < $scope.subjList[i].subjects.length; k++) {
							$scope.subjList[i].subjects[k]["isElective"]="0";
							$scope.generalSubj.push($scope.subjList[i].subjects[k]);
						}
					}else{
							$scope.electiveSubj.push($scope.subjList[i]);
						}
					}
					for (var k = 0; k < $scope.electiveSubj.length; k++) {
						for (var l = 0; l < $scope.electiveSubj[k].subjects.length; l++) {
						console.log($scope.electiveSubj[k].subjects[l]);
						$scope.electiveSubj[k].subjects[l]["electiveGroupName"]=$scope.electiveSubj[k].electiveGroupName;
						$scope.electiveSubj[k].subjects[l]["electiveGroupId"]=$scope.electiveSubj[k].electiveGroupId;
						$scope.electiveSubj[k].subjects[l]["isElective"]=$scope.electiveSubj[k].isElective;
						$scope.generalSubj.push($scope.electiveSubj[k].subjects[l]);
					}
				}
		}
			
		});
	}
  $scope.selectedSubjectChange=function(subj,isElective){
		console.log(subj);
		if (typeof subj=='string')
		$scope.selSubj = JSON.parse(subj);
		else
		$scope.selSubj=subj;

		$scope.isElectiveVal = $scope.selSubj.isElective;;
		$scope.selectedSubjId=$scope.selSubj.subjectId;
		$scope.selectedSubjectName = $scope.selSubj.subjectName;
		$scope.getChapterTopicsBySelectedSubject($scope.selSubj);
	}
  
  $scope.getChapterTopicsBySelectedSubject = function(selSubj){
		console.log(selSubj);
		var contentType = $scope.courses.courseName+","+selSubj.contentType;
		var contentOwner = "CEDZ,"+"COLLEGE";
		httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.classes.classId + "&subjectId="+$scope.selectedSubjId+"&schemaName="+$scope.schemaName+"&contentOwner="+contentOwner+"&contentType="+contentType+"&branchId="+$scope.branchId+"&courseId="+$scope.courses.courseId+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				$scope.chapterListBySub = data.Chaptertopics;
				console.log($scope.chapterListBySub);
			}
		});
	}
  
    $scope.createManualTest = function(){
    	$scope.submissionDate = document.getElementById("submissionDate").value;
    	if(!$scope.testName || !$scope.selectedInst || !$scope.chapters || !$scope.totalMarks || !$scope.submissionDate){
    	       alert("Please enter all fields");
    		   return true;
    		}
        var files = document.getElementById("choosenQPFile").files;
		if(files[0] == undefined){
		alert("UPLOAD QUESTION PAPER");
			return true;
		}
    	$scope.selectedSecList=[];
  	  for(i = 0;i<$scope.selectedSectionList.length;i++){
  		  $scope.selectedSecList.push($scope.selectedSectionList[i].sectionId)
  	  }
    	var testParams = {
    	        "testName": $scope.testName,
    	        "instId"  : localStorage.getItem("inst_id"),
    	        "courseId":$scope.courses.courseId,
    	        "branchId":localStorage.getItem("bnchId"),
    	        "classId" :$scope.classes.classId,
    	        "sectionList" : $scope.selectedSecList,
    	        "subjectId" :$scope.selectedSubjId,
    	        "chapterList" : $scope.chapters,
    	        "createdBy": $scope.user_id,
    	        "schemaName":localStorage.getItem("sname"),
    	         "isActive": "1",
    	         "totalMarks":$scope.totalMarks,
    	         "submissionDate" : $scope.submissionDate
    	         
    		};
        httpFactory.executePost("createManualTest", testParams, function(data) {
            console.log(data);
            //$location.path("uploadQuesPaper");
            if (data.STATUS == 'SUCCESS') {
            	alert("Exam Created Successfully");
            	$scope.manualTestId = data.manualTestId;
            	$scope.uploadQP();
            	$location.path("/exams");
              } else {
              alert('There was a problem saving test. Please try again later.');
              // $location.path("/exams");
            }
          });
    }
    
  
    $scope.selectedSectionList = [];
	$scope.updateSelectedSectionList = function(){
		$scope.selectedSectionList =[];
		for(var i=0; i<document.getElementsByName('secL').length;i++){
			if(document.getElementsByName('secL')[i].checked == true){
				$scope.selectedSectionList.push(JSON.parse(document.getElementsByName('secL')[i].value));
			}

		}
	}
	
	$scope.selectedChapterList =[];
	$scope.updateSelectedChapterList = function(){
		$scope.selectedChapterList =[];
		for(var i=0; i<document.getElementsByName('chapL').length;i++){
			if(document.getElementsByName('chapL')[i].checked == true){
				$scope.selectedChapterList.push(JSON.parse(document.getElementsByName('chapL')[i].value));
			}

		}
	}
	
	$scope.uploadQP = function(){
		var files = document.getElementById("choosenQPFile").files;
		if(files[0] == undefined){
			return true;
		}
		console.log(files);
		var fd = new FormData();
		fd.append("QPID", $scope.manualTestId);
		fd.append("schemaName",$scope.schemaName)
		for(var i=0; i<files.length; i++){

			fd.append("file", files[i]);
		}
		httpFactory.executeFileUpload("uploadQuestionPaper", fd, function(data) {
			console.log(data);
			document.getElementById("choosenFile").value = "";
		});
	}
    
 });
