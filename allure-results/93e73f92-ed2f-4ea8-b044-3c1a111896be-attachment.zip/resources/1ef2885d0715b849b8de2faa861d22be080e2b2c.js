projectModule.controller('staffAttendanceController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
	 $scope.$ = $;
	 $scope.instituteId = localStorage.getItem("inst_id");
	 $scope.userId = localStorage.getItem("userId");
	 $scope.absentStaffList = [];
	 var requestParams = {
	   "m_inst_id": $scope.instituteId
	 };

	 $scope.schemaName=localStorage.getItem("sname");
	 $scope.sectionId=$routeParams.secId;
	 $scope.branchId=localStorage.getItem("bnchId");
	 var date = new Date();
	 $scope.todayDate=date.getDate();
	 console.log($scope.todayDate);
	$scope.todayAttendenceFlag = false;
	$scope.isAttendanceTaken = true;
	$scope.staffAttendanceReportId = "";



	//getStaffForAttendanceAnalysis
	$scope.totalStaffList = [];
	$scope.staffTotalLRs = "";
	$scope.getStaffList = function(){
		httpFactory.getResult("getStaffForAttendanceAnalysis?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.totalStaffList = data.staffForAttendance;
				$scope.staffTotalLRs = data.leaveRequests;
				$scope.selectStaffDetails($scope.totalStaffList[0]);

				if($scope.staffLeaveReqForDayList != undefined && $scope.staffLeaveReqForDayList.length > 0){
					for(var j=0;j<$scope.totalStaffList.length;j++){
						for(var k=0; k<$scope.staffLeaveReqForDayList.length; k++){
							if($scope.totalStaffList[j].userId == $scope.staffLeaveReqForDayList[k].staffId){
								$scope.totalStaffList[j].staffLeaveReq = $scope.staffLeaveReqForDayList[k];
								break;
							}
						}
					}
				}
				if($scope.absentStaffListForToday != undefined && $scope.absentStaffListForToday.length > 0){
					for(var j=0;j<$scope.totalStaffList.length;j++){
						for(var k=0; k<$scope.absentStaffListForToday.length; k++){
							if($scope.totalStaffList[j].userId == $scope.absentStaffListForToday[k].userId){
								$scope.totalStaffList[j].staffLeaveReason = $scope.absentStaffListForToday[k].attendanceType;
								break;
							}
						}
					}
				}
					for(var i=0; i<$scope.totalStaffList.length; i++){
	          if($scope.totalStaffList[i].profilePic == 'NA'){
	            $scope.totalStaffList[i].profilePicPath = "";
	          }
	          else{
	            $scope.totalStaffList[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/userProfileDownload?filePath="+$scope.totalStaffList[i].profilePic;
	          }
	        }

			}
			else{
				$scope.totalStaffList = [];
			}


		console.log($scope.totalStaffList);
		});
	}


	$scope.selectedStaffMember = {};
	$scope.selectStaffDetails = function(stf){
		$scope.selectedStaffMember = stf;
		$scope.getStaffAttendanceForAnalysis();
		$scope.getStaffOverallAttendance();
	}

	$scope.openStaffAttendace = function(){
		$("#takeAttendance").modal("show");
	}
	$scope.openStaffAttendaceHistory = function(){
		$scope.activeRegisterView = 'monthView';
		$("#attendanceHistory").modal("show");
	}

	$scope.getTotalLeaveRequestCountByDate = function(){
		var date = new Date();
		var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
		console.log(ndate);
		httpFactory.getResult("getStaffLeaveRequestInfo?userId="+$scope.selectedStaffMember.userId+"&schemaName="+$scope.schemaName+"&date="+ndate, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {

				//$scope.
			  //$scope.totalLeaveReqCount = data.totalLeaveReqCount;
			}
			else{
				//$scope.totalLeaveReqCount = "-";
			}
		});
	}

	$scope.getAbsentStaff=function(){
		httpFactory.getResult("getAbsentStaffByMonth?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&year="+$scope.getViewYear+"&month="+$scope.getViewMonthNumber, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.absentStaffList = data.staffAttendanceArray;
			}
			else{
				$scope.absentStaffList = [];
			}
		});
		//$scope.getSectionDayAttendanceReport();
	}
	$scope.absentStaffListForToday = [];
	$scope.absentStaffForTodayCount = 0;
	$scope.getAbsentStaffForToday=function(){
		var date = new Date();
		var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
		console.log(ndate);
		httpFactory.getResult("getAbsentStaffByMonth?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&currentDate="+ndate, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.absentStaffForTodayCount = 0;
				$scope.absentStaffListForToday = data.staffAttendanceArray[0].staffList;
//				for(var i=0;i<$scope.absentStaffListForToday.length; i++){
//					if($scope.absentStaffListForToday[i].attendanceType != "L"){
//						$scope.absentStaffForTodayCount++;
//					}
//				}
			}
		});
		//$scope.getSectionDayAttendanceReport();
	}
	$scope.getStaffAttendanceForAnalysis=function(){
		httpFactory.getResult("getStaffAttendanceForAnalysis?schemaName="+$scope.schemaName+"&userId="+$scope.selectedStaffMember.userId+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.staffMonthWiseAttendance = data.staffMonthWiseAttendance;
			}
		});

	}
	$scope.staffYearWiseAttendanceData = [100,0,0];
	$scope.staffYearWiseAttendanceLabels = ["Present - Late","Absent"];
	$scope.staffYearWiseAttendanceColours = ['#8BC34A','#E76959','#FFC108'];
	$scope.staffYearWiseAttendanceoptions = {
		legend: {
			display: false,
		}
	};
	$scope.getStaffOverallAttendance=function(){
		httpFactory.getResult("getStaffOverallAttendance?schemaName="+$scope.schemaName+"&userId="+$scope.selectedStaffMember.userId+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.staffYearWiseAttendanceData = [Number(data.staffPresentDaysPercentage),Number(data.staffLeavePercentage)];
				$scope.staffYearWiseAttendanceData1 = [Number(data.staffPresentDaysPercentage),Number(data.staffLeavePercentage),Number(data.staffLatePercentage)];

			}
			else{
				$scope.staffYearWiseAttendanceData = [100,0,0];
				$scope.staffYearWiseAttendanceData1 = [0,0,0];

			}
			console.log($scope.staffYearWiseAttendanceData);
		});
		//$scope.getSectionDayAttendanceReport();
	}


	$scope.getStaffDayAttendanceReport=function(){
		var date = new Date();
		var nmonth = date.getMonth()+1;
		if(nmonth < 10){
			nmonth = "0"+nmonth;
		}
		var ndate = date.getFullYear()+"-"+nmonth+"-"+$scope.todayDate;
		console.log(ndate);

		httpFactory.getResult("getStaffDayAttendanceReport?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&currentDate="+ndate, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.staffAttendanceReportId = data.staffAttendanceReportId;
				$scope.isAttendanceTaken = false;
				$scope.todayAttendenceFlag = true;
				$scope.absentStaffForTodayCount=data.absentCount;
			}else{
				$scope.staffAttendanceReportId = "";
				$scope.isAttendanceTaken = true;
				$scope.todayAttendenceFlag = false;
			}
		});
	}

	$scope.staffLeaveReqForDayList  = [];
	$scope.getStffLeaveRequestsByDate=function(){
		var date = new Date();
		var nmonth = date.getMonth()+1;
		if(nmonth < 10){
			nmonth = "0"+nmonth;
		}
		var ndate = date.getFullYear()+"-"+nmonth+"-"+$scope.todayDate;
		console.log(ndate);

		httpFactory.getResult("getStffLeaveRequestsByDate?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&date="+ndate, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.staffLeaveReqForDayList = data.staffLeaveReq;
			}else{
				$scope.staffLeaveReqForDayList  = [];
			}
		});
	}

	$scope.openLeavePopup = function(){
		$("#allLeaveRequests").modal("show");
	}

	$scope.getTotalLeaveRequestsDetailsByDate = function(){
		$("#allIndivLeaveRequests").modal("show");
	}

	$scope.closeTotIndiv = function(){
		$("#allIndivLeaveRequests").modal("hide");
	}

	$scope.updateStaffLeaveRequestIndiv = function(slrId, isApprovedstat, adminComment){

		var teachComments = "";
		if(adminComment == undefined){
			teachComments = "";
		}
		else{
			teachComments = adminComment;
		}
		var params = {
			"schemaName" :$scope.schemaName,
			"updatedBy":$scope.userId,
			"updateLeaveReq":
			[
				{
					"staffLeaveReqId":slrId,
					"isApproved":isApprovedstat,
					"updatedBy":$scope.userId,
					"comments":teachComments
				}
			]
		};
		console.log(params);
		httpFactory.executePost("updateStaffLeaveRequest", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.selectedStaffMember.staffLeaveReq.isApproved = isApprovedstat;
				for(var i=0; i< $scope.staffLeaveReqForDayList.length; i++){
					if($scope.staffLeaveReqForDayList[i].staffLeaveReqId == slrId){
						$scope.staffLeaveReqForDayList[i].isApproved = isApprovedstat;
					}
				}

				alert("sucesfully changed");
			}
			else{

				alert("Please try agian after some time");
			}
		});

	}



		$scope.updateStaffLeaveRequest = function(slrId, isApprovedstat, adminComment){

			var teachComments = "";
			if(adminComment == undefined){
				teachComments = "";
			}
			else{
				teachComments = adminComment;
			}
			var params = {
				"schemaName" :$scope.schemaName,
				"updatedBy":$scope.userId,
				"updateLeaveReq":
				[
					{
						"staffLeaveReqId":slrId,
						"isApproved":isApprovedstat,
						"updatedBy":$scope.userId,
						"comments":teachComments
					}
				]
			};
			console.log(params);
			httpFactory.executePost("updateStaffLeaveRequest", params, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
					for(var i=0; i< $scope.staffLeaveReqForDayList.length; i++){
						if($scope.staffLeaveReqForDayList[i].staffLeaveReqId == slrId){
							$scope.staffLeaveReqForDayList[i].isApproved = isApprovedstat;
						}
					}

				  alert("sucesfully changed");
				}
				else{

					alert("Please try agian after some time");
				}
			});

		}


	$scope.getStffLeaveRequestsByDate();
	$scope.getAbsentStaffForToday();
	$scope.getStaffDayAttendanceReport();

	$scope.getStaffList();


	$scope.checkDayLeaveObj = {
	  "leaveFrom":"NA",
	  "LeaveTo":"NA",
	  "reason":"NA",
	  "description":"NA",
		"leaveRequestStatus":"0",
	};
	$scope.checkDayLeaveFortoday = function(dt){
	  $scope.checkDayLeaveObj = {};
	  //var date = new Date();
	  var nmonth = $scope.getViewMonthNumber;
	  if(nmonth < 10){
	    nmonth = "0"+nmonth;
	  }
	  var ndate = $scope.getViewYear+"-"+nmonth+"-"+dt.date;
	  console.log(ndate);
	    	httpFactory.getResult("getStaffLeaveRequestInfo?schemaName="+$scope.schemaName+"&userId="+ $scope.selectedStuObjAbsent.userId+"&date="+ndate ,function(data){
	        if(data.StatusCode == "200"){
	          $scope.checkDayLeaveObj = {
	            "leaveFrom":data.leaveFrom,
	            "LeaveTo":data.LeaveTo,
	            "reason":data.reason,
	            "description":data.description,
							"leaveRequestStatus":data.leaveRequestStatus,
	          }
	        }else{
	          $scope.checkDayLeaveObj = {
	            "leaveFrom":"NA",
	            "LeaveTo":"NA",
	            "reason":"NA",
	            "description":"NA",
							"leaveRequestStatus":"0",
	          }
	        }
	      });
	}
 $scope.attendenceListView = [];
 $scope.weekday = new Array(7);
 $scope.weekday[0] = "Sun";
 $scope.weekday[1] = "Mon";
 $scope.weekday[2] = "Tue";
 $scope.weekday[3] = "Wed";
 $scope.weekday[4] = "Thu";
 $scope.weekday[5] = "Fri";
 $scope.weekday[6] = "Sat";
 $scope.cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
 $scope.getViewMonth = "";
 $scope.getViewYear = "";
 $scope.getViewMonthNumber = 0;
 $scope.generateCalenderAttendenceObj = [];
 $scope.presentMonthFlag = true;
 $scope.nextMonthFlag = false;


 $scope.getCurrentAcademicYear=function(){

	 httpFactory.getResult("getCurrentAcademicYear?schemaName="+$scope.schemaName, function(data) {
		 console.log(data);
		 if (data.StatusCode == 200) {

		 var startArr = data.startDate.split("-");
		 var endArr = data.endDate.split("-");

		 console.log(startArr);
		 console.log(endArr);
		 console.log(parseInt(startArr[1]));

		 console.log($scope.cal_months_labels[parseInt(startArr[1])]);

		 var str1 = $scope.cal_months_labels[parseInt(startArr[1])]+" "+startArr[0];
		 var str2 = $scope.cal_months_labels[parseInt(endArr[1])]+" "+endArr[0];
		 console.log(diff(str1, str2));
		 $scope.academicMonthArr=diff(str1,str2);
		 console.log($scope.academicMonthArr);
		 }else{
		 }
	 });
 }


 function diff(from, to) {
		 var arr = [];
		 var datFrom = new Date('1 ' + from);
		 var datTo = new Date('1 ' + to);
		 var fromYear =  datFrom.getFullYear();
		 var toYear =  datTo.getFullYear();
		 var diffYear = (12 * (toYear - fromYear)) + datTo.getMonth();

		 for (var i = datFrom.getMonth(); i <= diffYear; i++) {
			 console.log(i);
			 if(i>11)
				 $scope.index=i-12;
			 else
			 $scope.index=i;

			 var params= {
					 "monthName":$scope.cal_months_labels[i%12],
					 "monthIndex":$scope.index+1,
					 "year":Math.floor(fromYear+(i/12))
			 }
				 arr.push(params);
		 }

		 return arr;
 }
 $scope.getCurrentAcademicYear();


 $scope.checkNextMonthFlag = function(year, month){
	var chckDate = new Date();
	if(year > chckDate.getFullYear() ){
		$scope.nextMonthFlag = true;
		$scope.presentMonthFlag = false;
	} else if(year == chckDate.getFullYear()){

		if(month > (chckDate.getMonth()+1)){
			$scope.nextMonthFlag = true;
			$scope.presentMonthFlag = false;
		}
		else if(month == (chckDate.getMonth()+1)){
			$scope.nextMonthFlag = false;
			$scope.presentMonthFlag = true;;
		}
		else if(month < (chckDate.getMonth()+1)){
			$scope.nextMonthFlag = false;
			$scope.presentMonthFlag = false;
		}

	} else if(year < chckDate.getFullYear()){
		$scope.nextMonthFlag = false;
		$scope.presentMonthFlag = false;
	}
 }

 $scope.goToNextMonth = function(){
   if($scope.getViewMonthNumber == 12){
     $scope.getViewMonthNumber = 1;
     $scope.getViewYear = parseInt($scope.getViewYear)+1;
     $scope.getViewMonth = $scope.cal_months_labels[0];
   }
   else{

     $scope.getViewMonth = $scope.cal_months_labels[$scope.getViewMonthNumber];
	 $scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)+1;
   }
    $scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
	$scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
   $scope.generateCalenderAttendence();
 }

 $scope.goToBeforeMonth = function(){
   if($scope.getViewMonthNumber == 1){
     $scope.getViewMonthNumber = 12;
     $scope.getViewYear = parseInt($scope.getViewYear)-1;
     $scope.getViewMonth = $scope.cal_months_labels[11];
   }
   else{
		$scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)-1;
		$scope.getViewMonth = $scope.cal_months_labels[parseInt($scope.getViewMonthNumber)-1];
   }
   $scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
   $scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
   $scope.generateCalenderAttendence();
 }

	$scope.generateDateOfobj = function(){
		var nDate = new Date();
		$scope.newDate = nDate;
		$scope.getViewMonth = $scope.cal_months_labels[nDate.getMonth()];
		$scope.getViewMonthNumber = parseInt(nDate.getMonth())+1;
		$scope.getViewYear = parseInt(nDate.getFullYear());
		$scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
		$scope.generateCalenderAttendence();
	}

	$scope.backMethod=function(){
		$("#takeAttendance").modal("hide");
		$("#attendanceHistory").modal("hide");
		$("#attendanceHistoryDayView").modal("hide");
		$("#allLeaveRequests").modal("hide");
	}

 $scope.generateCalenderAttendence = function(){
	 console.log($scope.newDate);
	 $scope.generateCalenderAttendenceObj = [];

   var date = new Date($scope.newDate);
   var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();
	//$scope.getStudentsForAttendance();
	$scope.getAbsentStaff();

	for(var i=1; i<=lastDay+1; i++){
	 var existed = false;
	 for(var j=0; j<$scope.absentStaffList.length; j++){
	 if(i == $scope.absentStaffList[j].day){
		 var staffAbsentIds = [];
		 for(var k=0; k<$scope.absentStaffList[j].staffList.length;k++){
			 staffAbsentIds.push($scope.absentStaffList[j].staffList[k].userId);
		 }
	   var dayObj = {
		 "date":i,
		 "weekday":$scope.weekday[new Date(date.getFullYear(),date.getMonth(),i).getDay()],
		 "absent":$scope.absentStaffList[j].staffList,
		 "staffAbsentIds":staffAbsentIds
	   };
	   existed = true;
	   $scope.generateCalenderAttendenceObj.push(dayObj);
	 }
	 }
	 if(existed == false){
		 var dayObj = {
		   "date":i,
		   "weekday":$scope.weekday[new Date(date.getFullYear(),date.getMonth(), i ).getDay()],
		 };
		 $scope.generateCalenderAttendenceObj.push(dayObj);
	 }
	}
   console.log($scope.generateCalenderAttendenceObj);
   $scope.getHolidaysForAttendance();
 }

	$scope.isTodayHoliday = false;
	$scope.getHolidaysForAttendance = function(){
		var params = {
			"schemaName":$scope.schemaName,
			"yearId":$scope.getViewYear,
			"monthId":$scope.getViewMonthNumber,
			"branchId":$scope.branchId
		};
		httpFactory.executePost("getHolidaysForStaffAttendance", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				var holidayDates = data.holidayDates.split(',');
				//	holidayDates.push("1");
				if(holidayDates.indexOf(""+$scope.todayDate) != -1){
					$scope.isTodayHoliday = true;
				}
				for(var i=0; i<$scope.generateCalenderAttendenceObj.length;i++){
					if(holidayDates.indexOf(""+$scope.generateCalenderAttendenceObj[i].date) == -1){
						$scope.generateCalenderAttendenceObj[i].isHoliday = false;
					}
					else{
						$scope.generateCalenderAttendenceObj[i].isHoliday = true;
					}
				}
			}
			else{
				for(var i=0; i<$scope.generateCalenderAttendenceObj.length;i++){
					$scope.generateCalenderAttendenceObj[i].isHoliday = false;
				}
			}
		});
		console.log($scope.generateCalenderAttendenceObj);
		$scope.getMonthTakenDaysForAtt();
	}
	$scope.branchMonthAttendanceDays = [];
	$scope.getMonthTakenDaysForAtt = function(){

    httpFactory.getResult("getbranchMonthWiseAttendanceDetails?schemaName="+$scope.schemaName+"&year="+$scope.getViewYear+"&month="+$scope.getViewMonthNumber+"&branchId="+$scope.branchId, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.branchMonthAttendanceDays = data.branchMonthAttendanceDays;

        for(var i=0; i<$scope.generateCalenderAttendenceObj.length; i++){
            var found= 0;
            for(var j=0; j<$scope.branchMonthAttendanceDays.length; j++){
              if($scope.generateCalenderAttendenceObj[i].date == $scope.branchMonthAttendanceDays[j].attendaceDate){
                $scope.generateCalenderAttendenceObj[i].attendanceStfId = $scope.branchMonthAttendanceDays[j].attendanceId;
                found++;
              }
            }
            if(found ==0){
              $scope.generateCalenderAttendenceObj[i].attendanceStfId = 0;
            }
        }


      }else{
				for(var i=0; i<$scope.generateCalenderAttendenceObj.length; i++){
          $scope.generateCalenderAttendenceObj[i].attendanceStfId = 0;
      	}
			}

      console.log($scope.generateCalenderAttendenceObj);
    });

  }





$scope.openStaffAttend = function(dt,stu){
	$scope.selectedDateobjAbsent = "";
	$scope.selectedStuObjAbsent = "";
	$scope.selectedDateobjAbsent = dt;
	$scope.selectedStuObjAbsent = stu;
	$scope.checkDayLeaveFortoday(dt);
	$('#assignabsent').modal('show');

}
$scope.openStaffPrevAttend = function(dt,stu){
	$scope.selectedDateobjAbsent = "";
	$scope.selectedStuObjAbsent = "";
	$scope.selectedDateobjAbsent = dt;
	$scope.selectedStuObjAbsent = stu;
	$scope.checkDayLeaveFortoday(dt);
	$('#assignabsent').modal('show');

}


$scope.studentAbsentArr = [];
$scope.enterStaffAttend=function(dt,stu){
	if($scope.selecAbsentType == undefined || $scope.selecAbsentType == "" || $scope.selectedReasonType == undefined || $scope.selectedReasonType == ""){
		alert("Select Absent type and Reason both ");
		return true;
	}
	var staffAttendObj = {
		"userId":""+stu.userId,
		"reason":$scope.selectedReasonType,
		"attendanceType":$scope.selecAbsentType
	};
	var dtObj = $scope.generateCalenderAttendenceObj.indexOf(dt);
	if($scope.selecAbsentType == "P"){
		$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.indexOf(""+stu.userId),1);
		$scope.generateCalenderAttendenceObj[dtObj].absent.splice(stu,1);
		$scope.studentAbsentArr.splice(stu,1);
		alert("removed");
	}
	else{
		if($scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds == undefined || $scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.length == 0){
			if($scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds == undefined)
			{
				$scope.generateCalenderAttendenceObj[dtObj].absent = [];
				$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds= [];
			}
			$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.push(""+stu.userId);
			$scope.generateCalenderAttendenceObj[dtObj].absent.push(staffAttendObj);
			alert("Added");
			$scope.studentAbsentArr.push(staffAttendObj);
		}
		else{
			if($scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.indexOf(""+stu.userId) == -1){
				$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.push(""+stu.userId);
				$scope.generateCalenderAttendenceObj[dtObj].absent.push(staffAttendObj);
				$scope.studentAbsentArr.push(staffAttendObj);
				alert("Added");
			}else{
				$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.indexOf(""+stu.userId),1);
				$scope.generateCalenderAttendenceObj[dtObj].absent.splice(stu,1);
				$scope.generateCalenderAttendenceObj[dtObj].staffAbsentIds.push(""+stu.userId);
				$scope.generateCalenderAttendenceObj[dtObj].absent.push(staffAttendObj);
				$scope.studentAbsentArr.splice(stu,1);
				$scope.studentAbsentArr.push(staffAttendObj);
				alert("updated");
			}
		}
	}

	console.log($scope.generateCalenderAttendenceObj);

	console.log($scope.studentAbsentArr);
	$('#assignabsent').modal('hide');
	$scope.openStuAttendDayViewStatus = false;
}



function contains(arr, key, val) {
    for (var i = 0; i < arr.length; i++) {
        if(arr[i][key] == val){
          $scope.AbsentarrIndex = i;
         return true;
       }
    }
    return false;
}

$scope.openPrevDayView = function(dt){
	$scope.studentAbsentArr = [];
	$scope.selectedPrevDateObj = dt;
	$("#attendanceHistory").modal("hide");
	$("#attendanceHistoryDayView").modal("show");
}

	$scope.saveAttendence=function(){
    var params = {
		"schemaName":$scope.schemaName,
		"attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+$scope.todayDate,
		"createdBy":1,
		"branchId":$scope.branchId,
		"totalStaff":$scope.totalStaffList.length,
		"insertRecords":$scope.studentAbsentArr
    }
    console.log(params);
		httpFactory.executePost("insertStaffAttendance", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.staffAttendanceReportId = data.staffAttendanceReportId;
				$scope.getAbsentStaffForToday();
				$scope.getStaffDayAttendanceReport();
				$scope.isAttendanceTaken = false;
				$scope.todayAttendenceFlag = true;
				alert("Saved SuccessFully");
				$scope.generateCalenderAttendence();
				$scope.getStaffList();
			}
			else{
				alert("Please try again later");
			}

		});
  }

	$scope.savePrevAttendence=function(){
		// $scope.selectedPrevDateObj
    var params = {
			"schemaName":$scope.schemaName,
			"attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+$scope.selectedPrevDateObj.date,
			"createdBy":1,
			"branchId":$scope.branchId,
			"totalStaff":$scope.totalStaffList.length,
			"insertRecords":$scope.studentAbsentArr
		};
    console.log(params);
		httpFactory.executePost("insertStaffAttendance", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.staffAttendanceReportId = data.staffAttendanceReportId;
				$scope.selectedPrevDateObj.attendanceStfId = data.staffAttendanceReportId;
				$scope.getAbsentStaffForToday();
				$scope.getStaffDayAttendanceReport();
				$scope.isAttendanceTaken = false;
				$scope.todayAttendenceFlag = true;
				alert("Saved SuccessFully");
				$scope.generateCalenderAttendence();
				$scope.getStaffList();
			}
			else{
				alert("Please try again later");
			}

		});
  }

	$scope.updateStfPrevAttendence=function(dt){


	    var params = {
			"schemaName":$scope.schemaName,
			"attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+dt.date,
			"createdBy":1,
			"branchId":$scope.branchId,
			"totalStaff":$scope.totalStaffList.length,
			"insertRecords":$scope.studentAbsentArr
	    }
	    console.log(params);
			httpFactory.executePost("insertStaffAttendance", params, function(data) {
				console.log(data);
				if(data.StatusCode == 200){
					$scope.staffAttendanceReportId = data.staffAttendanceReportId;
					$scope.isAttendanceTaken = false;
					$scope.todayAttendenceFlag = true;
					alert("Saved SuccessFully");
					$scope.generateCalenderAttendence();
					$scope.getStaffList();
				}
				else{
					alert("Please try again later");
				}

			});
	  }


  $scope.updateStaffAttend = function(dt,stu){
		$scope.selecAbsentType = "";
		$scope.selectedReasonType = "";
		$scope.prevAbsentType = "";
		$scope.selectedAttendanceId = 0;
		console.log(dt.absent);
		if(dt.absent != undefined){
			for(var i=0; i<dt.absent.length; i++){
				if(dt.absent[i].userId == stu.userId){
					$scope.selecAbsentType = dt.absent[i].attendanceType;
					$scope.selectedReasonType = dt.absent[i].reason;
					$scope.prevAbsentType = dt.absent[i].attendanceType;
					$scope.selectedAttendanceId = dt.absent[i].attendanceId;
				}
			}
		}else{
			$scope.selecAbsentType = "";
			$scope.selectedReasonType = "";
			$scope.prevAbsentType = "";
			$scope.selectedAttendanceId = 0;
		}
		$scope.selectedDateobjAbsent = "";
		$scope.selectedStuObjAbsent = "";
		$scope.selectedDateobjAbsent = dt;
		$scope.selectedStuObjAbsent = stu;
		$scope.checkDayLeaveFortoday(dt);
		$('#updateabsent').modal('show');

	}

	$scope.prevAbsentType = "";
	$scope.selectedAttendanceId = 0;
	$scope.updateAttendence = function(dt,stu){
	$scope.studentAbsentArr = [];
	$scope.selectedReasonType = document.getElementById("updReason").value;
	if($scope.selecAbsentType == "P"){
		$scope.selectedReasonType = "NA";
	}
	if($scope.selecAbsentType == undefined || $scope.selecAbsentType == "" || $scope.selectedReasonType == undefined || $scope.selectedReasonType == ""){
		alert("Select Absent type and Reason both ");
		return true;
	}
	var stuAttendObj = {
		"userId":stu.userId,
		"previousState":$scope.prevAbsentType,
		"attendanceId":$scope.selectedAttendanceId,
		"reason":$scope.selectedReasonType,
		"attendanceType":$scope.selecAbsentType
	};
	$scope.studentAbsentArr.push(stuAttendObj);
	var params = {
      "schemaName":$scope.schemaName,
      "attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+dt.date,
      "updatedBy":1,
      "branchId":$scope.branchId,
	  	"totalStaff":$scope.totalStaffList.length,
	  	"staffAttendanceReportId":parseInt(dt.attendanceStfId),
      "updateRecords":$scope.studentAbsentArr
    }
	console.log(params);
	 httpFactory.executePost("updateStaffAttendance", params, function(data) {
		console.log(data);
		if(data.StatusCode == 200){

			$scope.generateCalenderAttendence();
			console.log($scope.generateCalenderAttendenceObj);
			alert("Saved SuccessFully");
			$("#updateabsent").modal("hide");
			$scope.getAbsentStaffForToday();
			$scope.getStaffDayAttendanceReport();
			$scope.getStaffList();

		}
		else{
			alert("Please try again later");
		}

	});


	}

	$scope.activeRegisterView = 'todayView';
	$scope.changeDayView = function(dview){
		$scope.activeRegisterView = dview;
	}

	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	
	
 });
