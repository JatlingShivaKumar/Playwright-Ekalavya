projectModule.controller('ekalavyaStoreController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
	
	$scope.$ = $;
    $scope.courseOb = "";
    $scope.classOb = "";
    $scope.assignSubjStatus = 'none';
    $scope.userRoleId = localStorage.getItem("RD");
    $scope.userId = localStorage.getItem("userId");
    $scope.domainUrl = localStorage.getItem("domain");
    $scope.gotoLoc = function(loc,subj) {
        sessionStorage.setItem("selsubId", subj.subjectId);
        sessionStorage.setItem("selclassId", $scope.classOb.classId);
        sessionStorage.setItem("selsubName", subj.subjectName);
        sessionStorage.setItem("selclassName", $scope.classOb.className);
        sessionStorage.setItem("selcourseId", $scope.courseOb.courseId);
        sessionStorage.setItem("selcourseName", $scope.courseOb.courseName);
    	$location.path(loc);
    }
    
    $scope.ekalavyaStoreInit = function() {
        $scope.getAllClasses();
        $scope.getAllCourses();
        $scope.classSelect($scope.classList[0]);
        $scope.getSubjectsByCourse($scope.courseList[0]);
    }
    
    $scope.fromHomeScreen = false;
    if (sessionStorage.getItem("fromHomeScreen") == 'true') {
        $scope.fromHomeScreen = true;
    }
    
    $scope.redirectToDashboard = function() {
        $location.path("home");
    }

    $scope.addCourseModal = function() {
        $("#addCourse").modal('show');
    }
    
    $scope.assignClassModal = function() {
        $scope.showAddClassTag = "0";
        $("#assignClass").modal('show');
    }
    
    $scope.showAddClass = function() {
        $scope.showAddClassTag = "1";
    }
    
    $scope.assignSubjectModal = function() {
    	$scope.sCourseId="";
    	document.getElementById("newsubjectId").value="";
        $("#assignSubjects").modal('show');
    }
    
    $scope.getAllCourses = function() {
    	httpFactory.getResult("getCoursesForStore?schemaName=ekalavya_store", function(data) {
    	    console.log(data);
    	    if (data.StatusCode == 200) {
                $scope.courseList = data.Courses;
                for(i=0;i<$scope.courseList.length;i++){
					$scope.courseList[i]["isChecked"]=false;
					$scope.courseList[i]["classCourseId"]=0;
                }
    	    } else {
    	    
    	    }
    	  });
    }
    
    $scope.addNewCourse = function() {
        var params = {
            "courseName": $scope.courseNameText,
            "userId": localStorage.getItem("userId"),
            "schemaName": "ekalavya_store"
        }
        console.log(params);
        httpFactory.executePost("addNewCourseForStore", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("New Course added");
                $scope.getAllClasses();
                $scope.getAllCourses();
				$scope.classSelect($scope.classOob);
//                $scope.ekalavyaStoreInit();
                $("#addCourse").modal("hide");
            } else if (data.StatusCode == 300) {
                alert("Please Check Course Name ");
            } else {
                alert("Please Try again Later");
            }
        });
    }
    
    $scope.getAllClasses = function() {
    	$scope.classOb = "";
        $scope.subjectList = [];
        httpFactory.getResult("getAllClassesForStore?schemaName=ekalavya_store", function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' && data.StatusCode == 200) {
                $scope.classList = data.Classes;
                  for(i=0; i < $scope.classList.length; i++) {
                	var classCourses = "";
                	if(Object.keys($scope.classList[i].courseData).length > 0) {
                	    for(j=0;j<($scope.classList[i].courseData).length;j++) {
                	    	if($scope.classList[i].courseData[j].isActive == 1) {
                				classCourses = classCourses + $scope.classList[i].courseData[j].courseName + ", ";
                			}
                		}
                	}
                	if(classCourses.endsWith(", ")) {
        				classCourses = classCourses.replace(/, $/, '');
        			}
                	$scope.classList[i]["classCourses"] = classCourses;
                }
            } else {
            	
            }
        });
    }
    
    $scope.addNewClass = function() {
        console.log(document.getElementById("classNameAdd").value);
        $scope.newCLassName = document.getElementById("classNameAdd").value;
        if ($scope.newCLassName == undefined || $scope.newCLassName == "") {
            alert("Add Class Name");
            return true;
        }
        var params = {
            "schemaName": "ekalavya_store",
            "userId": localStorage.getItem("userId"),
            "className": $scope.newCLassName,
        }
        console.log(params);
        httpFactory.executePost("addNewClassForStore", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Class added");
//                $scope.getAllClasses();
                $scope.ekalavyaStoreInit();

                $("#assignClass").modal("hide");
            } else {
                alert("error updating name. Please make sure its unique");
            }
        });
    }
    
    $scope.classSelect = function(selectedClass) {
    	$scope.checkSubject=false;
		$scope.checkCourse=false;
    	$scope.assignedCourse =[];
    	$scope.selectedCourse=[];
    	for(i=0;i<$scope.courseList.length;i++){
    		$scope.courseList[i].isChecked = false;
    	}
    	$scope.classOb = selectedClass;
    	$scope.classOob = $scope.classOb;
    	for(j1=0;j1<$scope.classList.length;j1++) {
    		if($scope.classOb.classId==$scope.classList[j1].classId) {
    			$scope.classOb=$scope.classList[j1];
    		}
    	}
    	for(j=0;j<($scope.classOb.courseData).length;j++) {
    		for(k=0;k<$scope.courseList.length;k++) {
    			if(($scope.classOb.courseData[j].courseId == $scope.courseList[k].courseId) && ($scope.classOb.courseData[j].isActive == 1)) {
    				$scope.courseList[k].isChecked = true;
    			}
    		}
    	}
		$scope.selectedCourse = angular.copy($scope.courseList);
    	$scope.getSubjectsByCourse($scope.courseList[0]);
    }
    
    $scope.getSubjectsByCourse = function(selectedCourse) {
    	$scope.checkSubject=false;
    	$scope.assignedSubjects =[];
    	$scope.selectedSubject=[];
        $scope.courseOb = selectedCourse;
        $scope.subjectList=[];
        var courseId = $scope.courseOb.courseId;
        if($scope.classOb.classId != undefined && courseId != undefined) {
        	httpFactory.getResult("getStoreSubjectsByCourse?schemaName=ekalavya_store" + "&courseId=" + courseId + "&classId=" + $scope.classOb.classId, function(data) {
        		console.log(data);
        		if (data.STATUS == 'SUCCESS' && data.StatusCode == 200) {
        			$scope.selectedSubject = data.Subjects;
        			for(i=0;i<$scope.selectedSubject.length;i++) {
        				if($scope.selectedSubject[i].isActive==0) {
        					$scope.selectedSubject[i].isActive=false;
        				}else {
        					$scope.selectedSubject[i].isActive=true;
        				}
        			}
        		}else{

        		}
    			$scope.subjectList = angular.copy($scope.selectedSubject);
        	});
        }
    }
    
    $scope.addNewSubject = function() {
        if ($scope.newsubject == "" || $scope.newsubject == undefined) {
            alert("Add subject name");
            return true;
        }
        if ($scope.sCourseId == "" || $scope.sCourseId == undefined) {
            alert("Please select course");
            return true;
        }
        var params = {
            "schemaName": "ekalavya_store",
            "classId": $scope.classOb.classId,
            "courseId": $scope.sCourseId,
//            "createdBy": localStorage.getItem("userId"),
            "userId": localStorage.getItem("userId"),
            "subjectName": $scope.newsubject,
        }
        console.log(params);
        httpFactory.executePost("addNewSubjectForStore", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Subject added");
                $scope.getSubjectsByCourse($scope.courseOb);
                $("#assignSubjects").modal('hide');
            }
        });
    }
    
    $scope.cancleSave = function() {
        $scope.classSelect($scope.classOb);
    	$scope.checkSubject=false;
		$scope.checkCourse=false;
    }
    
    $scope.checCourse = function() {
		$scope.checkCourse=true;
    }
    $scope.checSubject = function() {
		$scope.checkSubject=true;
    }
    
    $scope.assignCourses = function() {
    	for(i=0;i<$scope.courseList.length;i++) {
    		if($scope.courseList[i].courseId===$scope.selectedCourse[i].courseId && $scope.courseList[i].isChecked!=$scope.selectedCourse[i].isChecked) {
    			$scope.assignedCourse.push(angular.copy($scope.courseList[i]));
    		}
    	}
    	
    	for(k=0;k<$scope.assignedCourse.length;k++) {
    		if($scope.assignedCourse[k].isChecked==true) {
    			$scope.assignedCourse[k].isChecked=1;
    		}else {
    			$scope.assignedCourse[k].isChecked=0;
    		}
    	}
    	
    	for(k=0;k<$scope.classOb.courseData.length;k++) {
    		for(l=0;l<$scope.assignedCourse.length;l++) {
    			if($scope.classOb.courseData[k].courseId == $scope.assignedCourse[l].courseId) {
    				$scope.assignedCourse[l].classCourseId=$scope.classOb.courseData[k].classCourseId;
    			}
    		}
    	}
    	var params = {
    			"AssignedCourses": $scope.assignedCourse,
    			"classId": $scope.classOb.classId,
    			"userId": localStorage.getItem("userId"),
    			"schemaName": "ekalavya_store"
    	}
    	if($scope.assignedCourse.length>0) {
    		console.log(params);
    		httpFactory.executePost("assignCourseForClass", params, function(data) {
    			console.log(data);
    			if (data.StatusCode == 200) {
    				alert("Course Assigned");
    				$scope.getAllClasses();
    				$scope.classSelect($scope.classOob);
    			} else if (data.StatusCode == 300) {
    				alert("Something went wrong");
    			} else {
    				alert("Please Try again Later");
    			}
    		});
    	}else {
    		alert("Nothing to update");
    		$scope.checkCourse=false;
    	}
    }
    $scope.addkeyword = function(selSubject){
    	$scope.selSubjectId=selSubject.subjectId;
    	$scope.selSubjectName=selSubject.subjectName;
    	 $scope.getQuestionDomainForStore();
		$("#keywordsandsentencesmodel").modal("show");
		
	
}
    $scope.getQuestionDomainForStore = function() {
    	$scope.keywordId='';
    	$scope.domainId='';
        $scope.domainList = [];
        $scope.kwSentanceList = [];
	        httpFactory.getResult("getQuestionDomainForStore?schemaName=ekalavya_store" ,function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.QuestionDomains != undefined) {
	            	$scope.domainList = data.QuestionDomains;

	            }
	        });
    }
    
    $scope.getDomainKeywords= function(domain) {
    	$scope.domainId=domain;
    	$scope.keywordId='';
        $scope.keywordList = [];
    	$scope.kwSentanceList = [];
        if( $scope.keywordList.length == 0){
	        httpFactory.getResult("getQuestionDomainKeywords?schemaName=ekalavya_store&domainId=" + $scope.domainId + "&subjectId=" + $scope.selSubjectId , function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.DomainKeywords != undefined) {
	            	$scope.keywordList = data.DomainKeywords;
	            }
	        });
        }
    }
    $scope.saveDomainSentences = function() {
    	if(document.getElementById("percentageId").value != ""){
    	    $scope.percentage = document.getElementById("percentageId").value;
    	}
    	if ($scope.percentage==">90%") {
    		$scope.percentageFrom = "90";
    		$scope.percentageTo = "100";
		} else if ($scope.percentage=="75%-89%") {
			$scope.percentageFrom = "75";
			$scope.percentageTo = "90";
		} else if ($scope.percentage=="60%-74%") {
			$scope.percentageFrom = "60";
			$scope.percentageTo = "75";
		} else if ($scope.percentage=="50%-59%") {
			$scope.percentageFrom = "50";
			$scope.percentageTo = "60";
		} else if ($scope.percentage=="<50%") {
			$scope.percentageFrom = "0";
			$scope.percentageTo = "50";
		}
    	 $scope.sentences =  $("#sentences").val();
        var params = {
            "domainId": $scope.domainId,
            "createdBy": localStorage.getItem("userId"),
            "schemaName": "ekalavya_store",
            "keywordId" : $scope.keywordId,
            "percentageFrom": $scope.percentageFrom,
            "percentageTo": $scope.percentageTo,
            "sentences": $scope.sentences
        }
        console.log(params);
        httpFactory.executePost("saveDomainSentences", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("New Sentence Added");
                $scope.getDomainKeywordSentences();
                document.getElementById("sentences").value="";
                document.getElementById("percentageId").value="";
            } else if (data.StatusCode == 300) {
                alert("Please Check Sentences ");
            } else {
                alert("Please Try again Later");
            }
        });
    }
    $scope.closePopUp = function(){
    	$("#keywordsandsentencesmodel").modal("hide");
    }
    
    $scope.assignSubjects = function() {
    	for(i=0;i<$scope.subjectList.length;i++) {
    		if($scope.subjectList[i].subjectId===$scope.selectedSubject[i].subjectId && $scope.subjectList[i].isActive!=$scope.selectedSubject[i].isActive) {
    			$scope.assignedSubjects.push(angular.copy($scope.subjectList[i]));
    		}
    	}
    	for(k=0;k<$scope.assignedSubjects.length;k++) {
    		if($scope.assignedSubjects[k].isActive==true) {
    			$scope.assignedSubjects[k].isActive=1;
    		}else {
    			$scope.assignedSubjects[k].isActive=0;
    		}
    	}
    	var params = {
    			"AssignedSubjects": $scope.assignedSubjects,
    			"classId": $scope.classOb.classId,
    			"userId": localStorage.getItem("userId"),
    			"schemaName": "ekalavya_store"
    	}
    	if($scope.assignedSubjects.length>0) {
    		console.log(params);
    		httpFactory.executePost("assignSubjectsForClass", params, function(data) {
    			console.log(data);
    			if (data.StatusCode == 200) {
    				alert("Subject Assigned");
    				$scope.getSubjectsByCourse($scope.courseOb);
    			} else if (data.StatusCode == 300) {
    				alert("Something went wrong");
    			} else {
    				alert("Please Try again Later");
    			}
    		});
    	}else {
    		alert("Nothing to update");
    		$scope.checkSubject=false;
    	}
    }
    $scope.getDomainKeywordSentences= function() {
        $scope.kwSentanceList = [];
        if( $scope.kwSentanceList.length == 0){
	        httpFactory.getResult("getDomainKeywordSentences?schemaName=ekalavya_store&domainId=" + $scope.domainId + "&keywordId=" + $scope.keywordId, function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.KwSentences != undefined) {
	            	$scope.kwSentanceList = data.KwSentences;
	            	for(i=0;i<$scope.kwSentanceList.length;i++) {
	            		if($scope.kwSentanceList[i].percentageFrom ==90 && $scope.kwSentanceList[i].percentageTo==100) {
	            			$scope.kwSentanceList[i]["percent"]="Above 90%"
	            		} else if($scope.kwSentanceList[i].percentageFrom ==75 && $scope.kwSentanceList[i].percentageTo==90) {
	            			$scope.kwSentanceList[i]["percent"]="75%-89%"
	            		}else if($scope.kwSentanceList[i].percentageFrom ==60 && $scope.kwSentanceList[i].percentageTo==75) {
	            			$scope.kwSentanceList[i]["percent"]="60%-74%"
	            		}else if($scope.kwSentanceList[i].percentageFrom ==50 && $scope.kwSentanceList[i].percentageTo==60) {
	            			$scope.kwSentanceList[i]["percent"]="50%-59%"
	            		}else if($scope.kwSentanceList[i].percentageFrom ==0 && $scope.kwSentanceList[i].percentageTo==50) {
	            			$scope.kwSentanceList[i]["percent"]="Below 50%"
	            		}
	            	}
	            }
	        });
        }
    }
	
});




