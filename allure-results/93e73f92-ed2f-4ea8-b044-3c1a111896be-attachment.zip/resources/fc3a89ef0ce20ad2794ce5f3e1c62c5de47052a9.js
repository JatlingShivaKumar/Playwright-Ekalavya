projectModule.controller('reportCardAttController', function ($scope, $rootScope, $compile, $timeout, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.getItem("branchName");
	$scope.attendanceMonthsArray = [];
	$scope.rcTemplateList = [];
	$scope.tableColumnOptions = ['Test', 'Average', 'Sum', 'Grade', 'Grade Points', 'Co-Curricular', 'Total Percentage'];
	$scope.newColumn = true;
	$scope.change = false;
	$scope.inputBox = true;

	$scope.getReportCardAttendance = function () {
		httpFactory.getResult("getBranchReportCardAttendance?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.monthsAttendanceArray = data.monthsAttendanceArray;
				$scope.attendanceCount = 0;
				for (i = 0; i < $scope.monthsAttendanceArray.length; i++) {
					if ($scope.monthsAttendanceArray[i].branchMonthId > 0) {
						$scope.attendanceCount++;
					}
				}
				document.getElementById("studentListDiv").style.display = "block";
				$scope.getStudentsWithAttendanceForReportCard();
			} else if (data.StatusCode == 300) {
				$scope.monthsAttendanceArray = [];
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.updateReportCardAttendance = function () {
		var insertAttendanceArray = [];
		var updateAttendanceArray = [];
		for (i = 1; i < 2; i++) {
			for (j = 1; j < $scope.monthsAttendanceArray.length + 1; j++) {
				if (($scope.monthsAttendanceArray[j - 1].branchMonthId == 0) && (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value > 0)) {
					var monthAttendanceObj = {
						"monthId": $scope.monthsAttendanceArray[j - 1].monthId,
						"monthName": $scope.monthsAttendanceArray[j - 1].monthName,
						"totalWorkingDays": document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value
					}
					insertAttendanceArray.push(monthAttendanceObj);
				} else if (($scope.monthsAttendanceArray[j - 1].branchMonthId > 0) && (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value != $scope.monthsAttendanceArray[j - 1].totalWorkingDays)) {
					var monthAttendanceObj = {
						"monthId": $scope.monthsAttendanceArray[j - 1].monthId,
						"monthName": $scope.monthsAttendanceArray[j - 1].monthName,
						"branchMonthId": $scope.monthsAttendanceArray[j - 1].branchMonthId,
						"totalWorkingDays": document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value
					}
					updateAttendanceArray.push(monthAttendanceObj);
				}
			}
		}
		if (insertAttendanceArray.length == 0 && updateAttendanceArray.length == 0) {
			alert("No Changes");
			return;
		} else {
			var params = {
				"schemaName": $scope.schemaName,
				"branchId": $scope.branchId,
				"userId": localStorage.getItem("userId")
			}
			if (insertAttendanceArray.length > 0) {
				params["insertAttendanceArray"] = insertAttendanceArray;
			}
			if (updateAttendanceArray.length > 0) {
				params["updateAttendanceArray"] = updateAttendanceArray;
			}
			console.log(params);
			httpFactory.executePost("updateBranchReportCardAttendance", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getReportCardAttendance();
				} else {
					alert('Error while updating attendance records');
				}
			});
		}
	}

	$scope.deleteReportCardAttendance = function () {
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId
		}
		console.log(params);
		httpFactory.executePost("deleteBranchReportCardAttendance", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Deleted");
				$scope.getReportCardAttendance();
			} else if (data.StatusCode == 300) {
				alert(data.MESSAGE);
			} else {
				alert('Error while deleting');
			}
		});
	}

	$scope.getCourseByBranchId = function () {
		$scope.reportCardStudents = [];
		httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if (sessionStorage.getItem('courseId') != null && sessionStorage.getItem('courseId') != undefined && sessionStorage.getItem('courseId') != '') {
					for (i = 0; i < $scope.courseList.length; i++) {
						if ($scope.courseList[i].courseId == sessionStorage.getItem('courseId')) {
							$scope.selectedCourseOb = JSON.stringify($scope.courseList[i]);
							$scope.courseSelect($scope.selectedCourseOb);
							sessionStorage.removeItem("courseId");
							break;
						}
					}
				} else if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					if (window.location.href.includes('reportCardTemplate'))
						$scope.getTemplatesByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('addReportCardTestDetails'))
						$scope.getTestsDetailsByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('reportCardSubjectManagement'))
						$scope.getSubjectsByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('reportCardMap') || window.location.href.includes('reportCardGeneration'))
						$scope.courseSelect($scope.selectedCourseOb);
				}
			}
		});
	}

	$scope.getStudentReportCard = function () {
		$scope.getBranchDetailsForRC();
		$scope.getStudentDetailsForReportCard();
		$scope.getTemplateToUse();
		$scope.getGradesandGradePointsForReportCard();
		var temp = {
			"courseId": sessionStorage.getItem("courseId"),
			"classId": sessionStorage.getItem("classId")
		}
		$scope.getSubjectsByCourseClass(temp, temp);
		$scope.getReportCardTestMarks();
		$scope.getRCPresentAttendance();
		$scope.totalWorkingDays = $scope.sum($scope.reportCardPresentDays, 'totalWorkingDays');
		$scope.totalPresentDays = $scope.sum($scope.reportCardPresentDays, 'presentDays');
	}

	$scope.calculatePresents = function () {
		$scope.studentArray.forEach(function (student) {
			student.totalPresentDays = $scope.sum(student.studentReportCardPresentDays, 'presentDays');
		});
	}

	$scope.courseSelect = function (selectedCourseOb) {
		$scope.selectedCourse = JSON.parse(selectedCourseOb);
		$scope.reportCardStudents = [];
		httpFactory.getResult("getCLassesByCourse?courseId=" + $scope.selectedCourse.courseId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
				if (sessionStorage.getItem('classId') != null && sessionStorage.getItem('classId') != undefined && sessionStorage.getItem('classId') != '') {
					for (i = 0; i < $scope.classList.length; i++) {
						if ($scope.classList[i].classId == sessionStorage.getItem('classId')) {
							$scope.selectedClassObj = JSON.stringify($scope.classList[i]);
							$scope.courseClassSelect($scope.selectedClassObj);
							sessionStorage.removeItem("classId");
							break;
						}
					}
				}
			}
		});
	}

	$scope.courseClassSelect = function (selectedClsOb) {
		console.log(selectedClsOb);
		if (typeof selectedClsOb == 'string')
			$scope.selectedClass = JSON.parse(selectedClsOb);
		else
			$scope.selectedClass = selectedClsOb;
		$scope.templateObj = '';
		$scope.classTemplateList = [];
		$scope.reportCardStudents = [];
		httpFactory.getResult("selectSectionsByBranchCourseClass?branchId=" + $scope.branchId + "&classCourseId=" + $scope.selectedClass.classCourseId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
				if (sessionStorage.getItem('sectionId') != null && sessionStorage.getItem('sectionId') != undefined && sessionStorage.getItem('sectionId') != '') {
					for (i = 0; i < $scope.sectionList.length; i++) {
						if ($scope.sectionList[i].sectionId == sessionStorage.getItem('sectionId')) {
							$scope.selectedSectionObj = JSON.stringify($scope.sectionList[i]);
							$scope.getClassWiseTemplates($scope.selectedCourse.courseId, $scope.selectedClass.classId);
							sessionStorage.removeItem("sectionId");
							break;
						}
					}
				}
			}
		});
	}

	$scope.goToDashbord = function () {
		sessionStorage.removeItem('courseId');
		$location.path("reportAnalysis");
	}

	$scope.getStudentsForReportCard = function () {
		httpFactory.getResult("getStudentsForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + $scope.selectedSection.sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardStudents = data.reportCardStudents;
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					$scope.reportCardStudents[i].selected = false;
					if ($scope.reportCardStudents[i].profilePic != 'NA' && $scope.reportCardStudents[i].profilePic != '') {
						$scope.reportCardStudents[i].profilePic = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.reportCardStudents[i].profilePic;
					}
				}
			} else {

			}
		});
	}

	$scope.getStudentsWithAttendanceForReportCard = function () {
		httpFactory.getResult("getStudentsWithAttendanceForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + JSON.parse($scope.selectedSectionObj).sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentAndAttList = data.reportCardStudents;
				for (i = 0; i < $scope.studentAndAttList.length; i++) {
					if ($scope.studentAndAttList[i].profilePic != 'NA' && $scope.studentAndAttList[i].profilePic != '') {
						$scope.studentAndAttList[i].profilePic = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.studentAndAttList[i].profilePic;
					}
				}
				$scope.originalStudentAttList = angular.copy($scope.studentAndAttList);
			} else {

			}
		});
	}


	function hasDataChanged(existingArray, updatedArray) {
		if (existingArray.length !== updatedArray.length) {
			return true;  // If lengths are different, data has changed
		}

		for (var i = 0; i < existingArray.length; i++) {
			var existingItem = existingArray[i];
			var updatedItem = updatedArray[i];

			// Assuming a simple comparison for illustration
			// You may need to customize this based on your data structure
			if (!angular.equals(existingItem, updatedItem)) {
				return true;  // If items are not equal, data has changed
			}
		}

		return false;  // If no differences found, data has not changed
	}

	$scope.getRCPresentAttendance = function (student) {
		var studentId = "";
		if (student != undefined) {
			studentId = student.studentId;
		}
		else {
			studentId = sessionStorage.getItem("studentId");
		}
		httpFactory.getResult("getRCPresentAttendance?schemaName=" + $scope.schemaName + "&studentId=" + studentId + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardPresentDays = data.reportCardPresentDays;
				$scope.tempReportCardPresentDays = angular.copy($scope.reportCardPresentDays);
			} else {

			}
		});
		return $scope.reportCardPresentDays;
	}

	$scope.backMethod = function () {
		$location.path("reportCardGeneration");
	}

	$scope.downloadCSV = function (type) {
		var fileName;
		if (confirm("Please do not edit column names.\n Are you sure want to download")) {
			if (type == "marks") {
				var excelData = getExcelData();
				fileName = "reportCardMarks.xlsx"
			}
			else if (type == "attendance") {
				var excelData = getAttendanceExcelData();
				fileName = "reportCardAttendance.xlsx"
			}
			// Create a worksheet
			var ws = XLSX.utils.aoa_to_sheet(excelData);

			// Create a workbook
			var wb = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, 'Sheet 1');

			// Save the workbook to a file
			XLSX.writeFile(wb, fileName);
		}
		else
			return;
	};

	function getExcelData() {
		// Headers
		var headers = ['Roll No', 'Student Name'];
		var selectedSubjects = $scope.classSubjectsList.filter(function (clssubList) {
			return clssubList.selected == true;
		});

		selectedSubjects.forEach(function (clssubList) {
			headers.push(clssubList.subjectName + "-" + $scope.testTotalMarks);
		});

		// Data rows
		var dataRows = $scope.reportCardStudents.map(function (secStud) {
			var row = [
				secStud.rollNumber,
				secStud.studentName,
			];

			selectedSubjects.forEach(function (clssubList) {
				var subjectId = clssubList.subjectId;
				var marksValue = $scope.getMarks(secStud.studentId, subjectId);
				row.push(marksValue);
			});

			return row;
		});

		// Combine headers and data rows
		var excelData = [headers].concat(dataRows);

		return excelData;
	}

	function getAttendanceExcelData() {
		// Headers
		var headers = ['Roll No', 'Student Name'];
		var selectedMonths = $scope.monthsAttendanceArray.filter(function (selectedMonth) {
			return selectedMonth.totalWorkingDays > 0;
		});
		selectedMonths.forEach(function (month) {
			headers.push(month.monthName + "-" + month.totalWorkingDays);
		});

		// Data rows
		var dataRows = $scope.studentAndAttList.map(function (student) {
			var row = [
				student.rollNumber,
				student.studentName,
			];

			selectedMonths.forEach(function (month) {
				var presentDays = $scope.getStudentPresentDays(student.studentId, month.monthId);
				row.push(presentDays);
			});

			return row;
		});

		// Combine headers and data rows
		var excelData = [headers].concat(dataRows);

		return excelData;
	}

	$scope.uploadExcelAtt = function (element) {
		var file = document.getElementById("fileInput").files[0];
		if (file == undefined) {
			alert("Please choose the file.")
			return;
		}
		if (confirm("Please re-check your data before uploading, any month miss match leads to error.\n Are you sure want to continue?")) {
			var reader = new FileReader();
			reader.onload = function (e) {
				var data = e.target.result;
				var workbook = XLSX.read(data, { type: 'binary' });
				var sheetName = workbook.SheetNames[0];
				var worksheet = workbook.Sheets[sheetName];

				// Process the uploaded data and update the table
				$scope.processUploadedDataOfAtt(XLSX.utils.sheet_to_json(worksheet, { header: 1 }));
			};

			reader.readAsBinaryString(file);
			alert("Upload Successfull");
		}
		else
			return;

	};

	$scope.processUploadedDataOfAtt = function (excelData) {
		try {
			$rootScope.$apply(function () {
				for (var i = 1; i < excelData.length; i++) {
					var rollNumber = excelData[i][0];
					var presentDaysColIndex = 2; // Adjust based on your data structure

					for (var j = 0; j < $scope.studentAndAttList.length; j++) {
						if ($scope.studentAndAttList[j].rollNumber === rollNumber) {
							for (var k = 0; k < $scope.monthsAttendanceArray.length; k++) {
								var presentDays = parseFloat(excelData[i][presentDaysColIndex + k]) || 0;
								// Update presentDays
								$scope.updateAtt($scope.studentAndAttList[j], $scope.monthsAttendanceArray[k], presentDays);
							}
							break;
						}
					}
				}
				$scope.updatedStudentAndAttList = angular.copy($scope.studentAndAttList);
			});
			setTimeout(function () {
				$scope.getReportCardAttendance();
				$scope.getStudentsWithAttendanceForReportCard();
				$scope.studentAndAttList = angular.copy($scope.updatedStudentAndAttList);
				var element = angular.element(document.getElementById('studentAttList'));
				if (element) {
					$compile(element)($rootScope.$new());
					$rootScope.$digest();
				}
			});

		} catch (error) {
			console.error("Error during $apply:", error);
		}
	};

	$scope.updateAtt = function (student, month, presentDays) {
		// Update the marks in $scope.studentArray
		if (student && student.studentId) {
			var studentInArray = $scope.studentAndAttList.find(function (s) {
				return s.studentId === student.studentId;
			});

			if (studentInArray) {
				var presentDaysIndex = studentInArray.months.findIndex(function (mon) {
					return mon.monthId == month.monthId;
				});

				if (presentDaysIndex !== -1) {
					studentInArray.months[presentDaysIndex].presentDays = presentDays;
				} else {
					// Subject not found, insert the subject if marks are greater than 0
					if (presentDays > 0) {
						var newMonth = {
							monthId: monthId,
							presentDays: presentDays.toString(),
							totalWorkingDays: month.totalWorkingDays
						};
						studentInArray.months.push(newMonth);
					}
				}
			} else {
				// Handle the case where studentInArray is undefined
				console.error("Invalid student object in studentArray:", studentInArray);
			}
		} else {
			// Handle the case where student or student.studentId is undefined
			console.error("Invalid student object in studentArray:", student);
		}
	};

	function getStudentPresentDayId(studentId, monthId) {
		var student = $scope.studentAndAttList.find(s => s.studentId === studentId);

		if (student) {
			var month = student.months.find(mon => mon.monthId === monthId);

			if (month) {
				return month.hasOwnProperty("studentPresentDayId") ? month.studentPresentDayId : 0;
			}
			else
				return 0;
		}

		// If student or subject not found, return a default value (you can adjust this based on your requirements)
		return 0;
	}

	function getAttPresentDays(studentId, monthId) {
		var inputId = studentId + "_" + monthId;
		var attPDInput = angular.element(document.getElementById(inputId));

		// Check if the input element is found before attempting to get its value
		var PDValue = attPDInput.length > 0 ? attPDInput.val() : undefined;

		return PDValue;
	}

	function getOriginalPresentDays(studentId, monthId) {
		var originalStudent = $scope.originalStudentAttList.find(item => item.studentId === studentId);

		if (originalStudent) {
			var originalMonth = originalStudent.monthArray.find(sub => sub.subjectId === subjectId);

			if (originalMonth) {
				return originalMonth.marks;
			}
			else
				return 0;
		}

		// If the original value is not found, return undefined
		return undefined;
	}

	$scope.saveStudentAttendance = function () {
		var result = {
			"schemaName": $scope.schemaName,
			"createdBy": $scope.userId,
			"studentArray": []
		};
		outerLoop:
		angular.forEach($scope.studentAndAttList, function (student) {
			var studentObj = {
				"studentId": student.studentId,
				"monthsArray": []
			};

			angular.forEach($scope.monthsAttendanceArray, function (month) {
				if (month.totalWorkingDays > 0) {
					var PDValue = getAttPresentDays(student.studentId, month.monthId);
					var originalPDValue = getOriginalPresentDays(student.studentId, month.monthId);
					if (Number(PDValue) > Number(month.totalWorkingDays)) {

						alert("Please enter the present days less than the total working days");
						return outerLoop;

					}
					if (originalPDValue != PDValue) {
						// If marks are modified, add the subject details to the student's subjectArray
						var monthObj = {
							"studentPresentDayId": getStudentPresentDayId(student.studentId, month.monthId),
							"monthId": month.monthId,
							"presentDays": PDValue
						};

						studentObj.monthsArray.push(monthObj);
					}
				}
			});

			// If the student has modified subjects, add the student details to the result array
			if (studentObj.monthsArray.length > 0) {
				result.studentArray.push(studentObj);
			}
		});
		if (result.studentArray.length > 0) {
			httpFactory.executePost("updateStudentRCAttendance", result, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getReportCardAttendance();
				} else {
					alert(data.MESSAGE);
				}
			});
		}
		else {
			alert("No Changes")
		}
	};

	function getOriginalPresentDays(studentId, monthId) {
		var originalStudent = $scope.originalStudentAttList.find(item => item.studentId === studentId);

		if (originalStudent) {
			var originalMonth = originalStudent.months.find(sub => sub.monthId === monthId);

			if (originalMonth) {
				return originalMonth.presentDays;
			}
			else
				return 0;
		}

		// If the original value is not found, return undefined
		return undefined;
	}

	$scope.getStudentPresentDays = function (studentId, monthId) {
		// Find the student in studentArray
		var student = $scope.studentAndAttList.find(function (student) {
			return student.studentId === studentId;
		});

		// Find the subject in the student's subjects array
		var month = student.months.find(function (sub) {
			return sub.monthId === monthId;
		});

		// Return marks if found, otherwise return 0
		return month ? parseFloat(month.presentDays) || 0 : 0;
	};

	$scope.selectedStudentsArray = [];

	$scope.selectStudents = function (studentDetail, studentIndex) {
		if (studentDetail == "" || studentDetail == undefined) {
			if (document.getElementById("isAllChecked").checked == true) {
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					if ($scope.reportCardStudents[i].selected == false || $scope.reportCardStudents[i].selected == undefined)
						$scope.reportCardStudents[i].selected = true;
				}
				$scope.selectedStudentsCount = $scope.reportCardStudents.length;
			} else if (document.getElementById("isAllChecked").checked == false) {
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					if ($scope.reportCardStudents[i].selected == true || $scope.reportCardStudents[i].selected == undefined)
						$scope.reportCardStudents[i].selected = false;
				}
				$scope.selectedStudentsCount = 0;
			}
		} else {
			if ($scope.reportCardStudents[studentIndex].selected == true) {
				$scope.reportCardStudents[studentIndex].selected = false;
				$scope.selectedStudentsCount--;
				document.getElementById("isAllChecked").checked = false;
			} else {
				$scope.reportCardStudents[studentIndex].selected = true;
				$scope.selectedStudentsCount++;
			}
		}
		var countIsSelected = 0;
		for (i = 0; i < $scope.reportCardStudents.length; i++) {
			if ($scope.reportCardStudents[i].selected == true)
				countIsSelected++;
		}
		if (countIsSelected == $scope.reportCardStudents.length)
			$scope.isAllChecked = true;
		else
			$scope.isAllChecked = false;
	}

});
