projectModule.controller('messagingController', function ($scope, $location, commonFactory, httpFactory, $routeParams, $route, $sce, $compile) {
	$scope.$ = $;
	$scope.goToDashbord = function () {
		$location.path("rankrPlus");
	}
	$scope.goToWATemplateRequest = function () {
		$location.path("whatsAppTemplate");
	}
	$scope.goToGlobalSms = function () {
		$location.path("globalSMS");
	}

	$scope.goToWhatsappMessaging = function () {
		$location.path("whatsAppMessaging");
	}
	$scope.goToMessages = function () {
		$location.path("messages/yes");
	}

});
