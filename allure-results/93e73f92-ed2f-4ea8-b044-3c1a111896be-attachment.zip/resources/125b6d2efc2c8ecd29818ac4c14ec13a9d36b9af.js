projectModule.controller('feeStructureController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");

	$scope.allFeeCatglist = [];
	$scope.courseList = [];
	$scope.courseClasses = [];

	$scope.selectedClassObj = {};
	$scope.selectedClass = "";
	$scope.isSubCategorised = false;

	$scope.getCoursesByBranch = function () {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					$scope.getClassesByCourse();
				}
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function () {
		//    	console.log($scope.selectedCourseOb);
		//		if($scope.selectedCourseOb == null){
		//			return true;
		//		}
		$scope.CourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.CourseObj.courseId;
		$scope.selectedCourseName = $scope.CourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();

	$scope.getSectionByClass = function (selectedClassObj) {
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("Got Error");
			}
		});
	}

	$scope.updateCrsClsSec = function (selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}

	$scope.getStudentsBySection = function () {
		httpFactory.getResult("selectStudentsBySection?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&sectionId=" + $scope.sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.showStudents = true;
				$scope.sectionStudents = data.sectionStudents;
			} else {

			}
		});
	}

	$scope.structureModal = function () {
		if ($scope.selectedClassObj == null) {
			$scope.showStructure = false;
		} else {
			if (typeof $scope.selectedClassObj === "string") {
				$scope.selectedClass = JSON.parse($scope.selectedClassObj);
				$scope.classCourseId = $scope.selectedClass.classCourseId;
			} else {
				$scope.selectedClass = $scope.selectedClassObj;
			}
			$scope.getFeeStructureDetails();
			$scope.showStructure = true;
		}
		//$scope.getFeeIntervals();
	}

	$scope.goToDashbord = function () {
		$location.path("feemanagement");
	}

	$scope.getFeeIntervals = function () {
		httpFactory.getResult("getFeeIntervals?schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.feeIntervals = data.data;
			} else {

			}
		});
	}

	$scope.feeCategoryArr = [];
	$scope.updateFeeCategoryDetails = function () {
		/*if(typeof $scope.feeCategoryInterval === "string"){
			$scope.selectedFeeInterval = JSON.parse($scope.feeCategoryInterval);
		}else{
			$scope.selectedFeeInterval = $scope.feeCategoryInterval;
		}
		if(document.getElementById("isOptional").checked == true){
			$scope.isOptional = 1;
			$scope.isOptionalText = "Yes";
		}else if(document.getElementById("isOptional").checked == false){
			$scope.isOptional = 0;
			$scope.isOptionalText = "No";
		}*/

		if ((document.getElementById("feeCategory").value == "" || document.getElementById("feeCategory").value == undefined) && $scope.isSubCategorised) {
			alert("Enter Fee Category Name");
			return;
		} else if (document.getElementById("feeCategoryAmount") != null && (document.getElementById("feeCategory").value == "" || document.getElementById("feeCategory").value == undefined ||
			document.getElementById("feeCategoryAmount").value == "" || document.getElementById("feeCategoryAmount").value == undefined) && !$scope.isSubCategorised) {
			alert("Enter Fee Category Name and Amount");
			return;
		} else {
			if ($scope.isSubCategorised) {
				for (i = 0; i < $scope.subCategoryArray.length; i++) {
					if ($scope.subCategoryArray[i].subCategoryAmount == 0)
						$scope.subCategoryArray[i].subCategoryAmount = "";
					if (($scope.subCategoryArray[i].subCategoryName == "" && $scope.subCategoryArray[i].subCategoryAmount == "") || ($scope.subCategoryArray[i].subCategoryName == null && $scope.subCategoryArray[i].subCategoryAmount == null) ||
						($scope.subCategoryArray[i].subCategoryName == "" && $scope.subCategoryArray[i].subCategoryAmount == null) || ($scope.subCategoryArray[i].subCategoryName == null && $scope.subCategoryArray[i].subCategoryAmount == "")) {
						$scope.subCategoryArray.splice(i, 1);
						i--;
					}
					if ($scope.subCategoryArray[i].subCategoryName == "" || $scope.subCategoryArray[i].subCategoryAmount == "" || $scope.subCategoryArray[i].subCategoryName == null || $scope.subCategoryArray[i].subCategoryAmount == null) {
						alert("Please enter all the fields");
						return;
					}
				}
			}
			if ($scope.isSubCategorised && document.getElementById("feeCategoryAmount") == null)
				$scope.feeCategoryAmount = 0;
			else
				$scope.feeCategoryAmount = document.getElementById("feeCategoryAmount").value;
			var feeCategoryObj = {
				"feeCategoryName": $scope.feeCategory,
				"feeCategoryAmount": $scope.feeCategoryAmount,
				"isDelete": 'false',
				"isSubCategorised": $scope.isSubCategorised ? 1 : 0
				/*"feeCategoryIntervalId":$scope.selectedFeeInterval.feeIntervalId,
				"feeCategoryIntervalName":$scope.selectedFeeInterval.feeIntervalName,
				"isOptional":$scope.isOptional,
				"isOptionalText":$scope.isOptionalText*/
			}
			if ($scope.isSubCategorised) {
				feeCategoryObj["subCategoryArray"] = $scope.subCategoryArray;
				$scope.subCategoryArray = [];
			}
			$scope.feeCategoryArr.push(feeCategoryObj);
			$scope.feeStructureDetailsArray.push(feeCategoryObj);
			document.getElementById("feeCategory").value = "";
			if (document.getElementById("feeCategoryAmount") != null)
				document.getElementById("feeCategoryAmount").value = "";
			/*document.getElementById("feeCategoryInterval").value = "";
			document.getElementById("isOptional").value = "";*/
			$("#addNewFeeCategory").modal("hide");
			if ($scope.feeStructureDetails.feeStructureId > 0)
				$scope.updateFeeStructure();
		}
	}

	$scope.addNewFeeStructure = function () {
		if ($scope.feeCategoryArr.length > 0) {
			if (document.getElementById("structName").value != "" && document.getElementById("structName").value != undefined) {
				var params = {
					"schemaName": $scope.schemaName,
					"feeStructureName": document.getElementById("structName").value,
					"classCourseId": $scope.classCourseId,
					"createdBy": $scope.user_id,
					"feeCategoryArray": $scope.feeCategoryArr
				}
				console.log(params);
				httpFactory.executePost("addNewFeeStructure", params, function (data) {
					console.log(data);
					if (data.StatusCode == 200) {
						alert("added");
						$scope.feeCategoryArr = [];
						$scope.getFeeStructureDetails();
					} else {
						alert("Got Error");
					}
				});
			} else {
				alert("Please enter Fee Structure Name")
			}
		} else {
			alert("Nothing Changed");
			return;
		}
	}

	$scope.getFeeStructureDetails = function () {
		$scope.feeStructureDetailsArray = [];
		$scope.tempCatId = 0;
		httpFactory.getResult("getFeeStructureDetails?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classCourseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.structureName = false;
				$scope.feeStructureDetails = data.data;
				if (Object.keys($scope.feeStructureDetails).length !== 0) {
					$scope.structureName = true;
					for (i = 0; i < $scope.feeStructureDetails.feeStructureDetailsArr.length; i++) {
						$scope.feeStructureDetails.feeStructureDetailsArr[i]["isDelete"] = true;
					}
					/*for(i=0;i<$scope.feeStructureDetails.feeStructureDetailsArr.length;i++){
						for(j=0;j<$scope.feeIntervals.length;j++){
							if($scope.feeStructureDetails.feeStructureDetailsArr[i].feeCategoryInterval == $scope.feeIntervals[j].feeIntervalId){
								$scope.feeStructureDetails.feeStructureDetailsArr[i]["feeCategoryIntervalName"] = $scope.feeIntervals[j].feeIntervalName;
							}
							if($scope.feeStructureDetails.feeStructureDetailsArr[i].isOptional == 1){
								$scope.feeStructureDetails.feeStructureDetailsArr[i]["isOptionalText"] = "Yes";
							}else if($scope.feeStructureDetails.feeStructureDetailsArr[i].isOptional == 0){
								$scope.feeStructureDetails.feeStructureDetailsArr[i]["isOptionalText"] = "No";
							}
						}
					}*/
					$scope.feeStructureDetailsArray = $scope.feeStructureDetails.feeStructureDetailsArr;
				}

			} else {

			}
		});
	}

	$scope.updateFeeStructure = function () {
		if (($scope.feeCategoryArr.length > 0) || (document.getElementById("structName").value != $scope.feeStructureDetails.feeStructureName)) {
			var params = {
				"schemaName": $scope.schemaName,
				"feeStructureId": $scope.feeStructureDetails.feeStructureId,
				"feeStructureName": document.getElementById("structName").value,
				"createdBy": $scope.user_id,
				"feeCategoryArray": $scope.feeCategoryArr
			}
			console.log(params);
			httpFactory.executePost("updateFeeStructure", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("added");
					$scope.feeCategoryArr = [];
					$scope.getFeeStructureDetails();
				}
				else {
					alert("Got Error");
				}
			});
		} else {
			alert("Nothing Changed");
			return;
		}
	}

	$scope.deleteFeeStructure = function (feeStructureObj) {
	    if(!confirm("The Structure will be deleted"))
            return;
	    var categoryArr=[];
	    for(i=0;i<feeStructureObj.feeStructureDetailsArr.length;i++){
            categoryArr.push(feeStructureObj.feeStructureDetailsArr[i].feeStructureDetailId);
	    }
		var params = {
			"schemaName": $scope.schemaName,
			"feeStructureId": feeStructureObj.feeStructureId,
			"categoryArr":categoryArr,
			"deletedBy": $scope.user_id,
		}
		httpFactory.executePost("deleteFeeStructure", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.getFeeStructureDetails();
				$scope.feeCategoryArr = [];
			} else if (data.StatusCode == 300) {
				alert(data.MESSAGE);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.deleteFeeCategory = function (categoryObj) {
		if ($scope.feeStructureDetailsArray.length == 1) {
			var check = confirm("This fee structure contains only one fee category. Do you want to delete the fee structure as well?");
			if (check) {
				$scope.deleteFeeStructure($scope.feeStructureDetails.feeStructureId);
			}
			return;
		} else {
			if (categoryObj.feeStructureDetailId != undefined) {
			    if(!confirm("The category will be deleted"))
            	    return;
				var params = {
					"schemaName": $scope.schemaName,
					"feeStructureDetailId": categoryObj.feeStructureDetailId,
					"isSubCategorised": categoryObj.isSubCategorised,
					"deletedBy": $scope.user_id
				}
				httpFactory.executePost("deleteFeeCategory", params, function (data) {
					console.log(data);
					if (data.StatusCode == 200) {
						alert(data.MESSAGE);
						$scope.getFeeStructureDetails();
					} else if (data.StatusCode == 300) {
						alert(data.MESSAGE);
					} else {
						alert(data.MESSAGE);
					}
				});
			} else {
				alert("Fee Structure is not created");
			}
		}
	}

	$scope.addSubCategory = function () {
		$scope.subCategoryArray = [];
		$scope.feeCategoryAmount = "";
		$scope.isSubCategorised = !$scope.isSubCategorised;
		if ($scope.isSubCategorised) {
			var subCategoryObj = {
				"subCategoryName": "",
				"subCategoryAmount": ""
			}
			$scope.subCategoryArray.push(subCategoryObj);
		}
	}

	$scope.addSubCategoryColumn = function () {
		var subCategoryObj = {
			"subCategoryName": "",
			"subCategoryAmount": ""
		}
		$scope.subCategoryArray.push(subCategoryObj);
	}

	//	$scope.calcSubCategoryAmount = function () {
	//		$scope.feeCategoryAmount = 0;
	//		for (i = 0; i < $scope.subCategoryArray.length; i++) {
	//			$scope.feeCategoryAmount += $scope.subCategoryArray[i].subCategoryAmount;
	//		}
	//	}

	$scope.displaySubCategory = function (feeStructureDetailId) {
		if ($scope.tempCatId != feeStructureDetailId)
			$scope.tempCatId = feeStructureDetailId;
		else
			$scope.tempCatId = 0;
	}

	$scope.addNewFeeSubCategory = function (feeStructureDetailObj) {
		//        $("#addNewFeeSubCategory").modal("show");
		if (feeStructureDetailObj != undefined)
			$scope.structureDetailObj = feeStructureDetailObj;
		$scope.isSubCategorised = false;
		$scope.addSubCategory();
	}

	$scope.addNewFeeCategory = function () {
		$scope.isSubCategorised = true;
		$scope.addSubCategory();
	}

	$scope.updateFeeSubCategoryDetails = function () {
		if ($scope.subCategoryArray.length == 0) {
			alert("Nothing to update");
			return;
		}
		for (i = 0; i < $scope.subCategoryArray.length; i++) {
			if ($scope.subCategoryArray[i].subCategoryAmount == 0)
				$scope.subCategoryArray[i].subCategoryAmount = "";
			if (($scope.subCategoryArray[i].subCategoryName == "" && $scope.subCategoryArray[i].subCategoryAmount == "") || ($scope.subCategoryArray[i].subCategoryName == null && $scope.subCategoryArray[i].subCategoryAmount == null) ||
				($scope.subCategoryArray[i].subCategoryName == "" && $scope.subCategoryArray[i].subCategoryAmount == null) || ($scope.subCategoryArray[i].subCategoryName == null && $scope.subCategoryArray[i].subCategoryAmount == "")) {
				$scope.subCategoryArray.splice(i, 1);
				i--;
			}
			if ($scope.subCategoryArray[i].subCategoryName == "" || $scope.subCategoryArray[i].subCategoryAmount == "" || $scope.subCategoryArray[i].subCategoryName == null || $scope.subCategoryArray[i].subCategoryAmount == null) {
				alert("Please enter all the fields");
				return;
			}
		}
		if ($scope.subCategoryArray.length == 0) {
			alert("Nothing to update");
			return;
		}

		//        for(i=0;i<$scope.feeStructureDetailsArray.length;i++){
		//            if($scope.feeStructureDetailsArray[i].feeStructureDetailId==$scope.structureDetailId){
		//                if($scope.feeStructureDetailsArray[i].hasOwnProperty("subCategoryArray")){
		//                    for(j=0;j<$scope.subCategoryArray.length;j++){
		//                        $scope.feeStructureDetailsArray[i].subCategoryArray.push($scope.subCategoryArray[j]);
		//                    }
		//                }else{
		//                    $scope.feeStructureDetailsArray[i]["subCategoryArray"]=$scope.subCategoryArray;
		//                }
		//            }
		//        }
		$scope.addFeeSubCategory();
	}

	$scope.addFeeSubCategory = function () {
		if ($scope.subCategoryArray.length > 0) {
			var params = {
				"schemaName": $scope.schemaName,
				"feeStructureDetailId": $scope.structureDetailObj.feeStructureDetailId,
				"isSubCategorised": $scope.structureDetailObj.isSubCategorised,
				"createdBy": $scope.user_id,
				"subCategoryArray": $scope.subCategoryArray
			}
			console.log(params);
			httpFactory.executePost("addFeeSubCategory", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("added");
					$scope.subCategoryArray = [];
					$scope.getFeeStructureDetails();
					$scope.structureDetailObj = {};
					$("#addNewFeeSubCategory").modal("hide");
				} else {
					alert("Got Error");
				}
			});
		} else {
			alert("Nothing Changed");
			return;
		}
	}

	$scope.deleteFeeSubCategory = function (selCategoryObj,subCategoryId) {

	    if (selCategoryObj.subCategoryArray.length == 1) {
//	        $scope.selectedSubCategoryObj=selSubCategoryObj;
            var check = confirm("This fee category contains only one fee subcategory. Do you want to delete the fee category as well?");
            if (check) {
                $scope.deleteFeeCategory(selCategoryObj);
            }
            return;
        }else{
		if (subCategoryId != undefined) {
		    if(!confirm("The sub category will be deleted"))
		        return;
			var params = {
				"schemaName": $scope.schemaName,
				"subCategoryId": subCategoryId,
				"deletedBy": $scope.user_id
			}
			httpFactory.executePost("deleteFeeSubCategory", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert(data.MESSAGE);
					$scope.getFeeStructureDetails();
				} else if (data.StatusCode == 300) {
					alert(data.MESSAGE);
				} else {
					alert(data.MESSAGE);
				}
			});
		} else {
			alert("Fee Structure is not created");
		}
		}
	}

});
