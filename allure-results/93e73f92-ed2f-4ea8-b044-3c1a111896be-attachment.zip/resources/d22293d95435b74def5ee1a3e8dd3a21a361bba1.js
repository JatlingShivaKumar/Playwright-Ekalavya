projectModule.controller('rankrClassesController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {

	$scope.$ = $;
	$scope.instituteId = 1;
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.getItem("bnchnme");

	$scope.rankrClassesInit=function(){
		if (sessionStorage.getItem("navClassId")) {
			$scope.navCourseId = sessionStorage.getItem("navCourseId");
			$scope.navClassId = sessionStorage.getItem("navClassId");
			sessionStorage.removeItem("navClassId");
			sessionStorage.removeItem("navCourseId");
		}
		$scope.getCourseByBranchId();
		$scope.currentpath=JSON.stringify(localStorage.getItem('location'));
		localStorage.setItem('location', JSON.stringify($location.path("rankrClasses")));
				
		
}
	$scope.getCourseByBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if($scope.courseList.length==1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);		
					$scope.courseSelect($scope.selectedCourseOb);
				}			
				console.log($scope.navCourseId);			
				if($scope.navCourseId){
					for (var i = 0; i < $scope.courseList.length; i++) {
						if($scope.courseList[i].courseId==$scope.navCourseId){
							$scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
							$scope.courseSelect($scope.selectedCourseOb);
						}
					}
				}
			}
		});
	}
	// $scope.getCourseByBranchId();
	$scope.courseSelect = function(courseOb){
		$scope.courseObj = JSON.parse(courseOb);
		$scope.selectedCourse=$scope.courseObj.courseId;
		$scope.courseName=$scope.courseObj.courseName;
		httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
				if($scope.navCourseId){
					for (var i = 0; i < $scope.classList.length; i++) {
						if($scope.classList[i].classId==$scope.navClassId){
							$scope.selectedClassOb=JSON.stringify($scope.classList[i]);
							$scope.selectedCCId=$scope.selectedClassOb.classCourseId;
							$scope.courseClassSelect($scope.selectedClassOb);
						}
					}
				}
			}
		});
	}
	
	$scope.courseClassSelect = function(classOb){
    console.log(classOb);
    $scope.classObj = JSON.parse(classOb);
    $scope.selectedCCId=$scope.classObj.classCourseId;
		$scope.className=$scope.classObj.className;
		$scope.sectionList=[];
		$scope.sectionId="";
		httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
				$scope.sectionSelected($scope.sectionList[0]);
			}else{
				$scope.sectionList=[];
			}
		});
	}
	$scope.sectionSelected=function(section){
		console.log(section);
		$scope.subjList=[];
		$scope.subjList=section.Subjects;
		$scope.selectedSectionOb=section;
		$scope.sectionId=$scope.selectedSectionOb.sectionId;
		$scope.sectionName = $scope.selectedSectionOb.sectionName;
	}
	$scope.goToAttendance=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.clsOb.classId);
			sessionStorage.setItem("navSectionId",$scope.sectionId);
			sessionStorage.setItem("myClasses","myClasses");
			$location.path("attendance");
	}
	$scope.goToHW=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.clsOb.classId);
			sessionStorage.setItem("navSectionId",$scope.sectionId);
			sessionStorage.setItem("myClasses","myClasses");
			$location.path("assignment");
	}
	$scope.goToTimeTable=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.clsOb.classId);
			sessionStorage.setItem("navSectionId",$scope.sectionId);
			sessionStorage.setItem("myClasses","myClasses");
			$location.path("timeTable");
	}

	$scope.goToRepotCard=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.clsOb.classId);
			sessionStorage.setItem("navSectionId",$scope.sectionId);
			sessionStorage.setItem("myClasses","myClasses");
		$location.path("reportAnalysis");
	}

	$scope.goToSectionStudents=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.clsOb.classId);
			sessionStorage.setItem("navSectionId",$scope.sectionId);
			sessionStorage.setItem("myClasses","myClasses");
			$location.path("sectionStudents");
	}
	$scope.goToAttendanceView=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
		sessionStorage.setItem("regAtt",$scope.sectionId);
		sessionStorage.setItem("navCourseId",$scope.selectedCourse);
		sessionStorage.setItem("navClassId",$scope.clsOb.classId);
		sessionStorage.setItem("navSectionId",$scope.sectionId);
		sessionStorage.setItem("myClasses","myClasses");
		$location.path("attendance");
	}
	$scope.goToHomeworkAdd=function(){
		$scope.clsOb = JSON.parse($scope.selectedClassOb);
		sessionStorage.setItem("hwadd",$scope.sectionId);
		sessionStorage.setItem("navCourseId",$scope.selectedCourse);
		sessionStorage.setItem("navClassId",$scope.clsOb.classId);
		sessionStorage.setItem("navSectionId",$scope.sectionId);
		sessionStorage.setItem("myClasses","myClasses");
		$location.path("assignment");
	}
	$scope.showSectionSubjects=function(){
		$("#sectionSubjects").modal("show");
	}
	$scope.closePopup=function(){
		$("#sectionSubjects").modal("hide");

	}
	
	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	
	$scope.goToHome = function(){
		$location.path("home");
	}
	
});
