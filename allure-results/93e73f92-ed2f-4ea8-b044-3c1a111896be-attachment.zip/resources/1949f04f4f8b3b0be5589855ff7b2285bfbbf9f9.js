projectModule.controller('whatsAppMessagingController', function ($scope, $location, commonFactory, httpFactory, $routeParams, $route, $sce, $compile) {
	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.roleId = localStorage.getItem("RD");
	$scope.isStudent = false;
	$scope.isStudentAll = true;
	$scope.isStudentAllChk = 1;
	$scope.isStaffS = false;
	$scope.isStaffAll = true;
	$scope.isStaffAllChk = 1;
	$scope.isStuAll = false;
	$scope.isCustomTemplate = false;

	$scope.smsType = 'Whatsapp';
	var selectDiv = document.getElementById("selectDiv");
	$scope.branchObjArray = [];
	$scope.courseIdArr = [];

	$scope.pageLoad = function () {
		$scope.getWhatsAppTemplates();
		$scope.selectWhatsAppMessageType('templates');
	}

	$scope.goToMessaging = function () {
		$location.path("messaging");
	}

	$scope.goToDashbord = function () {
		$location.path("rankrPlus");
	}


	$scope.isStuAllCheck = function () {
		if (document.getElementById("isS").checked == true) {
			$scope.isStudentAllChk = 1;
			$scope.allBCCList.isStudent = true;
			//console.log($scope.allBCCList);
		}
		else {
			$scope.isStudentAllChk = 0;
			$scope.allBCCList.isStudent = false;
			//console.log($scope.allBCCList);
			for (var i = 0; i < $scope.allBCCList.length; i++) {
				$scope.courseOb = $scope.allBCCList[i].courses;
				for (var j = 0; j < $scope.courseOb.length; j++) {
					$scope.courseIdArr.push($scope.courseOb[j].courseId);

					if (!$scope.courseIdStr) {
						$scope.courseIdStr = $scope.courseOb[j].courseId;
					} else {
						if (!$scope.courseIdArr.includes($scope.courseOb[j].courseId))
							$scope.courseIdStr = $scope.courseIdStr + "," + $scope.courseOb[j].courseId;
					}
					$scope.classOb = $scope.courseOb[j].classes;
					//console.log($scope.classOb);


					for (var k = 0; k < $scope.classOb.length; k++) {
						if (!$scope.classIdStr)
							$scope.classIdStr = $scope.classOb[k].classId;
						else
							$scope.classIdStr = $scope.classIdStr + "," + $scope.classOb[k].classId;
					}
				}

				var branchObject = {
					"branchId": $scope.allBCCList[i].branchId,
					"courseId": $scope.courseIdStr,
					"classId": $scope.classIdStr
				}

				$scope.courseIdStr = "";
				$scope.classIdStr = "";
				$scope.branchObjArray.push(branchObject);
			}
			//console.log($scope.branchObjArray);
			//console.log($scope.courseIdStr);
			//console.log($scope.classIdStr);

		}
	}
	$scope.isStaffAllCheck = function () {
		if (document.getElementById("isStaffAll").checked == false) {
			$scope.isStaffAllChk = 0;
		}
		else {
			$scope.isStaffAllChk = 1;

		}
	}

	$scope.allBCCList = [];
	$scope.staffBranchList = [];
	$scope.getAllBranchClassCourseSections = function () {
		httpFactory.getResult("getAllBranchClassCourseSections?schemaName=" + $scope.schemaName + "&instId=" + $scope.instituteId + "&roleId=" + $scope.roleId + "&branchId=" + $scope.branchId, function (data) {
			//console.log(data);
			if (data.StatusCode == '200') {
				$scope.allBCCList = data.collegesInfo;
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i]["selected"] = false;
					var stbrobj = {
						"branchId": $scope.allBCCList[i].branchId,
						"branchName": $scope.allBCCList[i].branchName,
						"selected": false
					};
					$scope.staffBranchList.push(stbrobj);
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						$scope.allBCCList[i].courses[j]["selected"] = false;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k]["selected"] = false;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"] = false;
							}
						}
					}
				}
				//console.log($scope.allBCCList);
				//				$scope.staffBranchList=$scope.allBCCList.slice();
				//console.log($scope.staffBranchList);
			}
		});
	}

	$scope.getAllBranchClassCourseSections();

	$scope.selecStudentDetails = [];

	$scope.genrateStudentDetails = function () {

		$scope.selecStudentDetails = [];
		//console.log($scope.allBCCList.isCommon);
		if ($scope.allBCCList.isCommon == false) {
			//console.log(document.getElementById("isStudent").checked);
			if (document.getElementById("isS").checked == false) {
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					//console.log($scope.allBCCList[i]);
					if ($scope.allBCCList[i].selected == true) {
						var branchSelected = {
							"branchId": $scope.allBCCList[i].branchId,
							"studentDetails":
								[{
									"courseId": 0,
									"classId": 0
								}]
						};
						$scope.selecStudentDetails.push(branchSelected);
					}
					else {
						var branchSelected = {
							"branchId": $scope.allBCCList[i].branchId,
							"studentDetails": []
						};
						for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
							if ($scope.allBCCList[i].courses[j].selected == true) {
								var courseSelected = {
									"courseId": $scope.allBCCList[i].courses[j].courseId,
									"classId": 0
								};
								branchSelected.studentDetails.push(courseSelected);
							} else {

								for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
									if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
										var courseSelected = {
											"courseId": $scope.allBCCList[i].courses[j].courseId,
											"classId": ""
										};
										courseSelected.classId = $scope.allBCCList[i].courses[j].classes[k].classId;
										branchSelected.studentDetails.push(courseSelected);
									}
								}

							}
						}
						if (branchSelected.studentDetails.length > 0) {
							$scope.selecStudentDetails.push(branchSelected);
						}
					}
				}
			}
		}
	}

	$scope.fileSizeCheck = function () {
		var files = document.getElementById("choosenFile").files;
		if (files[0] == undefined) {
			return false;
		} else {
			for (var i = 0; i < files.length; i++) {
				var fileSizeMB = files[i].size / (1024 * 1024); // File size in MB
				var fileType = files[i].type; // File type

				if (fileType.includes('image/') && fileSizeMB >= 1) {
					alert("Image file " + files[i].name + " is too big, please select a file less than 1MB");
					return true;
				} else if (fileType === 'video/mp4' && fileSizeMB >= 10) {
					alert("Video file " + files[i].name + " is too big, please select a file less than 10MB");
					return true;
				}
			}
		}
		return false;
	}

	$scope.sendWhatsAppMessage = function () {
		$scope.totalSectionObj = [];

		for (var i = 0; i < $scope.allBCCList.length; i++) {
			for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
				for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
					if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
						var object = {
							"branchId": $scope.allBCCList[i].branchId,
							"courseId": $scope.allBCCList[i].courses[j].courseId,
							"classId": $scope.allBCCList[i].courses[j].classes[k].classId,
						}
						$scope.totalSectionObj.push(object);
					}
				}
			}
		}

		if ($scope.totalSectionObj == undefined || $scope.totalSectionObj.length == 0) {
			alert("Select to whom it need to apply.");
			return true;
		}
		var params = {
			"schemaName": $scope.schemaName,
			"branchOb": $scope.totalSectionObj
		};

		if ($scope.whatsAppMessageType == 'templates') {
			params["staff"] = false;
			if (document.getElementById("stucheck").checked) {
				params["student"] = document.getElementById("stucheck").checked;
			}
			else {
				alert("Please Select Student");
				return;
			}
			params["isCustom"] = $scope.selectedTemplateObject.isCustom;
			params["message"] = $scope.getCombinedString();
			$scope.callSendWhatsAppMessageAPI(params);
		} else {
			if (!document.getElementById("stucheck").checked && !document.getElementById("stacheck").checked) {
				alert("Please Select Student or Staff");
				return;
			}
			else {
				params["staff"] = document.getElementById("stacheck").checked;
				params["student"] = document.getElementById("stucheck").checked;
			}
			var files = document.getElementById("choosenFile").files;
			if (files[0] != undefined) {
				if ($scope.fileSizeCheck() == true) {
					return true;
				}
				var hasVideo = false;
				var fd = new FormData();
				for (var i = 0; i < files.length; i++) {
					if (files[i].type.contains("video/mp4"))
						hasVideo = true
					var blob = files[i].slice(0, files[i].size, files[i].type);
					var newFile = new File([blob], files[i].name.replaceAll(/[^a-zA-Z0-9.]/g, "-"), { type: files[i].type });
					fd.append("file", newFile);

				}
				if (hasVideo)
					alert("Video uploading will take a bit of time, Please wait here and don't click Send again")
				fd.append("schemaName", $scope.schemaName);
				fd.append("domainName", localStorage.getItem("domain"))
				params["hasAttachement"] = true;
				httpFactory.executeFileUpload("uploadWhatsAppDoc", fd, function (data) {
					if (data.StatusCode == 200) {
						params["attachmentsArray"] = data.attachmentsArray;
						params["message"] = document.getElementById("tempmsg").value;
						$scope.callSendWhatsAppMessageAPI(params);
						document.getElementById("choosenFile").value = "";
					} else {
						alert(data.MESSAGE);
					}
				});
			}
			else {
				params["message"] = document.getElementById("tempmsg").value;
				$scope.callSendWhatsAppMessageAPI(params);
			}
			document.getElementById("tempmsg").value = "";
		}
		$scope.classStr = "";
		$scope.courseStr = "";
		$scope.courseIdArr = [];

	}

	$scope.callSendWhatsAppMessageAPI = function (params) {
		httpFactory.executePost("sendGlobalWhatsAppMessage", params, function (data) {
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.resetVal();
				$scope.clearInputs();
			}
		});
	}

	$scope.resetSelections = function (brInd, crInd, clsInd) {
		for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes.length; j++) {
			var cls = $scope.allBCCList[brInd].courses[crInd].classes[j];
			cls.selected = false;
			for (var l = 0; l < cls.sections.length; l++) {
				cls.sections[l].selected = false;
			}
		}
	}

	$scope.generateStudentObj = function (ob, brInd, crInd, clsInd, secInd) {
		if (ob == 'stuAll') {
			if ($scope.stuAll == true) {
				//					$scope.isStuAll=false;
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i].selected = false;
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						//console.log($scope.allBCCList[i]);
						$scope.allBCCList[i].courses[j].selected = false;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k].selected = false;;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = false;
							}
						}
					}
				}
			} else {
				//					$scope.isStuAll=true;

				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i].selected = true;
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						$scope.allBCCList[i].courses[j].selected = true;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k].selected = true;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = true;
							}
						}
					}
				}
			}

		} else if (ob == 'branch') {
			if ($scope.allBCCList[brInd].selected == true) {
				$scope.allBCCList[brInd].selected = false;
				for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
					$scope.allBCCList[brInd].courses[j].selected = false;
					for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
						$scope.allBCCList[brInd].courses[j].classes[k].selected = false;
						for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
							$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = false;
						}
					}
				}
			} else {
				$scope.allBCCList[brInd].selected = true;
				for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
					$scope.allBCCList[brInd].courses[j].selected = true;
					for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
						$scope.allBCCList[brInd].courses[j].classes[k].selected = true;
						for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
							$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = true;
						}
					}
				}
			}
			var isBranchFound = 0;
			for (var i = 0; i < $scope.allBCCList.length; i++) {
				//				alert($scope.allBCCList[i].selected);
				if ($scope.allBCCList[i].selected == false) {
					// $scope.stuAll=false;
					isBranchFound++;
				}
			}
			if (isBranchFound > 0) {
				$scope.stuAll = false;
			}
			else {
				$scope.stuAll = true;
			}
		}
		else if (ob == 'course') {
			if ($scope.allBCCList[brInd].courses[crInd].selected == true) {
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
					$scope.allBCCList[brInd].courses[crInd].classes[k].selected = false;
					//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
					for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
						$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = false;
					}
				}
			} else {
				//			$scope.allBCCList[brInd].selected=false;
				$scope.allBCCList[brInd].courses[crInd].selected = true;
				for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
					$scope.allBCCList[brInd].courses[crInd].classes[k].selected = true;
					//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
					for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
						$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = true;
					}
				}
			}

			var isCourseFound = 0;

			for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
				if ($scope.allBCCList[brInd].courses[j].selected == false) {
					isCourseFound++;
					//branchIndex=i;
				}
			}

			if (isCourseFound > 0) {
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			else {
				$scope.allBCCList[brInd].selected = true;
				//$scope.stuAll=true;
			}
			//$scope.checkBranchSelect();
		}
		else if (ob == 'class') {
			$scope.resetSelections(brInd, crInd, clsInd);
			if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected == true) {
				for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
					$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = false;
				}
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
			} else {
				//			$scope.allBCCList[brInd].courses[crInd].selected=true;
				for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
					$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = true;
				}
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
			}

			var isCourseFound = 0;
			//var branchIndex=-1;
			for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes.length; j++) {
				if ($scope.allBCCList[brInd].courses[crInd].classes[j].selected == true) {
					isCourseFound++;
				}
			}

			if (isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length) {
				$scope.allBCCList[brInd].courses[crInd].selected = true;
			}
			else {
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			// $scope.checkBranchCourseClassSelect(brInd, crInd);
			//$scope.checkBranchCourseSelect(brInd);
		}
		else if (ob == 'section') {
			if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected == true) {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected = false;
			} else {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected = true;
			}


			var isCourseFound = 0;
			//var branchIndex=-1;
			for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; j++) {
				if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[j].selected == false) {
					isCourseFound++;
				}
			}

			if (isCourseFound > 0) {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			else {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
			}
			// $scope.checkBranchCourseClassSelect(brInd, crInd);

		}
	}



	$scope.getWhatsAppMessageLanguages = function () {
		$scope.waLanguageList = [];
		httpFactory.getResult("getWhatsAppMessageLanguages?schemaName=" + $scope.schemaName, function (data) {
			if (data.StatusCode == '200') {
				$scope.waLanguageList = data.whatsappLanguagesArray;
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.getWhatsAppTemplates = function () {
		$scope.waTemplateList = [];
		httpFactory.getResult("getWhatsAppTemplates?schemaName=" + $scope.schemaName + "&roleId=" + $scope.userRoleId + "&branchId=" + $scope.branchId, function (data) {
			if (data.StatusCode == '200') {
				$scope.waTemplateList = data.whatsappTemplatesArray;
			} else {
				alert(data.MESSAGE);
			}
		});
	}


	$scope.showMessageDivFunction = function () {
		$("#messageDiv").css("display", "block");
	}

	$scope.hideMessageDivFunction = function () {
		$("#messageDiv").css("display", "none");
	}

	// Convert the selectTemplateTypeFunction
	$scope.selectTemplateTypeFunction = function (templateType) {
		$scope.getWhatsAppMessageLanguages();
		$scope.hideMessageDivFunction();
		$scope.selectedTemplateType = templateType;
	}

	// Convert the selectLanguageFunction
	$scope.selectLanguageFunction = function (waLang) {
		$scope.hideMessageDivFunction();
		$scope.filterTemplates(waLang);
	}

	// Convert the selectTemplateFunction
	$scope.selectTemplateFunction = function () {
		var a = document.getElementById('waTmplt');
		var option = a.options[a.selectedIndex].value;
		if (option != undefined || option != null) {
			$scope.selectedTemplateObject = JSON.parse(option);
			$scope.convertMessage();
			$scope.showMessageDivFunction();
		}
		else {
			return;
		}
	}

	// Convert the filterTemplates function
	$scope.filterTemplates = function (waLang) {
		if (waLang != undefined) {
			var isDefault = $scope.selectedTemplateType == "UserReqTemplates" ? 0 : 1;
			$scope.filteredTemplateList = [];
			waLang = JSON.parse(waLang);
			$.each($scope.waTemplateList, function (i, template) {
				if (template.languageId == waLang.languageId && template.isDefault == isDefault && template.isApproved == 1) {
					$scope.filteredTemplateList.push(template);
				}
			});
		}
		else
			return;
	}



	$scope.viewTemplate = function () {
		$scope.getWhatsAppTemplates();
		$("#viewTemplate").modal("show");
	}

	$scope.closePopUpLive = function () {
		$("#viewTemplate").modal("hide");
	}

	$scope.addTemplate = function () {
		$scope.getWhatsAppMessageLanguages();
		httpFactory.getResult("getMessageItems", function (data) {
			//console.log(data);
			if (data.STATUS == 'SUCCESS') {
				if ($scope.roleId != 1) {
					$scope.adminTempItemsList = data.itemArray;
					$scope.adminTempItemsList.splice(2, 1);
				} else {
					$scope.adminTempItemsList = data.itemArray;
				}
			} else {
				alert(data.MESSAGE);
			}
		});
		$("#addTemplate").modal("show");
	}

	$scope.cancel = function () {
		$("#addTemplate").modal("hide");
	}

	$scope.deleteTemplate = function (tmplt) {
		var templateId = tmplt.templateId;
		httpFactory.getResult("deleteTemplate?schemaName=" + $scope.schemaName + "&templateId=" + templateId, function (data) {
			if (data.STATUS == 'SUCCESS') {
				alert("Template Delete Successfully");
				$scope.getTemplateDetails();
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.deleteWhatsAppTemplate = function (waTemplateList) {
		var confirmation = confirm("Are you sure you want to delete this template?");
		if (confirmation) {
			var tempParams = {
				"templateId": waTemplateList.templateId,
				"schemaName": localStorage.getItem("sname")
			}
			httpFactory.executePost("deleteWhatsAppTemplate", tempParams, function (data) {
				console.log(data);
				if (data.STATUS == 'SUCCESS') {
					alert("Template Deleted Successfully");
					$scope.getWhatsAppTemplates();
				} else {
					alert(data.MESSAGE);
				}
			});
		}
	}


	$scope.selectWhatsAppMessageType = function (whatsAppMessageType) {
		selectDiv.style.display = "block";
		$scope.whatsAppMessageType = whatsAppMessageType;
		if (whatsAppMessageType == 'templates') {
			selectDiv.style.display = "block";
			if (document.getElementById("templatesAndTypes") != null)
				document.getElementById("templatesAndTypes").style.display = "block";
		} else if (whatsAppMessageType == 'manual') {
			selectDiv.style.display = "block";
			if (document.getElementById("templatesAndTypes") != null)
				document.getElementById("templatesAndTypes").style.display = "none";
		} else {
			selectDiv.style.display = "none";
			if (document.getElementById("templatesAndTypes") != null)
				document.getElementById("templatesAndTypes").style.display = "block";
		}
		$scope.whatsAppTxt = "";
		$scope.templateType = "";
		$scope.waTmplt = "";
		$scope.selectedTemplateObject = {};
		$scope.resetVal();
	}

	$scope.sendWAMessageCheck = function () {
		if ($scope.whatsAppMessageType == 'excel') {
			$scope.uploadWhatsAppExcel();
		} else {
			$scope.sendWhatsAppMessage();
		}
	}

	$scope.uploadWhatsAppExcel = function () {
		var files = document.getElementById("choosenFile").files;
		if (files[0] == undefined) {
			alert("Please upload the excel");
		}
		else {
			var text = $scope.updatedMessage;
			var regex = /{([^}]+)}/g;
			$scope.dataForExcel = [];
			var match;
			$scope.dataForExcel.push("phoneNumber")
			while (match = regex.exec(text)) {
				$scope.dataForExcel.push(match[1]);
			}
			var fd = new FormData();
			fd.append("file", files[0]);
			fd.append("whatsAppTempDetails", $scope.dataForExcel);
			httpFactory.executeFileUpload("uploadWhatsAppExcel", fd, function (data) {
				console.log(data);

				$scope.createMessageFromExcel(data);

			});
		}

	}

	$scope.createMessageFromExcel = function (data) {
		var updatedMessagesArray = [];

		data.forEach(function (obj) {
			var updatedMessage = $scope.updatedMessage;

			// Iterate through the dynamic property names in dataForExcel
			$scope.dataForExcel.forEach(function (propertyName) {
				updatedMessage = updatedMessage.replace('{' + propertyName + '}', obj[propertyName]);
			});
			// Remove newline characters (\n) from the updatedMessage
			updatedMessage = updatedMessage.replace(/\n/g, '');
			updatedMessagesArray.push({
				number: obj.phoneNumber,
				message: updatedMessage
			});
		});

		console.log(updatedMessagesArray);
		$scope.sendWhatsAppMessageThroughExcel(updatedMessagesArray);

	}

	$scope.sendWhatsAppMessageThroughExcel = function (updatedMessagesArray) {
		var params = {
			numberMessageArray: updatedMessagesArray,
			schemaName: localStorage.getItem("sname"),
			branchId: $scope.branchId,
		}
		if (params.numberMessageArray.length > 0) {
			httpFactory.executePost("sendWhatsAppMessageThroughExcel", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.resetVal();
					alert("Whatsapp Message Sent Successfully");
				} else {
					alert("Something went wrong");
					return;
				}
			});
		}
		else {
			alert("No numbers to send");
		}
	}

	$scope.selectAllBranches = function (branches) {
		if (document.getElementById('selectAllBrchs').checked == true) {
			for (j = 0; j < branches.length; j++) {
				document.getElementsByName('selectBrch')[j].checked = true;
			}
		} else {
			for (j = 0; j < branches.length; j++) {
				document.getElementsByName('selectBrch')[j].checked = false;
			}

		}
	}
	$scope.totalBranchObj = [];
	$scope.selectBranch = function (branches) {
		var count = 0;
		for (var i = 0; i < branches.length; i++) {
			if (document.getElementsByName('selectBrch')[i].checked == true) {
				count++;
			}
		}
		if (count == branches.length) {
			$('#selectAllBrchs').prop("checked", true);
		} else {
			$('#selectAllBrchs').prop("checked", false);
		}
	}

	$scope.back = function () {
		$location.path("rankrPlus");
	}

	$("#myInput").on('keyup', function () {
		var value = $(this).val().toLowerCase();
		$("#myUL li").each(function () {
			if ($(this).text().toLowerCase().search(value) > -1) {
				$(this).show();
				$(this).prev('.list').last().show();
			} else {
				$(this).hide();
			}
		});
	})

	$scope.convertMessage = function () {
		if ($scope.selectedTemplateObject != null) {
			if ($scope.selectedTemplateObject.templateMessage != undefined) {
				$scope.dynamicString = $scope.selectedTemplateObject.templateMessage;
				$scope.updatedMessage = $scope.selectedTemplateObject.templateMessage;
			}
			else {
				return
			}
		}
		else {
			return;
		}
		$scope.varArray = [];
		$scope.datePickerArray = [];
		var varPlaceholder = "{#var#}";
		var datePickerPlaceholder = "{#Date#}";
		var varCount = ($scope.dynamicString.match(new RegExp(varPlaceholder, "g")) || []).length;
		var datePickerCount = ($scope.dynamicString.match(new RegExp(datePickerPlaceholder, "g")) || []).length;
		// Replace {#var#} with {TextN}
		if (varCount > 0) {
			for (var i = 1; i <= varCount; i++) {
				$scope.varArray.push({
					var: 'Text' + i,
					value: ''
				});

				var replacementTextAsHTML = "<a ng-click=\"inputMethod('#Text" + i + "#')\">{Text" + i + "}</a>";
				var replacementText = "{Text" + i + "}";
				$scope.dynamicString = $scope.dynamicString.replace(varPlaceholder, replacementTextAsHTML);
				$scope.updatedMessage = $scope.updatedMessage.replace(varPlaceholder, replacementText);
			}
		}
		if (datePickerCount > 0) {
			for (var j = 1; j <= datePickerCount; j++) {
				$scope.datePickerArray.push({
					var: 'Date' + j,
					value: ''
				});
				var dateReplacementTextAsHTML = "<a ng-click=\"inputMethod('#Date" + j + "#')\">{Date" + j + "}</a>";
				var dateReplacementText = "{Date" + j + "}";
				$scope.dynamicString = $scope.dynamicString.replace(datePickerPlaceholder, dateReplacementTextAsHTML);
				$scope.updatedMessage = $scope.updatedMessage.replace(datePickerPlaceholder, dateReplacementText);

				//				var replacementPicker = "<datepicker ng-model=\"datePickerArray[" + (j - 1) + "].value\"></datepicker>";
				//				$scope.dynamicString = $scope.dynamicString.replace(datePickerPlaceholder, replacementPicker);
			}
		}
	}

	$scope.inputMethod = function (val) {
		$scope.selectedVar = '';
		$scope.selectedVar = val;
	}

	$scope.excelOnClick = function () {
		var text = $scope.updatedMessage;
		var regex = /{([^}]+)}/g;
		var matches = [];
		var match;

		while (match = regex.exec(text)) {
			matches.push(match[1]);
		}
		$scope.dataForExcel = matches;

		var CSV = '';
		var header = "phoneNumber,";
		if ($scope.dataForExcel.length > 0) {
			for (i = 0; i < $scope.dataForExcel.length; i++)
				header = header + $scope.dataForExcel[i] + ",";
		}
		else {
			header += "message";
		}
		if (CSV == '') {
			CSV += header + '\r\n';
		}
		blob = new Blob([CSV], {
			type: 'text/csv'
		});

		if (window.navigator && window.navigator.msSaveOrOpenBlob) {
			window.navigator.msSaveOrOpenBlob(blob, "Demo");
		} else {
			const url = URL.createObjectURL(blob);
			const link = document.createElement('a');
			link.href = url;
			link.setAttribute('download', 'Sample_WhatsApp_Template');
			document.body.appendChild(link);
			link.click();
		}

	}

	$scope.getCombinedString = function () {
		var combinedString = $scope.updatedMessage;

		for (var i = 0; i < $scope.varArray.length; i++) {
			var varPlaceholder = "{Text" + (i + 1) + "}";
			var inputValue = $scope.varArray[i].value;
			var regExp = new RegExp(varPlaceholder, "g");
			combinedString = combinedString.replace(regExp, inputValue);
		}

		for (var j = 0; j < $scope.datePickerArray.length; j++) {
			var datePickerPlaceholder = "{Date" + (j + 1) + "}";
			var selectedDate = $scope.datePickerArray[j].value;
			// Format the date to display only day, month, and year
			var formattedDate = new Date(selectedDate);
			var day = formattedDate.getDate();
			var month = formattedDate.getMonth() + 1; // Month is zero-indexed
			var year = formattedDate.getFullYear();

			// Construct the formatted date string
			var formattedDateString = day + '/' + month + '/' + year;
			var regExpDate = new RegExp(datePickerPlaceholder, "g");
			combinedString = combinedString.replace(regExpDate, formattedDateString);
		}

		return combinedString;
	};

	$scope.clearInputs = function () {
		for (var i = 0; i < $scope.varArray.length; i++) {
			$scope.varArray[i].value = '';
		}
		if ($scope.whatsAppMessageType != 'manual') {
			for (var j = 0; j < $scope.datePickerArray.length; j++) {
				$scope.datePickerArray[j].value = '';
			}
		}
		$scope.dynamicString = "";
	};


	$scope.resetVal = function () {
		$scope.selectedTemplateObject = undefined;
		if (document.getElementById("stucheck") != null)
			document.getElementById("stucheck").checked = false;
		if (document.getElementById("stacheck") != null)
			document.getElementById("stacheck").checked = false;
		if (document.getElementById("selectedClass") != null)
			document.getElementById("selectedClass").selectedIndex = -1;
		//$scope.stucheck = false;
		//$scope.stacheck = false;
		$scope.stuAll = false;
		$scope.whatsAppTxt = "";
		$scope.selectedClass = -1;
		$scope.choosenFile = "";
		if ($scope.datePickerArray) {
			$scope.datePickerArray.length = "";
		}

		$scope.dynamicString = '';
		$scope.tempvar = [];
		$scope.varArray = [];

		var checkboxes = document.querySelectorAll("input[id='c1'], input[id='c2']");
		checkboxes.forEach(function (checkbox) {
			checkbox.checked = false;
		});
		$scope.hideMessageDivFunction();
		$('.resett').val("");
	};

	$scope.updateTextArea = function (value) {
		const textarea = document.getElementById("templateMessage");
		textarea.value += value;
	}

	$scope.insertText = function (value) {
		const textarea = document.getElementById("templateMessage");
		textarea.value += value;
	}

	$scope.addWhatsAppTemplate = function () {
		if ($scope.templateMessage == undefined || $scope.templateMessage == "")
			alert("Please give template message");
		if ($scope.templateName == undefined || $scope.templateMessage == "")
			alert("Please give template name");
		var tempParams = {
			"templateName": document.getElementById("templateName").value,
			"templateMessage": document.getElementById("templateMessage").value,
			"createdBy": localStorage.getItem("userId"),
			"languageId": JSON.parse($scope.waLang).languageId,
			"isCustom": $scope.isCustomTemplate == true ? 1 : 0,
			"schemaName": localStorage.getItem("sname")
		}
		if ($scope.userRoleId != 1) {
			tempParams["branchId"] = $scope.branchId;
			tempParams["isApproved"] = 0;
			tempParams["isDefault"] = 0;
		}
		else {
			if ($scope.userRoleId == 1)
				tempParams["isApproved"] = 1;
			tempParams["isDefault"] = 1;
		}

		httpFactory.executePost("addWhatsAppTemplate", tempParams, function (data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS') {
				alert("Template Added Successfully");
				$("#addTemplate").modal("hide");
				$scope.getWhatsAppTemplates();
				$scope.resetFields();
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.resetFields = function () {
		$scope.templateName = '';
		$scope.templateMessage = '';
		$scope.value = null;
		$scope.whatsAppTxt = '';
		$scope.templateType = '';
		$scope.waTmplt = '';
		$scope.selectedTemplateObject = {};
	};

});
projectModule.directive('bindCompiledHtml', ['$compile', function ($compile) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			scope.$watch(attrs.bindCompiledHtml, function (html) {
				element.html(html);
				$compile(element.contents())(scope);
			});
		}
	};
}]);