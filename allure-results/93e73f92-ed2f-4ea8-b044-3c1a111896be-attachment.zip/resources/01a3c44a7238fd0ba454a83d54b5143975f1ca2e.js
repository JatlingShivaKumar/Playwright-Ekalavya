projectModule.controller('circularController', function($scope, $location, commonFactory, httpFactory, $routeParams,$route) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
  //$scope.schemaName = "events";
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.roleId = localStorage.getItem("RD");
	$scope.monthsArr=["January","February","March","April","May","June","July","August","September","October","November","December"];
	$scope.isStuAll=false;
	$scope.stuAll=false;
	$scope.isParentAll=false;
	$scope.staffAll=false;
	$scope.transactionUser=1;



	$scope.adminCircular=function(){
		//		$scope.getCCTransactions();
		$scope.selectTransactionUser($scope.transactionUser);
		$scope.getTransactionTypes();
		$scope.getCurrentAcademicYear();
		$scope.getAllBranchClassCourseSections();
	}
	$scope.studentCircular=function(){
		$scope.roleId=0;
		$scope.branchId=localStorage.getItem("stbrnchid");
		$scope.sectionId=localStorage.getItem("stsecid");
		$scope.transactionUser=2;
		$scope.selectTransactionUser($scope.transactionUser);

	}
	$scope.parentCircular=function(){
		//$scope.roleId=0;
		$scope.branchId=localStorage.getItem("stbrnchid");
		$scope.sectionId=localStorage.getItem("stsecid");
		$scope.transactionUser=3;
		$scope.selectTransactionUser($scope.transactionUser);

	}
	$scope.teacherCircular=function(){
		$scope.transactionUser=1;
		$scope.getTransactionTypes();
		$scope.selectTransactionUser($scope.transactionUser);
	}

	$scope.getTransactionTypes=function(){
		var trans={
				"transactionTypes":[{
					"transactionName":"PTM",
					"transactionId":"1"
				},
				{
					"transactionName":"SPORTS",
						"transactionId":"2"
				}]
		}
//		$scope.transactionTypes=["PTM","SPORTS"];
		$scope.transactionTypes=trans.transactionTypes;
		console.log($scope.transactionTypes);
	}

	$scope.selectMonth=function(month){
		console.log(month);
		var jsonMonth;
		if(typeof month=='string')
			jsonMonth = JSON.parse(month);
		else
			jsonMonth = month;

		console.log(jsonMonth);
		var splitMonth = jsonMonth.monthName.split(" ");
		console.log(splitMonth);
		if(jsonMonth.monthIndex>9 == true)
		$scope.circularDate = splitMonth[1]+"-"+jsonMonth.monthIndex+"-01";
		else
		$scope.circularDate = splitMonth[1]+"-0"+jsonMonth.monthIndex+"-01";

		console.log($scope.circularDate);
	}
	$scope.getCurrentAcademicYear=function(){

		httpFactory.getResult("getCurrentAcademicYear?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {

			var startArr = data.startDate.split("-");
			var endArr = data.endDate.split("-");

			console.log(startArr);
			console.log(endArr);
			console.log(parseInt(startArr[1]));
			console.log($scope.monthsArr);


			console.log($scope.monthsArr[parseInt(startArr[1])]);

			var str1 = $scope.monthsArr[parseInt(startArr[1])]+" "+startArr[0];
			var str2 = $scope.monthsArr[parseInt(endArr[1])]+" "+endArr[0];
			console.log(diff(str1, str2));
			$scope.academicMonthArr=diff(str1,str2);
			console.log($scope.academicMonthArr);
			var thisDate = new Date();
			for(var i=0; i<$scope.academicMonthArr.length; i++){
				if((thisDate.getMonth()+1) == $scope.academicMonthArr[i].monthIndex){
					$scope.selectMonObj = $scope.academicMonthArr[i];
					console.log($scope.selectMonObj);
					$scope.selectMonth($scope.selectMonObj);
					break;
				}
			}
			var trascDate = new Date();
			for(var i=0; i<$scope.academicMonthArr.length; i++){
				var transactionDateIndx = $scope.academicMonthArr[i].monthName.split(" ");
				if(transactionDateIndx[1] >  trascDate.getFullYear()){
					$scope.academicMonthArr[i].editState = true;
				}else if((trascDate.getFullYear() == transactionDateIndx[1]) && ( parseInt($scope.academicMonthArr[i].monthIndex) >= trascDate.getMonth()+1)){
					$scope.academicMonthArr[i].editState = true;
				}else{
					$scope.academicMonthArr[i].editState = false;
				}
			}

			}else{
			}
		});
	}

	function diff(from, to) {
	    var arr = [];
	    var datFrom = new Date('1 ' + from);
	    var datTo = new Date('1 ' + to);
	    var fromYear =  datFrom.getFullYear();
	    var toYear =  datTo.getFullYear();
	    var diffYear = (12 * (toYear - fromYear)) + datTo.getMonth();

	    for (var i = datFrom.getMonth(); i <= diffYear; i++) {
	    	if(i>11)
	    		$scope.index=i-12;
	    	else
	    	$scope.index=i;

	    	var params= {
	    			"monthName":$scope.monthsArr[i%12] + " " + Math.floor(fromYear+(i/12)),
	    			"monthIndex":$scope.index+1,
	    	}
	        arr.push(params);
	    }

	    return arr;
	}

	$scope.addCirculars=function(){
		console.log("addcirc");
		$scope.allBCCList=[];
		$scope.getAllBranchClassCourseSections();
		$('#addcirculars').modal("show");
	}
	$scope.allBCCList = [];
	$scope.staffBranchList=[];
	//$scope.staffBranchList=[];
	$scope.getAllBranchClassCourseSections = function(){
		$scope.staffBranchList = [];
		if($scope.roleId=="1"){
			$scope.apiResult = "getAllBranchClassCourseSections?schemaName="+localStorage.getItem("sname")+"&instId="+$scope.instituteId;
		}else{
			$scope.apiResult = "getAllBranchClassCourseSections?schemaName="+localStorage.getItem("sname")+"&instId="+$scope.instituteId+"&roleId="+$scope.roleId+"&branchId="+$scope.branchId;
		}
		console.log($scope.roleId);
		console.log($scope.apiResult);
		httpFactory.getResult($scope.apiResult, function(data) {
			console.log(data);
			if(data.StatusCode == '200'){
				$scope.allBCCList = data.collegesInfo;
				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i]["selected"]=false;
					var stbrobj ={
	                        "branchId": $scope.allBCCList[i].branchId,
	                        "branchName": $scope.allBCCList[i].branchName,
	                        "selected":false
	                    };
	                    $scope.staffBranchList.push(stbrobj);
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						$scope.allBCCList[i].courses[j]["selected"]=false;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k]["selected"]=false;
							console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"]=false;
							}
						}
					}
				}
				console.log($scope.allBCCList);
//				$scope.staffBranchList=$scope.allBCCList.slice();
				console.log($scope.staffBranchList);
			}
		});
	}


	$scope.checkIsCom =  function(){
		if(document.getElementById("isCom").checked == false){
			$scope.isCom = 0;
//		document.getElementById("isS").checked = false;
//			$scope.isStuAllCheck();
			$scope.allBCCList.isCommon=false;
			console.log($scope.allBCCList);
		}
		else{
			$scope.isCom = 1;
//			document.getElementById("isS").checked = true;
//			$scope.isStuAllCheck();
//			alert($scope.isCom);
			$scope.allBCCList.isCommon=true;
			console.log($scope.allBCCList);
		}
	}

	$scope.updateFlags=function(){
//		$scope.isStuAll=1;
	}
	$scope.updateFlags();
	$scope.generateStaffObj = function(ob,brInd){
		console.log(ob);
		if(ob=='staffAll'){
			for(var i=0;i<$scope.staffBranchList.length;i++){
				if($scope.staffBranchList[i].selected==false || $scope.staffBranchList[i].selected==undefined){
					$scope.staffBranchList[i].selected=true;
				}else{
					$scope.staffBranchList[i].selected=false;
				}
			}
		}else{
			if($scope.staffBranchList[brInd].selected==true){
				$scope.staffBranchList[brInd].selected=false;
			}else{
				$scope.staffBranchList[brInd].selected=true;
			}
				var stfeditAlChk = 0;
				for(var j=0;j<$scope.staffBranchList.length;j++){
					if($scope.staffBranchList[j].selected != true){
						stfeditAlChk++;
					}
				}
				if(stfeditAlChk == 0){
					$scope.staffAll = true;
				}else{
					$scope.staffAll = false;
				}

		}
	}
	$scope.generateStudentObj=function(ob,brInd,crInd,clsInd,secInd){
		if(ob=='student'){
		if($scope.isStuAll==true){
//			$scope.stuAll=false;
			for(var i=0;i<$scope.allBCCList.length;i++){
				$scope.allBCCList[i].selected=false;
				for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
					console.log($scope.allBCCList[i]);
					$scope.allBCCList[i].courses[j].selected=false;
					for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
						$scope.allBCCList[i].courses[j].classes[k].selected=false;;
						console.log($scope.allBCCList[i].courses[j].classes[k]);
						for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
							$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=false;
						}
					}
				}
			}
		}else{
//			$scope.stuAll=true;
			for(var i=0;i<$scope.allBCCList.length;i++){
				$scope.allBCCList[i].selected=true;
				for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
					$scope.allBCCList[i].courses[j].selected=true;
					for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
						$scope.allBCCList[i].courses[j].classes[k].selected=true;
						console.log($scope.allBCCList[i].courses[j].classes[k]);
						for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
							$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=true;
						}
					}
				}
			}
		}
	}
		else if(ob=='stuAll'){
			if($scope.stuAll==true){
//				$scope.isStuAll=false;
				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=false;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						console.log($scope.allBCCList[i]);
						$scope.allBCCList[i].courses[j].selected=false;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=false;;
							console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=false;
							}
						}
					}
				}
			}else{
//				$scope.isStuAll=true;

				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=true;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						$scope.allBCCList[i].courses[j].selected=true;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=true;
							console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=true;
							}
						}
					}
				}
			}

		}else if(ob=='branch'){
			if($scope.allBCCList[brInd].selected==true){
			$scope.allBCCList[brInd].selected=false;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=false;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=false;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=false;
					}
				}
			}
		}else{
			$scope.allBCCList[brInd].selected=true;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=true;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=true;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=true;
					}
				}
			}
		}
		for(var i=0;i<$scope.allBCCList.length;i++){
			var isBranchFound=0;
			if($scope.allBCCList[i].selected==false){
				// $scope.stuAll=false;
				isBranchFound++;
			}
	}
	if(isBranchFound>0)
	$scope.stuAll=false;
	else
	$scope.stuAll=true;
}
	else if(ob=='course'){
		if($scope.allBCCList[brInd].courses[crInd].selected==true){
		$scope.allBCCList[brInd].courses[crInd].selected=false;
		for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
			$scope.allBCCList[brInd].courses[crInd].classes[k].selected=false;
			console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=false;
			}
		}
	}else{
//		$scope.allBCCList[brInd].selected=false;
		$scope.allBCCList[brInd].courses[crInd].selected=true;
		for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
			$scope.allBCCList[brInd].courses[crInd].classes[k].selected=true;
			console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=true;
			}
		}
	}

		var isCourseFound=0;

		for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
			if($scope.allBCCList[brInd].courses[j].selected==false){
				isCourseFound++;
				//branchIndex=i;
			}
		}

	if(isCourseFound>0){
		$scope.allBCCList[brInd].selected=false;
		$scope.stuAll=false;
	}
	else{
		$scope.allBCCList[brInd].selected=true;
		//$scope.stuAll=true;
	}
	$scope.checkBranchSelect();
}
	else if(ob=='class'){
		if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected==true){
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected=false;
			}
			$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
	}else{
//		$scope.allBCCList[brInd].courses[crInd].selected=true;
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected=true;
			}
			$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
		}

			var isCourseFound=0;
			//var branchIndex=-1;
			for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes.length;j++){
				if($scope.allBCCList[brInd].courses[crInd].classes[j].selected==true){
					isCourseFound++;
				}
			}

		if(isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length){
			$scope.allBCCList[brInd].courses[crInd].selected = true;
		}
		else
		{
			$scope.allBCCList[brInd].courses[crInd].selected = false;
			$scope.allBCCList[brInd].selected=false;
			$scope.stuAll=false;
		}
		$scope.checkBranchCourseClassSelect(brInd,crInd);
		//$scope.checkBranchCourseSelect(brInd);
	}
	else if(ob=='section'){
		if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected==true){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=false;
	}else{
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=true;
		}


		var isCourseFound=0;
		//var branchIndex=-1;
		for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;j++){
			if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[j].selected==false){
				isCourseFound++;
			}
		}

	if(isCourseFound>0){
		$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
		$scope.allBCCList[brInd].courses[crInd].selected = false;
		$scope.allBCCList[brInd].selected=false;
		$scope.stuAll=false;
	}
	else{
		$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
	}
	$scope.checkBranchCourseClassSelect(brInd,crInd);

	}
	}

	$scope.checkBranchSelect = function(){
		var isBranchFound=0;
		for(var i=0;i<$scope.allBCCList.length;i++){

			if($scope.allBCCList[i].selected==true){
				// $scope.stuAll=false;
				isBranchFound++;
			}
		}
		if(isBranchFound == $scope.allBCCList.length)
			$scope.stuAll=true;
		else
			$scope.stuAll=false;
	}


	$scope.checkBranchCourseSelect=function(brInd){
		var isCourseFound = 0;
		for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
			if($scope.allBCCList[brInd].courses[j].selected==true){
				isCourseFound++;
			}
		}

		if(isCourseFound== $scope.allBCCList[brInd].courses.length){
			$scope.allBCCList[brInd].selected = true;
		}
		else{
			$scope.allBCCList[brInd].selected = false;
		}

		$scope.checkBranchSelect();
	}
	$scope.checkBranchCourseClassSelect=function(brInd,crInd){
		var isCourseFound = 0;
		for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes.length;j++){
			if($scope.allBCCList[brInd].courses[crInd].classes[j].selected==true){
				isCourseFound++;
			}
		}

		if(isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length){
			$scope.allBCCList[brInd].courses[crInd].selected = true;
		}
		else {
			$scope.allBCCList[brInd].courses[crInd].selected = false;
		}
		$scope.checkBranchCourseSelect(brInd);
	}


	$scope.selectTransactionType=function(obj){
	}

	$scope.userObj=[];
	$scope.addCircular=function(){
		var files = document.getElementById("choosenFile").files;
		console.log(files);
		if(files[0] == undefined){
			alert("Add File Attachment");
			return true;
		}

		$scope.totalStaffObj = [];
		for(var i=0; i<$scope.staffBranchList.length;i++){
			if($scope.staffBranchList[i].selected == true){
				var obj = {
					"branchId":$scope.staffBranchList[i].branchId
				}
				$scope.totalStaffObj.push(obj);
			}
		}


		$scope.totalSectionObj=[];
		for(var i=0;i<$scope.allBCCList.length;i++){
			for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
				console.log($scope.allBCCList[i]);
				for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
					console.log($scope.allBCCList[i].courses[j].classes[k]);
					for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
						if($scope.allBCCList[i].courses[j].classes[k].sections[l].selected==true){
								var object = {
										"branchId":$scope.allBCCList[i].branchId,
										"courseId":$scope.allBCCList[i].courses[j].courseId,
										"classId":$scope.allBCCList[i].courses[j].classes[k].classId,
										"sectionId":$scope.allBCCList[i].courses[j].classes[k].sections[l].sectionId
								}
							$scope.totalSectionObj.push(object);
						}
					}
				}
			}
		}
		console.log($scope.totalSectionObj);
		$scope.userObj = [];
		if($scope.isStuAll==1){
			var ob = {
					"userType":2
			}
			$scope.userObj.push(ob);
		}
		if($scope.isParentAll==1){
			var ob = {
					"userType":3
			}
			$scope.userObj.push(ob);
		}
		if($scope.totalSectionObj.length > 0){
			if($scope.userObj.length == 0){
				alert("Select from student and staff or both");
				return true;
			}
		}

		if($scope.totalStaffObj.length > 0){
			var ob = {
					"userType":1
			}
			$scope.userObj.push(ob);
		}

		if($scope.userObj.length>0){

		var params={
			"schemaName":$scope.schemaName,
			"transactionType":1,
			"transactionName":$scope.circularName,
			"transactionDate":$scope.circularDate,
			"createdBy":$scope.userId,
			"users":$scope.userObj,
			"staffDetails":$scope.totalStaffObj,
			"studentDetails":$scope.totalSectionObj
		}
		console.log(params);
		httpFactory.executePost("addCCTransactions", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
			  alert("sucesfully changed");
				$('#addcirculars').modal("hide");
				$scope.acadTransId=data.academicTransactionId;
				$scope.uploadCircular();
				$scope.selectTransactionUser($scope.transactionUser);
			}
			else{
				alert("Please try agian after some time");
			}
		});
	}else{
		alert("Select Users");
	}
	}


//	$scope.transactionUser=1;

	$scope.getCCTransactions = function(){
//		$scope.roleId=2;
//		$scope.branchId=4;

		var params = {
				"schemaName":localStorage.getItem("sname"),
				"roleId":$scope.roleId,
				"transactionUser":$scope.transactionUser,
			  "branchId":$scope.branchId
		}
		if($scope.roleId=="0" || $scope.roleId=="4"){
			params["sectionId"]=$scope.sectionId;
		}
		httpFactory.executePost("getCCTransactions", params, function(data) {
			console.log(data);
			$scope.transactionList=[];
			if (data.StatusCode == 200) {
				$scope.transactionList = data.transactions;
				for(var i=0; i<$scope.transactionList.length; i++){
					for(var j=0; j<$scope.transactionTypes.length;j++){
						if($scope.transactionList[i].transactionType == $scope.transactionTypes[j].transactionId){
							$scope.transactionList[i].transactionTypeName = $scope.transactionTypes[j].transactionName;
						}
					}
					if($scope.transactionList[i].filePath == 'NA'){
						$scope.transactionList[i].fileName = "NA";
					}else{
					 var dumpFileLs =	$scope.transactionList[i].filePath.split("/");
					 $scope.transactionList[i].fileName = dumpFileLs[dumpFileLs.length-1];
					}

					var transacDateIndx = $scope.transactionList[i].transactionDate.split("-");
					var trascDate = new Date();
					if(transacDateIndx[0] >  trascDate.getFullYear()){
						$scope.transactionList[i].editState = true;
					}else if((trascDate.getFullYear() == transacDateIndx[0]) && (trascDate.getMonth()+1 < parseInt(transacDateIndx[1]))){
						$scope.transactionList[i].editState = true;
					}else{
						$scope.transactionList[i].editState = false;
					}
				}
			}
			else{
				console.log("No Transactions");
			}


			$scope.reverseOrd = false;
			$scope.perpageIndx = 6;
			$scope.pgstartIndx = 1;
			$scope.pgendIndx = $scope.perpageIndx;
			$scope.prevFlag = false;
			$scope.nxtFlag = true;
			$scope.pgIndex = 1;
			$scope.resultsIndx = 1;
			if($scope.transactionList.length <= $scope.pgendIndx ){
				$scope.nxtFlag = false;
			}
			if($scope.transactionList.length < $scope.pgendIndx){
				$scope.resultsIndx = $scope.pgstartIndx + ($scope.transactionList.length - $scope.pgstartIndx);
			}else{
				$scope.resultsIndx = $scope.pgendIndx;
			}
		});
	}

	$scope.selectTransactionUser=function(user){
		$scope.transactionUser=user;
		$scope.getCCTransactions();
	}

	$scope.selectedCircular=function(circular){
		console.log(circular);
		$scope.acadTransId=circular.academicTransactionId;
		//$scope.acadCircularPaths = circular.filePath;
		console.log($scope.acadTransId);
		$scope.getAllBranchClassCourseSections();
		$scope.getDetailsByTransactionId();
	}
	$scope.showViewCircular = function(trans){
		//$scope.selectedCircular(trans);
		var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+trans.filePath+"&embedded=true";
		$("#MyFrame").attr("src", path);
		var fTypelist = trans.filePath.split(".");
		var ftype = fTypelist[fTypelist.length-1];


		if(ftype != "doc" && ftype != "docx" && ftype != "csv" && ftype != "xls" && ftype != "xlsx"){
			$("#viewcirculars").modal("show");
		}
		//$("#viewcirculars").modal("show");
	}

	$scope.showEditCircular = function(trans){
		$scope.selectedCircular(trans);


		console.log($scope.academicMonthArr);
		$("#editcirculars").modal("show");
	}

	$scope.uploadCircular = function(){
		var files = document.getElementById("choosenFile").files;
		console.log(files);
		if(files[0] == undefined){
			return true;
		}
		console.log(files);
		var fd = new FormData();
		fd.append("academicTransactionId",$scope.acadTransId);
		fd.append("schemaName",$scope.schemaName)
		for(var i=0; i<files.length; i++){
			fd.append("file", files[i]);
		}
		console.log(fd);
		httpFactory.executeFileUpload("uploadTransactionsDetail", fd, function(data) {
			console.log(data);
			alert("uploaded");
			document.getElementById("choosenFile").value = "";
		});
	}
	$scope.uploadCircular1 = function(){
		var files = document.getElementById("choosenFile1").files;
		console.log(files);
		if(files[0] == undefined){
			return true;
		}
		console.log(files);
		var fd = new FormData();
		fd.append("academicTransactionId",$scope.acadTransId);
		fd.append("schemaName",$scope.schemaName)
		for(var i=0; i<files.length; i++){
			fd.append("file", files[i]);
		}
		console.log(fd);
		httpFactory.executeFileUpload("uploadTransactionsDetail", fd, function(data) {
			console.log(data);
			alert("uploaded");
			document.getElementById("choosenFile1").value = "";
		});
	}

	$scope.getDetailsByTransactionId = function(){
		var params = {
				"schemaName":localStorage.getItem("sname"),
			  "academicTransactionId":$scope.acadTransId
		}
		httpFactory.executePost("getDetailsByTransactionId", params, function(data) {
			console.log(data);
//			if (data.StatusCode == 200) {
				$scope.transactionDetail = data;
				console.log($scope.transactionDetail);
				$scope.generateStaffEditOb();
				$scope.generateStuEditOb();
				$scope.ecircularName = data.transactionName;
				$scope.transactionTypeId = ""+data.transactionType;
				var transactionDateIndx = $scope.transactionDetail.transactionDate.split("-");
				for(var i=0; i<$scope.academicMonthArr.length; i++){
						//var doopMonthIndx = $scope.academicMonthArr[i].monthIndex;
					if(parseInt(transactionDateIndx[1]) == $scope.academicMonthArr[i].monthIndex){
						$scope.month = $scope.academicMonthArr[i];
						var splitMonth = $scope.month.monthName.split(" ");
						console.log(splitMonth);
						if($scope.month.monthIndex>9 == true)
							$scope.circularDate = splitMonth[1]+"-"+$scope.month.monthIndex+"-01";
						else
							$scope.circularDate = splitMonth[1]+"-0"+$scope.month.monthIndex+"-01";

						break;
					}
				}

				for(var j=0; j<$scope.transactionDetail.users.length;j++){
						if($scope.transactionDetail.users[j].userType == "2"){
							$scope.isStuAll = true;
						}
						if($scope.transactionDetail.users[j].userType == "3"){
							$scope.isParentAll = true;
						}
				}


//			}
//			else{
//				alert("Please try again after some time");
//			}
		});
	}
	$scope.generateStaffEditOb = function(){
		for(var i=0;i<$scope.transactionDetail.staffDetails.length;i++){
			for(var j=0;j<$scope.staffBranchList.length;j++){
				if($scope.staffBranchList[j].branchId == $scope.transactionDetail.staffDetails[i].branchId){
					$scope.staffBranchList[j].selected = true;
					$scope.staffBranchList[j]["academicTransactionDetailId"] = $scope.transactionDetail.staffDetails[i].academicTransactionDetailId;
				}
			}
		}
		var stfeditAlChk = 0;
		for(var j=0;j<$scope.staffBranchList.length;j++){
			if($scope.staffBranchList[j].selected != true){
				stfeditAlChk++;
			}
		}
		if(stfeditAlChk == 0){
			$scope.staffAllEdit = true;
		}else{
			$scope.staffAllEdit = false;
		}


	}

	$scope.generateStuEditOb = function(){
		$scope.isFound=-1;
		for(var i=0;i<$scope.transactionDetail.studentDetails.length;i++){
		for(var j=0;j<$scope.allBCCList.length;j++){
					for(var k=0;k<$scope.allBCCList[j].courses.length;k++){
							for(var l=0;l<$scope.allBCCList[j].courses[k].classes.length;l++){
									for(var m=0;m<$scope.allBCCList[j].courses[k].classes[l].sections.length;m++){
										if($scope.allBCCList[j].courses[k].classes[l].sections[m].sectionId==$scope.transactionDetail.studentDetails[i].sectionId){
											$scope.allBCCList[j].courses[k].classes[l].sections[m].selected=true;
											console.log($scope.allBCCList[j].courses[k].classes[l].sections[m]);
											$scope.allBCCList[j].courses[k].classes[l].sections[m]["academicTransactionDetailId"] = $scope.transactionDetail.studentDetails[i].academicTransactionDetailId;
										}
//										alert($scope.transactionDetail.studentDetails[i].academicTransactionDetailId);
								}
						}
				}
		}
	}


	for(var j=0;j<$scope.allBCCList.length;j++){
			var crsSelEdit = 0;
				for(var k=0;k<$scope.allBCCList[j].courses.length;k++){
						var clsSelEdit = 0;
						for(var l=0;l<$scope.allBCCList[j].courses[k].classes.length;l++){
								var secSelEdit = 0;
								for(var m=0;m<$scope.allBCCList[j].courses[k].classes[l].sections.length;m++){
									if($scope.allBCCList[j].courses[k].classes[l].sections[m].selected != true){
										secSelEdit++;
									}
								}
								if(secSelEdit == 0){
									$scope.allBCCList[j].courses[k].classes[l].selected = true;
								}else{
									$scope.allBCCList[j].courses[k].classes[l].selected = false;
								}

								if($scope.allBCCList[j].courses[k].classes[l].selected != true){
									clsSelEdit++;
								}
					}
					if(clsSelEdit == 0){
						$scope.allBCCList[j].courses[k].selected = true;
					}else{
						$scope.allBCCList[j].courses[k].selected = false;
					}
					if($scope.allBCCList[j].courses[k].selected != true){
						crsSelEdit++;
					}
			}
			if(crsSelEdit == 0){
				$scope.allBCCList[j].selected = true;
			}else{
				$scope.allBCCList[j].selected = false;
			}

	}


		console.log($scope.allBCCList);
}


	$scope.generateStfEditObj = function(ob,brInd){
		console.log(ob);
		if(ob=='staffAll'){
			for(var i=0;i<$scope.staffBranchList.length;i++){
				if($scope.staffAllEdit==false){
					$scope.staffBranchList[i].selected=true;
				}else{
					$scope.staffBranchList[i].selected=false;
				}
			}
		}else{
			if($scope.staffBranchList[brInd].selected==true){
				$scope.staffBranchList[brInd].selected=false;
			}else{
				$scope.staffBranchList[brInd].selected=true;
			}
			var stfeditAlChk = 0;
			for(var j=0;j<$scope.staffBranchList.length;j++){
				if($scope.staffBranchList[j].selected != true){
					stfeditAlChk++;
				}
			}
			if(stfeditAlChk == 0){
				$scope.staffAllEdit = true;
			}else{
				$scope.staffAllEdit = false;
			}
		}
	}

	$scope.generateEditStudentObj=function(ob,brInd,crInd,clsInd,secInd){
		if(ob=='student'){
		if($scope.isStuAll==true){
			for(var i=0;i<$scope.allBCCList.length;i++){
				$scope.allBCCList[i].selected=false;
				for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
					console.log($scope.allBCCList[i]);
					$scope.allBCCList[i].courses[j].selected=false;
					for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
						$scope.allBCCList[i].courses[j].classes[k].selected=false;;
						console.log($scope.allBCCList[i].courses[j].classes[k]);
						for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
							$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=false;
						}
					}
				}
			}
		}else{
			for(var i=0;i<$scope.allBCCList.length;i++){
				$scope.allBCCList[i].selected=true;
				for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
					$scope.allBCCList[i].courses[j].selected=true;
					for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
						$scope.allBCCList[i].courses[j].classes[k].selected=true;
						console.log($scope.allBCCList[i].courses[j].classes[k]);
						for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
							if($scope.allBCCList[j].courses[k].classes[l].sections[m].sectionId==$scope.transactionDetail.studentDetails[i].sectionId){
								$scope.allBCCList[j].courses[k].classes[l].sections[m].selected=true;
								$scope.allBCCList[j].courses[k].classes[l].sections[m]["academicTransactionDetailId"] = $scope.transactionDetail.studentDetails[i].academicTransactionDetailId;
							}else{
								$scope.allBCCList[j].courses[k].classes[l].sections[m].selected=false;
								$scope.allBCCList[j].courses[k].classes[l].sections[m]["academicTransactionDetailId"] = 0;
							}
					}
				}
			}
		}
	}
		}
		else if(ob=='stuAll'){
			if($scope.stuAll==true){
				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=false;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						console.log($scope.allBCCList[i]);
						$scope.allBCCList[i].courses[j].selected=false;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=false;;
							console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=false;
							}
						}
					}
				}
			}else{
				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=true;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						$scope.allBCCList[i].courses[j].selected=true;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=true;
							console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=true;
							}
						}
					}
				}
			}
		}else if(ob=='branch'){
			if($scope.allBCCList[brInd].selected==true){
			$scope.allBCCList[brInd].selected=false;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=false;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=false;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=false;
					}
				}
			}
		}else{
			$scope.allBCCList[brInd].selected=true;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=true;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=true;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=true;
					}
				}
			}
		}
	}else if(ob=='course'){
		if($scope.allBCCList[brInd].courses[crInd].selected==true){
			$scope.allBCCList[brInd].courses[crInd].selected=false;
			for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].selected=false;
				console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
				for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
					$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=false;
				}
			}
		}else{
	//		$scope.allBCCList[brInd].selected=false;
			$scope.allBCCList[brInd].courses[crInd].selected=true;
			for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].selected=true;
				console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
				for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
					$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=true;
				}
			}
		}

		var isCourseFound=0;

		for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
			if($scope.allBCCList[brInd].courses[j].selected==false){
				isCourseFound++;
				//branchIndex=i;
			}
		}

		if(isCourseFound>0){
			$scope.allBCCList[brInd].selected=false;
			$scope.stuAll=false;
		}
		else{
			$scope.allBCCList[brInd].selected=true;
			//$scope.stuAll=true;
		}
		$scope.checkBranchSelect();
	}
	else if(ob=='class'){
		if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected==true){
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=false;
			}
		}else{
	//		$scope.allBCCList[brInd].courses[crInd].selected=true;
				for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
					$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=true;
				}
			}

				var isCourseFound=0;
				//var branchIndex=-1;
				for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes.length;j++){
					if($scope.allBCCList[brInd].courses[crInd].classes[j].selected==true){
						isCourseFound++;
					}
				}

				if(isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length){
					$scope.allBCCList[brInd].courses[crInd].selected = true;
				}
				else
				{
					$scope.allBCCList[brInd].courses[crInd].selected = false;
					$scope.allBCCList[brInd].selected=false;
					$scope.stuAll=false;
				}
		$scope.checkBranchCourseClassSelect(brInd,crInd);
	}
	else if(ob=='section'){
			if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected==true){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=false;
			}else{
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=true;
			}



				var isCourseFound=0;
				//var branchIndex=-1;
				for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;j++){
					if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[j].selected==false){
						isCourseFound++;
					}
				}

			if(isCourseFound>0){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				$scope.allBCCList[brInd].selected=false;
				$scope.stuAll=false;
			}
			else{
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
			}
			$scope.checkBranchCourseClassSelect(brInd,crInd);
		}
	}


	$scope.updateCircular=function(){

		var stfuserObjIndex = 0;

		$scope.totalStaffEDitObj = [];
		for(var i=0; i<$scope.staffBranchList.length;i++){
			if($scope.staffBranchList[i].selected == true){
				stfuserObjIndex++;
			}
			if($scope.staffBranchList[i].selected == true && $scope.staffBranchList[i].academicTransactionDetailId == undefined){
				var obj = {
					"branchId": $scope.staffBranchList[i].branchId,
					"academicTransactionDetailId": 0
				}
				$scope.totalStaffEDitObj.push(obj);
			}else if($scope.staffBranchList[i].selected != true && $scope.staffBranchList[i].academicTransactionDetailId != undefined){
				var obj = {
					"branchId": $scope.staffBranchList[i].branchId,
					"academicTransactionDetailId": $scope.staffBranchList[i].academicTransactionDetailId
				}
				$scope.totalStaffEDitObj.push(obj);
			}
		}

		$scope.totalEditSecObj=[];
		for(var i=0;i<$scope.allBCCList.length;i++){
			for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
				console.log($scope.allBCCList[i]);
				for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
					for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
						console.log($scope.allBCCList[i].courses[j].classes[k].sections[l].academicTransactionId);
						console.log($scope.allBCCList[i].courses[j].classes[k].sections[l].selected);
						if($scope.allBCCList[i].courses[j].classes[k].sections[l].selected==true && $scope.allBCCList[i].courses[j].classes[k].sections[l].academicTransactionDetailId == undefined){
								var object = {
										"branchId":$scope.allBCCList[i].branchId,
										"courseId":$scope.allBCCList[i].courses[j].courseId,
										"classId":$scope.allBCCList[i].courses[j].classes[k].classId,
										"sectionId":$scope.allBCCList[i].courses[j].classes[k].sections[l].sectionId,
										"academicTransactionDetailId":0
								}
								$scope.totalEditSecObj.push(object);
						}else if($scope.allBCCList[i].courses[j].classes[k].sections[l].selected != true && $scope.allBCCList[i].courses[j].classes[k].sections[l].academicTransactionDetailId != undefined){
								var object = {
										"branchId":$scope.allBCCList[i].branchId,
										"courseId":$scope.allBCCList[i].courses[j].courseId,
										"classId":$scope.allBCCList[i].courses[j].classes[k].classId,
										"sectionId":$scope.allBCCList[i].courses[j].classes[k].sections[l].sectionId,
										"academicTransactionDetailId":$scope.allBCCList[i].courses[j].classes[k].sections[l].academicTransactionDetailId
								}
								$scope.totalEditSecObj.push(object);
						}
					}
				}
			}
		}
		console.log($scope.totalEditSecObj);

		$scope.userObj = [];
		if($scope.isStuAll==1){
			var ob = {
					"userType":2,
				}
			$scope.userObj.push(ob);
		}
		if($scope.isParentAll==1){
			var ob = {
					"userType":3,
			}
			$scope.userObj.push(ob);
		}
		if($scope.totalEditSecObj.length > 0){
			if($scope.userObj.length == 0){
				alert("Select from student and staff or both");
				return true;
			}
		}
		if($scope.totalStaffEDitObj.length > 0){
			var ob = {
					"userType":1,
			}
			$scope.userObj.push(ob);
		}
		var userObjDump = [];
		if($scope.userObj.length > 0){

			for(var i=0; i<$scope.userObj.length; i++){
				var found = 0;
				for(var j=0; j<$scope.transactionDetail.users.length; j++){
					if($scope.userObj[i].userType == $scope.transactionDetail.users[j].userType){
						found++;
					}
				}
				if(found == 0){
					$scope.userObj[i].academicTransactionUserId = 0;
					userObjDump.push($scope.userObj[i]);
				}
			}
			for(var i=0; i<$scope.transactionDetail.users.length; i++){
				var found = 0;
				for(var j=0; j<$scope.userObj.length; j++){
					if($scope.userObj[j].userType == $scope.transactionDetail.users[i].userType){
						found++;
					}
				}

				if(found == 0){
					userObjDump.push($scope.transactionDetail.users[i]);
				}
				if(stfuserObjIndex == 0 && $scope.transactionDetail.users[i].userType == 1){
					userObjDump.push($scope.transactionDetail.users[i]);
				}
			}
			console.log(userObjDump);

		var params={
		    "schemaName":$scope.schemaName,
		    "transactionType": $scope.transactionTypeId,
		    "academicTransactionId": $scope.transactionDetail.academicTransactionId,
		    "updatedBy":$scope.userId,
		    "studentDetails": $scope.totalEditSecObj,
		    "filePath": "NA",
		    "transactionName": $scope.ecircularName,
		    "transactionDate": $scope.circularDate,
		    "staffDetails": $scope.totalStaffEDitObj,
		    "createdBy":$scope.userId,
		    "users":userObjDump
		}
		console.log(params);
		//return true;
		httpFactory.executePost("updateTransaction", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
			  $scope.acadTransId = $scope.transactionDetail.academicTransactionId;
			  $scope.uploadCircular1();
			  alert("sucesfully changed");
				$scope.selectTransactionUser($scope.transactionUser);
				$("#editcirculars").modal("hide");
			}
			else{
				alert("Please try agian after some time");
			}
		});
	}else{
		alert("Select users");
	}
	}



	$scope.deleteTransaction=function(transactionDetail){
//			$scope.roleId=2;
//			$scope.branchId=6;
		var params={
			    "schemaName":$scope.schemaName,
			    "roleId": $scope.roleId,
			    "academicTransactionId":transactionDetail.academicTransactionId,
			    "branchId":$scope.branchId
			}
		console.log(params);

		httpFactory.executePost("deleteTransactionById", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
//			  alert("sucesfully changed");
			  alert($scope.transactionUser);
				$scope.selectTransactionUser($scope.transactionUser);
			}
			else{
				alert("Please try agian after some time");
			}
		});
	}

	$scope.viewCircular=function(trans){
		$scope.downLoadViewCircular(trans.filePath,"pdf");
	}

	$scope.downLoadViewCircular = function(fPath, ftype){
		var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/TransactionFileDownLoad?filePath="+fPath+"&embedded=true";
		$("#MyFrame").attr("src", path);
		if(ftype != "doc" && ftype != "docx" && ftype != "csv" && ftype != "xls" && ftype != "xlsx"){
			$("#studentCircular").modal("show");
		}
	}

	$scope.closeDownloadView = function(){
			$("#studentCircular").modal("hide");
	}
	$scope.viewParentCircular=function(trans){
		$scope.downLoadParentViewCircular(trans.filePath,"pdf");
	}

	$scope.downLoadParentViewCircular = function(fPath, ftype){
		var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/TransactionFileDownLoad?filePath="+fPath+"&embedded=true";
		$("#MyFrame").attr("src", path);
		if(ftype != "doc" && ftype != "docx" && ftype != "csv" && ftype != "xls" && ftype != "xlsx"){
			$("#parentCircular").modal("show");
		}
	}

	$scope.closeParentDownloadView = function(){
			$("#parentCircular").modal("hide");
	}

	// pagination code

	$scope.propertyName = 'transactionDate';
	$scope.reverseOrd = false;
	$scope.perpageIndx = 6;
	$scope.pgstartIndx = 1;
	$scope.pgendIndx = $scope.perpageIndx;
	$scope.prevFlag = false;
	$scope.nxtFlag = true;
	$scope.pgIndex = 1;
	$scope.resultsIndx = 1;
	$scope.sortByOrd = function(propertyName) {
    $scope.reverseOrd = ($scope.propertyName === propertyName) ? !$scope.reverseOrd : false;
    $scope.propertyName = propertyName;
  };
	$scope.checkPreviousPg = function(){
		$scope.pgstartIndx = $scope.pgstartIndx - $scope.perpageIndx;
		$scope.pgendIndx = $scope.pgendIndx - $scope.perpageIndx;
		$scope.pgIndex = $scope.pgIndex - 1;
		if($scope.pgstartIndx <= 1){
			$scope.pgstartIndx = 1;
			$scope.pgendIndx = $scope.perpageIndx;
			$scope.prevFlag = false;
			$scope.pgIndex = 1;
		}
		if($scope.transactionList.length < $scope.pgendIndx){
			$scope.resultsIndx = $scope.pgstartIndx + ($scope.transactionList.length - $scope.pgstartIndx);
		}else{
			$scope.resultsIndx = $scope.pgendIndx;
		}
		$scope.nxtFlag = true;
	}

	$scope.checkNextPg = function(){
		$scope.pgstartIndx = $scope.pgstartIndx + $scope.perpageIndx;
		$scope.pgendIndx = $scope.pgendIndx + $scope.perpageIndx;
		$scope.pgIndex = $scope.pgIndex + 1;
		if($scope.transactionList.length < $scope.pgendIndx){
			$scope.resultsIndx = $scope.pgstartIndx + ($scope.transactionList.length - $scope.pgstartIndx);
		}else{
			$scope.resultsIndx = $scope.pgendIndx;
		}

		if($scope.transactionList.length <= $scope.pgendIndx){

			$scope.nxtFlag = false;
		}
		$scope.prevFlag = true;

	}

	$(document).ready(function() {
		 $scope.checkIsCom();
		 $sscope.updateFlags();
	});

	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	
});
