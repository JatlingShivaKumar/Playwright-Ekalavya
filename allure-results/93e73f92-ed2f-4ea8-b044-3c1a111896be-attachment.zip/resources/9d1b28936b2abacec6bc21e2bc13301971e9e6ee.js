projectModule.controller('globalSMSController', function ($scope, $location, commonFactory, httpFactory, $routeParams, $route, $sce, $compile) {
	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	//$scope.schemaName = "events";
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.roleId = localStorage.getItem("RD");
	$scope.isStudent = false;
	$scope.isStudentAll = true;
	$scope.isStudentAllChk = 1;
	$scope.isStaffS = false;
	$scope.isStaffAll = true;
	$scope.isStaffAllChk = 1;
	$scope.isStuAll = false;

	$scope.goToMessaging = function () {
		$location.path("messaging");
	}

	$scope.goToDashbord = function () {
		$location.path("rankrPlus");
	}

	var xcel = document.getElementById("excelDiv");
	var selectDiv = document.getElementById("selectDiv");
	var templateDiv = document.getElementById("templateDiv");
	var buttonsDiv = document.getElementById("buttonsDiv");

	$scope.branchObjArray = [];
	$scope.courseIdArr = [];

	$scope.isStuAllCheck = function () {
		if (document.getElementById("isS").checked == true) {
			$scope.isStudentAllChk = 1;
			$scope.allBCCList.isStudent = true;
			//console.log($scope.allBCCList);
		}
		else {
			$scope.isStudentAllChk = 0;
			$scope.allBCCList.isStudent = false;
			//console.log($scope.allBCCList);
			for (var i = 0; i < $scope.allBCCList.length; i++) {
				$scope.courseOb = $scope.allBCCList[i].courses;
				for (var j = 0; j < $scope.courseOb.length; j++) {
					$scope.courseIdArr.push($scope.courseOb[j].courseId);

					if (!$scope.courseIdStr) {
						$scope.courseIdStr = $scope.courseOb[j].courseId;
					} else {
						if (!$scope.courseIdArr.includes($scope.courseOb[j].courseId))
							$scope.courseIdStr = $scope.courseIdStr + "," + $scope.courseOb[j].courseId;
					}
					$scope.classOb = $scope.courseOb[j].classes;
					//console.log($scope.classOb);


					for (var k = 0; k < $scope.classOb.length; k++) {
						if (!$scope.classIdStr)
							$scope.classIdStr = $scope.classOb[k].classId;
						else
							$scope.classIdStr = $scope.classIdStr + "," + $scope.classOb[k].classId;
					}
				}

				var branchObject = {
					"branchId": $scope.allBCCList[i].branchId,
					"courseId": $scope.courseIdStr,
					"classId": $scope.classIdStr
				}

				$scope.courseIdStr = "";
				$scope.classIdStr = "";
				$scope.branchObjArray.push(branchObject);
			}
		}
	}
	$scope.isStaffAllCheck = function () {
		if (document.getElementById("isStaffAll").checked == false) {
			$scope.isStaffAllChk = 0;
		}
		else {
			$scope.isStaffAllChk = 1;

		}
	}

	$scope.allBCCList = [];
	$scope.staffBranchList = [];
	$scope.getAllBranchClassCourseSections = function () {
		httpFactory.getResult("getAllBranchClassCourseSections?schemaName=" + $scope.schemaName + "&instId=" + $scope.instituteId + "&roleId=" + $scope.roleId + "&branchId=" + $scope.branchId, function (data) {
			if (data.StatusCode == '200') {
				$scope.allBCCList = data.collegesInfo;
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i]["selected"] = false;
					var stbrobj = {
						"branchId": $scope.allBCCList[i].branchId,
						"branchName": $scope.allBCCList[i].branchName,
						"selected": false
					};
					$scope.staffBranchList.push(stbrobj);
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						$scope.allBCCList[i].courses[j]["selected"] = false;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k]["selected"] = false;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l]["selected"] = false;
							}
						}
					}
				}
			}
		});
	}

	$scope.getAllBranchClassCourseSections();

	$scope.selecStudentDetails = [];

	$scope.genrateStudentDetails = function () {
		$scope.selecStudentDetails = [];
		if ($scope.allBCCList.isCommon == false) {
			if (document.getElementById("isS").checked == false) {
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					if ($scope.allBCCList[i].selected == true) {
						var branchSelected = {
							"branchId": $scope.allBCCList[i].branchId,
							"studentDetails":
								[{
									"courseId": 0,
									"classId": 0
								}]
						};
						$scope.selecStudentDetails.push(branchSelected);
					}
					else {
						var branchSelected = {
							"branchId": $scope.allBCCList[i].branchId,
							"studentDetails": []
						};
						for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
							if ($scope.allBCCList[i].courses[j].selected == true) {
								var courseSelected = {
									"courseId": $scope.allBCCList[i].courses[j].courseId,
									"classId": 0
								};
								branchSelected.studentDetails.push(courseSelected);
							} else {

								for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
									if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
										var courseSelected = {
											"courseId": $scope.allBCCList[i].courses[j].courseId,
											"classId": ""
										};
										courseSelected.classId = $scope.allBCCList[i].courses[j].classes[k].classId;
										branchSelected.studentDetails.push(courseSelected);
									}
								}

							}
						}
						if (branchSelected.studentDetails.length > 0) {
							$scope.selecStudentDetails.push(branchSelected);
						}
					}
				}
			}
		}
	}

	$scope.sendSMS = function () {
		$scope.totalSectionObj = [];
		for (var i = 0; i < $scope.allBCCList.length; i++) {
			for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
				for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
					if ($scope.allBCCList[i].courses[j].classes[k].selected == true) {
						var object = {
							"branchId": $scope.allBCCList[i].branchId,
							"courseId": $scope.allBCCList[i].courses[j].courseId,
							"classId": $scope.allBCCList[i].courses[j].classes[k].classId,
						}
						$scope.totalSectionObj.push(object);
					}
				}
			}
		}

		var stucheck = document.getElementById("stucheck").checked;
		var stacheck = document.getElementById("stacheck").checked;

		if (stucheck == false && stacheck == false) {
			alert("Please Select Student or Staff.");
			return;
		}
		if ($scope.selectedTemplt == undefined) {
			alert("Please Select Template.");
			return;
		}

		var params = {
			"schemaName": $scope.schemaName,
			"createdBy": $scope.userId,
			"templateName": $scope.selectedTemplt.smsTemplateName,
			"message": $scope.getCombinedString(),
			"smstid": $scope.selectedTemplt.smsTemplateId,
			"student": stucheck,
			"staff": stacheck,
			"mssgType": "sms"
		};

		$scope.classStr = "";
		$scope.courseStr = "";
		$scope.courseIdArr = [];

		params["branchOb"] = $scope.totalSectionObj;

		if (params.branchOb == undefined || params.branchOb.length == 0) {
			alert("Select to whom it need to apply.");
			return true;
		}

		httpFactory.executePost("sendGlobalSMS", params, function (data) {
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.resetVal();
				$scope.getBranchSMSBalance();
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.generateStudentObj = function (ob, brInd, crInd, clsInd, secInd) {
		if (ob == 'stuAll') {
			if ($scope.stuAll == true) {
				//					$scope.isStuAll=false;
				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i].selected = false;
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						//console.log($scope.allBCCList[i]);
						$scope.allBCCList[i].courses[j].selected = false;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k].selected = false;;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = false;
							}
						}
					}
				}
			} else {
				//					$scope.isStuAll=true;

				for (var i = 0; i < $scope.allBCCList.length; i++) {
					$scope.allBCCList[i].selected = true;
					for (var j = 0; j < $scope.allBCCList[i].courses.length; j++) {
						$scope.allBCCList[i].courses[j].selected = true;
						for (var k = 0; k < $scope.allBCCList[i].courses[j].classes.length; k++) {
							$scope.allBCCList[i].courses[j].classes[k].selected = true;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for (var l = 0; l < $scope.allBCCList[i].courses[j].classes[k].sections.length; l++) {
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected = true;
							}
						}
					}
				}
			}

		} else if (ob == 'branch') {
			if ($scope.allBCCList[brInd].selected == true) {
				$scope.allBCCList[brInd].selected = false;
				for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
					$scope.allBCCList[brInd].courses[j].selected = false;
					for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
						$scope.allBCCList[brInd].courses[j].classes[k].selected = false;
						for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
							$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = false;
						}
					}
				}
			} else {
				$scope.allBCCList[brInd].selected = true;
				for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
					$scope.allBCCList[brInd].courses[j].selected = true;
					for (var k = 0; k < $scope.allBCCList[brInd].courses[j].classes.length; k++) {
						$scope.allBCCList[brInd].courses[j].classes[k].selected = true;
						for (var l = 0; l < $scope.allBCCList[brInd].courses[j].classes[k].sections.length; l++) {
							$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected = true;
						}
					}
				}
			}
			var isBranchFound = 0;
			for (var i = 0; i < $scope.allBCCList.length; i++) {
				//				alert($scope.allBCCList[i].selected);
				if ($scope.allBCCList[i].selected == false) {
					// $scope.stuAll=false;
					isBranchFound++;
				}
			}
			if (isBranchFound > 0) {
				$scope.stuAll = false;
			}
			else {
				$scope.stuAll = true;
			}
		}
		else if (ob == 'course') {
			if ($scope.allBCCList[brInd].courses[crInd].selected == true) {
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
					$scope.allBCCList[brInd].courses[crInd].classes[k].selected = false;
					//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
					for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
						$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = false;
					}
				}
			} else {
				//			$scope.allBCCList[brInd].selected=false;
				$scope.allBCCList[brInd].courses[crInd].selected = true;
				for (var k = 0; k < $scope.allBCCList[brInd].courses[crInd].classes.length; k++) {
					$scope.allBCCList[brInd].courses[crInd].classes[k].selected = true;
					//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
					for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[k].sections.length; l++) {
						$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected = true;
					}
				}
			}

			var isCourseFound = 0;

			for (var j = 0; j < $scope.allBCCList[brInd].courses.length; j++) {
				if ($scope.allBCCList[brInd].courses[j].selected == false) {
					isCourseFound++;
					//branchIndex=i;
				}
			}

			if (isCourseFound > 0) {
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			else {
				$scope.allBCCList[brInd].selected = true;
				//$scope.stuAll=true;
			}
			//$scope.checkBranchSelect();
		}
		else if (ob == 'class') {
			if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected == true) {
				for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
					$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = false;
				}
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
			} else {
				//			$scope.allBCCList[brInd].courses[crInd].selected=true;
				for (var l = 0; l < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; l++) {
					$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected = true;
				}
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
			}

			var isCourseFound = 0;
			//var branchIndex=-1;
			for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes.length; j++) {
				if ($scope.allBCCList[brInd].courses[crInd].classes[j].selected == true) {
					isCourseFound++;
				}
			}

			if (isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length) {
				$scope.allBCCList[brInd].courses[crInd].selected = true;
			}
			else {
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			$scope.checkBranchCourseClassSelect(brInd, crInd);
			//$scope.checkBranchCourseSelect(brInd);
		}
		else if (ob == 'section') {
			if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected == true) {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected = false;
			} else {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected = true;
			}


			var isCourseFound = 0;
			//var branchIndex=-1;
			for (var j = 0; j < $scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length; j++) {
				if ($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[j].selected == false) {
					isCourseFound++;
				}
			}

			if (isCourseFound > 0) {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
				$scope.allBCCList[brInd].courses[crInd].selected = false;
				$scope.allBCCList[brInd].selected = false;
				$scope.stuAll = false;
			}
			else {
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
			}
			$scope.checkBranchCourseClassSelect(brInd, crInd);

		}
	}

	$scope.getSMSTemplateDetails = function () {
		httpFactory.getResult("getSMSTemplateDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			if (data.StatusCode == '200') {
				$scope.templateList = data.templateDetails;
			}
		});
	}

	$scope.pageLoad = function () {
		$scope.getSMSTemplateDetails();
		$scope.selectSmsType('sms');
	}
	$scope.selectedTemplt = undefined;

	$scope.selectedTemplate = function () {
		if (typeof document.getElementById("tmplt").value == 'string') {
			$scope.selectedTemplt = JSON.parse(document.getElementById("tmplt").value);
		} else {
			$scope.selectedTemplt = document.getElementById("tmplt").value;
		}
		$scope.convertMessage();
	}

	$scope.viewTemplate = function () {
		$("#viewTemplate").modal("show");
	}

	$scope.addExcelTemplate = function () {
		$("#addExcelTemplate").modal("show");
	}

	$scope.addTemplate = function () {
		$("#addTemplate").modal("show");
	}

	$scope.closePopUpLive = function () {
		$("#viewTemplate").modal("hide");
		$("#addExcelTemplate").modal("hide");
		$("#myBalanceReqsModal").modal("hide");
	}

	$scope.myRequests = function () {
		$("#myBalanceReqsModal").modal("show");
		$scope.getBranchBalanceRequests();
	}

	$scope.cancel = function () {
		$("#addTemplate").modal("hide");
	}

	$scope.uploadTemplates = function () {
		$scope.studentsArrSucRec = [];
		var files = document.getElementById("choosenFile").files;
		if ($scope.selectedTemplt == undefined) {
			alert("Please Select Template");
			return;
		}
		if (files[0] == undefined) {
			alert('Please select a Excel file');
			return;
		}
		//console.log(document.getElementById("choosenFile"));
		//console.log(files);
		var fd = new FormData();
		fd.append("file", files[0]);
		$scope.studentList = [];
		httpFactory.executeFileUpload("uploadTemplates", fd, function (data) {
			//console.log(data);
			if (data.length > 0) {
				$scope.studentsArr = [];
				$scope.studentList = data.slice(0);

				var tmptmsg = $scope.createmsg($scope.studentList);
				httpFactory.executePost("sendSMSFromExcel", tmptmsg, function (data) {
					//console.log(data);
					if (data.StatusCode == 200) {
						alert(data.MESSAGE);
					} else {
						alert(data.MESSAGE);
					}

				});

			} else {
				alert('Please select a valid Excel file');
			}
		});
	}

	$scope.createmsg = function (msgArray) {
		var sendxel = {
			messages: [],
			schemaName: localStorage.getItem("sname"),
			templateId: $scope.selectedTemplt.smsTemplateId,
			branchId: $scope.branchId
		}
		$scope.totalCols = msgArray[msgArray.length - 1];

		var tmsg = $scope.getCombinedString();

		tmpMsgValArr = [];
		n = 65;
		for (var z = 0; z < $scope.totalCols; z++) {
			x = String.fromCharCode(n);
			t = "#" + x + "#";
			n++;
			tmpMsgValArr.push(t);
		}
		for (w = 0; w < msgArray.length - 1; w++) {
			for (var k = 0; k < tmpMsgValArr.length; k++) {
				if (tmsg.includes(tmpMsgValArr[k])) {
					tempval = tmpMsgValArr[k].charAt(1);
					tmsg = tmsg.replaceAll(tmpMsgValArr[k], msgArray[w][tempval]);
				}
			}
			sendxel.messages.push({
				"numbers": msgArray[w]["B"],
				"message": tmsg
			})
			tmsg = $scope.getCombinedString();
		}
		return sendxel;
	}

	$scope.selectSmsType = function (smsType) {
		$scope.smscheck = smsType;
		if (smsType == 'sms') {
			xcel.style.display = "none";
			templateDiv.style.display = "block";
			buttonsDiv.style.display = "block";
			selectDiv.style.display = "block";
			document.getElementById("whatsappDiv").style.display = "none";
		} else if (smsType == 'excel') {
			xcel.style.display = "block";
			templateDiv.style.display = "block";
			buttonsDiv.style.display = "block";
			selectDiv.style.display = "none";
			document.getElementById("whatsappDiv").style.display = "none";
		}
	}

	$scope.sendSmsCheck = function () {
		var smsradioValue = $("input[name='smsradio']:checked").val();
		if (smsradioValue == "sms") {
			$scope.sendSMS();
		} else if (smsradioValue == "smsexcel") {
			$scope.uploadTemplates();
		} else {
			alert("Please Check your input.")
		}
	}

	$scope.getBranchSMSBalance = function () {
		httpFactory.getResult("getBranchSMSBalance?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			//console.log(data);
			if (data.StatusCode == '200') {
				$scope.smsBalanceDetails = data.smsBalanceDetails;
				if ($scope.smsBalanceDetails.smsBalance == undefined) {
					$scope.smsBal = 0;
				} else {
					$scope.smsBal = $scope.smsBalanceDetails.smsBalance;
				}
			}
		});
	}

	$scope.getBranchSMSBalance();

	$scope.addBalanceForBranches = function () {
		$("#addBalanceModal").modal("show");
		//$scope.addBalanceForMulBranches();
	}
	$scope.reqBalance = function () {
		$("#packDetailsModal").modal("show");
	}
	$scope.payment = function () {
		$("#reqBalanceModal").modal("show");
		$("#packDetailsModal").modal("hide");
	}
	$scope.selectAllBranches = function (branches) {
		if (document.getElementById('selectAllBrchs').checked == true) {
			for (j = 0; j < branches.length; j++) {
				document.getElementsByName('selectBrch')[j].checked = true;
			}
		} else {
			for (j = 0; j < branches.length; j++) {
				document.getElementsByName('selectBrch')[j].checked = false;
			}

		}
	}
	$scope.totalBranchObj = [];
	$scope.selectBranch = function (branches) {
		var count = 0;
		for (var i = 0; i < branches.length; i++) {
			if (document.getElementsByName('selectBrch')[i].checked == true) {
				count++;
			}
		}
		if (count == branches.length) {
			$('#selectAllBrchs').prop("checked", true);
		} else {
			$('#selectAllBrchs').prop("checked", false);
		}
	}
	$scope.addBalanceForMulBranches = function (branches) {
		$scope.totalBranchObj = [];
		for (var i = 0; i < branches.length; i++) {
			if (document.getElementsByName('selectBrch')[i].checked == true) {
				var object = {
					"branchId": branches[i].branchId
				}
				$scope.totalBranchObj.push(object);
			}
		}
		var params = {
			"smsBalance": $scope.smsBalance,
			"branchId": $scope.totalBranchObj,
			"schemaName": localStorage.getItem("sname")
		};
		if (params.branchId == undefined || params.branchId.length == 0) {
			alert("Select to whom it need to apply.");
			return true;
		}
		httpFactory.executePost("addBalanceForBranches", params, function (data) {
			//console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$("#addBalanceModal").modal("hide");
				document.getElementById("smsBalance").value = "";
				document.getElementsByName('selectAllBrchs').checked = false;
				for (j = 0; j < branches.length; j++) {
					document.getElementsByName('selectBrch')[j].checked = false;
				}
				$scope.getBranchSMSBalance();
			} else {
				alert(data.MESSAGE);
			}

		});
	}
	$scope.back = function () {
		$location.path("rankrPlus");
	}

	$("#myInput").on('keyup', function () {
		var value = $(this).val().toLowerCase();
		$("#myUL li").each(function () {
			if ($(this).text().toLowerCase().search(value) > -1) {
				$(this).show();
				$(this).prev('.list').last().show();
			} else {
				$(this).hide();
			}
		});
	})


	$scope.getBranchBalanceRequests = function () {
		httpFactory.getResult("getBranchBalanceRequests?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&roleId=" + $scope.roleId, function (data) {
			if (data.StatusCode == '200') {
				$scope.balaceRequests = data.balaceRequests;
			}
			else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.smsPackageSelect = function (value) {
		var payDiv = document.getElementById("payDiv");
		if (value == '5000') {
			$scope.price = "INR 5000";
		}
		if (value == '10000') {
			$scope.price = "INR 10000";
		}
		if (value == '20000') {
			$scope.price = "INR 20000";
		}
		if (value == '50000') {
			$scope.price = "INR 50000";
		}
		if (value == '100000') {
			$scope.price = "INR 100000";
		}
		if (value == '500000') {
			$scope.price = "INR 500000";
		}
		if (value == '1000000') {
			$scope.price = "INR 1000000";
		}
		payDiv.style.display = "block"
	}

	$scope.uploadSS = function (requestId) {
		var files = document.getElementById("choosenSSFile").files;
		if (files[0] == undefined) {
			return;
		}
		console.log(files);
		var fd = new FormData();

		fd.append("requestId", requestId);
		fd.append("schemaName", $scope.schemaName)
		for (var i = 0; i < files.length; i++) {

			fd.append("file", files[i]);
		}
		httpFactory.executeFileUpload("uploadPaymentSS", fd, function (data) {
			console.log(data);
			document.getElementById("choosenFile").value = "";
		});
	}
	$scope.addBalanceRequest = function () {
		var files = document.getElementById("choosenSSFile").files;
		if (files[0] == undefined) {
			alert("Please upload the Screenshot of Payment");
			return;
		}
		var vidParams = {
			"branchId": $scope.branchId,
			"smsCount": $scope.smsCount,
			"status": "PENDING",
			"createdBy": localStorage.getItem("userId"),
			"schemaName": localStorage.getItem("sname")
		}
		//console.log(vidParams);
		httpFactory.executePost("addBalanceRequest", vidParams, function (data) {
			// console.log(data);
			if (data.StatusCode == 200) {
				alert("Balance requested Successfully");
				$("#reqBalanceModal").modal("hide");
				$scope.uploadSS(data.requestId);
				$scope.getBranchBalanceRequests();

			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.downLoadPaymentSS = function (fPath, ftype) {
		var path = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + fPath + "&embedded=true";
		$("#MyFrame").attr("src", path);
		if (ftype != "doc" && ftype != "docx" && ftype != "csv" && ftype != "xls" && ftype != "xlsx" && ftype != "txt" && ftype != "pdf" && ftype != "zip" && ftype != "png" && ftype != "jpg" && ftype != "jpeg") {
			alert("Not a valid file");
		}
		//$("#SSModalPopup").modal("show");
		window.open(path)
	}
	$scope.acceptBalanceRequest = function (branches) {
		if (branches.status == "SUCCESS") {
			alert("Balance already Accepted");
			return;
		}
		$scope.totalBranchObj = [];
		var object = {
			"branchId": branches.branchId
		}
		$scope.totalBranchObj.push(object);
		var params = {
			"smsBalance": branches.smsCount,
			"branchId": $scope.totalBranchObj,
			"schemaName": localStorage.getItem("sname"),
			"isAccepted": true,
			"requestId": branches.requestId
		};
		httpFactory.executePost("addBalanceForBranches", params, function (data) {
			//console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$("#addBalanceModal").modal("hide");
				$scope.getBranchBalanceRequests();
			} else {
				alert(data.MESSAGE);
			}

		});
	}
	$scope.requestStatus = function (value) {
		$scope.requestStatus = value;
	}

	$scope.convertMessage = function () {
		var count = 1;
		var delimiters = /([ ,.\n])/;
		$scope.tempvar = $scope.selectedTemplt.smsTemplateMsg.replace(/ {2,}/g, ' ').split(delimiters).filter(Boolean);

		$scope.varArray = [];
		for (i = 0; i < $scope.tempvar.length; i++) {
			if ($scope.tempvar[i] == '{#var#}') {
				var tempVarValue = {
					var: 'Text' + count,
					value: ''
				}
				$scope.tempvar[i] = "<a ng-click=\"inputMethod('#Text" + count + "#')\">{Text" + count + "}</a>";
				$scope.varArray.push(tempVarValue);
				count++;
			}
		}
		$scope.dynamicString = $scope.tempvar.join('');
	}

	$scope.inputMethod = function (val) {
		$scope.selectedVar = '';
		$scope.selectedVar = val;
	}

	$scope.getCombinedString = function () {
		var count = 1;
		var textMssg = '';
		for (i = 0; i < $scope.tempvar.length; i++) {
			if ($scope.tempvar[i] == "<a ng-click=\"inputMethod('#Text" + count + "#')\">{Text" + count + "}</a>") {
				for (j = 0; j < $scope.varArray.length; j++) {
					if ($scope.tempvar[i] == "<a ng-click=\"inputMethod('#" + $scope.varArray[j].var + "#')\">{" + $scope.varArray[j].var + "}</a>") {
						textMssg += $scope.varArray[j].value;
						count++;
						break;
					}
				}
			} else {
				textMssg += $scope.tempvar[i];
			}
		}
		return textMssg;
	}

	$scope.resetVal = function () {
		$scope.selectedTemplt = undefined;
		$scope.stucheck = false;
		$scope.stacheck = false;
		$scope.stuAll = false;
		$scope.tempvar = [];
		$scope.varArray = [];

		var checkboxes = document.querySelectorAll("input[id='c1'], input[id='c2']");
		checkboxes.forEach(function (checkbox) {
			checkbox.checked = false;
		});

		$('.resett').val("");
	};

});
projectModule.directive('bindCompiledHtml', ['$compile', function ($compile) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			scope.$watch(attrs.bindCompiledHtml, function (html) {
				element.html(html);
				$compile(element.contents())(scope);
			});
		}
	};
}]);