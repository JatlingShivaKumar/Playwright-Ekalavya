projectModule.controller('rankrSectionStudents', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.userId = localStorage.getItem("userId");
 $scope.branchId=localStorage.getItem("bnchId");
 $scope.branchName = localStorage.getItem("bnchnme");
 $scope.httpPath=(localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath=";

 var requestParams = {
   "m_inst_id": $scope.instituteId
 };

 $scope.navCourseId=sessionStorage.getItem("navCourseId");
 $scope.navClassId = sessionStorage.getItem("navClassId");
 $scope.myClasses=sessionStorage.getItem("myClasses");
 $scope.navSectionId=sessionStorage.getItem("navSectionId");
 sessionStorage.removeItem("navCourseId");
 sessionStorage.removeItem("navClassId");
 sessionStorage.removeItem("myClasses");
 sessionStorage.removeItem("navSectionId");

 if ($scope.navCourseId) {
   $scope.selectedCourse=$scope.navCourseId;
 }

 $scope.getCourseByBranchId=function(){
   httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.courseList = data.Courses;
       if($scope.navCourseId){
         for (var i = 0; i < $scope.courseList.length; i++) {
           if($scope.courseList[i].courseId==$scope.navCourseId){
             console.log(JSON.stringify($scope.courseList[i]));
             $scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
             $scope.courseSelect($scope.selectedCourseOb);
         }
       }
     }
     }
   });
 }
 $scope.getCourseByBranchId();

 $scope.courseSelect = function(selCrs){
   if(typeof selCrs=='string')
   $scope.selCrsOb =JSON.parse(selCrs);
   else
   $scope.selCrsOb = selCrs;

   $scope.selectedCourse=$scope.selCrsOb.courseId;
   $scope.courseName = $scope.selCrsOb.courseName;

   httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.classList = data.Classes;
       if($scope.navCourseId){
         for (var i = 0; i < $scope.classList.length; i++) {
           if($scope.classList[i].classId==$scope.navClassId){
             console.log(JSON.stringify($scope.classList[i]));
             $scope.selectedClassOb=JSON.stringify($scope.classList[i]);
             $scope.selectedCCId=$scope.classList[i].classCourseId;
             console.log($scope.selectedCCId);
             $scope.courseClassSelect($scope.selectedClassOb);
         }
       }
     }else{
     }
     }
   });
 }


 $scope.courseClassSelect = function(clsOb){
   if(typeof clsOb=='string')
   $scope.selClsOb =JSON.parse(clsOb);
   else
   $scope.selClsOb = clsOb;

   console.log($scope.selClsOb);
   $scope.selectedCCId = $scope.selClsOb.classCourseId;
   $scope.className = $scope.selClsOb.className;
   httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.sectionList = data.Sections;
       $scope.sectionId=$scope.sectionList[0].sectionId;
       // $scope.getSectionAttendanceDetails(/$scope.sectionList[0].sectionId,$scope.sectionList[0].sectionName);

       $scope.getSectionStudents();
     }
   });
 }

 $scope.sectionSelected=function(section){
   $scope.sectionId=section.sectionId;
   $scope.getSectionStudents();
 }

 $scope.getSectionStudents = function(){
   //selectStudentsBySection
   httpFactory.getResult("selectStudentsBySection?schemaName="+$scope.schemaName+"&branchId=" + $scope.branchId +"&sectionId="+$scope.sectionId, function(data) {
     console.log(data);
     if (data.StatusCode == 200){
       $scope.sectionStudents = data.sectionStudents;
     } else {
       $scope.sectionStudents=[];
     }
   });
 }
 $scope.goToMyClasses=function(){
   sessionStorage.setItem("navCourseId",$scope.selectedCourse);
   sessionStorage.setItem("navClassId",$scope.selClsOb.classId);
   $location.path("/rankrClasses");
  }

  $scope.goToProfile=function(student){
    console.log(student);
    $scope.studentId=student.studentId;
    sessionStorage.setItem("navCourseId",$scope.selectedCourse);
    sessionStorage.setItem("navClassId",$scope.selClsOb.classId);
    $location.path("studentDetails/"+student.studentId);
  }

});
