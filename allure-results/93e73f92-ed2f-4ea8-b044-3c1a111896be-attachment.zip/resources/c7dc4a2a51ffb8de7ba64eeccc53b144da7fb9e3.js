projectModule.controller('rankrDashboardController', function($scope, $window, $location, commonFactory, httpFactory, $routeParams,$route) {
  $scope.$ = $;
  $scope.instituteId = parseInt(localStorage.getItem("inst_id"));
  $scope.insName = parseInt(localStorage.getItem("instName"));

  $scope.instituteTypes = [];
  $scope.latestCurrentInstTab = "";
  $scope.schemaName = localStorage.getItem("sname");
  $scope.userRoleId = localStorage.getItem("RD");
  $scope.userName = localStorage.getItem("userName");
  $scope.bnchId=localStorage.getItem("bnchId");
  $scope.stuAttBnchId = $scope.bnchId;
  $scope.staffAttBnchId = $scope.bnchId;
  $scope.progressPerc=0;

  $scope.userId=localStorage.getItem("userId");
  $scope.instName=localStorage.getItem("instName");
  console.log($scope.instName);
  $scope.backgroundColor = {'background-color':localStorage.getItem("clr")};
  $scope.backgroundImage = localStorage.getItem("logo");
  $scope.rankrAdminLogin = localStorage.getItem("rankrAdminLogin");
	$scope.activeAdminTab = "home";
	$scope.presentDate= new Date();

	//to hide setup page
	$scope.progressPerc=100;

  $scope.themeColorStatus = false;
  $scope.themeColorStatus2 = false;
  $scope.themeColorStatus3 = false;

  if(localStorage.getItem("domain") == 'ekalavya.gorankr.com' || localStorage.getItem("domain") == 'localhost:9000'){
    $scope.themeColorStatus3 = true;
  }
	else if(localStorage.getItem("domain") == "narayana.gorankr.com"){
		  $scope.themeColorStatus = true;
	}else {
		  $scope.themeColorStatus2 = true;
	}


  $scope.backMethod = function(modalId){
    $('#'+modalId).modal('hide');
    //$scope.branchStatus();
  }
  $scope.redirectToDashboard = function(){
	  $scope.activeAdminTab = "home";
    $location.path("home");
    //$scope.branchStatus();
  };

  $scope.redirectToExam = function() {
	   $scope.activeAdminTab = "exams";
     $location.path("exams");
    //$scope.branchStatus();
  };

  $scope.redirectToContent = function() {
    $scope.activeAdminTab = "contentManagement";
    $location.path("contentManagement");
    //$scope.branchStatus();
  };

	$scope.redirectToAnalytics = function() {
    $scope.activeAdminTab = "analytics";
	  $location.path("analytics");
	  //$scope.branchStatus();
	};

  $scope.redirectToSettings = function() {
    $scope.activeAdminTab = "settings";
		$location.path("settings");
		//$scope.branchStatus();
	};

  $scope.redirectToStudents = function() {
    $scope.activeAdminTab = "manageStudent";
	  $location.path("manageStudent");
	  //$scope.branchStatus();
	};

	$scope.redirectToRankrPlus = function(){
    $scope.activeAdminTab = "rankrPlus";
		$location.path("rankrPlus");
		//$scope.branchStatus();
	};
	
	$scope.redirectToEkalavyaStore = function(){
    $scope.activeAdminTab = "branchEkalavyaStore";
		$location.path("branchEkalavyaStore");
		//$scope.branchStatus();
	};

	$scope.redirectToStoreHome = function(){
    $scope.activeAdminTab = "adminStoreHome";
    	$location.path("adminStoreHome");
    	//$scope.branchStatus();
    };

    $scope.redirectToStoreContentManagement = function(){
    $scope.activeAdminTab = "adminStoreContentManagement";
        $location.path("adminStoreContentManagement");
        //$scope.branchStatus();
    };

    $scope.redirectToStoreContent = function(){
        $scope.activeAdminTab = "adminStoreContent";
            $location.path("adminStoreContent");
            //$scope.branchStatus();
        };

	$scope.redirectToManageAcadamics=function(){
    $scope.activeAdminTab = "settings";
		$location.path("acadamicChart");
		//$scope.branchStatus();
	};

	$scope.gotoAcadamicsHome = function(){
    $scope.activeAdminTab = "settings";
		sessionStorage.setItem("fromHomeScreen", true);
		$location.path("acadamicChart");
		//$scope.branchStatus();
	};

  $scope.goToMessages = function(){
	 localStorage.setItem('location', JSON.stringify($location.path("home")));
    $location.path("messages/yes");
    //$scope.branchStatus();
  };

  $scope.goToMyClass=function(cls){
    sessionStorage.setItem("navCourseId",$scope.courseObject.courseId);
    sessionStorage.setItem("navClassId",cls.classId);
    sessionStorage.setItem("nav","mycls");
	localStorage.setItem('location', JSON.stringify($location.path("home")));
    $location.path("rankrClasses");
    //$scope.branchStatus();
  };

  $scope.redirectToResult=function(test){
    console.log(test);
    $location.path("testResult/"+ test.testId+"/"+localStorage.getItem("bnchId"));
    //$scope.branchStatus();
  };

  $scope.redirectToRepublishTest=function(test){
    var editTestOb = JSON.stringify(test);
    console.log(editTestOb);
    localStorage.setItem('editTest', editTestOb);
    $location.path("publishTest/"+test.testId+"/"+test.branchId+"/republish");
    //$scope.branchStatus();
  };

  $scope.goToCalendar=function(){
	  localStorage.setItem('location', JSON.stringify($location.path("home")));
      $location.path("adminCalendar");
      //$scope.branchStatus();
  };

  $scope.gotoGallery = function(){
	localStorage.setItem('location', JSON.stringify($location.path("home")));
    $location.path("gallery");
    //$scope.branchStatus();
  }

  $scope.adminDashInit=function(){
    $scope.getBranchInstTypes();
    $scope.getBranchList();
    $scope.getUpcomingTestForAdminDashBoard();
    $scope.getAdminMeetingDetailsForHome();
    $scope.getStudentAttendanceReportForAdmin();
    $scope.getStaffAttendanceReportForAdmin();
    $scope.getAllLeaveRequestsByBranch();
	// $scope.renderChartsForStudent();
    $scope.calendarInitMethod();
	   showTime();
	   $scope.branchStatus();	   
  }
  $scope.redirectToTestStudents=function(testId){
    console.log(testId);
    $scope.testId=testId.testId;
    $scope.getStudentsExamStatusByTestId($scope.testId);
    //$scope.branchStatus();
   
  }

  $scope.redirectToReAssignTest=function(test){
    console.log(test);

    $location.path("publishTest/"+test.testId+"/"+test.branchId+"/reassign")
    //$scope.branchStatus();

  }
  $scope.logoutAdmin=function(){
    localStorage.clear();
    sessionStorage.clear();

    // $location.path("admin.html");
    window.location.href = "../../admin.html";
  }
  $scope.openModal = function() {
    // $("#addNewtest").modal("show");
    $location.path("examGeneration");
  }
  $scope.TestModal = function() {
    // $("#customTest").modal("show");
    $location.path("/examType");
  }
  $scope.manualExamsModal = function() {
	    // $("#customTest").modal("show");
	    $location.path("/manualExamsView");
	  }	
  $scope.profile = function(){
    $location.path("profile/"+localStorage.getItem("userId")+"/"+$scope.userRoleId+"/"+$scope.bnchId);
  }


  $scope.closeModal = function() {
    $("#addNewtest").modal("hide");
    $("#customTest").modal("hide");
  }

  $scope.manageSubjects = function(){
    $("#subjectsManage").modal("show");
  }

  $scope.getAllDetails = function() {
    // $scope.getAllBranches();
    // $scope.getCourses();
    // $scope.getClasses();
  }
  $scope.fotClick=function(fot){
    // alert(fot);
    $scope.subjectGrp=fot;
  }

  $scope.greetDay =function(){
    $scope.getCollegeOnBoardingStatus();
    var myDate = new Date();
   var hrs = myDate.getHours();

   $scope.greet="";

   if (hrs < 12)
       $scope.greet = 'Good Morning';
   else if (hrs >= 12 && hrs < 16)
       $scope.greet = 'Good Afternoon';
   else if (hrs >= 16 && hrs <= 23)
       $scope.greet = 'Good Evening';

       console.log($scope.greet);
  }
	function showTime(){
    $scope.daysInWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  $scope.monthInYear = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    var date = new Date();
      $scope.dayName=$scope.daysInWeek[date.getDay()];
      $scope.monthname=$scope.monthInYear[date.getMonth()];
      $scope.fullYear = date.getFullYear();
      $scope.dayDate = date.getDate();
      var h = date.getHours(); // 0 - 23
      var m = date.getMinutes(); // 0 - 59
      var s = date.getSeconds(); // 0 - 59
      var session = "AM";
      $scope.hour=h;
      if(h == 0){
          h = 12;
      }
      if(h >= 12){
          if(h>12){
        	   h = h - 12;
        	}
          session = "PM";
      }
       if ($scope.hour>=0 && $scope.hour<12) {
          $scope.dayText="Morning";
        }
        if ($scope.hour>=12 && $scope.hour<=16) {
          $scope.dayText="Afternoon";
        }
        if($scope.hour>=17){
          $scope.dayText="Evening";
        }
      h = (h < 10) ? "0" + h : h;
      m = (m < 10) ? "0" + m : m;
      s = (s < 10) ? "0" + s : s;

      var time = h + ":" + m + ":" + s + " " + session;
      document.getElementById("timings").innerText = time+" ,"+$scope.dayName+" "+$scope.monthname;
      document.getElementById("timings").textContent = time+"-"+$scope.dayName+","+$scope.dayDate+" "+$scope.monthname+" "+$scope.fullYear;
      setTimeout(showTime, 1000);
  }

  $scope.getCollegeOnBoardingStatus=function(){
    httpFactory.getResult("getCollegeOnBoardingStatus?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id"), function(data){
      console.log(data);
      if(data.StatusCode == 200){
		  $scope.progressPerc = 0;
		  $scope.progressRecord = {};
		 if(data.record != undefined){
        $scope.progressRecord=data.record;
        // $scope.progressPerc=$scope.progressPerc+20;
        $scope.progressPerc=$scope.progressPerc+60;

        // if ($scope.progressRecord.EnableClassCourseStatus==1) {
        //   $scope.progressPerc=$scope.progressPerc+20;
        // }
        if ($scope.progressRecord.addBranchStatus==1) {
          $scope.progressPerc=$scope.progressPerc+20;
        }
        // if ($scope.progressRecord.addStudentStatus==1) {
        //     $scope.progressPerc=$scope.progressPerc+20;
        //    }
           // if ($scope.progressRecord.subjectsVerifiedStatus==1) {
          //   }
            if ($scope.progressRecord.timePeriodStatus==1) {
               $scope.progressPerc=$scope.progressPerc+20;
             }
             // $scope.progressPerc=100;
             console.log($scope.progressPerc);
		 }
      }
    });
  }

  $scope.saveSubject=function(){
    console.log($scope.clsOb);
    console.log($scope.instCrsOb.courseId);
    console.log($scope.subjectName);
    console.log($scope.subjectGrp);
    $scope.addNewSubject();
  }

  $scope.courseLists = ["MEC","CEC"];

  function isJSON(data) {
   var ret = true;
   try {
      JSON.parse(data);
   }catch(e) {
      ret = false;
   }
   return ret;
}
  $scope.acadamicTimeInstituteTypes = [];
  $scope.getInstituteTypes = function(){
		httpFactory.getResult("getCollegeInstituteTypes?schemaName="+localStorage.getItem("sname") + "&instId=" +localStorage.getItem("inst_id"), function(data){
			if(data.statusCode == '200'){
				$scope.instituteTypes = data.data;
				console.log($scope.instituteTypes);
				$scope.acadamicTimeInstituteTypes = data.data;
				$scope.latestCurrentInstTab = $scope.instituteTypes[0].instTypeId;
				$scope.showCourseByInstType($scope.instituteTypes[0]);
			}
		});
	}

  $scope.showCourseByInstType=function(instType){
    if (instType) {
      $scope.instTypeOb=instType;
	  $scope.latestCurrentInstTab = instType.instTypeId;
      $scope.redirectToCurrentInstTab(instType.instTypeId);
    }
    httpFactory.getResult("getAllCoursesByInstType?instType=" + $scope.instTypeOb.instTypeId + "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      $scope.crsListInstType=[];
      $scope.clsListCrsInstType=[];
      $scope.subjList=[];
      if (data.StatusCode == 200) {
        $scope.crsListInstType=data.Courses;
      } else {
        console.log("No Courses");
      }
    });
  }

  $scope.showClsBycrsInstype=function(instCrs){
    $scope.subjList=[];
    if(typeof instCrs === "string")
    $scope.instCrsOb = JSON.parse(instCrs);
      else
      $scope.instCrsOb=instCrs;

    console.log($scope.instCrsOb);
    httpFactory.getResult("getAllClassesByInstTypeAndCourseId?instType=" + $scope.instTypeOb.instTypeId + "&courseId="+$scope.instCrsOb.courseId+ "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      $scope.clsListCrsInstType=[];
      if (data.StatusCode == 200) {
        $scope.clsListCrsInstType=data.Classes;
      } else {
        console.log("No Courses");
      }
    });
  }
  $scope.selectedClsMethod=function(){
  }

  $scope.showClassSubjList = function(instCls){
    $scope.instClsObj = instCls;
    console.log($scope.instCls);

    httpFactory.getResult("getCourseClassSubjects?classId=" + $scope.instClsObj.classId +"&courseId=" + $scope.instCrsOb.courseId +"&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
          $scope.subjList = data.Classes;
    }
    });
  }


  // $scope.getStudentsExamStatusByTestId=function(){
  //   httpFactory.getResult("getStudentsExamStatusByTestId?testId=" + $routeParams.testId +"&branchId=" + $routeParams.branchId +"&schemaName="+$scope.schemaName, function(data) {
  //     console.log(data);
  //     if (data.StatusCode == 200) {
  //         $scope.studentTestList = data.TestStudentArray;
  //   }
  //   });
  // }

$scope.addNewCourse = function(){
  var params = {
	"courseName" : "CBSE4",
	"instType" : $scope.instTypeOb.instTypeId,
	"instId" : localStorage.getItem("inst_id") ,
	"userId" : localStorage.getItem("userId"),
  "schemaName": localStorage.getItem("sname")
}

httpFactory.executePost("addNewCourse", params, function(data) {
  console.log(data);
  if (data.StatusCode == 200) {
    alert("newCourse added");
      console.log($scope.instSubjs);
      $scope.showCourseByInstType();
    }
});
}


$scope.updateStudentTestStatus=function(statusOb,statusTag){
  if(statusTag==null){}else{
  var params = {
  "schemaName": localStorage.getItem("sname"),
  "updatedRecords":[{
  "studentId" : statusOb.studentId,
  "testId" : $scope.selTestId,
  "testStatus" : statusTag ,
  "updatedBy" : localStorage.getItem("userId"),
  "branchId" : statusOb.branchId

}
]
  }
console.log(params);
httpFactory.executePost("updateStudentTestStatus", params, function(data) {
  console.log(data);
  if (data.StatusCode == 200) {
	  alert("success");
    }
});
}
}

$scope.updateAcademicYear=function(){
  $scope.paramArray=[];
  console.log($scope.acadamicTimeInstituteTypes);
  for (var i = 0; i < $scope.acadamicTimeInstituteTypes.length; i++) {
    if($scope.acadamicTimeInstituteTypes[i].startDate && $scope.acadamicTimeInstituteTypes[i].endDate){
    $scope.stdate = $scope.acadamicTimeInstituteTypes[i].startDate;
    $scope.endate = $scope.acadamicTimeInstituteTypes[i].endDate;
    var startDT = new Date($scope.stdate);
    var endDT = new Date($scope.endate);

    var date = new Date();

    // var date2 = new Date();
    // $scope.todayDate2=date2.getDate($scope.endate);
    // console.log($scope.todayDate2);

    $scope.acadamicTimeInstituteTypes[i]["startDate"]=startDT.getFullYear()+"-"+(startDT.getMonth()+1)+"-"+ startDT.getDate($scope.stdate);
    $scope.acadamicTimeInstituteTypes[i]["endDate"]=endDT.getFullYear()+"-"+(endDT.getMonth()+1)+"-"+endDT.getDate($scope.endate);
    $scope.acadamicTimeInstituteTypes[i]["yearName"]=startDT.getFullYear()+"-"+endDT.getFullYear();

  console.log($scope.acadamicTimeInstituteTypes);
  var params = {
    "instTypeId":$scope.acadamicTimeInstituteTypes[i].instTypeId,
    "startDate":$scope.acadamicTimeInstituteTypes[i].startDate,
    "endDate":$scope.acadamicTimeInstituteTypes[i].endDate,
    "yearName":$scope.acadamicTimeInstituteTypes[i].yearName,
    "createdBy":localStorage.getItem("userId")
}
$scope.acadamicTimeInstituteTypes[i].startDate="";
$scope.acadamicTimeInstituteTypes[i].endDate="";

$scope.paramArray.push(params);
}
}

  var paramOj =  {
    "schemaName":localStorage.getItem("sname"),
    "insertRecords":$scope.paramArray
}


console.log($scope.paramArray);
  httpFactory.executePost("updateAcademicTimings", paramOj, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
		$("#setTimePopup").modal("hide");
      }
	  else{
		 alert("Please Try Again Later.");
	  }
  });
}

$scope.cancelPopUp=function(){
  $("#setTimePopup").modal("hide");
}

$scope.addNewSubject = function(){

	if($scope.subjectName == undefined || $scope.subjectName == "" || $scope.subjectGrp == undefined || $scope.subjectGrp == "" || $scope.instCrsOb.courseId == undefined || $scope.instCrsOb.courseId == "" || $scope.clsOb == undefined || $scope.clsOb == ""){
		alert("Please Add/Select All Fields");
		return true;
	}

	var params = {
		"schemaName": localStorage.getItem("sname"),
		"courseId":$scope.instCrsOb.courseId,
		"classId":$scope.clsOb,
		"isActive":1,
		"createdBy":localStorage.getItem("userId"),
		"userId" : localStorage.getItem("userId"),
		"instId":localStorage.getItem("inst_id"),
		"insertRecords":[
		  {
			"subjectName":$scope.subjectName,
			"subjectGroup":$scope.subjectGrp
		  }
		]
	}

	httpFactory.executePost("insertSubjects", params, function(data) {
	  console.log(data);
		if (data.StatusCode == 200) {
			alert("New Subject Added");
			$("#subjectsManage").modal("hide");
			console.log($scope.instSubjs);
			$scope.showCourseByInstType();
		}
		else{
			alert("Please verify entered data");
		}
	});
}

$scope.mapNewSubjectToCourseAndClass = function(){
	var params = {
		"schemaName": localStorage.getItem("sname"),
		"subjectId":30,
		"classId":$scope.instClsObj.classId,
		"courseId":$scope.instCrsOb.courseId,
		"isActive":1,
		"instId":localStorage.getItem("inst_id")
	}

	httpFactory.executePost("mapNewSubjectToCourseAndClass", params, function(data) {
	  console.log(data);
	  if (data.StatusCode == 200) {
		alert("newCourse added");
		  console.log($scope.instSubjs);
		  $scope.showCourseByInstType();
		}
	});
}

$scope.createNewElectiveGroup = function(){
  var params = {
        "schemaName":$scope.schemaName,
        "electiveGroupName":"Namastey Group",
        "instId":localStorage.getItem("inst_id"),
        "instType":$scope.instTypeOb.instTypeId,
        "isActive":1,
        "createdBy":localStorage.getItem("userId")
      }
      console.log(params);
      httpFactory.executePost("createNewElectiveGroup", params, function(data) {
        console.log(data);
        if (data.StatusCode == 200) {
          alert("newCourse added");
            console.log($scope.instSubjs);
          }
      });
}

$scope.subjectClick=function(subj){
$scope.selectedSubId = subj.subjectId;
// $scope.assignSubjectToElectiveGroup();
}

$scope.assignSubjectToElectiveGroup = function(){
  var params = {
        "schemaName":$scope.schemaName,
          "classId":$scope.instClsObj.classId,
          "courseId":$scope.instCrsOb.courseId,
          "electiveGrpId":1,
          "subId":$scope.selectedSubId
      }
      console.log(params);
      httpFactory.executePost("assignSubjectToElectiveGroup", params, function(data) {
        console.log(data);
        if (data.StatusCode == 200) {
          alert("newCourse added");
            console.log($scope.instSubjs);
          }
      });
}


$scope.assignSubjects=function(){
    $scope.mapNewSubjectToCourseAndClass();
}

//	$scope.getInstituteTypes();


	$scope.allbranchList = [];
	$scope.getAllBranchesForUser = function() {
		httpFactory.getResult("getAllBranches?instId=" +localStorage.getItem("inst_id") + "&schemaName="+localStorage.getItem("sname")+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.allbranchList=data.collegeBranches;
        var roleId =parseInt(localStorage.getItem("RD"));
        if (roleId >1) {
          for (var i = 0; i < $scope.allbranchList.length; i++) {
            if ($scope.allbranchList[i].branchId == localStorage.getItem("bnchId")) {
              $scope.selBranchObj = $scope.allbranchList[i];
              console.log($scope.selBranchObj);
            }
          }
        }else{
			var obj = {
				"branchId":"0",
				"branchName":"Default"
			}
			$scope.allbranchList.splice(0, 0, obj);

			console.log($scope.allbranchList);
			if (roleId<1 && $scope.bnchId == 0){
			  localStorage.setItem("bnchId",0);
			}else{
			  for (var i = 0; i < $scope.allbranchList.length; i++) {
				if ($scope.allbranchList[i].branchId == localStorage.getItem("bnchId")) {
				  $scope.selBranchObj = $scope.allbranchList[i];
				  console.log($scope.selBranchObj);
				}
			  }
			}
			
      }
				console.log($scope.allbranchList);
				console.log($scope.selBranchObj);
			} else {
				console.log("No branches");
			}
		});
		//$scope.branchStatus();
  }


	$scope.changeSelBranchObj = function(){
		console.log($scope.selBranchObj);
		localStorage.setItem("mainSelBranchId",$scope.selBranchObj.branchId);
    localStorage.setItem("bnchId",$scope.selBranchObj.branchId);
    localStorage.setItem("bnchnme",$scope.selBranchObj.branchName);
		$route.reload();
	}

	$scope.branchListByType = [];
	$scope.getAllBranchesByType = function() {

    httpFactory.getResult("getAllBranchesByRole?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname")+"&roleId="+localStorage.getItem("RD")+"&userId="+localStorage.getItem("userId")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.branchListByType=data.collegeBranches;
          console.log($scope.branchListByType);
      } else {
        console.log("No branches");
      }
    });
  }

$scope.listCourseClassForInst = [];
$scope.listCourseClassForInstBranch = [];
$scope.selBranchForMapping = "";
	$scope.getCourseClassForInstBranch = function(instTypeId,brchId){
		//$scope.getCourseClassForInst(instTypeId);
		//$scope.getCourseClassesForBranch(brchId);
		$scope.listCourseClassForInstBranch = [];
		$scope.selBranchForMapping = brchId;
		httpFactory.getResult("getCourseClassesForBranchWithMapping?instTypeId=" +instTypeId+"&branchId=" +brchId+ "&schemaName="+localStorage.getItem("sname"), function(data) {
		  console.log(data);
		  if (data.statusCode == 200) {
			$scope.listCourseClassForInstBranch = data.records;
		  } else {
			console.log("No branches");
      $scope.listCourseClassForInstBranch = [];

		  }
		});
	}

$scope.getCourseClassForInst = function(instTypeId) {
	$scope.listCourseClassForInst = [];
    httpFactory.getResult("getCourseClassesForInstType?instTypeId=" +instTypeId+ "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      if (data.statusCode == 200) {
        $scope.listCourseClassForInst = data.records;
      } else {
        console.log("No branches");
      }
    });
  }
$scope.listCourseClassForBranch = [];
$scope.getCourseClassesForBranch = function(brchId) {

    httpFactory.getResult("getCourseClassesForBranch?branchId=" +brchId+ "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
		  $scope.listCourseClassForBranch = data.records;
			for(var i=0; i<$scope.listCourseClassForInst.length; i++){
				for(var j=0; j<$scope.listCourseClassForBranch.length; j++){
					if($scope.listCourseClassForInst[i].courseId == $scope.listCourseClassForBranch[j].courseId ){

					}
				}
			}
      } else {
        console.log("No branches");
      }
    });
}

$scope.instTypeSubj=function(){
  $scope.getInstituteTypes();
}

$scope.subjectsByInstType=function(instType){
	$scope.instTypeOb=instType;
	$scope.instTypeObId = instType.instTypeId;
	$scope.latestCurrentInstTab =instType.instTypeId;

  var params = {
    "instTypeId":$scope.instTypeObId,
    "schemaName":localStorage.getItem("sname")
  }

  httpFactory.executePost("getAllSubjectDetailsForInstType", params, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
        $scope.instSubjs = data.data;

        console.log($scope.instSubjs);
      }
  });
}
  $scope.getCourses = function() {
    httpFactory.getResult("getAllCourses?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        for (i = 0; i < data.length; i++)
          $scope.courseList = data;
      } else {
        console.log("No courses");
      }
    });
  }
// instId=" + $scope.instituteId +
  $scope.getTestByCalender = function() {
    httpFactory.getResult("getTestByCalender?schemaName="+localStorage.getItem("sname")+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        if (data.TestCategories.length>0) {
        $scope.selectExamDetauls = [];
        $scope.brnchSections=data.TestCategories;
        console.log($scope.brnchSections);
        for (var i = 0; i < $scope.brnchSections.length; i++) {
          console.log($scope.brnchSections[i].branchId);
          if (localStorage.getItem("bnchId") == 0) {
            $scope.brchSelect = $scope.brnchSections[0];
            $scope.selectExamDetauls=$scope.brnchSections[0].years;
            console.log($scope.selectExamDetauls);

            $scope.branchLoad = $scope.brchSelect.branchId;
            $scope.yearLoad = $scope.brchSelect.years[0].yearId;
            $scope.monthLoad = $scope.brchSelect.years[0].Months[0].monthId;
            $scope.weekload = $scope.brchSelect.years[0].Months[0].Weeks[0].weekOfMonth;

            $scope.getAllTestsForAdminByCalnder($scope.yearLoad,$scope.monthLoad,$scope.weekload);
          }
          else if(localStorage.getItem("bnchId") == $scope.brnchSections[i].branchId){
            $scope.brchSelect = $scope.brnchSections[i];
            $scope.selectExamDetauls=$scope.brnchSections[i].years;
            console.log($scope.selectExamDetauls);


            $scope.branchLoad = $scope.brchSelect.branchId;
            $scope.yearLoad = $scope.brchSelect.years[0].yearId;
            $scope.monthLoad = $scope.brchSelect.years[0].Months[0].monthId;
            $scope.weekload = $scope.brchSelect.years[0].Months[0].Weeks[0].weekOfMonth;
			$scope.getAllTestsForAdminByCalnder($scope.yearLoad,$scope.monthLoad,$scope.weekload);
        }else{
          $scope.brchSelect = [];
          // $scope.selectExamDetauls.push($scope.brnchSections[i].years[0]);

          $scope.branchLoad = '';
          $scope.yearLoad = "";
          $scope.monthLoad = "";
          $scope.weekload = "";
        }


      }
    }else{
        alert("No Exams");
      }
    }
    });
  }

  $scope.testsYearForCalender = "";
  $scope.testsMonthForCalender = "";
  $scope.testsWeekendForCalender = "";
  $scope.getAllTestsForAdminByCalnder = function(year,month,week) {
    $scope.testsYearForCalender = year;
    $scope.testsMonthForCalender = month;
    $scope.testsWeekendForCalender = week;
    httpFactory.getResult("getAllTestsForAdminByCalnder?year=" + year + "&branchId=" + localStorage.getItem("bnchId") +"&monthId=" + month + "&week=" + week +"&schemaName="+localStorage.getItem("sname")+"&roleId="+localStorage.getItem("RD"), function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
          $scope.newtestData = data.TestCategories;
          console.log($scope.newtestData);
      } else {
		  $scope.newtestData = [];
        console.log("No classes");
      }
    });
  }
    $scope.getClasses = function() {
      httpFactory.getResult("getAllClasses?instId=" + $scope.instituteId + "&schemaName="+localStorage.getItem("sname"), function(data) {
        console.log(data);
        if (data.StatusCode == 200) {
          for (i = 0; i < data.length; i++)
            $scope.classList = data;
        } else {
          console.log("No classes");
        }
      });
    }

    $scope.brchCLassMapObj = [];
    $scope.classIndex=0;
    $scope.selectedClass=function(crs,indexV){
      console.log(crs);
      var flag =contains($scope.brchCLassMapObj,"classId",crs.classes[indexV].classId);
      if (flag==false) {
        var clsMap = {
          "classId":crs.classes[indexV].classId,
          "courseId":crs.courseId,
          "branchId":$scope.selBranchForMapping
        }
        $scope.brchCLassMapObj.push(clsMap);
      }else {
        $scope.brchCLassMapObj.splice($scope.classIndex,1);
      }
      console.log($scope.brchCLassMapObj);
    }

    function contains(arr, key, val) {
        for (var i = 0; i < arr.length; i++) {
            if(arr[i][key] == val){
              $scope.classIndex = i;
             return true;
           }
        }
        return false;
    }

    $scope.mapCourseClass=function(){
    var params = {
	       "schemaName" : localStorage.getItem("sname"),
	        "insertRecords" : $scope.brchCLassMapObj
        }

    httpFactory.executePost("updateBranchClassCourse", params, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        }
    });
  }

    $scope.changeBranch = function(index){
      $scope.selectExamDetauls=[];
      $scope.selectExamDetauls.push($scope.brchSelect.years[0]);
      $scope.branchLoad = $scope.brchSelect.branchId;
      $scope.yearLoad = $scope.brchSelect.years[0].yearId;
      $scope.monthLoad = $scope.brchSelect.years[0].Months[0].monthId;
      $scope.weekload = $scope.brchSelect.years[0].Months[0].Weeks[0].weekOfMonth;
      $scope.getAllTestsForAdminByCalnder($scope.yearLoad,$scope.monthLoad,$scope.weekload);

    }

    $scope.rankrDashboardInit = function(){
      $scope.getAllDetails();

    }

    $scope.openWindow = function(testId) {
    $location.path("/");
    var params = [
	  'height='+screen.height,
	  'width='+screen.width,
	  'fullscreen=yes' // only works in IE, but here for completeness
	  ].join(',');

      $scope.test = JSON.parse(localStorage.getItem("test"));
      $scope.studentId = localStorage.getItem("stuid");
      $window.open("http://localhost:9000/module/html/studentdashboard.html#!/onlineExam?id="+testId+ "&sid="+$scope.studentId, '', 'width=4000,height=2000');

  }

	$scope.sortCalenderViewByYear = function(yearlevelSelected){
    for(var i=0; i<$scope.selectExamDetauls.length; i++){
     if($scope.selectExamDetauls[i].yearId == yearlevelSelected){
      if($scope.selectExamDetauls[i].selected == true){
       $scope.selectExamDetauls[i].selected = false;
      }
      else
      {
       $scope.selectExamDetauls[i].selected = true;
      }
     }
     else{
      $scope.selectExamDetauls[i].selected == false;
     }
    }
  }

   $scope.sortCalenderViewByMonth = function(yearSel, monthSel){
    for(var i=0; i<$scope.selectExamDetauls.length; i++){
     if($scope.selectExamDetauls[i].yearId == yearSel){
      for(var j=0; j<$scope.selectExamDetauls[i].Months.length; j++){
       if($scope.selectExamDetauls[i].Months[j].monthId == monthSel){
        if($scope.selectExamDetauls[i].Months[j].selected == true){
         $scope.selectExamDetauls[i].Months[j].selected = false;
        }
        else
        {
         $scope.selectExamDetauls[i].Months[j].selected = true;
        }
       }
       else{
        $scope.selectExamDetauls[i].Months[j].selected = false;
       }
      }
     }
    }
   }
   $scope.sortCalenderViewByMonthWeek = function(yearSel, monthSel, weekSel){
    for(var i=0; i<$scope.selectExamDetauls.length; i++){
     if($scope.selectExamDetauls[i].yearId == yearSel){
      for(var j=0; j<$scope.selectExamDetauls[i].Months.length; j++){
       if($scope.selectExamDetauls[i].Months[j].monthId == monthSel){
        if($scope.selectExamDetauls[i].Months[j].selected == true){
         for(var k=0; k< $scope.selectExamDetauls[i].Months[j].Weeks.length; k++){
          if($scope.selectExamDetauls[i].Months[j].Weeks[k].weekOfMonth == weekSel){
           $scope.selectExamDetauls[i].Months[j].Weeks[k].selected = true;
          }
          else{
           $scope.selectExamDetauls[i].Months[j].Weeks[k].selected = false;
          }
         }
        }
       }
       else{
        $scope.selectExamDetauls[i].Months[j].selected = false;
       }
      }
     }
    }
   }

   $scope.editTest=function(test){
		console.log(test);
		// test.testCourse=1;
		// test.selectedBranch=1;
    var editTestOb = JSON.stringify(test);
    console.log(editTestOb);
		localStorage.setItem('editTest', editTestOb);
		$location.path("editTest/"+ test.testId + "/" +test.branchId);
	}
	$scope.branchArr = [];
	$scope.addBranch = function(){
		var brchDump = {
            "branchName": "",
            "branchCode": "",
            "branchContact": "",
            "branchAddress": "",
            "branchPinCode": "",
            "instTypeId": "",
            "createdBy":localStorage.getItem("userId")
        };
		$scope.branchArr.push(brchDump);
	}

	$scope.saveBranches = function(){
		var instTypeId = "";
		for(var i=0; i<$scope.instituteTypes.length; i++){
			if($scope.instituteTypes[i].checked == true){
				if(instTypeId == ""){
					instTypeId = ""+$scope.instituteTypes[i].instTypeId;
          console.log(instTypeId);
				}else{
					instTypeId = instTypeId+","+$scope.instituteTypes[i].instTypeId;
          console.log(instTypeId);
				}
			}
		}
		console.log(instTypeId);

		if(instTypeId == ""){
			alert("Please Select atleast on Institute");
			return true;
		}

		if($scope.branchArr.length > 0){
			for(var i=0; i<$scope.branchArr.length; i++){
				if($scope.branchArr[i].branchName != undefined && $scope.branchArr[i].branchName != "" &&  $scope.branchArr[i].branchCode != undefined && $scope.branchArr[i].branchCode != "" && $scope.branchArr[i].branchContact != undefined && $scope.phoneValidation($scope.branchArr[i].branchContact) != false && $scope.branchArr[i].branchAddress != undefined && $scope.branchArr[i].branchAddress != "" && $scope.branchArr[i].branchPinCode != undefined && $scope.branchArr[i].branchPinCode != "" ){
					$scope.branchArr[i].instTypeId = instTypeId;
				}
				else{
					//$scope.branchArr = [];
					alert("Please Fill all fields approriately");
					return true;
				}
			}
		}
		var requestParams = {
			"schemaName": localStorage.getItem("sname"),
			"instId": $scope.instituteId,
			"userId": localStorage.getItem("userId"),
			"insertRecords": $scope.branchArr
		};
		console.log(requestParams);
		httpFactory.executePost("setUpBranch", requestParams, function(data) {
			if (data.statusCode==200) {
			// addBranchPopup.hide();
			if(data.recordStatus[0].status == "failure"){
				alert(data.recordStatus[0].errorMsg);
			}else{
				//$scope.getAllBranchesForUser();
				alert("Added Successfully.");

				$("#addBranchPopup").modal("hide");
				//window.location.href = "http://localhost:9000/module/html/learnHome.html#!/home";
				$window.location.reload();


			}
			}else{
				console.log(data);
			}
		});
	}

	$scope.redirectToCurrentInstTab = function(tabName){
		$scope.latestCurrentInstTab = tabName;
		console.log($scope.latestCurrentInstTab);
	}

	$scope.subjectGroupAvail =[];
	$scope.getSubjectGroups = function(){
		httpFactory.getResult("getSubjectGroups?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				$scope.subjectGroupAvail = data.SubGroups;
			}
		});
	}
//	$scope.getSubjectGroups();
	$scope.phoneValidation = function(numb){
		 var myPhoneFormat = /[0-9]\d{0,10}/;
		 if(numb != "" && numb != undefined){
			return myPhoneFormat.test(numb);
		 }
	}

  $scope.getStudentsExamStatusByTestId=function(testId){
    console.log(testId);
    $scope.selTestId=testId;
    httpFactory.getResult("getStudentsExamStatusByTestId?schemaName="+$scope.schemaName+"&testId="+testId+"&branchId="+$scope.bnchId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				// $scope.subjectGroupAvail = data.SubGroups;
        $scope.studentTestList=data.TestStudentArray;
        $("#studentAssignList").modal("show");
			}
		});
  }


$scope.closePopUp=function(){
  $("#studentAssignList").modal("hide");

}

  // Daashboard sservices

  $scope.getBranchClassCourse = function(){
  	httpFactory.getResult("getClassCoursesByBId?instType="+$scope.instTypeStr+"&schemaName="+localStorage.getItem("sname")+"&branchId="+$scope.bnchId+"&instId="+$scope.instituteId, function(data) {
  		console.log(data);
  		if (data.StatusCode==200) {
  			// $scope.categoryList = data.TestCategories;
  			$scope.classCourseList = data.ClassCourses;
  			 console.log($scope.classCourseList);
  			if ($scope.classCourseList.length>0) {
          for (var i = 0; i < $scope.classCourseList.length; i++) {
            if($scope.classCourseList[i].isDefault==1){
              $scope.brnchCourseId = $scope.classCourseList[i].courseId;
              console.log($scope.brnchCourseId);
              console.log($scope.classCourseList);
              $scope.courseOb = JSON.stringify($scope.classCourseList[i]);

            $scope.courseObject = $scope.classCourseList[i];
              $scope.courseSelect($scope.classCourseList[i]);
              break;
            }
          }

  			}else{
            $scope.classCourseList=[];
  				alert("No Classes");
  			}
  		}
  		 else {
  		}
  	});
  }

  $scope.courseSelect=function(crs){
    console.log(crs);
    $scope.selectedCrsOb={};
    if (typeof crs == 'string') {
      $scope.selectedCrsOb = JSON.parse(crs);
    }else{
      $scope.selectedCrsOb = crs;
    }
    console.log($scope.selectedCrsOb);
  }

  $scope.getBranchInstTypes = function(brnch){
  	console.log(brnch);
  	$scope.crsListInstType=[];
  	httpFactory.getResult("getBranchInstTypes?branchId=" +$scope.bnchId+"&schemaName="+localStorage.getItem("sname"), function(data) {
  		console.log(data);
  		if (data.StatusCode==200) {
        $scope.instTypeStr="";
  			$scope.branchTypes = data.branchTypes;
        for (var i = 0; i < $scope.branchTypes.length; i++) {
            if ($scope.branchTypes.length-1 == i) {
              $scope.instTypeStr += + $scope.branchTypes[i].instTypeId + "";
            }else{
            $scope.instTypeStr += + $scope.branchTypes[i].instTypeId + ",";
          }
        }
        $scope.getBranchClassCourse();
  		}
  		 else {
  		}
  	});
  }

  $scope.getUpcomingTestForAdminDashBoard = function(){
    httpFactory.getResult("getUpcomingTestForAdminDashBoard?branchId="+$scope.bnchId+"&schemaName="+localStorage.getItem("sname")+"&roleId="+$scope.userRoleId , function(data) {
      console.log(data);
      $scope.upcomingTests=[];
      if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
        $scope.upcomingTests = data.upComingTestArray;
        console.log($scope.upcomingTests);
      }
       else {
         $scope.upcomingTests=[];
      }

    });
  }

  $scope.branchList = [];
	$scope.getBranchList = function() {
		httpFactory.getResult("getAllBranches?instId=" +localStorage.getItem("inst_id") + "&schemaName="+localStorage.getItem("sname")+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.branchList=data.collegeBranches;
        var roleId =parseInt(localStorage.getItem("RD"));
        if (roleId >1) {
          for (var i = 0; i < $scope.branchList.length; i++) {
            if ($scope.branchList[i].branchId == localStorage.getItem("bnchId")) {
              $scope.branchob = $scope.branchList[i];
              $scope.staffbranchob=$scope.branchList[i];
              console.log($scope.branchob);
            }
          }
        }else{
			var obj = {
				"branchId":"0",
				"branchName":"Default"
			}
			$scope.branchList.splice(0, 0, obj);

			console.log($scope.branchList);
			if (roleId<1 && $scope.bnchId == 0) {
			  localStorage.setItem("bnchId",0);
			}else{
			  for (var i = 0; i < $scope.branchList.length; i++) {
				if ($scope.branchList[i].branchId == localStorage.getItem("bnchId")) {
				  $scope.branchob = $scope.branchList[i];
          $scope.staffbranchob=$scope.branchList[i];
				  console.log($scope.branchob);
				}
			  }
			}
      }
				console.log($scope.allbranchList);
				console.log($scope.branchob);
			} else {
				console.log("No branches");
			}
		});
  }

  $scope.stuAtten = [
    {
      "latePercentageCount":0,
      "presentPercentage":0,
      "presentPercentageCount":0,
      "absentPercentageCount":0,
      "absentPercentage":0,
      "latePercentage":0
      }
    ];
  $scope.getStudentAttendanceReportForAdmin=function(){
    console.log($scope.allbranchList);
    $scope.currDate=currentDateMethod();
    httpFactory.getResult("getStudentAttendanceReportForAdmin?currentDate="+$scope.currDate+"&branchId="+$scope.stuAttBnchId+"&schemaName="+localStorage.getItem("sname")+"&roleId="+$scope.userRoleId, function(data) {
      console.log(data);
      if (data.StatusCode==200) {
        $scope.stuAtten = data.studentAttendanceArray[0];
        console.log($scope.stuAtten);
        $scope.labels = ["Present", "Absent", "Late"];
        setTimeout(function() { $scope.renderChartsForStudent(); }, 500);

      }
       else {
         $scope.stuAtten=
           {
             "attTkn":0,
             "latePercentageCount":0,
             "presentPercentage":0,
             "presentPercentageCount":0,
             "absentPercentageCount":0,
             "absentPercentage":0,
             "latePercentage":0
           };
         setTimeout(function() { $scope.renderChartsForStudent(); }, 500);
      }
    });
  }

  $scope.branchStuAttendance=function(attBranchId){
    console.log(attBranchId);
    $scope.attBranchOb=attBranchId;
    $scope.stuAttBnchId=attBranchId.branchId;
    console.log($scope.stuAttBnchId);
    $scope.getStudentAttendanceReportForAdmin();
  }



  $scope.branchStaffAttendance=function(attBranchId){
    console.log(attBranchId);
    $scope.staffAttBnchId=attBranchId.branchId;
    console.log($scope.staffAttBnchId);
    $scope.getStaffAttendanceReportForAdmin();
  }

  function currentDateMethod(){
    var date = new Date();
        var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate();
        console.log(ndate);
        return ndate;
  }

  $scope.getStaffAttendanceReportForAdmin=function(){
    $scope.currDate=currentDateMethod();
    httpFactory.getResult("getStaffAttendanceReportForAdmin?currentDate="+$scope.currDate+"&branchId="+$scope.staffAttBnchId+"&schemaName="+localStorage.getItem("sname")+"&roleId="+$scope.userRoleId, function(data) {
      console.log(data);
      if (data.StatusCode==200) {
        $scope.staffAtten = data.staffAttendanceArray[0];
        $scope.getStaffAttendenceChartData=[10,20,30];
        $scope.labels = ["Present", "Absent", "Late"];
        console.log($scope.staffAtten);
        setTimeout(function(){$scope.renderChartsForStaff();}, 500);
      }
       else {
         $scope.staffAtten=
           {
             "attTkn":0,
             "lateCount":0,
             "presentPercentage":0,
             "presentCount":0,
             "absentCount":0,
             "absentPercentage":0,
             "latePercentage":0
           };

         setTimeout(function(){$scope.renderChartsForStaff();}, 500);
      }
    });

  }
  $scope.getAllLeaveRequestsByBranch=function(){
    $scope.currDate=currentDateMethod();
    httpFactory.getResult("getAllLeaveRequestsByBranch?currentDate="+$scope.currDate+"&branchId="+$scope.bnchId+"&schemaName="+localStorage.getItem("sname")+"&roleId="+$scope.userRoleId, function(data) {
      console.log(data);
      if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
        $scope.leaveReq = data;
        console.log($scope.leaveReq);
      }
       else {
         $scope.leaveReq=[];
      }
    });
  }

$scope.upcomingExamClick=function(){
  $location.path("exams");
}

	$scope.calendarInitMethod=function(){
		var ndate = new Date();
		$scope.monthId=ndate.getMonth()+1;
		$scope.yearId=ndate.getFullYear();
		$scope.getEventsAndHolidaysMonth();
		$scope.generateDateOfobj();
	}
	$scope.getEventsAndHolidaysMonth=function(){
		var params = {
				"monthId":$scope.monthId,
				"schemaName":$scope.schemaName,
				"yearId":$scope.yearId,
				"branchId":$scope.bnchId,
				"roleId":$scope.userRoleId
			};
		console.log(params);
		httpFactory.executePost("getEventsAndHolidaysMonth", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				console.log(data);
				$scope.EventsHolidays = data.EventsAndHolidays;
				console.log($scope.EventsHolidays);
				$scope.thisMonthGeneration();
			}
			});
	}
	$scope.weekday = new Array(7);

	$scope.weekday[0] = "Mon";
	$scope.weekday[1] = "Tue";
	$scope.weekday[2] = "Wed";
	$scope.weekday[3] = "Thu";
	$scope.weekday[4] = "Fri";
	$scope.weekday[5] = "Sat";
	$scope.weekday[6] = "Sun";

	$scope.weekDisplayDays = new Array(7);
	$scope.weekDisplayDays[0] = "Sun";
	$scope.weekDisplayDays[1] = "Mon";
	$scope.weekDisplayDays[2] = "Tue";
	$scope.weekDisplayDays[3] = "Wed";
	$scope.weekDisplayDays[4] = "Thu";
	$scope.weekDisplayDays[5] = "Fri";
	$scope.weekDisplayDays[6] = "Sat";


	$scope.cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.getViewMonth = "";
	$scope.getViewYear = "";
	$scope.getViewMonthNumber = 0;
	$scope.newDate = "";

	$scope.monthView = [];
	$scope.monthDaysList = [];
	$scope.monthDaysListView = [];


	$scope.generateDateOfobj = function(){
		var nDate = new Date();
		$scope.newDate = nDate;
		$scope.monthId=nDate.getMonth()+1;
		$scope.yearId=nDate.getFullYear();
		$scope.getViewMonth = $scope.cal_months_labels[nDate.getMonth()];
		$scope.getViewMonthNumber = parseInt(nDate.getMonth())+1;
		$scope.getViewYear = parseInt(nDate.getFullYear());
//    $scope.getEventsAndHolidaysMonth();
//		$scope.thisMonthGeneration();
	}

	$scope.thisMonthGeneration =  function(){
		var date = new Date($scope.newDate);
		var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();

		console.log(lastDay);

			var startDay = $scope.weekday[new Date(date.getFullYear(),date.getMonth(), 0).getDay()]
			var firstWeekStart = false;
			var weekIndex = 0;
			var dayStartedIndex = 0;
			var dateIndx = 1;
			$scope.monthDaysList = [];
			do{
				$scope.monthDaysList[weekIndex] = [];
				for(var j=0;j<$scope.weekDisplayDays.length;j++){
					wdayObj = {};
					if(firstWeekStart == false){
						if(startDay != $scope.weekDisplayDays[j] && dayStartedIndex == 0 ){
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],

							};
							console.log("entered");
						}
						else{
							wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
					}
					else{
						if(dayStartedIndex < lastDay+1){
							wdayObj = wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
						else{
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],
							};
							if($scope.weekDisplayDays.length-1 == j){
								dayStartedIndex++;
							}
						}

					}
					$scope.monthDaysList[weekIndex].push(wdayObj);
				}
				firstWeekStart = true;
				weekIndex++;

			}
			while(dayStartedIndex <= lastDay)
		console.log($scope.monthDaysList);
		console.log(JSON.stringify($scope.monthDaysList));
		$scope.generateEventsWithMonth();
	}

	$scope.selectedDayEvents = [];
	$scope.selectedDayforEvent = 0;
	$scope.generateEventsWithMonth = function(){
		var date = new Date();
		$scope.todayDate=date.getDate();
		$scope.selectedDayforEvent = date.getDate();
		console.log($scope.EventsHolidays);


  for(var k=0;k<$scope.EventsHolidays.length;k++){

    for(var j=0;j<$scope.EventsHolidays[k].eventDetails.length; j++){

      if($scope.EventsHolidays[k].eventDetails[j].from == $scope.EventsHolidays[k].eventDetails[j].to){
        var ndate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
        var ndateEve = ndate.getDate();
        for(var i=0; i<$scope.monthDaysList.length; i++){
          for(var l=0; l<$scope.monthDaysList[i].length; l++){
            var ndateEveSel =$scope.monthDaysList[i][l].date;
            if(ndateEveSel == ndateEve){

              if($scope.monthDaysList[i][l].eventList == undefined){
                $scope.monthDaysList[i][l].eventList = [];
              }
              if($scope.monthDaysList[i][l].eventList.length == 0){
                var doopEventDet ={
                  "eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
                  "eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
                  "eventDetails":[]
                };
                doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                $scope.monthDaysList[i][l].eventList.push(doopEventDet);
              }else{
                var founIndx = 0;
                for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
                  if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
                    founIndx++;
                    $scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                  }
                }
                if(founIndx == 0){
                  var doopEventDet ={
                    "eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
                    "eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
                    "eventDetails":[]
                  };
                  doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                  $scope.monthDaysList[i][l].eventList.push(doopEventDet);
                }
              }
            }
          }
        }
      }else{
        var nFromDate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
        var nToDate = new Date($scope.EventsHolidays[k].eventDetails[j].to);
        var date = new Date($scope.newDate);
        var nstartDate = 0;
        var nendDate = 0;
        if(date.getMonth() == nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
          nstartDate = nFromDate.getDate();
          nendDate = nToDate.getDate();
        }else if(date.getMonth() == nFromDate.getMonth() && date.getMonth() != nToDate.getMonth()){
          var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();
          nstartDate = nFromDate.getDate();
          nendDate = lastDay;
        }else if(date.getMonth() != nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
          nstartDate = 1;
          nendDate = nToDate.getDate();
        }

        for(var i=0; i<$scope.monthDaysList.length; i++){
          for(var l=0; l<$scope.monthDaysList[i].length; l++){
            var ndateEveSel =$scope.monthDaysList[i][l].date;
            if(ndateEveSel >= nstartDate && ndateEveSel <= nendDate){
              if($scope.monthDaysList[i][l].eventList == undefined){
                $scope.monthDaysList[i][l].eventList = [];
              }
                if($scope.monthDaysList[i][l].eventList.length == 0){
                  var doopEventDet ={
                    "eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
                    "eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
                    "eventDetails":[]
                  };
                  doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                  $scope.monthDaysList[i][l].eventList.push(doopEventDet);
                }else{
                  var founIndx =0;
                  for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
                    if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
                      founIndx++;
                      $scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                    }
                  }
                  if(founIndx == 0){
                    var doopEventDet ={
                      "eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
                      "eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
                      "eventDetails":[]
                    };
                    doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
                    $scope.monthDaysList[i][l].eventList.push(doopEventDet);
                  }
                }
            }
          }
        }
      }
    }
  }

  console.log($scope.monthDaysList);

    if ($scope.EventsHolidays) {
      for(var k=0;k<$scope.EventsHolidays.length;k++){
        var ndate = new Date($scope.EventsHolidays[k].eventDate);
        for( var i=0; i<$scope.monthDaysList.length; i++){
          for(var j=0; j <$scope.monthDaysList[i].length; j++){

              if($scope.todayDate == $scope.monthDaysList[i][j].date){
                $scope.getEventsOfDay($scope.monthDaysList[i][j]);
              }

          }
        }
      }
    }
		console.log($scope.monthDaysList);
	}

	$scope.getEventsOfDay = function(wdob){
		$scope.selectedDayEvents = [];
		$scope.selectedDayforEvent = wdob.date;
		if(wdob.eventList == undefined){
			$scope.selectedDayEvents = [];
		}
		else{
			for(var i=0; i<wdob.eventList.length; i++){
				for(var j =0; j<wdob.eventList[i].eventDetails.length;j++){
					$scope.selectedDayEvents.push(wdob.eventList[i].eventDetails[j]);
				}
			}

		}
	}

  $scope.deleteTest=function(test,arrIndex){
		  httpFactory.getResult("deleteTest?testId=" + test.testId + "&schemaName="+$scope.schemaName, function(data) {
		      console.log(data);
		      if (data.StatusCode == 200) {
		        alert("Success",arrIndex);
		          $scope.newtestData.splice(arrIndex,1);
		          for(var i=0; i<$scope.selectExamDetauls.length; i++){
		            if($scope.selectExamDetauls[i].yearId == $scope.testsYearForCalender){
		              for(var j=0; j<$scope.selectExamDetauls[i].Months.length; j++){
		                if($scope.selectExamDetauls[i].Months[j].monthId == $scope.testsMonthForCalender){
		                  for(var k=0; k<$scope.selectExamDetauls[i].Months[j].Weeks.length; k++){
		                    if($scope.selectExamDetauls[i].Months[j].Weeks[k].weekOfMonth == $scope.testsWeekendForCalender){
		                      $scope.selectExamDetauls[i].Months[j].Weeks[k].noOfTest--;
		                    }
		                  }
		                }
		              }
		            }
		          }
		      } else {
		        console.log("error occured");
		      }
		    });
  }

  $scope.staffLeaveRequestModal=function(){
	  $scope.viewAllStaffLeaveRequest();
  }
  $scope.closeLRpopUp=function(){
	  $("staffLeaveRequest").modal("hide");

  }
  $scope.viewAllStaffLeaveRequest=function(){

	  httpFactory.getResult("getTotalLeaveRequestsForStaffByBranch?branchId=" + $scope.bnchId + "&schemaName="+$scope.schemaName, function(data) {
	      console.log(data);
	      if (data.StatusCode == 200) {
	    	  $scope.staffLeaveRequests = data.staffLeaveReqArray;

	    	  for(var i=0;i<$scope.staffLeaveRequests.length;i++){
	    		  var from=CompareDate($scope.staffLeaveRequests[i].leaveFrom);
	    		  var to=CompareDate($scope.staffLeaveRequests[i].leaveTo);
	    		 $scope.staffLeaveRequests[i]["leaveFromStatus"]=from;
	    		 $scope.staffLeaveRequests[i]["leaveToStatus"]=to;
	    	  }

	    	  $("#staffLeaveRequest").modal("show");

	      } else {
	        console.log("error occured");
	        alert("No Leave Requests");
	      }
	    });

  }

  $scope.viewAllStudentLeaveRequests = function(){

	  httpFactory.getResult("getTotalLeaveRequestsForStudentByBranch?branchId=" + $scope.bnchId + "&schemaName="+$scope.schemaName, function(data) {
	      console.log(data);
	      $scope.studentLeaveRequest=[];
	      if (data.StatusCode == 200) {
	    	  $scope.studentLeaveRequests = data.studentLeaveReqArray;
	    	  console.log($scope.studentLeaveRequests);
	    	  for(var i=0;i<$scope.studentLeaveRequests.length;i++){
	    		  var from=CompareDate($scope.studentLeaveRequests[i].leaveFrom);
	    		  var to=CompareDate($scope.studentLeaveRequests[i].leaveTo);
	    		 $scope.studentLeaveRequests[i]["leaveFromStatus"]=from;
	    		 $scope.studentLeaveRequests[i]["leaveToStatus"]=to;
	    	  }

	    	  $("#studentLeaveRequest").modal("show");

	      } else {
	        console.log("error occured");
	        alert("No Leave Requests");
	      }
	    });
  }

  $scope.updateStudentLeaveRequest = function(slrId, isApprovedstat, adminComment,reqIndex){

		var teachComments = "";
		if(teachComments == undefined){
			teachComments = "";
		}
		var params = {
			"schemaName" :$scope.schemaName,
			"updatedBy":$scope.userId,
			"updateLeaveReq":
			[
				{
					"studentLeaveReqId":slrId,
					"isApproved":isApprovedstat,
					"updatedBy":$scope.userId,
					"teacherComments":teachComments
				}
			]
		};
		console.log(params);
		httpFactory.executePost("updateStudentLeaveRequest", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				if(isApprovedstat==1){
					$scope.studentLeaveRequests[reqIndex].LeaveRequestStatus = "ALR";
				}else if(isApprovedstat==0){
					$scope.studentLeaveRequests[reqIndex].LeaveRequestStatus = "RLR";
				}
				alert("sucesfully changed");
			}
			else{

				alert("Please try agian after some time");
			}
		});

	}



  function CompareDate(dateOb) {
      var todayDate = new Date(); //Today Date
      var dateOne = new Date(dateOb);
      var boolval=false;
tdDate = todayDate.getDate();
doDate = dateOne.getDate();
      if (tdDate <= doDate) {
//           alert("Today Date is greater than Date One.");
          boolVal=true;

       }else {
//           alert("Today Date is greater than Date One.");
          boolVal=false;

       }
      return boolVal;
   }

  $scope.dateToTime=function(dateOb){
	  var dateVal = new Date(dateOb).getTime();
	  return dateVal;
  }


 $scope.absentStudentsModal=function(){
	 $scope.getAllAbsentStudents("absent");
 }

 $scope.lateStudentsModal=function(){
	 $scope.getAllAbsentStudents("late");
 }
 $scope.modelBackMethod=function(){

	$("#absentStudentsModal").modal("hide");
	$("#lateStudentsModal").modal("hide");
	$("#absentStaffModal").modal("hide");
	$("#lateStaffModal").modal("hide");
}

  $scope.getAllAbsentStudents=function(tag){

	  if($scope.attBranchOb)
		  $scope.attBnchId=$scope.attBranchOb.branchId;
	  else
		  $scope.attBnchId=$scope.bnchId

	  httpFactory.getResult("viewAllTodayAbsentStudents?schemaName="+$scope.schemaName+"&branchId="+$scope.attBnchId, function(data) {
	      console.log(data);
	      $scope.absentStudents=[];
	      if (data.StatusCode == 200) {
	    	  $scope.absentStudents = data.data;
	    	  $scope.attStatus=tag;

	    	  console.log($scope.attStatus);

	    	  if(tag=='absent')
	    		 $("#absentStudentsModal").modal("show");
	    	  else if(tag=='late')
	    		$("#lateStudentsModal").modal("show");

	      } else {
	        console.log("error occured");
	        alert("No Absent Students");
	      }
	    });
  }

  $scope.absentStaffModal=function(){
		 $scope.getAllAbsentStaff("absent");
	 }

	 $scope.lateStaffModal=function(){
		 $scope.getAllAbsentStaff("late");
	 }

  $scope.getAllAbsentStaff=function(tag){

	  if($scope.attBranchOb)
		  $scope.attBnchId=$scope.attBranchOb.branchId;
	  else
		  $scope.attBnchId=$scope.bnchId

	  httpFactory.getResult("viewAllTodayAbsentStaff?schemaName="+$scope.schemaName+"&branchId="+$scope.attBnchId, function(data) {
	      console.log(data);
	      $scope.absentStudents=[];
	      if (data.StatusCode == 200) {
	    	  $scope.absentStaff = data.data;
	    	  $scope.staffAttStatus=tag;

	    	  if(tag=='absent')
	    		 $("#absentStaffModal").modal("show");
	    	  else if(tag=='late')
	    		$("#lateStaffModal").modal("show");

	      } else {
	        console.log("error occured");
	        alert("No Absent Students");
	      }
	    });
  }

	$scope.updateStaffLeaveRequestIndiv = function(slrId, isApprovedstat, adminComment,reqIndex){

		var teachComments = "";
		if(adminComment == undefined){
			teachComments = "";
		}
		else{
			teachComments = adminComment;
		}
		var params = {
			"schemaName" :$scope.schemaName,
			"updatedBy":$scope.userId,
			"updateLeaveReq":
			[
				{
					"staffLeaveReqId":slrId,
					"isApproved":isApprovedstat,
					"updatedBy":$scope.userId,
					"comments":teachComments
				}
			]
		};
		console.log(params);
		httpFactory.executePost("updateStaffLeaveRequest", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				if(isApprovedstat==1){
					$scope.staffLeaveRequests[reqIndex].LeaveRequestStatus = "ALR";
				}else if(isApprovedstat==0){
					$scope.staffLeaveRequests[reqIndex].LeaveRequestStatus = "RLR";
				}
				alert("sucesfully changed");
			}
			else{

				alert("Please try agian after some time");
			}
		});
	}

$scope.renderChartsForStaff = function(){
  var stfpresentPercentage = Number($scope.staffAtten.presentPercentage).toFixed(2) ;
  $scope.staffAtten.presentPercentage = stfpresentPercentage;
  var stfabsentPercentage = Number($scope.staffAtten.absentPercentage).toFixed(2);
  $scope.staffAtten.absentPercentage = stfabsentPercentage;
  var stflatePercentage = Number($scope.staffAtten.latePercentage).toFixed(2);
  $scope.staffAtten.latePercentage = stflatePercentage;

  console.log(stfpresentPercentage);
  console.log(stfabsentPercentage);
  console.log(stflatePercentage);

//  if(isNaN(stfpresentPercentage) && isNaN(stfabsentPercentage) && isNaN(stfpresentPercentage)){
//
//	  $scope.staffAttendanceFlag="false";
//  }else{
	var chart = new CanvasJS.Chart("staffAttendanceContainer", {
		theme: "",
		animationEnabled: true,
		legend:{
			cursor: "pointer",
			itemclick: explodePie
		},
		data: [{
			type: "doughnut",
      innerRadius:30,
			dataPoints: [
				{ y: stfpresentPercentage , name: "Present", color:'#6FDAA0' },
				{ y: stfabsentPercentage , name: "Absent", color:'#E76959' },
			]
		}]
	});
	chart.render();
//  }
}


$scope.sendSms = function(tag){
    var params = {
      "schemaName":$scope.schemaName,
      "branchId":$scope.attBnchId,
      "attStatus":$scope.attStatus
    }
    if (tag=="sms") {
      params["SMSNotification"]=1;
    }else if(tag=="push"){
      params["pushNotification"]=1;
    }else if(tag=="both"){
      params["SMSNotification"]=1;
      params["pushNotification"]=1;
    }
    console.log(params);
    httpFactory.executePost("sendStudentAttendanceNotification", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
        alert("Sent Successfully");
				}
			else{
				alert("Please try agian after some time");
			}
		});
  }


$scope.renderChartsForStudent = function(){
  var stupresentPercentage = Number($scope.stuAtten.presentPercentage).toFixed(2);
  $scope.stuAtten.presentPercentage = stupresentPercentage;
  var stuabsentPercentage = Number($scope.stuAtten.absentPercentage).toFixed(2);
  $scope.stuAtten.absentPercentage = stuabsentPercentage;
  var stulatePercentage = Number($scope.stuAtten.latePercentage).toFixed(2);
  $scope.stuAtten.latePercentage = stulatePercentage;

//  if(isNaN(stfpresentPercentage) && isNaN(stfabsentPercentage) && isNaN(stfpresentPercentage)){
//
//	  $scope.studentAttendanceFlag="false";
//  }else{

	var chart2 = new CanvasJS.Chart("studentAttendanceContainer", {
		theme: "",
		animationEnabled: true,
		legend:{
			cursor: "pointer",
			itemclick: explodePie
		},
		data: [{
			type: "doughnut",
      innerRadius:30,
			dataPoints: [
				{ y: stupresentPercentage , name: "Present", color:'#6FDAA0' },
				{ y: stuabsentPercentage , name: "Absent", color:'#E76959' },
			]
		}]
	})
	chart2.render();
//  }
}
function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}

$scope.branchStatus = function(){
    httpFactory.getResult("getBranchStatus?schemaName="+$scope.schemaName+"&branchId="+$scope.bnchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				if(data.isActive == 0){
                  alert("Your Branch is inActive");
                  $scope.logoutAdmin();
				 }
				}
			else{
				alert("Please try agian after some time");
			}
		});
  }

$scope.getAdminMeetingDetailsForHome = function(){
	//console.log(section);
	//console.log(month);
	$scope.meetingList=[];
	$scope.meetingActiveList = [];
	var	year;
	var j = 0;
	var now = new Date;
	var date=new Date();
	year = date.getFullYear();
	month = date.getMonth()+1;

	httpFactory.getResult("getAdminMeetingDetailsForHome?branchId="+localStorage.getItem("bnchId")+"&schemaName="+localStorage.getItem("sname")+"&monthId="+month+"&yearId="+year+"&newFlag=1", function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
			$scope.meetingList = data.meetingdetails;
			console.log(data);
			for(var i = 0; i < data.meetingdetails.length  ; i++){
				var startTime = new Date($scope.meetingList[i].startTime);
				if($scope.meetingList[i].meetType == 'General'){
					  var endTime = new Date($scope.meetingList[i].endTime);
				  }
				  if($scope.meetingList[i].meetType == 'ZOOM'){
					  var endTime = new Date($scope.meetingList[i].startTime);
					  endTime.setMinutes(endTime.getMinutes() + $scope.meetingList[i].duration);
				  }
					if(now.getTime() < endTime.getTime()){
						$scope.meetingActiveList[j] = $scope.meetingList[i];
						//$scope.meetingActiveList[j]["meetStatus"] = 'ACTIVE';
						j++;
					}
			}
			$scope.meetActiveCount = $scope.meetingActiveList.length;
		}
		else{
			$scope.meetingList=[];
		}
	});
	//$scope.selectStudentsBySection();
	
}


$scope.goToMeeting = function(meetObj){
	if(meetObj.meetType == 'General'){
			var endTime = new Date(meetObj.endTime);
			var link = meetObj.meetLink;
		}
		if(meetObj.meetType == 'ZOOM'){
			var endTime = new Date(meetObj.startTime);
			endTime.setMinutes(endTime.getMinutes() + meetObj.duration);
			var link = meetObj.startUrl;
		}
		var startTime = new Date(meetObj.startTime);
		var now = new Date;
		if(startTime.getTime() < now.getTime()){
			if(now.getTime() < endTime.getTime()){
				window.location.href = link;
			}
			else{
				alert("Meeting has ended");
			}
		}else{
			alert("Meeting not yet started");
		}
}
$scope.getStudentsByBranchId = function(){
	
	$scope.sectionStudentsForBranch = [];
	httpFactory.getResult("selectStudentsByBranchId?schemaName=" + $scope.schemaName + "&branchId=" +  $scope.bnchId + "&studentsName=" + $scope.studentsName, function(data) {
	console.log(data);
	if (data.StatusCode == 200) {
		$scope.sectionStudentsForBranch = data.sectionStudentsForBranch;
		
	}

  });
}

$scope.goToProfile = function(student) {
	console.log(student);

	$scope.studentId = student.studentId;
	sessionStorage.setItem("navCourseId",
			$scope.selectedCourse);
	sessionStorage.setItem("navClassId",
			$scope.selectedClassId);
	$location.path("studentDetails/" + student.studentId);
	$scope.studentsName = "";

}


});

