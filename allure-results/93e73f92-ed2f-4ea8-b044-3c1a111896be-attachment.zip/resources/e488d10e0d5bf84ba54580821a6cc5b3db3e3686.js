	projectModule.controller('rankrPlusController', function($scope, $location, commonFactory, httpFactory, $routeParams,$route) {

	$scope.$ = $;
	$scope.instTestTypeId=$routeParams.testType;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.schemaName=localStorage.getItem("sname");
	$scope.branchId=localStorage.getItem("bnchId");
	$scope.instTestTypeName=$routeParams.testName;
	$scope.userId=localStorage.getItem("userId");

	$scope.classIdRoute=$routeParams.classId;
	$scope.courseIdRoute = $routeParams.courseId;

	$scope.navCourseId=sessionStorage.getItem("navCourseId");
	$scope.navClassId=sessionStorage.getItem("navClassId");
	$scope.myClasses=sessionStorage.getItem("myClasses");
	$scope.navSectionId=sessionStorage.getItem("navSectionId");

	sessionStorage.removeItem("navCourseId");
	sessionStorage.removeItem("navClassId");
	sessionStorage.removeItem("navSectionId");
	sessionStorage.removeItem("myClasses");
	
	$scope.gotoLoc = function(loc) {
        $location.path(loc);
    }

	$scope.goToAttendance = function(){
	$location.path("attendance");
	}
    $scope.goToGallery = function(){
	$location.path("gallery");
	
	}
	  $scope.goToFeeManage = function(){
	$location.path("feemanagement");
	}

	 $scope.goToTransport = function(){
	$location.path("transport");
	}

	$scope.goTotransportRoute = function(){
	$location.path("transportRoute");
	}
	$scope.goToBalance = function(){
    	$location.path("balanceRequests");
    }

	$scope.goToStaffAttendance = function(){
	$location.path("staffAttendance");
	}
	$scope.goToRegisterView = function(sectionId){
	$location.path("registerView/"+sectionId);
	}
	$scope.goToTimeTable = function(){
	$location.path("timeTable");
	// $location.path("timeTable/"+$scope.);
	}
	$scope.goLive = function(){
		$location.path("liveclass");
	}
	$scope.goToHomework = function(){
	$location.path("assignment");
	// $location.path("timeTable/"+$scope.);
	}
	$scope.goToMembers = function(){
	$location.path("members");
	}
	$scope.goToReportCard=function(){
	$location.path("reportAnalysis");
	}
    
	$scope.goToMyClasses=function(){
		$location.path("rankrClasses");
	}
//	$scope.goToMessages = function(){
//		$location.path("messages/yes");
//		
//	}
	$scope.goToMessaging=function(){
		$location.path("messaging");
	}
	$scope.navigateToReportCards=function(){
//		alert('new reports');
		$location.path("classReports");
	}
	
	$scope.goToCirculars=function(){
		$location.path("circulars");
	}
	$scope.gotoLiveDashboard=function(){
		$location.path("liveDashboard");
	}
	$scope.goBranchLive = function(){
		$("#addHomeWork").modal("show");
	}
	$scope.closePopUpLive=function(){
		$("#addHomeWork").modal("hide");
	}
	$scope.addStudentButton = function(){
		$scope.getBranchCourseClassSectionsForTest();
	    $("#addStudents").modal("show");
	}
	$scope.closeAddStudentsPopUp = function(){
		 $("#addStudents").modal("hide");
	}
	 $scope.assignArr=[];
	 $scope.brnchSectionsSelDump = [];
	$scope.getBranchCourseClassSectionsForTest = function(){
		  httpFactory.getResult("getAllBranchClassCourseSectionsForLiveClass?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id")+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
		   console.log(data);
		   if (data.StatusCode==200) {
		      $scope.brnchSections=data.testSectionsObj;
		      console.log($scope.brnchSections);
		      }
		    else {
		   }
		 });
		}
	$scope.selectedSections=function(branchId,branchName,courseId,courseName,classId,className,sectionId,sectionName){
		debugger;
		$scope.found=0;
		var obj={
			"classId":classId,
			"courseId":courseId,
			"branchId":branchId,
			"sectionId":sectionId,
			"branchName":branchName,
			"courseName":courseName,
			"className":className,
			"sectionName":sectionName,
			"createdBy":localStorage.getItem("userId")
		}

		if ($scope.assignArr.length==0) {
		  $scope.found=2;
		  $scope.assignArr.push(obj);
		  $scope.updateBrnchSections(obj,true);
		}else{
		  for(i=0;i<$scope.assignArr.length;i++){
			if($scope.assignArr[i].branchId == branchId && $scope.assignArr[i].courseId == courseId && $scope.assignArr[i].classId == classId && $scope.assignArr[i].sectionId == sectionId){
			  $scope.found=1;
			  $scope.assignArr.splice(i,1);
				$scope.updateBrnchSections(obj,false);
			  break;
			}
		  }
		}
		if ($scope.found==0) {
			$scope.assignArr.push(obj);
			$scope.updateBrnchSections(obj,true);
		}
		console.log($scope.assignArr);
		$scope.updateSelectedSecTreeView(obj);
		$scope.selectedClasses();
	}
	
	$scope.selectedClasses = function(){
		$scope.selectedClass = "";
		for(i=0;i<$scope.assignArr.length;i++){
			$scope.selectedClass = $scope.selectedClass + "," + $scope.assignArr[i].classId ;
		}
		$scope.selectedClass = $scope.selectedClass.slice(1);
		$scope.getSubjectsForLiveClasses();
	}
	
	$scope.getSubjectsForLiveClasses=function(){
		debugger;
		httpFactory.getResult("getSubjectsForLiveClasses?classId="+$scope.selectedClass+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.branchSubjectList = data.branchSubjectList;
		}
		});
		}
	
	
	$scope.selectedSubject=function(subj){
		debugger;
		console.log(subj);
		if (typeof subj=='string')
		$scope.selSubj = JSON.parse(subj);
		else
		$scope.selSubj=subj;
		$scope.selectedSubjId=$scope.selSubj.subjectId;
		$scope.selectedSubjectName = $scope.selSubj.subjectName;
	}
	
	$scope.updateBrnchSections = function(obj, boolValue){
		for(var i=0; i<$scope.brnchSections.length; i++ ){
			if($scope.brnchSections[i].branchId == obj.branchId){
				for(var j=0; j<$scope.brnchSections[i].courses.length; j++){
					if($scope.brnchSections[i].courses[j].courseId == obj.courseId){
						for(var k=0; k<$scope.brnchSections[i].courses[j].classes.length; k++){
							if($scope.brnchSections[i].courses[j].classes[k].classId == obj.classId){
								for(var l=0; l<$scope.brnchSections[i].courses[j].classes[k].sections.length; l++){
									if(	$scope.brnchSections[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
										$scope.brnchSections[i].courses[j].classes[k].sections[l].isSelected = boolValue;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	$scope.updateSelectedSecTreeView = function(obj){
		debugger;
		  console.log(obj);
		  console.log($scope.brnchSectionsSelDump);
			if($scope.brnchSectionsSelDump.length == 0){
				var brchObj =
				{
					'branchId':obj.branchId,
					'branchName':obj.branchName,
					'courses':[
						{
						'courseId': obj.courseId,
						'courseName': obj.courseName,
						'classes':[
							{
								'classId': obj.classId,
								'className':obj.className,
								'sections':[
									{
										'sectionId': obj.sectionId,
										'sectionName':obj.sectionName
									}
								]
							}
						]

						}
					]
				};
				$scope.brnchSectionsSelDump.push(brchObj);
			}
			else
			{
				var sectionfound=0;
				var branchFound =  0;
				var courseFound = 0;
				var classFound = 0
				for(var i=0; i<$scope.brnchSectionsSelDump.length; i++ ){
					if($scope.brnchSectionsSelDump[i].branchId == obj.branchId){
						branchFound =1;
						for(var j=0; j<$scope.brnchSectionsSelDump[i].courses.length; j++){
							if($scope.brnchSectionsSelDump[i].courses[j].courseId == obj.courseId){
								courseFound =1;
								for(var k=0; k<$scope.brnchSectionsSelDump[i].courses[j].classes.length; k++){
									if($scope.brnchSectionsSelDump[i].courses[j].classes[k].classId == obj.classId){
										classFound =1;
										for(var l=0; l<$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length; l++){
											if(	$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
												sectionfound = 1;
												$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.splice(l,1);

											}
										}
										if(sectionfound == 1){
											if($scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length==0){
												$scope.brnchSectionsSelDump[i].courses[j].classes.splice(k,1);
											}
										}
										else if(sectionfound == 0){
											var secObj = {
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName
											};
											$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.push(secObj);
										}
									}
								}
								if(classFound == 0){
									var clsObj = {
										'classId': obj.classId,
										'className':obj.className,
										'sections':[
											{
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName
											}
										]
									};
									$scope.brnchSectionsSelDump[i].courses[j].classes.push(clsObj);
								}
								else if(classFound ==1){
									if($scope.brnchSectionsSelDump[i].courses[j].classes.length == 0){
										$scope.brnchSectionsSelDump[i].courses.splice(j,1);
									}
								}

							}
						}
						if(courseFound == 0){
							var cursObj = {
								'courseId': obj.courseId,
								'courseName': obj.courseName,
								'classes':[
									{
										'classId': obj.classId,
										'className':obj.className,
										'sections':[
											{
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName
											}
										]
									}
								]

							}
							$scope.brnchSectionsSelDump[i].courses.push(cursObj);
						}else if(courseFound == 1){
							if($scope.brnchSectionsSelDump[i].courses.length == 0){
								$scope.brnchSectionsSelDump.splice(i,1);
							}
						}
					}
				}
				if(branchFound == 0){
						var brObj = {
						'branchId':obj.branchId,
						'branchName':obj.branchName,
						'courses':[
							{
							'courseId': obj.courseId,
							'courseName': obj.courseName,
							'classes':[
								{
									'classId': obj.classId,
									'className':obj.className,
									'sections':[
										{
											'sectionId': obj.sectionId,
											'sectionName':obj.sectionName
										}
									]
								}
							]

							}
						]
					};
					$scope.brnchSectionsSelDump.push(brObj);
				}
			}
		  console.log($scope.brnchSectionsSelDump);
		}
	$scope.addMeeting = function(meetObj){
		k = 0;
		var now = new Date();
		if($scope.selectedSubjId == undefined || $scope.selectedSubjId == "" )
			k = 1;
		if(meetObj.meetName == undefined || meetObj.meetName == "")
			k = 1;
		if(meetObj.meetLink == undefined || meetObj.meetLink == "")
			k = 1;
		if(meetObj.meetNumber == undefined || meetObj.meetNumber =="")
			k = 1;
		if(meetObj.meetPassword == undefined || meetObj.meetPassword =="")
			k = 1;
		if(meetObj.startTime == undefined || meetObj.startTime== ""){
			k = 1;
		}else{
			stmonth = meetObj.startTime.getMonth()+1;
			var starttime = meetObj.startTime.getFullYear() +"-"+ stmonth +"-"+ meetObj.startTime.getDate() + " "+ meetObj.startTime.getHours() +":"+ meetObj.startTime.getMinutes();
		}
			
		if(meetObj.endTime == undefined){
			k = 1;
		}else{
			etmonth = meetObj.endTime.getMonth()+1;
			var endtime = meetObj.endTime.getFullYear() +"-"+ etmonth +"-"+ meetObj.endTime.getDate() + " "+ meetObj.endTime.getHours() +":"+ meetObj.endTime.getMinutes();
		}
		if($scope.assignArr == undefined || $scope.assignArr == ""){
			k = 1
		}

		var requestParams = {
				"schemaName":localStorage.getItem("sname"),
				"subjectId": $scope.selectedSubjId,
				"meetingType": "ZOOM",
				"meetingName": meetObj.meetName,
				"meetingLink": meetObj.meetLink,
				"meetingNumber": meetObj.meetNumber,
				"meetingPassword": meetObj.meetPassword,
				"createdBy": localStorage.getItem("userId"),
				"startTime": starttime,
				"endTime": endtime,
				"secList": $scope.assignArr
		}
		console.log(requestParams);
		if(meetObj.startTime.getTime() < meetObj.endTime.getTime() && meetObj.endTime.getTime() > now.getTime() && k == 0){
			httpFactory.executePost("addMeeting", requestParams, function(data) {
				console.log(data);
				if (data.STATUS == 'SUCCESS') {
					alert("Added Sucessfully");
					$("#addHomeWork").modal("hide");
				}
				else{
					alert("Something went wrong");
				}
	     
			});
		}else{
			alert("Please enter valid data");
		}
		
	}
	
$scope.goBackToMyClasses=function(){
	$scope.clsOb = JSON.parse($scope.selectedClsOb);

	sessionStorage.setItem("navCourseId",$scope.selectedCourse);
	sessionStorage.setItem("navClassId",$scope.clsOb.classId);
	$location.path("rankrClasses");

}
	$scope.goToSectionReport=function(){
		if (typeof $scope.selectedClsOb) {
				$scope.selClassOb= JSON.parse($scope.selectedClsOb);
		}else{
			$scope.selClassOb=$scope.selectedClsOb;
		}
		console.log($scope.selectedClsOb);
		$location.path("sectionReport/"+$scope.selectedCourse+"/"+$scope.selClassOb.classId);
	}
	$scope.goToAddReportCard=function(testType){
		console.log(testType);
	$location.path("addReport/"+testType.instTestTypeId+"/"+testType.testType+"/"+$routeParams.courseId+"/"+$routeParams.classId);
	}

	$scope.addReportToStudent=function(student){
		console.log(student);
		$location.path("addStuRprt/"+$routeParams.classId+"/"+$routeParams.courseId+"/"+sessionStorage.getItem("rpSectionId")+"/"+student.studentId);
	}

	$scope.goToCalendar=function(){
		$location.path("adminCalendar");
	}

	$scope.getSectionReportCards=function(section){
		console.log(section);
		$scope.sectionId=section.sectionId;
		$scope.sectionName=section.sectionName;

		sessionStorage.setItem("rpSectionId",$scope.sectionId);
		$scope.getInstTestGrades();
		$scope.getOverAllSectionRprtCrd();
	}

$scope.addReportInit=function(){
	$scope.reportCardName = $routeParams.testName;
	$scope.getAllCourseClassSubjects();
	$scope.getInstTestGrades();
	$scope.getInstTestTypes();
	$scope.getStudentsReportCardDetails();
}

$scope.reportCardDetailInit=function(){
	$scope.getInstTestTypes();
	$scope.getAllTestsReportBySection();
}
	$scope.getCourseByBranchId=function(){
	httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	console.log(data);
	if (data.StatusCode == 200) {
	$scope.courseList = data.Courses;
	  if($scope.courseList.length = 1) {
    	  $scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
      }		 
      $scope.courseSelect($scope.selectedCourseOb);

	if($scope.navCourseId){
		for (var i = 0; i < $scope.courseList.length; i++) {
			if($scope.courseList[i].courseId==$scope.navCourseId){
				console.log(JSON.stringify($scope.courseList[i]));
				$scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
				$scope.selectedCourse=$scope.courseList[i].courseId;
				$scope.courseSelect($scope.courseList[i]);
				break;
		}
	}
}else{
	$scope.selectedCourse=$scope.courseList[0].courseId;
}
	}
	});
	}
	$scope.reportCancel=function(){
		$location.path("/sectionReport/"+$routeParams.courseId+"/"+$routeParams.classId);
	}
	$scope.courseSelect = function(selectedCourseOb){

		// $scope.selectedCourseOb=JSON.stringify(selectedCourseOb);
		console.log(selectedCourseOb);
		if(typeof selectedCourseOb == 'string')
		 $scope.courseOb = JSON.parse(selectedCourseOb);
	 else
		 $scope.courseOb = selectedCourseOb;

		$scope.selectedCourse=$scope.courseOb.courseId;

		sessionStorage.setItem("rpCourseId",$scope.selectedCourse);
		httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.classList = data.Classes;
		if($scope.navCourseId){
			for (var i = 0; i < $scope.classList.length; i++) {
				if($scope.classList[i].classId==$scope.navClassId){
					console.log(JSON.stringify($scope.classList[i]));
					$scope.selectedClsOb=JSON.stringify($scope.classList[i]);
					$scope.selectedCCId=$scope.classList[i].classCourseId;
					$scope.courseClassSelect($scope.selectedClsOb);
					break;
			}
		}
	}
		}
		});
	}

	$scope.courseClassSelect = function(){
		console.log($scope.selectedClsOb);
		$scope.sectionList=[];
		$scope.selectedClsObject = JSON.parse($scope.selectedClsOb);
		$scope.selectedClassId=$scope.selectedClsObject.classId;
		$scope.selectedCCId=$scope.selectedClsObject.classCourseId;
		sessionStorage.setItem("rpClassId",$scope.selectedClassId);

	httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
	console.log(data);
		if (data.StatusCode == 200) {
		$scope.sectionList = data.Sections;
		$scope.getSectionReportCards($scope.sectionList[0]);
		}
		});
	}

	$scope.adminRprtInit=function(){
		$scope.getCourseByBranchId();
	}

	$scope.enterStudManually = function(){
	$scope.studentSubjArr=[];
	if($scope.manualAdding > 0){
	$scope.studentsArr = [];

	for(var i=0; i<$scope.manualAdding; i++){
	var stuObj = {
	"studentId":$scope.studentReportList[i].studentId,
	"studentName":$scope.studentReportList[i].studentName
	};
	for (var k = 0; k < $scope.subjectIdArr.length; k++) {
		$scope.instTestGrade="";
		$scope.isElective=0;
		$scope.electiveGroupId=0;
		$scope.instStudentExamId=0;
		$scope.testMarks="";
		// alert($scope.subjectIdArr[k].subjectId);
		$scope.isStudentSubject=0;

		for (var m = 0; m < $scope.studentReportList[i].studentTestTypes.length; m++) {
			$scope.repSubjArr=[];
				$scope.repSubjArr=$scope.studentReportList[i].studentTestTypes[m];
				// console.log($scope.repSubjArr);
			if ($scope.repSubjArr.subjectId == $scope.subjectIdArr[k].subjectId) {
				$scope.isStudentSubject=1;
				if ($scope.repSubjArr.marksAvailable>0) {
					$scope.instTestGrade=$scope.repSubjArr.instGrade;
					$scope.isElective=$scope.repSubjArr.isElective;
					$scope.electiveGroupId=$scope.repSubjArr.electiveGroupId;
					$scope.instStudentExamId=$scope.repSubjArr.instStudentExamId;
					$scope.testMarks=$scope.repSubjArr.marks;
					$scope.marks=parseInt($scope.testMarks);
					$scope.perc = Number(($scope.marks/$scope.testTotalMarks)*100);
				}
			}
		}
	var subParams={
	"stuDupId":$scope.studentsArr.length,
	"studentId":$scope.studentReportList[i].studentId,
	"studentName":$scope.studentReportList[i].studentName,
	"createdBy":$scope.userId,
	"subjectId":$scope.subjectIdArr[k].subjectId,
	"subjectName":$scope.subjectIdArr[k].subjectName,
	"instTestGrade":$scope.instTestGrade,
	"instTestGradeId":1,
	"instTestType":$scope.instTestType,
	"instTestTypeId":$scope.instTestTypeId,
	"percentage":$scope.perc,
	"gradeId":0,
	"marks":$scope.testMarks,
	"isElective":$scope.isElective,
	"electiveGroupId":$scope.electiveGroupId,
	"instStudentExamId":$scope.instStudentExamId,
	"isStudentSubject":$scope.isStudentSubject

	}
	$scope.studentSubjArr.push(subParams);
}
	stuObj["Subjects"]=$scope.studentSubjArr;
	$scope.studentsArr.push(stuObj);
	$scope.studentSubjArr=[];
	}
	}
	else{
	alert("Select No'of students to be Added");
	}
	}

	$scope.checkGrade=function(marks){
	console.log(marks);
	}

	$scope.validateMarks=function(marks){
		if (marks>$scope.testTotalMarks) {
			alert("Entered more than exam total marks");
			return "";
		}
		else{
			return marks;
		}
	}

	$scope.validateGrade=function(marks){

		if (marks>$scope.testTotalMarks) {
			//alert("Entered more than exam total marks");

		}else{
			for(var i=0;i<$scope.instTestTypes.length;i++){
				$scope.marks=parseInt(marks);
				$scope.perc = Number(($scope.marks/$scope.testTotalMarks)*100);
				if ($scope.perc>=$scope.instTestTypes[i].gradeMarksPercenFrom && $scope.perc<=$scope.instTestTypes[i].gradeMarksPercenTo) {
					return $scope.instTestTypes[i].grade;
				}
			}
		}
	}
	$scope.validateInstGradeId=function(marks){
		if (marks>$scope.testTotalMarks) {
			// alert("Entered more than exam total marks");
		}else{

		for(var i=0;i<$scope.instTestTypes.length;i++){
				if (marks>=$scope.instTestTypes[i].gradeMarksPercenFrom && marks<=$scope.instTestTypes[i].gradeMarksPercenTo) {
					return $scope.instTestTypes[i].instGradeId;
				}
		}
	}
	}
	$scope.calculatePercentage=function(marks){
		if (marks>$scope.testTotalMarks) {
			// alert("Entered more than exam total marks");
		}else{
			$scope.marks=parseInt(marks);
			$scope.perc = Number(($scope.marks/$scope.testTotalMarks)*100);
			$scope.checkForGenerateReportCard();
		return $scope.perc;
	}
}

$scope.returnGradeMethod=function(marks){
	for(var i=0;i<$scope.instTestTypes.length;i++){
		$scope.marks=parseInt(marks);
		$scope.perc = Number(($scope.marks/$scope.testTotalMarks)*100);
		console.log(Number($scope.perc));
			if ($scope.perc>=$scope.instTestTypes[i].gradeMarksPercenFrom && $scope.perc<=$scope.instTestTypes[i].gradeMarksPercenTo) {
				return $scope.instTestTypes[i].grade;
			}
	}
}
$scope.getAllCourseClassSubjects=function(){
	httpFactory.getResult("getAllCourseClassSubjects?classId="+$scope.classIdRoute+"&courseId="+$scope.courseIdRoute+"&schemaName="+$scope.schemaName, function(data) {
	console.log(data);
	if (data.StatusCode == 200) {
		$scope.subArr=[];
	// $scope.subjectIdArr=data.Subjects;
	$scope.detailSubjArr = data.Subjects;
	$scope.subjectIdArr=[];
	console.log(data.Subjects);
	for (var i = 0; i < data.Subjects.length; i++) {
		var subj={};
		for (var k = 0; k< data.Subjects[i].subjects.length; k++) {
			 subj={
				"isElective":data.Subjects[i].isElective,
				"electiveGroupName":data.Subjects[i].electiveGroupName,
				"electiveGroupId":data.Subjects[i].electiveGroupId,
				"subjectName":data.Subjects[i].subjects[k].subjectName,
				"subjectGroup":data.Subjects[i].subjects[k].subjectGroup,
				"subjectId":data.Subjects[i].subjects[k].subjectId
			}
				$scope.subArr.push(subj);
		}
	}
	$scope.subjectIdArr=$scope.subArr;
	// console.log($scope.subjectIdArr);
	console.log($scope.studentsArr);
	// $scope.selectStudentsBySection();
	}else{
	$scope.subjectIdArr=[];
	}
	});
}
	$scope.instTestTypeChange=function(){
		console.log($scope.instType);
		if (typeof $scope.instType == "string")
			$scope.testTypeObj=JSON.parse($scope.instType);
		else
			$scope.testTypeObj=$scope.instType;

		console.log($scope.testTypeObj);
		$scope.testTotalMarks=$scope.testTypeObj.totalMarks;
		$scope.instTestTypeId=$scope.testTypeObj.instTestTypeId;
		$scope.instTestTypeName=$scope.testTypeObj.testType;

	}

	$scope.getInstTestGrades=function(){
		httpFactory.getResult("getInstGrades?schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.instTestTypes = data.InstTestGrades;
		}
		});
	}

	$scope.getInstTestTypes=function(){
		httpFactory.getResult("getInstTestTypes?schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.instTestTypesId = data.InstTestTypes;
		console.log($scope.instTestTypesId);
		for (var i = 0; i < $scope.instTestTypesId.length; i++) {
			for(var j = 0; j < $scope.instTestTypesId[i].tests.length; j++){
				if($scope.instTestTypesId[i].tests[j].testType==$scope.instTestTypeName){
					$scope.instType=$scope.instTestTypesId[i].tests[j];
					$scope.instTestTypeChange();
					break;
				}
			}
		}
	}
	});
}

$scope.getAllTestsReportBySection=function(){

var params = {
		"schemaName":localStorage.getItem("sname"),
		"sectionId":sessionStorage.getItem("rpSectionId")
}
console.log(params);
httpFactory.executePost("getAllTestAnalysisBySection", params, function(data) {
console.log(data);
if (data.STATUS == 'SUCCESS') {
	$scope.studentReportList=[];
	$scope.studentRptobj=[];
	$scope.studentTestRpt=[];
	$scope.stuRprtList=data.studentReportCardDetails;
	console.log($scope.stuRprtList);
	obj={};
	for (var k = 0; k < $scope.stuRprtList.length; k++) {
		for (var i = 0; i < $scope.instTestTypesId.length; i++) {
			for(var j = 0; j < $scope.instTestTypesId[i].tests.length; j++)
			{
				var status = 0;
				for (var m = 0; m < $scope.stuRprtList[k].testAverageAnalysis.length; m++) {
					if ($scope.stuRprtList[k].testAverageAnalysis[m].testTypeId == $scope.instTestTypesId[i].tests[j].instTestTypeId) {
						status=1;
							break;
				}else{
						status=0;
						}
				}

				if (status == 1) {
					obj ={
					 "studentId":$scope.stuRprtList[k].studentId,
					 "studentName":$scope.stuRprtList[k].studentName,
					 "grade":$scope.stuRprtList[k].testAverageAnalysis[m].grade,
					 "percentage":$scope.stuRprtList[k].testAverageAnalysis[m].percentage,
					 "testTypeId":$scope.stuRprtList[k].testAverageAnalysis[m].testTypeId,
					 "testType":$scope.stuRprtList[k].testAverageAnalysis[m].testType,
					 "totalMarks":$scope.instTestTypesId[i].tests[j].totalMarks,
					 "testStartDate":$scope.instTestTypesId[i].tests[j].testStartDate,
					 "testEndDate":$scope.instTestTypesId[i].tests[j].testEndDate
				 }
				 $scope.studentRptobj.push(obj);
				 $scope.studentTestRpt.push($scope.studentRptobj[0]);
				 $scope.studentRptobj=[];

				}else{
					obj ={
					"studentId":$scope.stuRprtList[k].studentId,
					"studentName":$scope.stuRprtList[k].studentName,
					"grade":"",
					"percentage":"",
					"testTypeId":$scope.instTestTypesId[i].tests[j].instTestTypeId,
					"testType":$scope.instTestTypesId[i].tests[j].testType,
					"totalMarks":"",
					"testStartDate":"",
					"testEndDate":""
				 }
				 $scope.studentRptobj.push(obj);
				 $scope.studentTestRpt.push($scope.studentRptobj[0]);
				 $scope.studentRptobj=[];
				}

				console.log($scope.studentTestRpt);
			}

	}
	var stuObj = {
		"studentId":$scope.stuRprtList[k].studentId,
		"studentName":$scope.stuRprtList[k].studentName,
		"testAverageAnalysis":$scope.studentTestRpt
	}
	$scope.studentReportList.push(stuObj);
	$scope.studentRptobj=[];
	$scope.studentTestRpt=[];
}

console.log($scope.studentReportList);

}
else {
alert('There was a problem saving test. Please try again later.');
// $location.path("/exams");
}
});
}

	$scope.saveReport=function(){
	console.log($scope.studentsArr);
	$scope.reportSubjArr=[];
	$scope.reportArr=[];
	for (var i = 0; i < $scope.studentsArr.length; i++) {
	for (var k = 0; k < $scope.studentsArr[i].Subjects.length; k++) {
	if($scope.studentsArr[i].Subjects[k].marks!=""){
	$scope.reportSubjArr.push($scope.studentsArr[i].Subjects[k]);
	}else{
	}
	}
	// $scope.reportArr.push($scope.studentsArr[i]);
	var stuFinal={
	"studentId":$scope.studentsArr[i].studentId,
	"Subjects":$scope.reportSubjArr
	}
	if ($scope.reportSubjArr.length>0) {
		$scope.reportArr.push(stuFinal);
	}
	$scope.reportSubjArr=[];

	}
	console.log($scope.reportArr);
	var params ={
	"schemaName":localStorage.getItem("sname"),
	"instTestTypeId":$scope.instTestTypeId,
	"classId":sessionStorage.getItem("rpClassId"),
	"courseId":sessionStorage.getItem("rpCourseId"),
	"sectionId":sessionStorage.getItem("rpSectionId"),
	"isActive":1,
	"createdBy":localStorage.getItem("userId"),
	"Students":$scope.reportArr
	}
	console.log(params);
	httpFactory.executePost("insertInstituteTestMarks", params, function(data) {
	console.log(data);
	if (data.STATUS == 'SUCCESS') {
	// $scope.selectedCategoryName="CLASS-WISE";
	alert("Successfully Updated");
	$scope.reportArr=[];
	$scope.studentsArr=[];
	// $scope.getAllCourseClassSubjects();
	// $scope.getInstTestGrades();
	// $scope.getInstTestTypes();
	// $scope.getStudentsReportCardDetails();
$route.reload();
	} else {
	alert('There was a sdsdproblem saving test. Please try again later.');
	// $location.path("/exams");
	}
	});
	}

	$scope.selectStudentsBySection = function(){
	$scope.selectedSection=1;
	$scope.branchId=localStorage.getItem("bnchId");
	$scope.schemaName=localStorage.getItem("sname");
	httpFactory.getResult("selectStudentsBySection?sectionId="+$scope.selectedSection+"&branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	console.log(data);
	if (data.StatusCode == 200) {
	$scope.studentListHW=data.sectionStudents;
	$scope.manualAdding=$scope.studentListHW.length;
	$scope.enterStudManually();
	$("#subjectModal").modal("hide");
	}else{
	$scope.studentListHW=[];
	}
	});
	}

	$scope.getStudentsReportCardDetails = function(){

		var params = {
				"schemaName":localStorage.getItem("sname"),
				"sectionId":sessionStorage.getItem("rpSectionId"),
				"classId":sessionStorage.getItem("rpClassId"),
				"courseId":sessionStorage.getItem("rpCourseId"),
				"testTypeId":$routeParams.testType
		}
		console.log(params);
		$scope.studentReportList=[];
	httpFactory.executePost("getStudentsReportCardDetails", params, function(data) {
	console.log(data);
	$scope.subArry=[];
	if (data.StatusCode == 200) {
	// $scope.selectedCategoryName="CLASS-WISE";
	$scope.studentReportList=data.studentReportCardDetails;
	$scope.manualAdding=$scope.studentReportList.length;
		$scope.enterStudManually();
		$scope.checkForGenerateReportCard();
	}

 else {
	alert('There was a problem saving test. Please try again later.');
	// $location.path("/exams");
	}
	});
}

$scope.generateFinalReportCard=function(){
	var params={
		"schemaName":$scope.schemaName,
		"sectionId":sessionStorage.getItem("rpSectionId"),
		"instTestTypeId":$routeParams.testType
	}
	console.log(params);
	httpFactory.executePost("generateReportCard", params, function(data) {
	if (data.STATUS == 'SUCCESS') {
		alert(data.MESSAGE);
	}
 else {
	alert('There was a problem saving test. Please try again later.');
	}
	});
}

$scope.getOverAllSectionRprtCrd=function(){
	$scope.topStudents=[];
	var perc = 0.0;
	$scope.overAllGrade=0.0;
	$scope.overAllPerc=0.0;
	httpFactory.getResult("getOverAllSectionRprtCrd?branchId="+$scope.branchId+"&sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName, function(data) {
	console.log(data);
	if (data.StatusCode == 200) {
		$scope.overAllReport=data;
		$scope.topStudents=data.studentarray;

		for (var i = 0; i < $scope.overAllReport.sectionAverage.length; i++) {
			perc =perc+$scope.overAllReport.sectionAverage[i].testSectionAvgPercentage;
		}
		console.log(perc);
		console.log($scope.overAllReport.sectionAverage.length);
		$scope.overAllPerc= perc/$scope.overAllReport.sectionAverage.length;
		$scope.overAllPerc=$scope.overAllPerc.toFixed(2);

		$scope.overAllGrade = $scope.getGradeByPercent($scope.overAllPerc);
		console.log($scope.overAllGrade);
	}else{
	}
	});
}

$scope.getGradeByPercent=function(perc){
		for(var i=0;i<$scope.instTestTypes.length;i++){
			if (perc>=$scope.instTestTypes[i].gradeMarksPercenFrom && perc<=$scope.instTestTypes[i].gradeMarksPercenTo) {
				return $scope.instTestTypes[i].grade;
			}
		}
	}

	// ends here add report js
	$scope.closeSubjectPopup=function(){
	$("#subjectModal").modal("hide");
	}

	$scope.openAssignTeacherPopup = function(wekday, perdTime){
	$scope.selectedDay = wekday;
	$scope.selectedTime = perdTime;
	$("#assignTeacher").modal("show");
	};

$scope.getStudentReportCard=function(){
	var params= {
	"schemaName":$scope.schemaName,
	"courseId":$routeParams.courseId,
	"classId":$routeParams.classId,
	"sectionId":$routeParams.sectionId,
	"studentId":$routeParams.studentId
	}
	httpFactory.executePost("getStudentReportCard", params, function(data) {
	if (data.StatusCode == 200) {
		$scope.studentReportCard = data.studentReportCardDetails;
		$scope.termsArr = [];
		$scope.totalTermObj={};
		for (var i = 0; i < $scope.studentReportCard.length; i++) {
			if($scope.termsArr.includes($scope.studentReportCard[i].termName)){
			}else{
				$scope.termsArr.push($scope.studentReportCard[i].termName);
			}
		}
		for (var i = 0; i < $scope.termsArr.length; i++) {
				var obj = {
						"termName":$scope.termsArr[i].termName
				}
		}
		// for (var i = 0; i < $scope.termsArr.length; i++) {
		// 	for (var i = 0; i < $scope.studentReportCard[i].length; i++) {
		// 		if ($scope.termsArr[i] == $scope.studentReportCard[i].termName) {
		//
		// 		}
		// 	}
		// }
	}
 else {
	alert('There was a problem saving test. Please try again later.');
	}
	});
}

	$scope.generateFlag=false;
	$scope.checkForGenerateReportCard = function(){
		console.log("hello");
		// console.log($scope.studentsArr);
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			// console.log($scope.studentsArr[i].Subjects);
			for(var m=0;m<$scope.studentsArr[i].Subjects.length;m++){
				console.log($scope.studentsArr);
					if($scope.studentsArr[i].Subjects[m].marks=="" && $scope.studentsArr.isStudentSubject==1){
						console.log($scope.studentsArr.isStudentSubject);
						console.log("empty");
						alert("hello");
						$scope.generateFlag=true;
						break;
					}
			}
		}
		console.log($scope.generateFlag);
	}
	
	$scope.goToFeeStructure = function(){
		$location.path("feeStructure");
	}
	
	$scope.gotoFeeAllocation = function(){
		$location.path("feeAllocation");
	}
	
	$scope.gotoFeeReceipt = function(){
		$location.path("feeReceipt");
	}
	$scope.gotoFeeReport = function(){
		$location.path("feeReport");
	}
	$scope.gotoReceiptsHistory = function(){
		$location.path("feeReceiptsHistory");
	}
	$scope.gotoRefundHistory = function(){
		$location.path("feeRefundHistory");
	}
	$scope.gotoCustomPushNotifications = function(){
		$location.path("pushNotifications");
	}
	$scope.gotoCertificates = function(){
		$location.path("certificates");
	}
	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}

	$scope.gotoHallticket = function(){
		$location.path("hallticket");
	}
	$scope.gotohallTicketCreation = function(){
		
		$location.path("hallTicketCreation");
	}
	$scope.gotohallTicketAllotment = function(){
		$location.path("hallTicketAllotment");
	}
	$scope.gotoAddReportCardTestDetails = function(){
		$location.path("addReportCardTestDetails");
	}
	$scope.gotoReportCardAttendanceManagement = function(){
		$location.path("reportCardAttendanceManagement");
	}
	$scope.gotoReportCardSubjectsManagement = function(){
		$location.path("reportCardSubjectManagement");
	}
	$scope.goToGenerateReportCard = function(){
		$location.path("generateReportCard");
	}
	$scope.gotoReportCardTemplate = function(){
		$location.path("reportCardTemplate");
	}
	$scope.gotoReportCardGeneration = function(){
		$location.path("reportCardGeneration");
	}
	$scope.gotoMapReportCard = function(){
		$location.path("reportCardMap");
	}
	$scope.goToDashbord = function(){
		$location.path("reportAnalysis");
	}

	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	$scope.goToHome = function(){
		$location.path("home");
	}
	
	});
