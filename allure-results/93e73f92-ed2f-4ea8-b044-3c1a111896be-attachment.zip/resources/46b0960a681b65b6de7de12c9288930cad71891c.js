projectModule.controller('moveContentController', function($scope, $location, commonFactory, httpFactory, $routeParams, $sce) {
    $scope.$ = $;
    $scope.instituteId = localStorage.getItem("inst_id");
    $scope.schemaName = localStorage.getItem("sname");
    $scope.selInstCrsCls = localStorage.getItem("classId");
    $scope.selSubjId = localStorage.getItem("subId")
    $scope.branchId = localStorage.getItem("bnchId");
    $scope.userId = localStorage.getItem("userId");
    $scope.oldCourseList = [];
    $scope.newCourseList = [];
    $scope.categoryList =[];
    $scope.localDomain = localStorage.getItem("domain");
    $scope.contentChapterInit = function() {
      $scope.oldGetCourses();
      $scope.newGetCourses();  
    }

    $scope.oldGetCourses = function() {
        httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.oldCourseList = data.Courses;
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.newGetCourses = function() {
        httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.newCourseList = data.Courses;
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.oldCourseChange = function(course) {
        $scope.oldChapterList = [];
        $scope.oldCourseId = course.courseId;
        $scope.oldCourseName = course.courseName;
        $scope.oldGetClassByCourseId($scope.oldCourseId);
        $scope.oldGetContentOwner($scope.oldCourseId);
        $scope.oldSubjList = [];
        $scope.selectedSbj = "";
        $scope.selInstCrsCls = 0;
        $scope.selSubjId = 0;
        $scope.contentOb = {};
        $scope.oldContentType = "";
    }
    
    $scope.newCourseChange = function(course) {
        $scope.newChapterList = [];
        $scope.newCourseId = course.courseId;
        $scope.newCourseName = course.courseName;
        $scope.newGetClassByCourseId($scope.newCourseId);
        $scope.newGetContentOwner($scope.newCourseId);
        $scope.newSubjList = [];
        $scope.selectedSbj = "";
        $scope.selInstCrsCls = 0;
        $scope.selSubjId = 0;
        $scope.contentOb = {};
        $scope.newContentType = "";
    }

    $scope.oldClassChange = function(classObj) {
        $scope.oldChapterList = [];
        $scope.oldClassId = classObj.classId;
        $scope.classCourseId = classObj.classCourseId;
        $scope.selSubjId = 0;
        $scope.oldContentType = "";
        $scope.oldContentOb = {};
        $scope.oldGetSubjectsByClassChange($scope.oldClassId,$scope.oldCourseId);
    }
    
     $scope.newClassChange = function(classObj) {
        $scope.newChapterList = [];
        $scope.newClassId = classObj.classId;
        $scope.classCourseId = classObj.classCourseId;
        $scope.selSubjId = 0;
        $scope.newContentType = "";
        $scope.newContentOb = {};
        $scope.newGetSubjectsByClassChange($scope.newClassId,$scope.newCourseId);
    }

    $scope.oldSubjectChange = function() {
        $scope.oldChapterList = [];
        console.log($scope.selectedSbj);
        $scope.oldSelSubjId = $scope.oldSelectedSbj.subjectId;
        console.log($scope.selSubjId);
        $scope.oldContentType = "";
        $scope.contentOb = {};
        $scope.getSuperAdminUserId();
    }
    
    $scope.newSubjectChange = function() {
        $scope.newChapterList = [];
        console.log($scope.selectedSbj);
        $scope.newSelSubjId = $scope.newSelectedSbj.subjectId;
        console.log($scope.selSubjId);
        $scope.newContentType = "";
        $scope.contentOb = {};
        $scope.getSuperAdminUserId();
    }

    $scope.oldGetClassByCourseId = function(courseId) {
        httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + courseId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.oldClassList = data.Classes;
                var classes = data.Classes;
                $scope.oldClassList =[];
                 for(var i =0;i<classes.length ;i++){
                 	if(classes[i].isActive == 1){
                 		$scope.oldClassList.push(classes[i]);
                 	}
                 }
            } else {
                console.log("No branches");
            }
        });
    }
      $scope.newGetClassByCourseId = function(courseId) {
        httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + courseId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.newCassList = data.Classes;
                var classes = data.Classes;
                $scope.newClassList =[];
                 for(var i =0;i<classes.length ;i++){
                 	if(classes[i].isActive == 1){
                 		$scope.newClassList.push(classes[i]);
                 	}
                 }
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.oldGetContentOwner = function(courseId) {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.oldContentOwnerList = [];
                $scope.oldContentList = data.ContentOwner;
                for (var i = 0; i < $scope.oldContentList.length; i++) {
                    if ($scope.oldContentList[i].courseId == "" + courseId) {
                        $scope.oldContentOwnerList.push($scope.oldContentList[i]);
                    }
                }
            } else {
                console.log("No ContentList");
            }
        });
    }

   $scope.newGetContentOwner = function(courseId) {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.newContentOwnerList = [];
                $scope.newContentList = data.ContentOwner;
                for (var i = 0; i < $scope.newContentList.length; i++) {
                    if ($scope.newContentList[i].courseId == "" + courseId) {
                        $scope.newContentOwnerList.push($scope.newContentList[i]);
                    }
                }
            } else {
                console.log("No ContentList");
            }
        });
    }


    $scope.oldGetSubjectsByClassChange = function(classId,courseId) {
        httpFactory.getResult("getCourseClassSubjects?classId=" + classId + "&courseId=" + courseId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + localStorage.getItem("bnchId"), function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.oldSubjList = data.Classes;
            } else {}
        });
    }
    $scope.newGetSubjectsByClassChange = function(classId,courseId) {
        httpFactory.getResult("getCourseClassSubjects?classId=" + classId + "&courseId=" + courseId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + localStorage.getItem("bnchId"), function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.newSubjList = data.Classes;
            } else {}
        });
    }

    $scope.oldContentSelectMethod = function(content) {
        $scope.oldChapterList = [];
        $scope.oldContentType = content.contentType;
        $scope.oldGetChapterTopicsBySubjectChangeques($scope.oldSelSubjId,$scope.oldClassId,$scope.oldCourseName,$scope.oldContentType,$scope.oldCourseId);
    }
    
    $scope.newContentSelectMethod = function(content) {
        $scope.newChapterList = [];
        $scope.newContentType = content.contentType;
        $scope.newGetChapterTopicsBySubjectChangeques($scope.newSelSubjId,$scope.newClassId,$scope.newCourseName,$scope.newContentType,$scope.newCourseId);
    }
    $scope.oldGetChapterTopicsBySubjectChangeques = function(subjectId,classId,courseName,selContentType,courseId) {
        angular.element("#smallLoader").show();
        setTimeout(function() {
            $scope.cedzDb = "CEDZ";
            $scope.contentOwner = "COLLEGE" + ',' + $scope.cedzDb;
            var contentType = courseName +","+ selContentType;
                httpFactory.getResult("getChapterTopicsBySubId?classId=" + classId + "&subjectId=" + subjectId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&contentType=" + contentType + "&branchId=" + localStorage.getItem("bnchId")+"&courseId="+ courseId +"&instId="+$scope.instituteId, function(data) {
                    console.log(data);
                    if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                        $scope.chapterListByClassSubject = data.Chaptertopics;
                        $scope.oldChapterList = data.Chaptertopics;
                        angular.element("#smallLoader").hide();
                    } else {
                        angular.element("#smallLoader").hide();
                        alert("No Chapters");
                    }
                });
        }, 100)
    }
    
    $scope.newGetChapterTopicsBySubjectChangeques = function(subjectId,classId,courseName,selContentType,courseId) {
        angular.element("#smallLoader").show();
        setTimeout(function() {
            $scope.cedzDb = "CEDZ";
            $scope.contentOwner = "COLLEGE" + ',' + $scope.cedzDb;
            var contentType = courseName +","+ selContentType;
                httpFactory.getResult("getChapterTopicsBySubId?classId=" + classId + "&subjectId=" + subjectId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&contentType=" + contentType + "&branchId=" + localStorage.getItem("bnchId")+"&courseId="+ courseId +"&instId="+$scope.instituteId, function(data) {
                    console.log(data);
                    if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                        $scope.chapterListByClassSubject = data.Chaptertopics;
                        $scope.newChapterList = data.Chaptertopics;
                        angular.element("#smallLoader").hide();
                    } else {
                        angular.element("#smallLoader").hide();
                        alert("No Chapters");
                    }
                });
        }, 100)
    }
    $scope.lviewexpand = true;
    $scope.toogleSide = function() {
        $('.togglesidebar').toggleClass('is-collapsed');
        $('.togglecontent').toggleClass('is-full-width');
        // $('.togglebtn').toggleClass('fa-chevron-right');
        $scope.lviewexpand = !$scope.lviewexpand;
    }

    $scope.lviewstate = true;
    $scope.expandToggle = function(lview) {
        $scope.lviewstate = lview;

    }

    $scope.closePopUp = function() {
        $scope.getQuestionsByTopicId();
    }
    
    $scope.getSuperAdminUserId = function() {
        httpFactory.getResult("getSuperAdminUserId?instId="+$scope.instituteId+"&schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if(data.statusCode = 200){
            	$scope.superAdminUserId = data.UserObject.userId;
            }
            else{
            	$scope.superAdminUserId = "";
            }
        });
    }
    
    $scope.subjectChangeToMoveConnect = function() {
        $scope.getChapterTopicsBySubjectChange($scope.selectedSbj);
    }
    $scope.oldSelectedChapter=function(chap){
		if(typeof chap=='string')
		  $scope.oldTopicList=JSON.parse(chap.Topics);
		else
		  $scope.oldTopicList=chap.Topics;
		$scope.oldChapterId = chap.chapterId;  
	}

	$scope.oldSelectedTopic=function(tpc){
		if(typeof tpc=='string')
			$scope.oldSelTopicList=JSON.parse(tpc);
		else
			$scope.oldSelTopicList=tpc;
		$scope.oldSelTopicId=$scope.oldSelTopicList.topicId;
	}
		
	$scope.newSelectedChapter=function(chap){
		if(typeof chap=='string')
		   $scope.newTopicList=JSON.parse(chap.Topics);
		else
		   $scope.newTopicList=chap.Topics;
		$scope.newChapterId = chap.chapterId;  
	}

	$scope.newSelectedTopic=function(tpc){
		if(typeof tpc=='string')
			$scope.newSelTopicList=JSON.parse(tpc);
		else
			$scope.newSelTopicList=tpc;
		$scope.newSelTopicId=$scope.newSelTopicList.topicId;
	}
	$scope.copyContentFromTopic=function(){
		var params = {
		        "schemaName" : $scope.schemaName,
				"oldChapterId" : $scope.oldChapterId,
				"newChapterId" : $scope.newChapterId,
				"oldTopicId" : $scope.oldSelTopicId,
				"newTopicId" : $scope.newSelTopicId,
				"newSubjectId" : $scope.newSelSubjId,
				"newContentType" : $scope.newCourseName
		}
		httpFactory.executePost("copyContentFromTopic",params, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
			  alert("Content Copied Successfully")
			}
		});
	}
		
	$scope.getChapterTopicsBySubjectChange = function(selSubj){
		console.log(selSubj);
		var contentType = $scope.selCourseName+","+selSubj.contentType;
		httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selectedClassId + "&subjectId="+selSubj.subjectId+"&schemaName="+$scope.schemaName+"&contentOwner=CEDZ,COLLEGE&contentType="+contentType+"&branchId="+$scope.branchId+"&courseId="+$scope.selectedCourse+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				$scope.chapterListBySub = data.Chaptertopics;
				console.log($scope.chapterListBySub);
			}
		});
	}
    
}).directive("videoViews", function($timeout) {
    return {
        restrict: "A",
        compile: function compile(tElement, tAttrs, transclude) {
            return {
                pre: function preLink(scope, iElement, iAttrs, controller) {},
                post: function postLink(scope, Element, Attrs, controller) {

                    var iframe = document.querySelector("#vimeo");
                    var player1;
                    var player2;

                    function formYoutubePlayer(id) {
                        player1 = new YT.Player('player', {
                            origin: window.location.hostname,
                            height: '315',
                            width: '100%',
                            videoId: id,
                            playerVars: {
                                autoplay: 1,
                                loop: 1
                            },
                            events: {
                                'onReady': onPlayerReady
                            }
                        });
                    }

                    function onPlayerReady(event) {
                        event.target.playVideo();
                    }

                    var videoLink = scope.videoLinkToPlay;

                    if (videoLink.indexOf('youtu') >= 0) {
                        var id = videoLink.substring(videoLink.lastIndexOf('/') + 1, videoLink.indexOf('?'));
                        formYoutubePlayer(id);

                    } else {
                        var youtubIf = document.querySelector("#player");

                        iframe.setAttribute("src", scope.trustSrc(scope.videoLinkToPlay));
                        player2 = new Vimeo.Player(iframe);
                    }

                    scope.$watch("videoLinkToPlay", function(newValue, oldValue) {
                        if (newValue !== oldValue) {
                            if (newValue.indexOf('youtu') >= 0) {
                                var id = newValue.substr(newValue.lastIndexOf('/') + 1);
                                var youtubIf = document.querySelector("#player");
                                youtubIf.setAttribute("style", "display: block;");
                                if (!!player1) {
                                    player1.destroy();
                                }
                                formYoutubePlayer(id);
                                iframe.setAttribute("style", "display: none;");
                            } else {
                                // player.destroy();
                                var youtubIf = document.querySelector("#player");
                                youtubIf.setAttribute("style", "display: none;");

                                iframe.setAttribute("style", "display: block;");
                                $timeout(function() {
                                    scope.$apply(function() {
                                        player2.loadVideo(scope.videoLinkToPlay.split('/')[4]);
                                    });
                                }, 300);
                            }
                        }

                    });

                },
            };
        },
    };
    
});