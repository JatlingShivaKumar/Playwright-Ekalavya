projectModule.controller('attendanceController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
    $scope.$ = $;
    $scope.instituteId = localStorage.getItem("inst_id");
    $scope.userId = localStorage.getItem("userId");
    $scope.branchId=localStorage.getItem("bnchId");
    $scope.absentStudentList = [];
    var requestParams = {"m_inst_id": $scope.instituteId};

    $scope.branchName = localStorage.getItem("bnchnme");

    if(localStorage.getItem("RD")!=3) {
        $scope.navCourseId=localStorage.getItem("attCourseId");
        $scope.navClassId = localStorage.getItem("selectedCId");
        $scope.navSectionId=sessionStorage.getItem("navSectionId");
        sessionStorage.removeItem("navCourseId");
        sessionStorage.removeItem("navClassId");
        sessionStorage.removeItem("navSectionId");
    }else {
        $scope.navCourseId=sessionStorage.getItem("rpCrs");
        $scope.navClassId = sessionStorage.getItem("rpCls");
    }

    $scope.myClasses=sessionStorage.getItem("myClasses");
    sessionStorage.removeItem("myClasses");

    if ($scope.navCourseId) {
        $scope.selectedCourse=$scope.navCourseId;
    }
    $scope.schemaName=localStorage.getItem("sname");
    $scope.sectionId=$routeParams.secId;
    $scope.branchId=localStorage.getItem("bnchId");
    var date = new Date();
    $scope.todayDate = date.getDate();
    $scope.currentMonth = date.getMonth();
    $scope.currentYear = date.getFullYear();

    console.log($scope.todayDate);


    $scope.getCourseByBranchId=function(){
        httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.courseList = data.Courses;
                if($scope.courseList.length == 1) {
                    $scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
                    setTimeout(function() { $scope.courseSelectMethod($scope.selectedCourseOb); }, 5);
                }
                if($scope.navCourseId!=null && $scope.navCourseId!="undefined"){
                    for (var i = 0; i < $scope.courseList.length; i++) {
                        if($scope.courseList[i].courseId==$scope.navCourseId){
                            console.log(JSON.stringify($scope.courseList[i]));
                            $scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
                            setTimeout(function() { $scope.courseSelectMethod($scope.selectedCourseOb); }, 5);
                            console.log($scope.selectedCourseOb);
                        }
                    }
                    //			 }else {
                    //				 setTimeout(function() { $scope.courseSelectMethod($scope.selectedCourseOb); }, 5);
                }
            }
        });
    }
    $scope.getCourseByBranchId();

    if(!window.location.href.includes("registerView")) {
        $scope.getCourseByBranchId();
    }

    $scope.courseSelectMethod = function(selCrs){
        if(typeof selCrs=='string')
        $scope.selCrsOb =JSON.parse(selCrs);
        else
        $scope.selCrsOb = selCrs;
        $scope.selectedCourse=$scope.selCrsOb.courseId;
        localStorage.setItem("attCourseId", $scope.selectedCourse);
        $scope.courseName = $scope.selCrsOb.courseName;
        httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.classList = data.Classes;
                if($scope.navCourseId){
                    for (var i = 0; i < $scope.classList.length; i++) {
                        if($scope.classList[i].classId==$scope.navClassId){
                            console.log(JSON.stringify($scope.classList[i]));
                            $scope.selectedClassOb=JSON.stringify($scope.classList[i]);
                            $scope.selectedCCId=$scope.classList[i].classCourseId;
                            $scope.courseClassSelect($scope.selectedClassOb);
                            $scope.courseName = $scope.selCrsOb.courseName;
                            $scope.className = $scope.classList[i].className;
                            break;
                        }
                    }
                }
            }
        });
    }
    $scope.selectedCId = "";
    if(localStorage.getItem("selectedCId") != undefined && localStorage.getItem("selectedCId") == "" ){
        $scope.selectedCId = localStorage.getItem("selectedCId");
    }

    $scope.courseClassSelect = function(clsOb){
        if(typeof clsOb=='string')
        $scope.selClsOb =JSON.parse(clsOb);
        else
        $scope.selClsOb = clsOb;

        console.log($scope.selClsOb);
        $scope.selectedCId = $scope.selClsOb.classId;
        localStorage.setItem("selectedCId", $scope.selectedCId);
        console.log(localStorage.getItem("selectedCId"));
        $scope.selectedCCId = $scope.selClsOb.classCourseId;
        $scope.navClassId = $scope.selClsOb.classId;
        $scope.className = $scope.selClsOb.className;
        //  alert($scope.className);

        httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionList = data.Sections;
                if ($scope.myClasses && $scope.myClasses != 'null') {
                    for (var i = 0; i < $scope.sectionList.length; i++) {
                        if($scope.sectionList[i].sectionId==$scope.navSectionId){
                            $scope.sectionOb=$scope.sectionList[i];
                            break;
                        }
                    }
                }else{
                    for (var i = 0; i < $scope.sectionList.length; i++) {
                        if($scope.sectionList[i].sectionId==$scope.sectionId) {
                            $scope.sectionOb=$scope.sectionList[i];
                            break;
                        } else if($scope.sectionId == undefined || i == $scope.sectionList.length-1){
                            $scope.sectionOb=$scope.sectionList[0];
                            break;
                        }
                    }
                }
                $scope.selectedSection=$scope.sectionOb.sectionId;
                $scope.sectionId=$scope.sectionOb.sectionId;
                $scope.sectionName=$scope.sectionOb.sectionName;
                $scope.getSectionAttendanceDetails($scope.sectionOb.sectionId,$scope.sectionOb.sectionName);
            }else{
                $scope.sectionList=[];
            }
        });
    }

    $scope.goToRegisterView = function(sectionId){
        sessionStorage.setItem("regcrsName",$scope.courseName);
        sessionStorage.setItem("regclsName",$scope.className);
        sessionStorage.setItem("regsecName",$scope.sectionName);
        sessionStorage.setItem("myClasses",$scope.myClasses);
        console.log($scope.selectedCourse);
        console.log($scope.selClsOb.classId);
        $location.path("registerView/"+$scope.sectionId+"/"+$scope.selectedCourse+"/"+$scope.selClsOb.classId);
    }


    $scope.getSectionAttendanceDetails = function(secId,name){
        $scope.secName=name;
        console.log(secId);
        $scope.sectionId = secId;
        $scope.sectionName=name;
        if(sessionStorage.getItem("regAtt")){
            sessionStorage.removeItem("regAtt");
            $scope.goToRegisterView(secId);
        }else{
            $scope.getStudentsForAttendance();
            if($scope.studentList.length > 0){
                $scope.getTotalLeaveRequestCountByDate();
                $scope.getSectionDayAttendanceReport();
                $scope.getMonthWiseAttendanceAnalysis();
                setTimeout(function() { $scope.renderChartsForSec(); }, 100);
            }
        }

    }

    $scope.getTotalLeaveRequestCountByDate = function(){
        var date = new Date();
        var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
        console.log(ndate);
        httpFactory.getResult("getTotalLeaveRequestCountByDate?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&date="+ndate, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.totalLeaveReqCount = data.totalLeaveReqCount;
            }
            else{
                $scope.totalLeaveReqCount = "-";
            }
        });
    }

    $scope.sectionAttendanceReport = {};

    $scope.todayAttendenceFlag = false;
    $scope.sectionAttendanceId = "";
    if($scope.sectionAttendanceId == ""){
        $scope.sectionAttendanceId = localStorage.getItem("sectionAttendanceId");
    }
    $scope.getSectionDayAttendanceReport = function(){
        var date = new Date();
        var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
        console.log(ndate);
        httpFactory.getResult("getSectionDayAttendanceReport?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&currentDate="+ndate, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionAttendanceReport.presentCount = data.presentCount;
                $scope.sectionAttendanceReport.lateCount = data.lateCount;
                $scope.sectionAttendanceReport.absentCount = data.absentCount;
                $scope.sectionAttendanceId = data.sectionAttendanceId;
                localStorage.setItem("sectionAttendanceId", $scope.sectionAttendanceId);
                $scope.todayAttendenceFlag = true;
            }
            else{
                $scope.sectionAttendanceReport = {};
                $scope.sectionAttendanceReport.presentCount = 0;
                $scope.sectionAttendanceReport.lateCount = 0;
                $scope.sectionAttendanceReport.absentCount = 0;
            }
        });
    }

    $scope.getTotalLeaveRequestsDetailsByDate = function(){

        var date = new Date();
        var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
        console.log(ndate);
        httpFactory.getResult("getTotalLeaveRequestsDetailsByDate?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&date="+ndate, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.studentsLeaveReq = data.studentsLeaveReq;
                $("#allLeaveRequests").modal("show");
            }
            else if (data.StatusCode == 300) {
                $scope.studentsLeaveReq=[];
                alert("No Leave Request For this section");
            }
            else{
                $scope.studentsLeaveReq = [];
                alert("Please try agian after some time");
            }
        });
        // $("#allLeaveRequests").modal("show");

        //console.log(studentsLeaveReq);
    }

    $scope.studentsMonthWiseAttendance = [];
    $scope.getMonthWiseAttendanceAnalysis = function(){
        var date = new Date();
        var ndate = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+$scope.todayDate;
        console.log(ndate);
        httpFactory.getResult("getMonthWiseAttendanceAnalysis?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&endDate="+ndate, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.overallPresent=0.0;
                $scope.overallAbsent=0.0;
                $scope.overallLate=0.0;
                $scope.attTakenCount=0;
                $scope.studentsMonthWiseAttendance = data.studentsMonthWiseAttendance;
                console.log($scope.studentsMonthWiseAttendance);
                for (var i = 0; i < $scope.studentsMonthWiseAttendance.length; i++) {
                    if($scope.studentsMonthWiseAttendance[i].attendanceTakenDays>0){
                        $scope.overallPresent= parseFloat($scope.overallPresent)+parseFloat($scope.studentsMonthWiseAttendance[i].presentPercentage);
                        $scope.overallAbsent= parseFloat($scope.overallAbsent)+parseFloat($scope.studentsMonthWiseAttendance[i].AbsentPercentage);
                        $scope.overallLate= parseFloat($scope.overallLate)+parseFloat($scope.studentsMonthWiseAttendance[i].LatePercentage);
                        $scope.attTakenCount++;
                    }
                }
                console.log($scope.overallPresent);
                $scope.overallPresent=parseFloat($scope.overallPresent/$scope.attTakenCount);
                $scope.overallAbsent=parseFloat($scope.overallAbsent/$scope.attTakenCount);
                $scope.overallLate=parseFloat($scope.overallLate/$scope.attTakenCount);

            }
            else{
                $scope.studentsMonthWiseAttendance = [];
                $scope.overallLate=0.0;
                $scope.overallPresent=0.0;
                $scope.overallAbsent=0.0;
                // alert("Please try agian after some time");
            }
        });
    }


    var chartRenderdFlag = 0;
    $scope.renderChartsForSec = function(){
        var chart1 = new CanvasJS.Chart("secAttendanceContainer", {
            theme: "",
            animationEnabled: true,
            legend:{
                cursor: "pointer",
                itemclick: explodePie
            },
            data: [{
                type: "doughnut",
                dataPoints: [
                    { y: $scope.overallPresent, name: "Present" },
                    { y: $scope.overallAbsent, name: "Absent" }
                    //          { y: $scope.overallLate, name: "Late" }

                ]
            }]
        });
        chart1.render();

        /* if(chartRenderdFlag == 0){
            chartRenderdFlag = 1;
            $scope.renderChartsForSec();
        } */
    };
    function explodePie (e) {
        if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
            e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
        } else {
            e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
        }
        e.chart1.render();
    }



    $scope.updateStudentLeaveRequest = function(slrId, isApprovedstat, techComment){

        var teachComments = "";
        if(techComment == undefined){
            teachComments = "";
        }
        var params = {
            "schemaName" :$scope.schemaName,
            "updatedBy":$scope.userId,
            "updateLeaveReq":
            [
                {
                    "studentLeaveReqId":slrId,
                    "isApproved":isApprovedstat,
                    "updatedBy":$scope.userId,
                    "teacherComments":teachComments
                }
            ]
        };
        console.log(params);
        httpFactory.executePost("updateStudentLeaveRequest", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                for(var i=0; i< $scope.studentsLeaveReq.length; i++){
                    if($scope.studentsLeaveReq[i].studentLeaveReqId == slrId){
                        $scope.studentsLeaveReq[i].isApproved = isApprovedstat;
                    }
                }

                alert("sucesfully changed");
            }
            else{

                alert("Please try agian after some time");
            }
        });

    }


    // generateCalenderAttendence

    // getStudentsForAttendance

    $scope.studentAbsentArr=[];
    //var holidayString = "1,3,5,7,9,10";
    //$scope.holidayDates = [];
    //$scope.holidayDates = holidayString.split(",");
    //console.log($scope.holidayDates);
    $scope.getStudentsForAttendance=function(){
        httpFactory.getResult("getStudentsForAttendance?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.studentList = data.studentAttendance;
                for(var i=0; i<$scope.studentList.length; i++){
                    if($scope.studentList[i].profilePic == 'NA'){
                        $scope.studentList[i].profilePicPath = "";
                    }
                    else{
                        $scope.studentList[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+$scope.studentList[i].profilePic;
                    }
                }
            }else{
                //alert("no students");
                $scope.studentList = [];
                if($scope.myClasses && $scope.myClasses!='null'){
                    sessionStorage.setItem("navCourseId",$routeParams.courseId);
                    sessionStorage.setItem("navClassId",$routeParams.classId);
                    sessionStorage.setItem("navSectionId",$routeParams.secId);
                    $location.path("/attendance");
                    // sessionStorage.setItem("myClasses","myClasses");
                    //window.history.back();
                }else{
                    //window.history.back();
                    $location.path("/attendance");
                }
            }
        });
    }
    $scope.getAbsentStudents=function(){
        httpFactory.getResult("getAbsentStudentsForAtt?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&year="+$scope.getViewYear+"&month="+$scope.getViewMonthNumber, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.absentStudentList = data.studentAttendanceArray;

            }
            else{
                $scope.absentStudentList = [];
            }
        });
        $scope.getSectionDayAttendanceReport();
    }

    $scope.selectedDateobjAbsent = "";
    $scope.selectedStuObjAbsent = "";
    $scope.selecAbsentType = "";
    $scope.selectedReasonType = "";

    $scope.checkDayLeaveObj = {
        "leaveFrom":"NA",
        "LeaveTo":"NA",
        "reason":"NA",
        "description":"NA",
        "leaveRequestStatus":"0",
    };
    $scope.checkDayLeaveFortoday = function(){
        $scope.checkDayLeaveObj = {};
        var date = new Date();
        var nmonth = date.getMonth()+1;
        if(nmonth < 10){
            nmonth = "0"+nmonth;
        }
        var ndate = date.getFullYear()+"-"+nmonth+"-"+$scope.todayDate;
        console.log(ndate);
        httpFactory.getResult("getStudentLeaveRequestInfo?schemaName="+$scope.schemaName+"&studentId="+ $scope.selectedStuObjAbsent.studentId+"&date="+ndate ,function(data){
            if(data.StatusCode == "200"){
                $scope.checkDayLeaveObj = {
                    "leaveFrom":data.leaveFrom,
                    "LeaveTo":data.LeaveTo,
                    "reason":data.reason,
                    "description":data.description,
                    "leaveRequestStatus":data.leaveRequestStatus,
                }
            }else{
                $scope.checkDayLeaveObj = {
                    "leaveFrom":"NA",
                    "LeaveTo":"NA",
                    "reason":"NA",
                    "description":"NA",
                    "leaveRequestStatus":"0",
                }
            }
        });
    }

    $scope.changeAttendenceStatus = function(status,stuAtt,stu,reason){
        if(reason!=undefined && reason!=null) {
            for(i=0;i<stuAtt.absent.length;i++) {
                if(stuAtt.absent[i].studentId==stu.studentId) {
                    $scope.selecAbsentTypeAtt.selecAbsentType = stuAtt.absent[i].attendanceType;
                    $scope.selecAbsentTypeAtt.selectedReasonType = reason;
                    break;
                }
            }
        }else {
            $scope.selecAbsentTypeAtt.selecAbsentType = status;
        }
        //		if(reason!=undefined && reason!=null)
        //	$scope.selecAbsentTypeAtt.selectedReasonType = reason;
        $scope.selectedDateobjAbsent = "";
        $scope.selectedStuObjAbsent = "";
        $scope.selectedDateobjAbsent = stuAtt;
        $scope.selectedStuObjAbsent = stu;
        $scope.checkDayLeaveFortoday();
        $scope.enterStuAttend(stuAtt,stu);
    }

    $scope.openStuAttend = function(dt,stu){
        $scope.selectedDateobjAbsent = "";
        $scope.selectedStuObjAbsent = "";
        $scope.selectedDateobjAbsent = dt;
        $scope.selectedStuObjAbsent = stu;
        $scope.checkDayLeaveFortoday();
        //	$('#assignabsent').modal('show');

    }
    $scope.updateStuAttend = function(dt,stu){
        $scope.selecAbsentType = "";
        $scope.selectedReasonType = "";
        $scope.prevAbsentType = "";
        $scope.selectedAttendanceId = 0;
        console.log(dt.absent);
        if(dt.absent != undefined && dt.absent.length > 0){
            for(var i=0; i<dt.absent.length; i++){
                if(dt.absent[i].studentId == stu.studentId){
                    $scope.selecAbsentType = dt.absent[i].attendanceType;
                    $scope.selectedReasonType = dt.absent[i].reason;
                    document.getElementById("selecUpdAbsentType").value = dt.absent[i].attendanceType;
                    document.getElementById("updReason").value = dt.absent[i].reason;
                    $scope.prevAbsentType = dt.absent[i].attendanceType;
                    $scope.selectedAttendanceId = dt.absent[i].attendanceId;
                }
            }
        }else{
            $scope.selecAbsentType = "";
            $scope.selectedReasonType = "";
            $scope.prevAbsentType = "";
            $scope.selectedAttendanceId = 0;
        }
        $scope.selectedDateobjAbsent = "";
        $scope.selectedStuObjAbsent = "";
        $scope.selectedDateobjAbsent = dt;
        $scope.selectedStuObjAbsent = stu;
        $scope.checkDayLeaveFortoday();
        //	$('#updateabsent').modal('show');
    }

    $scope.openStuAttendDayViewStatus = false;

    $scope.closeAttendanceHistory = function(){
        $("#attendanceHistory").modal("hide");
        $("#attendanceHistoryPrevDate").modal("hide");
    }
    $scope.viewAttendanceHistory = function(){
        $scope.studentAbsentArr = [];
        $scope.generateDateOfobj();
        $scope.activeRegisterView = 'monthView';
        $("#attendanceHistory").modal("show");
    }

    $scope.opensectionPrevAtt = function(dt){
        $scope.selectedPrevDateObj = dt;
        $scope.getSectionprevDayAttendanceReport(dt);
        $scope.isPrevSaveClicked = true;
        $("#attendanceHistory").modal("hide");
        $("#attendanceHistoryPrevDate").modal("show");
    }
    $scope.getSectionprevDayAttendanceReport = function(dt){
        //var date = new Date();
        $scope.udate = dt.date;
        var ndate = $scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+dt.date;
        console.log(ndate);
        httpFactory.getResult("getSectionDayAttendanceReport?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&currentDate="+ndate, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionAttendanceId = data.sectionAttendanceId;
                localStorage.setItem("sectionAttendanceId", $scope.sectionAttendanceId);
            }
        });
    }

    $scope.openStuAttendDayView = function(dt,stu){
        $scope.selectedDateobjAbsent = "";
        $scope.selectedStuObjAbsent = "";
        $scope.selectedDateobjAbsent = dt;
        $scope.selectedStuObjAbsent = stu;

        $scope.openStuAttendDayViewStatus = true;
    }
    $scope.closeDayAttView = function(){
        $scope.openStuAttendDayViewStatus = false;
    }
    $scope.selecAbsentTypeAtt = {
        "selecAbsentType":"",
        "selectedReasonType":""
    };
    $scope.enterStuAttend=function(dt,stu){
        //  if($scope.selecAbsentTypeAtt.selecAbsentType == undefined || $scope.selecAbsentTypeAtt.selecAbsentType == "" || $scope.selecAbsentTypeAtt.selectedReasonType == undefined || $scope.selecAbsentTypeAtt.selectedReasonType == ""){
        //		alert("Select Absent type and Reason both ");
        //		return true;
        //	}
        if(dt.absent==undefined || dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)==-1 && dt.sectionAttendanceId==0){
            $scope.attendanceId=0;
            $scope.prevAbsentType='';
        }else if(dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)==-1 && dt.sectionAttendanceId!=0){
            $scope.attendanceId=0;
            $scope.prevAbsentType=(dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)==-1)?'':dt.absent[dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)].attendanceType;
        }else{
            $scope.attendanceId=dt.absent[dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)].attendanceId;
            $scope.prevAbsentType=dt.absent[dt.absent.findIndex(x => x.studentId ==="" + stu.studentId)].attendanceType;
        }
        var stuAttendObj = {
            "studentId":""+stu.studentId,
            "reason":$scope.selecAbsentTypeAtt.selectedReasonType,
            "attendanceType":$scope.selecAbsentTypeAtt.selecAbsentType,
            "previousState":$scope.prevAbsentType,
            "attendanceId":$scope.attendanceId
        };
        var dtObj = $scope.generateCalenderAttendenceObj.indexOf(dt);
        $scope.todayAttendenceFlag = false;
        if($scope.selecAbsentTypeAtt.selecAbsentType == "P" && $scope.sectionAttendanceId==0){
            $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId),1);
            $scope.generateCalenderAttendenceObj[dtObj].absent.splice($scope.generateCalenderAttendenceObj[dtObj].absent.findIndex(x => x.studentId ==="" + stu.studentId),1);
            $scope.studentAbsentArr.splice(stu,1);
            //		alert("removed");
        }
        else{
            if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds == undefined || $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.length == 0){
                if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds == undefined)
                {
                    $scope.generateCalenderAttendenceObj[dtObj].absent = [];
                    $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds= [];
                }
                $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                //			alert("Added");
                $scope.studentAbsentArr.push(stuAttendObj);
            }
            else{
                if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId) == -1){
                    $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                    $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                    $scope.studentAbsentArr.push(stuAttendObj);
                    //				alert("Added");
                }else{
                    $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId),1);
                    //				$scope.generateCalenderAttendenceObj[dtObj].absent.splice($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId),1);
                    $scope.generateCalenderAttendenceObj[dtObj].absent.splice($scope.generateCalenderAttendenceObj[dtObj].absent.findIndex(x => x.studentId ==="" + stu.studentId),1);
                    $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                    $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                    $scope.studentAbsentArr.splice($scope.studentAbsentArr.findIndex(x => x.studentId ==="" + stu.studentId),1);
                    $scope.studentAbsentArr.push(stuAttendObj);
                    //				alert("updated");
                }
            }
        }
        $scope.isSaveClicked = false;
        $scope.isAttendanceTaken = true;
        $scope.isPrevSaveClicked = false;
        //	$scope.isAttendanceReasonSelected = function(dt, secStud, reason) {
        //	    const index = dt.absent.findIndex(x => x.studentId === '' + secStud.studentId);
        //	    return index !== -1 && dt.absent[index].reason === reason;
        //	}

        console.log($scope.generateCalenderAttendenceObj);

        /* var flag =contains($scope.studentAbsentArr,"studentId",stu.studentId);
        if (flag==false) {
          $scope.studentAbsentArr.push(stuAttendObj);
        }else {
          $scope.studentAbsentArr.splice($scope.AbsentarrIndex,1);
        } */
        console.log($scope.studentAbsentArr);
        $('#assignabsent').modal('hide');
        $scope.selecAbsentTypeAtt = {
            "selecAbsentType":"",
            "selectedReasonType":""
        };
        $scope.openStuAttendDayViewStatus = false;
    }


    $scope.prevAbsentType = "";
    $scope.selectedAttendanceId = "";
    $scope.updateAttendence = function(){
        //	$scope.studentAbsentArr = [];
        //	$scope.selectedReasonType = document.getElementById("updReason").value;
        //  $scope.selecAbsentType = document.getElementById("selecUpdAbsentType").value;

        //	if($scope.selecAbsentType == "P"){
        //		$scope.selectedReasonType = "NA";
        //	}

        for(i=0;i<$scope.studentAbsentArr.length;i++){
            if(($scope.studentAbsentArr[i].attendanceType=='L' && ($scope.studentAbsentArr[i].reason==undefined || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason=='')) || ($scope.studentAbsentArr[i].attendanceType=='LR' && ($scope.studentAbsentArr[i].reason==undefined  || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason==''))){
                alert("Please select reason for the attendance type 'IA' and 'L', then click on save.");
                return;
            }
            if($scope.studentAbsentArr[i].attendanceType == 'P' || $scope.studentAbsentArr[i].attendanceType=='A'){
                $scope.studentAbsentArr[i].reason = "NA";
            }
        }

        //  if($scope.selecAbsentType == undefined || $scope.selecAbsentType == "" || $scope.selectedReasonType == undefined || $scope.selectedReasonType == ""){
        //		alert("Select Absent type and Reason both ");
        //		return true;
        //	}
        //	var stuAttendObj = {
        //		"studentId":""+stu.studentId,
        //		"previousState":$scope.prevAbsentType,
        //		"attendanceId":$scope.selectedAttendanceId,
        //		"reason":$scope.selectedReasonType,
        //		"attendanceType":$scope.selecAbsentType
        //	};
        //	$scope.studentAbsentArr.push(stuAttendObj);
        var params = {
            "schemaName":$scope.schemaName,
            "sectionId":$scope.sectionId,
            "attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+$scope.selectedDateobjAbsent.date,
            "updatedBy":$scope.userId,
            "branchId":$scope.branchId,
            "totalStudents":$scope.studentList.length,
            "sectionAttendanceId":parseInt($scope.sectionAttendanceId),
            "updateRecords":$scope.studentAbsentArr
        }
        console.log(params);
        $scope.isPrevSaveClicked = true;
        $scope.isSaveClicked = true;
        httpFactory.executePost("updateSectionAttendance", params, function(data) {
            console.log(data);
            if(data.StatusCode == 200){
                /* var dtObj = $scope.generateCalenderAttendenceObj.indexOf(dt);
                if($scope.prevAbsentType == "P" || $scope.prevAbsentType == ""){
                    stuAttendObj.attendanceId = data.attendanceId;
                }

                if($scope.selecAbsentType == "P"){
                    $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId),1);
                    $scope.generateCalenderAttendenceObj[dtObj].absent.splice(stu,1);
                    $scope.studentAbsentArr.splice(stu,1);
                    alert("removed");
                }
                else{
                    if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds == undefined || $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.length == 0){
                        if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds == undefined)
                        {
                            $scope.generateCalenderAttendenceObj[dtObj].absent = [];
                            $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds= [];
                        }
                        $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                        $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                        alert("Added");
                        $scope.studentAbsentArr.push(stuAttendObj);
                    }
                    else{
                        if($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId) == -1){
                            $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                            $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                            $scope.studentAbsentArr.push(stuAttendObj);
                            alert("Added");
                        }else{
                            $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.splice($scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.indexOf(""+stu.studentId),1);
                            $scope.generateCalenderAttendenceObj[dtObj].absent.splice(stu,1);
                            $scope.generateCalenderAttendenceObj[dtObj].studentAbsentIds.push(""+stu.studentId);
                            $scope.generateCalenderAttendenceObj[dtObj].absent.push(stuAttendObj);
                            $scope.studentAbsentArr.splice(stu,1);
                            $scope.studentAbsentArr.push(stuAttendObj);
                            alert("updated");
                        }
                    }
                }
     */
                $scope.selecAbsentTypeAtt = {
                    "selecAbsentType":"",
                    "selectedReasonType":""
                };
                $scope.generateCalenderAttendence();
                console.log($scope.generateCalenderAttendenceObj);
                alert("Saved SuccessFully");
                //      $("#updateabsent").modal("hide");
                $scope.getSectionAttendanceDetails($scope.sectionId, $scope.sectionName);
            }
            else{
                alert("Please try again later");
            }

        });


    }

    function contains(arr, key, val) {
        for (var i = 0; i < arr.length; i++) {
            if(arr[i][key] == val){
                $scope.AbsentarrIndex = i;
                return true;
            }
        }
        return false;
    }
    $scope.isAttendanceTaken = true;
    $scope.isSaveClicked = false;
    $scope.saveAttendence=function(){
        for(i=0;i<$scope.studentAbsentArr.length;i++){
            if(($scope.studentAbsentArr[i].attendanceType=='L' && ($scope.studentAbsentArr[i].reason==undefined || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason=='')) || ($scope.studentAbsentArr[i].attendanceType=='LR' && ($scope.studentAbsentArr[i].reason==undefined  || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason==''))){
                alert("Please select reason for the attendance type 'IA' and 'L', then click on save.");
                return;
            }
        }
        $scope.isSaveClicked = true;
        var params = {
            "schemaName":$scope.schemaName,
            "sectionId":$scope.sectionId,
            "attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+$scope.todayDate,
            "createdBy":$scope.userId,
            "branchId":$scope.branchId,
            "totalStudents":$scope.studentList.length,
            "insertRecords":$scope.studentAbsentArr
        }
        console.log(params);
        httpFactory.executePost("insertStudentsAttendance", params, function(data) {
            console.log(data);
            if(data.StatusCode == 200){
                $scope.generateCalenderAttendence();
                $scope.isAttendanceTaken = false;
                $scope.todayAttendenceFlag = true;
                $scope.sectionAttendanceId = data.sectionAttendanceId;
                localStorage.setItem("sectionAttendanceId", data.sectionAttendanceId);
                alert("Saved SuccessFully");
                $scope.studentAbsentArr = [];
            }
            else{
                $scope.isSaveClicked = false;
                alert("Please try again later");
            }
        });

    }
    $scope.isPrevSaveClicked = false;
    $scope.savePrevAttendence=function(){
        for(i=0;i<$scope.studentAbsentArr.length;i++){
            if(($scope.studentAbsentArr[i].attendanceType=='L' && ($scope.studentAbsentArr[i].reason==undefined || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason=='')) || ($scope.studentAbsentArr[i].attendanceType=='LR' && ($scope.studentAbsentArr[i].reason==undefined  || $scope.studentAbsentArr[i].reason==null || $scope.studentAbsentArr[i].reason==''))){
                alert("Please select reason for the attendance type 'IA' and 'L', then click on save.");
                return;
            }
        }
        var params = {
            "schemaName":$scope.schemaName,
            "sectionId":$scope.sectionId,
            "attenDate":$scope.getViewYear+"-"+$scope.getViewMonthNumber+"-"+$scope.selectedPrevDateObj.date,
            "createdBy":1,
            "branchId":$scope.branchId,
            "totalStudents":$scope.studentList.length,
            "insertRecords":$scope.studentAbsentArr
        }
        console.log(params);
        $scope.isPrevSaveClicked = true;
        httpFactory.executePost("insertStudentsAttendance", params, function(data) {
            console.log(data);
            if(data.StatusCode == 200){

                $scope.isAttendanceTaken = false;
                $scope.todayAttendenceFlag = true;
                $scope.sectionAttendanceId = data.sectionAttendanceId;
                $scope.selectedPrevDateObj.sectionAttendanceId = data.sectionAttendanceId;
                $scope.generateCalenderAttendence();
                localStorage.setItem("sectionAttendanceId", data.sectionAttendanceId);
                alert("Saved SuccessFully");
                $scope.getSectionAttendanceDetails($scope.sectionId, $scope.sectionName);
            }
            else{
                alert("Please try again later");
                $scope.isPrevSaveClicked = false;
            }
        });
    }
    $scope.backMethod=function(){
        $('#allLeaveRequests').modal('hide');
    }

    $scope.backToAttendance=function(){
        if($scope.myClasses && $scope.myClasses!='null'){
            sessionStorage.setItem("navCourseId",$routeParams.courseId);
            sessionStorage.setItem("navClassId",$routeParams.classId);
            sessionStorage.setItem("myClasses","myClasses");
            $location.path("/rankrClasses");
        }else{
            sessionStorage.setItem("navCourseId",$routeParams.courseId);
            sessionStorage.setItem("navClassId",$routeParams.classId);
            window.history.back();
            //      $location.path("/attendance");
        }
    }
    $scope.goToMyClasses=function(){
        sessionStorage.setItem("navCourseId",$scope.selectedCourse);
        sessionStorage.setItem("navClassId",$scope.selClsOb.classId);
        $location.path("/rankrClasses");
    }

    $scope.nextMonthFlag = false;
    $scope.attendenceListView = [];
    $scope.weekday = new Array(7);
    $scope.weekday[0] = "Sun";
    $scope.weekday[1] = "Mon";
    $scope.weekday[2] = "Tue";
    $scope.weekday[3] = "Wed";
    $scope.weekday[4] = "Thu";
    $scope.weekday[5] = "Fri";
    $scope.weekday[6] = "Sat";
    $scope.cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $scope.getViewMonth = "";
    $scope.getViewYear = "";
    $scope.getViewMonthNumber = 0;
    $scope.generateCalenderAttendenceObj = [];
    $scope.presentMonthFlag = true;

    $scope.getCurrentAcademicYear=function(){

        httpFactory.getResult("getCurrentAcademicYear?schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {

                var startArr = data.startDate.split("-");
                var endArr = data.endDate.split("-");

                console.log(startArr);
                console.log(endArr);
                console.log(parseInt(startArr[1]));

                console.log($scope.cal_months_labels[parseInt(startArr[1])]);

                var str1 = $scope.cal_months_labels[parseInt(startArr[1])]+" "+startArr[0];
                var str2 = $scope.cal_months_labels[parseInt(endArr[1])]+" "+endArr[0];
                console.log(diff(str1, str2));
                $scope.academicMonthArr=diff(str1,str2);
                console.log($scope.academicMonthArr);
            }else{
            }
        });
    }


    function diff(from, to) {
        var arr = [];
        var datFrom = new Date('1 ' + from);
        var datTo = new Date('1 ' + to);
        var fromYear =  datFrom.getFullYear();
        var toYear =  datTo.getFullYear();
        var diffYear = (12 * (toYear - fromYear)) + datTo.getMonth();

        for (var i = datFrom.getMonth(); i <= diffYear; i++) {
            console.log(i);
            if(i>11)
            $scope.index=i-12;
            else
            $scope.index=i;

            var params= {
                "monthName":$scope.cal_months_labels[i%12],
                "monthIndex":$scope.index+1,
                "year":Math.floor(fromYear+(i/12))
            }
            arr.push(params);
        }

        return arr;
    }
    $scope.getCurrentAcademicYear();


    $scope.checkNextMonthFlag = function(year, month){
        var chckDate = new Date();
        if(year > chckDate.getFullYear() ){
            $scope.nextMonthFlag = true;
            $scope.presentMonthFlag = false;
        } else if(year == chckDate.getFullYear()){

            if(month > (chckDate.getMonth()+1)){
                $scope.nextMonthFlag = true;
                $scope.presentMonthFlag = false;
            }
            else if(month == (chckDate.getMonth()+1)){
                $scope.nextMonthFlag = false;
                $scope.presentMonthFlag = true;;
            }
            else if(month < (chckDate.getMonth()+1)){
                $scope.nextMonthFlag = false;
                $scope.presentMonthFlag = false;
            }

        } else if(year < chckDate.getFullYear()){
            $scope.nextMonthFlag = false;
            $scope.presentMonthFlag = false;
        }
    }

    $scope.goToNextMonth = function(){
        if($scope.getViewMonthNumber == 12){
            $scope.getViewMonthNumber = 1;
            $scope.getViewYear = parseInt($scope.getViewYear)+1;
            $scope.getViewMonth = $scope.cal_months_labels[0];
        }
        else{

            $scope.getViewMonth = $scope.cal_months_labels[$scope.getViewMonthNumber];
            $scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)+1;
        }
        $scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
        $scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
        $scope.generateCalenderAttendence();
        if($scope.presentMonthFlag == true) {
            $scope.monthdays =$scope.todayDate;
        } else {
            $scope.monthdays =$scope.generateCalenderAttendenceObj.length;
        }

    }

    $scope.goToBeforeMonth = function(){
        if($scope.getViewMonthNumber == 1){
            $scope.getViewMonthNumber = 12;
            $scope.getViewYear = parseInt($scope.getViewYear)-1;
            $scope.getViewMonth = $scope.cal_months_labels[11];
        }
        else{
            $scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)-1;
            $scope.getViewMonth = $scope.cal_months_labels[parseInt($scope.getViewMonthNumber)-1];
        }
        $scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
        $scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
        $scope.generateCalenderAttendence();
        if($scope.presentMonthFlag == true) {
            $scope.monthdays =$scope.todayDate;

        } else {
            $scope.monthdays =$scope.generateCalenderAttendenceObj.length;
        }
    }

    $scope.generateDateOfobj = function(){

        $scope.branchName=localStorage.getItem("bnchnme");
        if(sessionStorage.getItem("regcrsName") != undefined ){
            $scope.courseName = sessionStorage.getItem("regcrsName");
        }
        if(sessionStorage.getItem("regclsName") != undefined ){
            $scope.className = sessionStorage.getItem("regclsName");
        }
        if(sessionStorage.getItem("regsecName") != undefined ){
            $scope.sectionName = sessionStorage.getItem("regsecName");
        }
        sessionStorage.removeItem("regcrsName");
        sessionStorage.removeItem("regclsName");
        sessionStorage.removeItem("regsecName");
        var nDate = new Date();
        $scope.newDate = nDate;
        $scope.getViewMonth = $scope.cal_months_labels[nDate.getMonth()];
        $scope.getViewMonthNumber = parseInt(nDate.getMonth())+1;
        $scope.getViewYear = parseInt(nDate.getFullYear());
        $scope.checkNextMonthFlag($scope.getViewYear,$scope.getViewMonthNumber);
        $scope.generateCalenderAttendence();
        $scope.monthdays =$scope.todayDate;
    }

    $scope.generateCalenderAttendence = function(){
        console.log($scope.newDate);
        $scope.generateCalenderAttendenceObj = [];
        $scope.getStudentsForAttendance();
        if($scope.studentList.length == 0 && localStorage.getItem("RD") == 3) {
            alert("There are no Students");
            $scope.backToAttendance();
            return;
        }
        $scope.getAbsentStudents();


        var date = new Date($scope.newDate);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();


        for(var i=1; i<=lastDay+1; i++){
            var existed = false;
            for(var j=0; j<$scope.absentStudentList.length; j++){
                if(i == $scope.absentStudentList[j].day){
                    var studentAbsentIds = [];
                    for(var k=0; k<$scope.absentStudentList[j].studentList.length;k++){
                        studentAbsentIds.push($scope.absentStudentList[j].studentList[k].studentId);
                    }
                    var dayObj = {
                        "date":i,
                        "weekday":$scope.weekday[new Date(date.getFullYear(),date.getMonth(),i).getDay()],
                        "absent":$scope.absentStudentList[j].studentList,
                        "studentAbsentIds":studentAbsentIds
                    };
                    existed = true;
                    $scope.generateCalenderAttendenceObj.push(dayObj);
                }
            }
            if(existed == false){
                var dayObj = {
                    "date":i,
                    "weekday":$scope.weekday[new Date(date.getFullYear(),date.getMonth(), i ).getDay()],
                };
                $scope.generateCalenderAttendenceObj.push(dayObj);
            }
        }

        $scope.getMonthTakenDaysForAtt();
        $scope.getHolidaysForAttendance();
    }
    $scope.isTodayHoliday = false;

    $scope.checkJoiningDate = function(dt, stu) {
        var joiningDate = new Date(stu.joiningDate);
        var dateToCompare = new Date();

        dateToCompare.setDate(dt.date)
        dateToCompare.setMonth($scope.getViewMonthNumber - 1)
        dateToCompare.setFullYear($scope.getViewYear)

        joiningDate.setHours(0, 0, 0, 0);
        dateToCompare.setHours(0, 0, 0, 0);

        return joiningDate <= dateToCompare
    }

    $scope.getHolidaysForAttendance = function(){
        $scope.holidayDates=[];
        var params = {
            "schemaName":$scope.schemaName,
            "monthId":$scope.getViewMonthNumber,
            "yearId":$scope.getViewYear,
            "branchId":$scope.branchId,
            "courseId":$scope.navCourseId,
            "classId":$scope.navClassId
        };

        httpFactory.executePost("getHolidaysForStudentAttendance", params, function(data) {
            console.log(data);
            if(data.StatusCode == 200){
                $scope.holidayDates = data.holidayDates.split(',');

                if($scope.holidayDates.indexOf(""+$scope.todayDate) != -1){
                    $scope.isTodayHoliday = true;
                }
                for(var i=0; i<$scope.generateCalenderAttendenceObj.length;i++){
                    if($scope.holidayDates.indexOf(""+$scope.generateCalenderAttendenceObj[i].date) == -1){
                        $scope.generateCalenderAttendenceObj[i].isHoliday = false;
                    }
                    else{
                        $scope.generateCalenderAttendenceObj[i].isHoliday = true;
                    }
                }
            }
            else{
                for(var i=0; i<$scope.generateCalenderAttendenceObj.length;i++){
                    $scope.generateCalenderAttendenceObj[i].isHoliday = false;
                }
            }

            $scope.calculateAttendanceSummary();
        });
        console.log($scope.generateCalenderAttendenceObj);
    }



    $scope.getMonthTakenDaysForAtt = function(){
        $scope.sectionMonthAttendanceDays=[];
        httpFactory.getResult("getSectionMonthWiseAttendanceDetails?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&year="+$scope.getViewYear+"&month="+$scope.getViewMonthNumber, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionMonthAttendanceDays = data.sectionMonthAttendanceDays;

                for(var i=0; i<$scope.generateCalenderAttendenceObj.length; i++){
                    var found= 0;
                    for(var j=0; j<$scope.sectionMonthAttendanceDays.length; j++){
                        if($scope.generateCalenderAttendenceObj[i].date == $scope.sectionMonthAttendanceDays[j].attendaceDay){
                            $scope.generateCalenderAttendenceObj[i].sectionAttendanceId = $scope.sectionMonthAttendanceDays[j].sectionAttendanceId;
                            found++;
                        }
                    }
                    if(found ==0){
                        $scope.generateCalenderAttendenceObj[i].sectionAttendanceId = 0;
                    }
                }

            }else{
                for(var i=0; i<$scope.generateCalenderAttendenceObj.length; i++){
                    $scope.generateCalenderAttendenceObj[i].sectionAttendanceId = 0;
                }
            }

            console.log($scope.generateCalenderAttendenceObj);
        });

    }


    $scope.activeRegisterView = 'todayView';
    $scope.changeDayView = function(dview){
        if(dview == 'todayView'){
            $scope.generateDateOfobj();
        }
        $scope.activeRegisterView = dview;
    }

    $scope.sendSms = function(tag){
        var params = {
            "sectionId":$scope.sectionId,
            "schemaName":$scope.schemaName,
            "branchId":$scope.branchId
        }
        if (tag=="sms") {
            params["SMSNotification"]=1;
        }else if(tag=="push"){
            params["pushNotification"]=1;
        }else if(tag=="whatsAppE"){
            params["whatsApp"]=1;
            params["lang"]="en";
        }else if(tag=="whatsAppT"){
            params["whatsApp"]=1;
            params["lang"]="te";
        }else if(tag=="whatsAppH"){
            params["whatsApp"]=1;
            params["lang"]="hi";
        }
        console.log(params);
        httpFactory.executePost("sendStudentAttendanceNotification", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            }
            else{
                alert(data.MESSAGE);
            }
        });
    }


    $scope.absentStudentListFoMonth = [];
    $scope.getAbsentStudentsForMonth = function(montyer){
        var montyerObj = montyer.split("-");
        httpFactory.getResult("getAbsentStudentsForAtt?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&year="+montyerObj[0]+"&month="+montyerObj[1], function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.absentStudentListFoMonth = data.studentAttendanceArray;
            }
            else{
                $scope.absentStudentListFoMonth = [];
            }
        });
    }
    $scope.getStudentsForAttendanceForExcel=function(){
        httpFactory.getResult("getStudentsForAttendance?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.studentListExcel = data.studentAttendance;
                for(var i=0; i<$scope.studentListExcel.length; i++){
                    if($scope.studentListExcel[i].profilePic == 'NA'){
                        $scope.studentListExcel[i].profilePicPath = "";
                    }
                    else{
                        $scope.studentListExcel[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+$scope.studentList[i].profilePic;
                    }
                }
            }else{

                $scope.studentListExcel = [];
            }
        });
    }

    $scope.monAttendanceDaysTaken = [];
    $scope.getMonthTakenDaysForAttExcel = function(montyer){
        var montyerObj = montyer.split("-");
        httpFactory.getResult("getSectionMonthWiseAttendanceDetails?sectionId="+$scope.sectionId+"&schemaName="+$scope.schemaName+"&year="+montyerObj[0]+"&month="+montyerObj[1], function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.monAttendanceDaysTaken = data.sectionMonthAttendanceDays;
            }
        });
    }

    $scope.excelReportFields = {
        studentName:'Student Name',
        rollNumber:'Roll Number',
        i:' ',
        day1:'01',
        day2:'02',
        day3:'03',
        day4:'04',
        day5:'05',
        day6:'06',
        day7:'07',
        day8:'08',
        day9:'09',
        day10:'10',
        day11:'11',
        day12:'12',
        day13:'13',
        day14:'14',
        day15:'15',
        day16:'16',
        day17:'17',
        day18:'18',
        day19:'19',
        day20:'20',
        day21:'21',
        day22:'22',
        day23:'23',
        day24:'24',
        day25:'25',
        day26:'26',
        day27:'27',
        day28:'28',
        day29:'29',
        day30:'30',
        day31:'31',
        O:' ',
        i:' ',
        Present:'Present',
        Absent:'Absent',
        Late:'Late',
        LeaveRequest:'Leave Request',
        AttendanceNotTaken:'Attendance Not Taken',
        AttendanceNotJoinedYet:'Attendance Not Joined Yet',
        Holiday:'Holiday'
    };

    $scope.generateExcelAttendence = function(montyer){
        $scope.getStudentsForAttendanceForExcel();
        $scope.getAbsentStudentsForMonth(montyer);
        $scope.getMonthTakenDaysForAttExcel(montyer);

        var montyerdate = montyer.split('-');
        var date = new Date(montyerdate[0],parseInt(montyerdate[1]),0);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();

        var attendenceStatus= {};
        $scope.studentListExcelData=[];
        for(var k=0; k< $scope.studentListExcel.length; k++){
            for(var i=1; i<=lastDay+1; i++){
                var fnd = false;
                if(k==0) {
                    attendenceStatus["day"+i]=$scope.weekday[new Date(date.getFullYear(),date.getMonth(), i ).getDay()];
                }
                for(var m =0; m<$scope.monAttendanceDaysTaken.length;m++){
                    if(i == $scope.monAttendanceDaysTaken[m].attendaceDay){
                        fnd = true;
                        var existed = false;
                        for(var j=0; j<$scope.absentStudentListFoMonth.length; j++){
                            if(i == $scope.absentStudentListFoMonth[j].day){
                                for(var l =0; l<$scope.absentStudentListFoMonth[j].studentList.length;l++){
                                    if($scope.studentListExcel[k].studentId == $scope.absentStudentListFoMonth[j].studentList[l].studentId){
                                        $scope.studentListExcel[k]["day"+i] = $scope.absentStudentListFoMonth[j].studentList[l].attendanceType;
                                        existed = true;
                                    }
                                }
                            }
                        }
                        if(existed == false){
                            if(!$scope.checkJoiningDate({date: i}, $scope.studentListExcel[k])){
                                $scope.studentListExcel[k]["day"+i] = "NJY";
                            } else
                            $scope.studentListExcel[k]["day"+i] = "P";
                        }
                    }
                }
                if(fnd == false && (i+1 <= $scope.todayDate) && ($scope.presentMonthFlag == true)|| fnd == false && $scope.presentMonthFlag == false ){
                    if(!$scope.checkJoiningDate({date: i}, $scope.studentListExcel[k])){
                        $scope.studentListExcel[k]["day"+i] = "NJY";
                    } else
                    $scope.studentListExcel[k]["day"+i] = "NT";
                }
                for(var a = 0; a < $scope.holidayDates.length; a++) {
                    if(i==$scope.holidayDates[a]) {
                        $scope.studentListExcel[k]["day"+i] = "H";
                    }
                }
            }
            for(var a = $scope.generateCalenderAttendenceObj.length - 7; a < $scope.generateCalenderAttendenceObj.length; a++) {
                for(var b = 0; b <  $scope.generateCalenderAttendenceObj[a].studentList.length; b++) {
                    if($scope.studentListExcel[k].studentId == $scope.generateCalenderAttendenceObj[a].studentList[b].studentId) {
                        if($scope.generateCalenderAttendenceObj[a].date == "P") {
                            $scope.studentListExcel[k]["Present"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "L") {
                            $scope.studentListExcel[k]["Late"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "A") {
                            $scope.studentListExcel[k]["Absent"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "LR") {
                            $scope.studentListExcel[k]["LeaveRequest"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "NT") {
                            $scope.studentListExcel[k]["AttendanceNotTaken"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "NJY") {
                            $scope.studentListExcel[k]["AttendanceNotJoinedYet"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        } else if($scope.generateCalenderAttendenceObj[a].date == "H") {
                            $scope.studentListExcel[k]["Holiday"] = $scope.generateCalenderAttendenceObj[a].studentList[b].noOfDays;
                        }
                    }
                }
            }
            if(k==0) {
                attendenceStatus['Present']='P';
                attendenceStatus['Absent']='A';
                attendenceStatus['Late']='L';
                attendenceStatus['LeaveRequest']='LR';
                attendenceStatus['AttendanceNotTaken']='NT';
                attendenceStatus['AttendanceNotJoinedYet']='NJY';
                attendenceStatus['Holiday']='H';

                $scope.studentListExcelData.push(attendenceStatus);
            }
            $scope.studentListExcelData.push($scope.studentListExcel[k]);
        }
        setTimeout(function(){$("#monthExcelBtn").click();}, 1000);
    }

    $scope.calculateAttendanceSummary=function(){
        let studentAbsentList = [];
        let studentLateList = [];
        let studentLvReqList = [];
        let studentPresentList = [];
        let studentNottakenList = [];
        let studentNotJoinedList = []
        let holiday = [];
        let student = [];

        let presentStudList, absentStudList, lateStudList, leaveReqStudList ,notTakenStudList ,holidayList, notJoinedStudList = {};
        if($scope.sectionMonthAttendanceDays.length==0)
            return;
        let NTcountTmp = $scope.monthdays - $scope.sectionMonthAttendanceDays.length;
        if($scope.presentMonthFlag == true) {
            for(i = 0; i < $scope.holidayDates.length; i++) {
                if($scope.todayDate>Number($scope.holidayDates[i]))
                NTcountTmp--;
            }
        }else {
            NTcountTmp-=$scope.holidayDates.length;
        }

        for(let i=0; i<$scope.studentList.length; i++) {
            let NTcount = NTcountTmp
            let  Hcount = 0 ,Lcount = 0, Acount = 0, LRcount = 0, Pcount = $scope.generateCalenderAttendenceObj.length, NJYcount = 0;
            for(let j=0; j<$scope.generateCalenderAttendenceObj.length; j++) {
                if(!$scope.checkJoiningDate($scope.generateCalenderAttendenceObj[j],$scope.studentList[i])){
                    Pcount--;
                    if(!$scope.generateCalenderAttendenceObj[j].isHoliday==true)
                        NJYcount++;
                    if($scope.generateCalenderAttendenceObj[j].sectionAttendanceId === 0)
                        NTcount--;
                    continue;
                }
                if($scope.generateCalenderAttendenceObj[j].isHoliday && $scope.generateCalenderAttendenceObj[j].sectionAttendanceId > 0) {
                    Pcount--;
                    if($scope.generateCalenderAttendenceObj[j].date != $scope.todayDate)
                        NTcount++;
                    continue;

                }
//                if($scope.presentMonthFlag == true && i == 0 && $scope.generateCalenderAttendenceObj[j].isHoliday && $scope.generateCalenderAttendenceObj[j].sectionAttendanceId == 0) {
//                    NTcount++;
//                }
                if($scope.presentMonthFlag == true && $scope.generateCalenderAttendenceObj[j].date == $scope.todayDate && $scope.generateCalenderAttendenceObj[j].sectionAttendanceId == 0){
                    NTcount--;
                }
                if($scope.generateCalenderAttendenceObj[j].hasOwnProperty('absent')) {
                    for(let k=0;k<$scope.generateCalenderAttendenceObj[j].absent.length;k++) {
                        if($scope.studentList[i].studentId == $scope.generateCalenderAttendenceObj[j].absent[k].studentId) {
                            if($scope.generateCalenderAttendenceObj[j].absent[k].attendanceType=="L" && $scope.generateCalenderAttendenceObj[j].isHoliday==false) {
                                Lcount++;
                            } else if($scope.generateCalenderAttendenceObj[j].absent[k].attendanceType=="A" && $scope.generateCalenderAttendenceObj[j].isHoliday==false) {
                                Acount++;
                            } else if($scope.generateCalenderAttendenceObj[j].absent[k].attendanceType=="LR" && $scope.generateCalenderAttendenceObj[j].isHoliday==false) {
                                LRcount++;
                            }
                            Pcount--;
                        }
                    }
                }else if($scope.generateCalenderAttendenceObj[j].sectionAttendanceId == 0 || $scope.generateCalenderAttendenceObj[j].isHoliday==true) {
                    Pcount--;
                }
            }

            Hcount = $scope.holidayDates.length;
            presentStudList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":Pcount,
            };
            absentStudList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":Acount,
            };
            lateStudList =  {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":Lcount,
            };
            leaveReqStudList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":LRcount,
            };
            notTakenStudList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":NTcount <= 0 ? 0 : NTcount,
            };
            notJoinedStudList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":NJYcount,
            };
            holidayList = {
                "studentId":$scope.studentList[i].studentId,
                "noOfDays":Hcount,
            };
            studentAbsentList.push(absentStudList);
            studentLateList.push(lateStudList);
            studentLvReqList.push(leaveReqStudList);
            studentPresentList.push(presentStudList);
            studentNottakenList.push(notTakenStudList);
            studentNotJoinedList.push(notJoinedStudList);
            holiday.push(holidayList);
        }
        let allsum = {
            "date":" ",
            "studentList":student
        };
        let allsumP = {
            "date":"P",
            "studentList":studentPresentList
        };
        let allsumA = {
            "date":"A",
            "studentList":studentAbsentList
        };
        let allsumL = {
            "date":"L",
            "studentList":studentLateList
        };
        let allsumLR = {
            "date":"LR",
            "studentList":studentLvReqList
        };
        let allsumNT = {
            "date":"NT",
            "studentList":studentNottakenList
        };
        let allsumNJY = {
            "date":"NJY",
            "studentList":studentNotJoinedList
        };
        let allsumH = {
            "date":"H",
            "studentList":holiday
        };
        $scope.generateCalenderAttendenceObj.push(allsum);
        $scope.generateCalenderAttendenceObj.push(allsumP);
        $scope.generateCalenderAttendenceObj.push(allsumA);
        $scope.generateCalenderAttendenceObj.push(allsumL);
        $scope.generateCalenderAttendenceObj.push(allsumLR);
        $scope.generateCalenderAttendenceObj.push(allsumNT);
        $scope.generateCalenderAttendenceObj.push(allsumNJY);
        $scope.generateCalenderAttendenceObj.push(allsumH);
    }
    $scope.goToDashbord = function(){
        $location.path("rankrPlus");
    }

    $scope.markAttendence = function(studentid, attType){
        for(i = 0; i < $scope.studentList.length; i++) {
            if(studentid == $scope.studentList[i].studentId) {
                if(attType == 'present') {
                    document.getElementById("presentDiv").style.background = "green";
                }
            }

        }

    }

    $scope.attendance=function(){
        if($scope.selectedDateobjAbsent.sectionAttendanceId==0 || $scope.selectedDateobjAbsent.sectionAttendanceId==undefined)
        $scope.saveAttendence();
        else
        $scope.updateAttendence();
    }

    $scope.prevAttendance=function(){
        if($scope.selectedDateobjAbsent.sectionAttendanceId==0)
        $scope.savePrevAttendence();
        else
        $scope.updateAttendence();
    }
    //
    //	$scope.uninformedAbsent = function(){
    //		if(document.getElementById("uninformedAbsent").innerHTML == 'UA') {
    //			document.getElementById("uninformedAbsent").style.background = "#D9534F";
    //		}
    //
    //	}

});
