projectModule.controller('profileController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {
$scope.$ = $;
$scope.instituteId = 1;
$scope.Math = window.Math;
$scope.userSession = sessionStorage.getItem("userSession");
$scope.userId=localStorage.getItem("userId");
$scope.TuserId=localStorage.getItem("TuserId");
$scope.roleId=localStorage.getItem('RD');
// sessionStorage.removeItem("userSession");
var requestParams = {
  "m_inst_id": $scope.instituteId
};
$scope.schemaName=localStorage.getItem("sname");
$scope.sectionName=localStorage.getItem("stsecnme");
if ($routeParams.stuId) {
  $scope.studentId = $routeParams.stuId;
}else{
  $scope.studentId = localStorage.getItem("stuid");
}

if($routeParams.userId){
	$scope.teacherId = $routeParams.userId;
	$scope.teacherRoleId=$routeParams.roleId;
	$scope.teacherBranchId=$routeParams.branchId;
}
else{
$scope.teacherId =$scope.TuserId;
$scope.teacherRoleId=localStorage.getItem("RD");
$scope.teacherBranchId=localStorage.getItem("bnchId");

}


$scope.logRoleId = $routeParams.roleId;
$scope.logRD = localStorage.getItem("RD");

console.log($scope.logRoleId);
console.log($scope.logRD);


$scope.profileEdit = function(){
  if($scope.userSession=="student"){
    $scope.userDetailsForProfile();
    $scope.getStudentOverallAttendance();
    $scope.getStudentOverallHWForAnalysis();
    $scope.getStudentTestCountForAnalysis();
  }
//  else if($scope.userSession=="admin"){
//    $scope.userDetailsForProfile();
//  }else if($scope.userSession=="teacher"){
//    $scope.userDetailsForProfile();
//  }
  else{
   $scope.userDetailsForProfile();

  }
}
$scope.teacherProfileInit=function(){
	$scope.teacherDetailsForProfile();
}
$scope.goToExamLogs=function(){
  $location.path("stuExmLog");
}
$scope.goToAttendance=function(){
  sessionStorage.setItem("profnav","att");
  sessionStorage.setItem("profuserid",$scope.teacherId);
  sessionStorage.setItem("profroleid",$scope.teacherRoleId);
  sessionStorage.setItem("profbranchid",$scope.teacherBranchId);
  
  if($routeParams.userId)
  $location.path("teacherRankrPlus");
  else
  $location.path("rankrPlus");

}
$scope.goToHomework=function(){
  sessionStorage.setItem("stuNav","hw");
  $location.path("mySchool");
}
$scope.goToReportCard=function(){
  sessionStorage.setItem("stuNav","rpt");
  $location.path("mySchool");
}
$scope.userDetailsForProfile = function(){
	
  httpFactory.getResult("userDetailsForProfile?userId="+$scope.teacherId+"&roleId="+$scope.teacherRoleId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.profileData = data;
    $scope.profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/userProfileDownload?filePath="+$scope.profileData.profilePic;
		} else {
		}
	});
}

$scope.teacherDetailsForProfile = function(){
	
	  httpFactory.getResult("userDetailsForProfile?userId="+$scope.teacherId+"&roleId="+$scope.teacherRoleId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
			$scope.profileData = data;
	    $scope.profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/userProfileDownload?filePath="+$scope.profileData.profilePic;
			} else {
			}
		});
	}
$scope.getStaffOverallAttendance=function(){
	httpFactory.getResult("getStaffOverallAttendance?schemaName="+$scope.schemaName+"&userId="+$scope.teacherId+"&branchId="+$scope.teacherBranchId, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
//			$scope.presentDaysPerc = data.staffPresentDaysPercentage;
//			$scope.attedanceTakenDays = data.attendanceTakenDays;
//			$scope.staffLeaves=data.staffLeaves;
//			$scope.staffPresentDays=data.staffPresentDays;
			$scope.staffAttData=data;
		}else if (data.StatusCode == 300){
      $scope.staffAttData = {
        "workingDays":data.workingDays,
        "attendanceTakenDays":data.attendanceTakenDays
      }
    }else {
			console.log("Error getting Staff attendance");
		}
		console.log($scope.staffYearWiseAttendanceData);
	});
	//$scope.getSectionDayAttendanceReport();
}
$scope.getStaffOverallAttendance();

$scope.changePwdModal=function(){
  $("#changePwdModal").modal("show");
}

$scope.resetStudentPassword=function(){
   httpFactory.getResult("resetUserPassword?userId="+$scope.teacherId+"&schemaName="+$scope.schemaName+"&updatedBy="+$scope.userId, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       alert("Password resetted to 'Welcome123$'");
     } else {
       alert("Please try again!");
     }
   });
}


$scope.changePassword=function(){
  var params={
    "loginName":$scope.profileData.loginName,
    "oldPassword":$scope.oldPwdVal,
    "newPassword":$scope.newPwdVal,
    "schemaName":$scope.schemaName,
    "updatedBy":$scope.teacherId
  }
  httpFactory.executePost("changeStudentPassword", params, function(data) {
		console.log(data);
  	if (data.STATUS == 'SUCCESS') {
  		alert(data.MESSAGE);
  		$("#changePwdModal").modal("hide");
  	}
  	else{
  	}
  });
}

$scope.changeUserPassword=function(){
	  var params={
	    "loginId":$scope.profileData.loginName,
	    "oldPassword":$scope.oldPwdVal,
	    "newPassword":$scope.newPwdVal,
	    "schemaName":$scope.schemaName,
	    "updatedBy":$scope.teacherId
	  }
	  
	  console.log(params);
	  httpFactory.executePost("changePassword", params, function(data) {
			console.log(data);
	  	if (data.STATUS == 'SUCCESS') {
	  		alert(data.MESSAGE);
	  		$("#changePwdModal").modal("hide");
	  	}
	  	else{
	  	}
	  });
	}

$scope.getStudentOverallAttendance = function(){
  $scope.studentAttendance=[];
  httpFactory.getResult("getStudentOverallAttendance?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentAttendance = data;
        $scope.stuAtt = (($scope.studentAttendance.wokingDays - $scope.studentAttendance.studentLeaves)/$scope.studentAttendance.wokingDays)*100;
		} else {
      $scope.studentAttendance=[];
		}
	});
}

$scope.getStudentOverallHWForAnalysis = function(){
  $scope.studentHomeWorks=[];
  httpFactory.getResult("getStudentOverallHWForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentHomeWorks = data;
        console.log($scope.studentHomeWorks);
		} else {
      $scope.studentHomeWorks=[];
      var obj = {
        "completedHW": 0,
        "pendingHW": 0,
        "totalHW": 0
      }
      $scope.studentHomeWorks=obj;
		}
	});
}
$scope.getStudentTestCountForAnalysis = function(){
  httpFactory.getResult("getStudentTestCountForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentTests = data;
		} else {
      $scope.studentTests=[];
      var obj = {
        "testCompleted": 0
      }
      $scope.studentTests=obj;
		}
	});
}

$scope.goToHomework=function(){
  $location.path("teacherHw/"+$scope.profileData.userId+"/"+$scope.profileData.branch_id);
}
$scope.getTeacherClassSectionSubjects=function(){
  httpFactory.getResult("getTeacherClassSectionSubjects?userId=" + $scope.teacherId + "&schemaName=" + localStorage.getItem("sname"), function(data) {
    console.log(data);
      if (data.StatusCode == 200) {
      $scope.teacherSubj = data.userClassSubjects;
      console.log($scope.teacherSubj);
    } else {
      alert("You are not assigned to any classes assigned");
      $location.path("rankrPlus");
      // alert('No Branches Defined')
    }
  });
}
$scope.homeWorkMethodsCalling=function(){
  $scope.getTeacherHomeWorks();
  $scope.selectStudentsBySection();
}

$scope.courseSelect=function(teacherCrs){
  $scope.courseOb=JSON.parse(teacherCrs);
  console.log($scope.selectedCourse);
  $scope.courseId=$scope.courseOb.courseId;
  $scope.selCourse = $scope.courseOb.courseName;
  $scope.classList=$scope.courseOb.Classes;
}

  $scope.classSelect=function(cls){
    console.log($scope.classOb);
    $scope.classOb = JSON.parse(cls);
    console.log($scope.selectedClasOb);
    $scope.classId=$scope.classOb.classId;
    $scope.selClass = $scope.classOb.className;
    $scope.sectionList=$scope.classOb.Sections;
    $scope.rpSectionId=$scope.sectionList[0].sectionId;
    $scope.sectionSelected($scope.sectionList[0]);
    }

  $scope.sectionSelected=function(section){
    console.log(section);
    $scope.subjList=[];
    $scope.subjList=section.Subjects;
    console.log($scope.subjList);
    $scope.selectedSectionOb=section;
    $scope.rpSectionId=$scope.selectedSectionOb.sectionId;
    $scope.rpSectionName=$scope.selectedSectionOb.sectionName;
    console.log($scope.rpSectionName);
    $scope.homeWorkMethodsCalling();
  }

$scope.getTeacherHomeWorks=function(){
  $scope.homeWorks=[];
  var date=new Date();
  var	year = date.getFullYear();
  var month = date.getMonth()+1;
  httpFactory.getResult("getTeacherHomeWorks?branchId="+$scope.teacherBranchId+"&sectionId="+$scope.rpSectionId+"&schemaName="+$scope.schemaName+"&monthId="+month+"&yearId="+year+"&userId="+$routeParams.userId, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.homeWorks = data.homeWorkDetails;
      console.log($scope.homeWorks);
      $scope.homeIndex=0;
    }else{
      $scope.homeWorks=[];
      alert("No Homeworks");
    }
  });
}
$scope.selectStudentsBySection = function(){
  httpFactory.getResult("selectStudentsBySection?sectionId="+$scope.rpSectionId+"&branchId="+$scope.teacherBranchId+"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.studentListHW=data.sectionStudents;
      $("#subjectModal").modal("hide");
  }else{
    $scope.studentListHW=[];
  }
  });
}

$scope.uploadUserProfile = function(){
  var files = document.getElementById("ProfileFile").files;
  if(files[0] == undefined){
    return true;
  }
  console.log(files);
  var fd = new FormData();
  
  fd.append("userId", $scope.teacherId);
  fd.append("schemaName",$scope.schemaName)
  fd.append("file", files[0]);


  httpFactory.executeFileUpload("uploadUserProfilePic", fd, function(data) {
    console.log(data);
    if (data.StatusCode== '200') {
      $scope.userDetailsForProfile();
    //  $route.reload();
    }else{
      alert("Please upload an image");
    }

    document.getElementById("ProfileFile").value = "";
  //	$scope.downLoadHw();
  });
}

$scope.editBranchProfile = function(){
	$scope.getBranchDetails();
	$scope.branchName = $scope.branchDetails.branchName;
	$scope.branchAddress = $scope.branchDetails.branchAddress;
	$("#editBranchProfile").modal("show");
}

$scope.getBranchDetails = function(){
	httpFactory.getResult("getBranchDetails?schemaName="+$scope.schemaName+"&branchId="+$scope.teacherBranchId, function(data) {
    	console.log(data);
    	if (data.statusCode == 200) {
      		$scope.branchDetails = data.data;
  		}else{
    
  		}
  	});
}

$scope.updateBranchDetails = function(){
	var fd = new FormData();
	if($scope.branchName != $scope.branchDetails.branchName){
		fd.append("branchName", $scope.branchName);
		$scope.brName = true;
	}
	if($scope.branchAddress != $scope.branchDetails.branchAddress){
		fd.append("branchAddress", $scope.branchAddress);
		$scope.brAddress = true;
	}
	if(document.getElementById("logo").files.length != 0){
		var logo = document.getElementById("logo").files;
		fd.append("logo", logo[0]);
		$scope.brLogo = true;
	}
	if(document.getElementById("signature").files.length != 0){
		var signature = document.getElementById("signature").files;
		fd.append("signature", signature[0]);
		$scope.brSignature = true;
	}
	if($scope.brName || $scope.brAddress || $scope.brLogo || $scope.brSignature){
		fd.append("branchId", $scope.teacherBranchId);
  		fd.append("schemaName",$scope.schemaName);
  		httpFactory.executeFileUpload("updateBranchDetails", fd, function(data) {
    		console.log(data);
    		if (data.StatusCode== '200') {
      			alert("Details Updated Successfully");
      			$("#editBranchProfile").modal("hide");
    		}else{
      			alert("Error while updating");
    		}
    		document.getElementById("logo").value = "";
    		document.getElementById("signature").value = "";
  		});
	}else{
		alert("Nothing Changed");
	}
}

});
