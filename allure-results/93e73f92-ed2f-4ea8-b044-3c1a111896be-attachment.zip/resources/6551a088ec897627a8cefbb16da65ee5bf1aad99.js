/**
* Wordfind.js 0.0.1
* (c) 2012 Bill, BunKat LLC.
* Wordfind is freely distributable under the MIT license.
* For all details and documentation:
*     https://github.com/bunkat/wordfind
*/

projectModule.controller('matchingPuzzuleController', function($scope, $location, $timeout, $routeParams, httpFactory) {
  $scope.$ = $;
  $scope.matchingArray = [{
	  "column1":"Citric Acid",
	  "column2":"Tamarind"
  },
  {
	  "column1":"Olfactory Acid",
	  "column2":"Substance smell varies with Acid and Base"
  },
  {
	  "column1":"Olfactory Indicator",
	  "column2":"Vanila"
  },
  {
	  "column1":"Hclo3",
	  "column2":"Strong Acid"
  },
  {
	  "column1":"HCo2H",
	  "column2":"Weak Acid"
  },
  {
	  "column1":"Reason behind Cake Bulge",
	  "column2":"Baking Powder undergoes Chemical Reaction during which Carbon Dioxide gas is produced"
  },
  {
	  "column1":"Example for Chemical Reaction",
	  "column2":"Rotten Banana"
  },
  {
	  "column1":"Gypsum",
	  "column2":"Hydrated Calcium Sulphate"
  },
  {
	  "column1":"Why Tap Water conducts Electricity",
	  "column2":"Because of Dissolved Salts In it"

  }
  , {
	  "column1":"Action of Dilute Hydrochloric Acid + Sodium Hydroxide",
	  "column2":"HCl+ NaOH ==>>NaCl + H2O"
  },
  {
	  "column1":"Action of Dilute Hydrochloric Acid + Magnesium Ribbon",
	  "column2":"Mg(s) + 2 HCl(aq) --> MgCl 2(aq) + H 2(g) "

  }
  ,
  {
	  "column1":"Dilute Hydrochloric Acid + Crushed Egg Shells",
	  "column2":"2HCl+ CaCO3 CaCl2 + CO2 + H2O"

  }
  ];

  $scope.tempArr =[{
	  "column1":"Citric Acid",
	  "column2":"Tamarind"
  },
  {
	  "column1":"Olfactory Acid",
	  "column2":"Substance smell varies with Acid and Base"
  },
  {
	  "column1":"Olfactory Indicator",
	  "column2":"Vanila"
  },
  {
	  "column1":"Hclo3",
	  "column2":"Strong Acid"
  },
  {
	  "column1":"HCo2H",
	  "column2":"Weak Acid"
  },
  {
	  "column1":"Reason behind Cake Bulge",
	  "column2":"Baking Powder undergoes Chemical Reaction during which Carbon Dioxide gas is produced"
  },
  {
	  "column1":"Example for Chemical Reaction",
	  "column2":"Rotten Banana"
  },
  {
	  "column1":"Gypsum",
	  "column2":"Hydrated Calcium Sulphate"
  },
  {
	  "column1":"Why Tap Water conducts Electricity",
	  "column2":"Because of Dissolved Salts In it"
  },
  {
	  "column1":"Action of Dilute Hydrochloric Acid + Sodium Hydroxide",
	  "column2":"HCl+ NaOH ==>>NaCl + H2O"
  },
  {
	  "column1":"Action of Dilute Hydrochloric Acid + Magnesium Ribbon",
	  "column2":"Mg(s) + 2 HCl(aq) --> MgCl 2(aq) + H 2(g) "
  }
  ,
  {
	  "column1":"Dilute Hydrochloric Acid + Crushed Egg Shells",
	  "column2":"2HCl+ CaCO3 CaCl2 + CO2 + H2O"
  }
  ];

  function shuffle(array) {
	  var currentIndex = array.length, temporaryValue, randomIndex;
	  // While there remain elements to shuffle...
	  while (0 !== currentIndex) {

	    // Pick a remaining element...
	    randomIndex = Math.floor(Math.random() * currentIndex);
	    currentIndex -= 1;

	    // And swap it with the current element.
	    temporaryValue = array[currentIndex];
	    array[currentIndex] = array[randomIndex];
	    array[randomIndex] = temporaryValue;
	  }

	  return array;
	}
  $scope.shuffledArr=[];
  $scope.shuffledArr = shuffle($scope.tempArr);
//  	$scope.shuffledArr=$scope.tempArr;
  	console.log($scope.shuffledArr);
  	console.log($scope.matchingArray);


  $scope.matchInit=function(){
	  for(var i=0;i<$scope.matchingArray.length;i++){
		$scope.matchingArray[i]["selected"]=false;
	  }

	  for(var i=0;i<$scope.shuffledArr.length;i++){
			$scope.shuffledArr[i]["selected"]=false;
		  }
  }

  $scope.matchInit();

  $scope.totalCorrectAttempts = 0;
  $scope.totalWrongAttempts = 0;

  $scope.matchIndex=-1;
  $scope.shuffleIndex=-1;

  $scope.matchArr = [];
  $scope.CompletedStatus =  false;
  $scope.column1Click=function(match,index,tag){
	  console.log(match);

	  console.log($scope.matchIndex);
	  console.log($scope.shuffleIndex);

	  if(tag=='m'){
		  $scope.matchIndex = index;
      //$scope.matchingArray[$scope.matchIndex].selected=true;

	  }
	  else if(tag=='s'){
		  $scope.shuffleIndex=index;
      //$scope.shuffledArr[$scope.shuffleIndex].selected=true;
	  }
	  console.log($scope.matchIndex);
	  console.log($scope.shuffleIndex);
//	  alert($scope.matchIndex);
//	  alert($scope.shuffleIndex);
	  if($scope.shuffleIndex>=0 && $scope.matchIndex>=0){

		  console.log($scope.matchIndex);
		  console.log($scope.shuffleIndex);

//		  alert($scope.matchArr.length);
		  console.log($scope.matchArr);
		  if($scope.matchArr.length>0){
			  console.log($scope.matchArr[0].column1);
			  console.log(match.column1);

			  if($scope.matchArr[0].column1 == match.column1){
              $scope.totalCorrectAttempts++;
				     $scope.shuffledArr[$scope.shuffleIndex].selected=true;
				     $scope.matchingArray[$scope.matchIndex].selected=true;
             //$scope.shuffledArr[$scope.shuffleIndex].answered=true;
				     //$scope.matchingArray[$scope.matchIndex].answered=true;
             $scope.shuffledArr.splice($scope.shuffleIndex,1);
				     $scope.matchingArray.splice($scope.matchIndex,1);


				  console.log($scope.shuffledArr);
				  console.log($scope.matchingArray);
				  $scope.matchArr=[];
				  $scope.matchIndex=-1;
				  $scope.shuffleIndex=-1;
          if($scope.shuffledArr.length == 0 && $scope.matchingArray.length == 0){
            $scope.CompletedStatus = true;
          }
			  }else{
          $scope.totalWrongAttempts++;
				  $scope.matchArr=[];
				  $scope.matchIndex=-1;
				  $scope.shuffleIndex=-1;
				  alert("wrong");
			  }

		  }else{
			  $scope.matchIndex=-1;
			  $scope.shuffleIndex=-1;
		  }
	  }else{
		  if($scope.matchArr.length==0){
		  $scope.matchArr.push(match);
		  }
		  else{
			  $scope.matchArr=[];
			  $scope.matchIndex=-1;
			  $scope.shuffleIndex=-1;
 	  }
	  }
	  }

  $scope.column2Click=function(match,index){
	  console.log(match);
	  if($scope.shuffledArr.length>0){
		  if($scope.shuffledArr[0] == match){
			  $scope.shuffledArr[index].selected=true;
		  }else{
			  $scope.shuffledArr[index].selected=false;
		  }
	  }else{
		  $scope.shuffledArr.push(match);
	  }
  }

$scope.gotoLoc= function(loc){
        $location.path(loc);
    }

});
