projectModule.controller('instSettingsController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

    $scope.$ = $;
    $scope.instituteId = localStorage.getItem("inst_id");
    $scope.enableCC = 'branch';
    $scope.enableCCmapping = false;
    $scope.enableLPmapping = false;
    $scope.enableBranchmapping = false;
    $scope.classCourseArr = [];
    $scope.branchSubjectsArr = [];
    $scope.branchBilingualSubjectsArr = [];
    $scope.latestCurrentInstTab = "";
    $scope.instTypeObId = "";
    $scope.instCrsOb = "";
    $scope.instClsObj = "";
    $scope.assignSubjStatus = 'none';
    $scope.userRoleId = localStorage.getItem("RD");
    $scope.newsubjectName = "";
    $scope.newsubGrp = "";
    $scope.schemaName = localStorage.getItem("sname");
    $scope.userId = localStorage.getItem("userId");
    $scope.domainUrl = localStorage.getItem("domain");
    $scope.isClassChecked = 1;
    $scope.gotoLoc = function (loc) {
        $location.path(loc);
    }

    $scope.instSettingsInit = function () {
        $scope.getAllCourses();
        $scope.getAllClasses();
        $scope.getAllBranches();
        $scope.getBranchClassCourse();
        // $scope.getInstituteTypes();
    }
    $scope.fromHomeScreen = false;
    if (sessionStorage.getItem("fromHomeScreen") == 'true') {
        $scope.fromHomeScreen = true;
    }
    $scope.redirectToDashboard = function () {
        $location.path("home");
    }
    $scope.gotoLoc = function (loc) {
        $location.path(loc);
    }
    $scope.viewSubjectsModal = function (crsyr, crs) {
        console.log(crsyr);
        console.log(crs);
        $scope.viewSubjectId = crsyr.classId;
        $scope.brnchCourseId = crs.courseId;
        $scope.viewClassCourseSubjList();
    }

    $scope.academicChartInit = function () {
        $scope.getInstituteTypes();
    }

    $scope.branchSettingsInit = function () {
        $scope.getInstituteTypes();
        $scope.getAllBranches();
    }
    $scope.getAllBranches = function () {

        httpFactory.getResult("getAllBranchesForSA?instId=" + $scope.instituteId + "&schemaName=" + localStorage.getItem("sname") + "&roleId=" + localStorage.getItem("RD") + "&branchId=" + localStorage.getItem("bnchId"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.branchList = data.collegeBranches;
                console.log($scope.branchList);
                $scope.selectedBranchForMap = $scope.branchList[0];
                console.log($scope.selectedBranchForMap);
                $scope.getBranchInstTypes($scope.selectedBranchForMap);
            } else { }
        });
    }

    $scope.getBranchInstTypes = function (brnch) {
        console.log(brnch);
        if (brnch) {
            $scope.selectedBranch = brnch.branchId;
            $scope.branchTypes = [];
            $scope.crsListInstType = [];
            httpFactory.getResult("getBranchInstTypes?branchId=" + brnch.branchId + "&schemaName=" + localStorage.getItem("sname"), function (data) {
                console.log(data);
                if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                    $scope.branchTypes = data.branchTypes;
                    $scope.instTypeObId = $scope.branchTypes[0].instTypeId;
                    $scope.instTypeBranchMethod($scope.instTypeObId);
                    // $scope.selectedBranchForMap = $scope.branchList[0];
                    // console.log($scope.selectedBranchForMap);
                } else { }
            });
        }
    }

    $scope.selectedInstType = function (instType) {
        console.log(instType);
        $scope.selectedBranchId = instType.branchId;
        $scope.selectedInstTypeId = instType.instTypeId;
        $scope.getCourseClassesForBranch();
    }

    $scope.getCourseClassesForBranch = function () {
        httpFactory.getResult("getCourseClassesForBranchWithMapping?branchId=" + $scope.selectedBranchId + "&instTypeId=" + $scope.selectedInstTypeId + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.branchCourses = data.records;
                // $scope.selectedBranchForMap = $scope.branchList[0];
                // console.log($scope.selectedBranchForMap);
            } else { }
        });
    }
    $scope.isBranchCourseMapped = false;
    $scope.showClassesForCourseBranch = function (clsOb) {
        console.log(clsOb);
        console.log(clsOb.classes);
        $scope.instCrsOb = clsOb;
        $scope.branchClsOb = clsOb.classes;
        if (clsOb.isMapped == 1) {
            $scope.isBranchCourseMapped = true;
        } else {
            $scope.isBranchCourseMapped = false;
        }

    }
    $scope.getAllCourses = function () {

        httpFactory.getResult("getAllCourses?instId=" + localStorage.getItem("inst_id") + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.courseList = data.Courses;
            } else { }
        });
    }

    $scope.getAllClasses = function () {
        httpFactory.getResult("getAllClasses?instId=" + localStorage.getItem("inst_id") + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.classList = data.Classes;
            } else { }
        });
    }

    $scope.getBranchClassCourse = function () {
        httpFactory.getResult("getClassCoursesByBId?instType=" + $scope.instTypeObId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + $scope.selectedBranchForMap.branchId + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.classCourseList = data.ClassCourses;
                console.log($scope.classCourseList);
                if ($scope.classCourseList.length > 0) {
                    $scope.brnchCourseId = $scope.classCourseList[0].courseId;
                } else {
                    alert("No Classes");
                }
            }
        });
    }

    $scope.acadamicTimeIntituteTypes = [];
    $scope.getInstituteTypes = function () {
        httpFactory.getResult("getCollegeInstituteTypes?schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            if (data.statusCode == '200') {
                $scope.instituteTypes = data.data;
                console.log($scope.instituteTypes);
                $scope.acadamicTimeIntituteTypes = data.data;
                $scope.latestCurrentInstTab = $scope.instituteTypes[0].instTypeId;
            }
        });
    }

    $scope.branchArr = [];
    $scope.addBranch = function () {
        //console.log(typeid);

        var brchDump = {
            "branchName": "",
            "branchCode": "",
            "branchContact": "",
            "branchAddress": "",
            "branchPinCode": "",
            "instTypeId": "",
            "createdBy": localStorage.getItem("userId")
        };
        $scope.branchArr.push(brchDump);

    }


    $scope.addBoard = function () {
        if ($scope.boardName) {
            if ($scope.boardName.trim().length > 0) {
                var params = {
                    "boardName": $scope.boardName.trim(),
                    "boardDesc": "kdlfkdflk",
                    "schemaName": $scope.schemaName
                }
                httpFactory.executePost("addBoardType", params, function (data) {
                    console.log(data);
                    if (data.StatusCode == 200) {
                        $scope.boardName = undefined;
                        alert("successfully added");
                    }
                });
            } else {
                alert("Name cannot be spaces or blank");
            }
        } else {

            alert("Enter all fields");
        }
    }

    $scope.getBoardTypes = function () {

        var params = {
            "schemaName": $scope.schemaName
        }
        httpFactory.executePost("getBoardTypes", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.boardList = data.boardTypes;
                console.log($scope.boardList);
            }
        });
    }

    $scope.boardPopupMethod = function () {
        $scope.getBoardTypes();
    }



    $scope.getDataInstSbjs = function () {
        console.log($scope.instituteTypes[0]);
        $scope.subjectsByInstType($scope.instituteTypes[0]);

    }
    $scope.disableSelSubject = {};
    $scope.openDisablingWarning = function (sbj) {
        $scope.disableSelSubject = sbj;
        $("#sbjDisable").modal("show");
    }
    $scope.disableSubject = function () {
        console.log($scope.disableSelSubject);
        $("#sbjDisable").modal("hide");
    }


    $scope.subjectsByInstType = function (instType) {

        $scope.instTypeOb = instType;
        $scope.instTypeObId = instType.instTypeId;
        $scope.latestCurrentInstTab = instType.instTypeId;
        $scope.showCourseByInstType($scope.instTypeOb);

        var params = {
            "instTypeId": $scope.instTypeObId,
            "schemaName": localStorage.getItem("sname")
        }

        httpFactory.executePost("getAllSubjectDetailsForInstType", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.instSubjs = data.data;

                console.log($scope.instSubjs);
            }
        });
    }

    /* $scope.addNewSubject = function(){
        if($scope.subjectName == undefined || $scope.subjectName == "" || $scope.subjectGrp == undefined || $scope.subjectGrp == ""){
            alert("Please Add All Fields");
            return true;
        }

        var params = {
            "schemaName": localStorage.getItem("sname"),
            "courseId":$scope.instCrsOb.courseId,
            "classId":$scope.clsOb,
            "isActive":1,
            "createdBy":localStorage.getItem("userId"),
            "userId" : localStorage.getItem("userId"),
            "instId":localStorage.getItem("inst_id"),
            "insertRecords":[
              {
                "subjectName":$scope.subjectName,
                "subjectGroup":$scope.subjectGrp
              }
            ]
        }

        httpFactory.executePost("insertSubjects", params, function(data) {
          console.log(data);
          if (data.StatusCode == 200) {
            alert("newCourse added");
              console.log($scope.instSubjs);
              $scope.showCourseByInstType();
            }
        });
    }
     */
    $scope.showCourseByInstType = function (instType) {
        $scope.isDefaultCourse = 0;
        $scope.generalSubj = [];
        $scope.electiveSubj = [];
        $scope.optionalSubj = [];
        $scope.instCrsOb = "";
        $scope.instClsObj = "";
        if (instType) {
            $scope.instTypeOb = instType;
            $scope.instTypeObId = instType.instTypeId;
            //$scope.redirectToCurrentInstTab(instType.instTypeId);
        }
        // $scope.getCourseClassesForBranch();
        httpFactory.getResult("getAllCoursesByInstType?instType=" + $scope.instTypeOb.instTypeId + "&schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            console.log(data);
            $scope.crsListInstType = [];
            $scope.clsListCrsInstType = [];
            if (data.StatusCode == 200) {
                $scope.crsListInstType = data.Courses;
            } else {
                console.log("No Courses");
            }
        });
    }

    $scope.showClsBycrsInstype = function (instCrs) {
        $scope.isDefaultCourse = instCrs.isDefault;
        if (typeof instCrs == 'string') {
            $scope.instCrsOb = JSON.parse(instCrs);

        } else {
            $scope.instCrsOb = instCrs;
        }
        $scope.instClsObj = "";
        $scope.generalSubj = [];
        $scope.electiveSubj = [];
        $scope.optionalSubj = [];
        $scope.crsListInstTypeFiltered = [];
        var courseId = $scope.instCrsOb.courseId;
        for (var i = 0; i < $scope.crsListInstType.length; i++) {
            if ($scope.crsListInstType[i].courseId == courseId) {
                $scope.crsListInstTypeFiltered.push($scope.crsListInstType[i]);
            }
        }

        //filter courses based courseId
        console.log($scope.instCrsOb);
        httpFactory.getResult("getAllClassesByInstTypeAndCourseId?instType=" + $scope.instTypeOb.instTypeId + "&courseId=" + courseId + "&schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            console.log(data);
            $scope.clsListCrsInstType = [];
            if (data.StatusCode == 200) {
                $scope.clsListCrsInstType = data.Classes;
                console.log($scope.clsListCrsInstType);
            } else {
                console.log("No Courses");
            }
        });
    }
    $scope.isUpdateCourseMap = false;
    $scope.updateCourseMap = function () {
        $scope.isUpdateCourseMap = true;
    }
    //$scope.branchArr = [];

    $scope.removeExtraBr = function (indx) {
        $scope.branchArr.splice(indx, 1);
    }


    $scope.saveBranches = function () {

        var instTypeId = "";
        for (var i = 0; i < $scope.acadamicTimeIntituteTypes.length; i++) {
            if ($scope.acadamicTimeIntituteTypes[i].checked == true) {
                if (instTypeId == "") {
                    instTypeId = "" + $scope.acadamicTimeIntituteTypes[i].instTypeId;
                    console.log(instTypeId);
                } else {
                    instTypeId = instTypeId + "," + $scope.acadamicTimeIntituteTypes[i].instTypeId;
                    console.log(instTypeId);
                }
            }
        }
        console.log(instTypeId);

        if (instTypeId == "") {
            alert("Please Select atleast on Institute");
            return true;
        }
        if ($scope.branchArr.length == 0) {
            alert("Add branch details");
            return true;
        }
        for (var i = 0; i < $scope.branchArr.length; i++) {
            if ($scope.branchArr[i].branchName != "" && $scope.branchArr[i].branchCode != "" && $scope.branchArr[i].branchContact != "" && $scope.branchArr[i].branchAddress != "") {
                $scope.branchArr[i].instTypeId = instTypeId;
            } else {
                alert("Please Add all the fields correctly");
                return true;
            }
        }
        var requestParams = {
            "schemaName": localStorage.getItem("sname"),
            "instId": $scope.instituteId,
            "userId": localStorage.getItem("userId"),
            "insertRecords": $scope.branchArr
        };
        console.log(requestParams);
        httpFactory.executePost("setUpBranch", requestParams, function (data) {
            if (data.StatusCode == 200) {
                if (data.DuplicateRecords.length > 0) {
                    var str = "Branch Code already Exists for ";
                    for (var i = 0; i < data.DuplicateRecords.length; i++) {
                        str = str + "" + data.DuplicateRecords.branchCode;
                    }
                    alert(str);
                }
                $scope.acadamicTimeIntituteTypes = $scope.instituteTypes;
                $scope.branchArr = [];
                $scope.getAllBranches();
                $("#addBranchPopup").modal("hide");
            } else {
                if (data.ErrorRecords) {
                    var str = "Branch Code already Exists for ";
                    for (var i = 0; i < data.DuplicateRecords.length; i++) {
                        str = str + "" + data.branchCode;
                    }
                    alert(str);
                } else {
                    alert("Something went wrong");
                }
                console.log(data);
            }
        });
    }


    $scope.getAllClassesByInstType = function () {
        httpFactory.getResult("getAllClassesByInstType?instType=" + $scope.instTypeOb.instTypeId + "&schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.assignCLassList = data.Classes;
                console.log($scope.assignCLassList);
                if ($scope.assignCLassList != undefined) {
                    for (var i = 0; i < $scope.assignCLassList.length; i++) {
                        for (var j = 0; j < $scope.clsListCrsInstType.length; j++) {
                            console.log($scope.clsListCrsInstType);
                            console.log($scope.assignCLassList[i]);
                            if ($scope.assignCLassList[i].classId == $scope.clsListCrsInstType[j].classId) {
                                var key = "isMapped";
                                var val = "1";
                                $scope.assignCLassList[i][key] = val;
                            }
                        }
                    }
                }
                console.log($scope.assignCLassList);
            } else { }
        });
    }
    $scope.allGeneElecSubjList = [];

    $scope.showClassSubjList = function (instCls) {
        $scope.instClsObj = instCls;
        $scope.electiveSubj = [];
        $scope.generalSubj = [];

        console.log($scope.instClsObj);
        console.log($scope.instCrsOb);
        httpFactory.getResult("getAllCourseClassSubjectsForAC?classId=" + $scope.instClsObj.classId + "&courseId=" + $scope.instCrsOb.courseId + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.generalSubj = [];
                $scope.electiveSubj = [];
                $scope.allGeneElecSubjList = [];
                $scope.subjList = data.Subjects;

                for (var i = 0; i < $scope.subjList.length; i++) {

                    if ($scope.subjList[i].electiveGroupId == 0) {
                        $scope.generalSubj = $scope.subjList[i].subjects;
                        for (var j = 0; j < $scope.generalSubj.length; j++) {
                            $scope.allGeneElecSubjList.push($scope.generalSubj[j].subjectId);
                        }
                    } else {
                        $scope.electiveSubj.push($scope.subjList[i]);
                        for (var j = 0; j < $scope.subjList[i].subjects.length; j++) {
                            $scope.allGeneElecSubjList.push($scope.subjList[i].subjects[j].subjectId);
                        }
                    }
                }
                console.log($scope.generalSubj);
                console.log($scope.electiveSubj);
                console.log($scope.allGeneElecSubjList);
            }
        });
    }
    $scope.showElectiveGroupSubj = function (elec) {
        console.log(elec);
    }


    $scope.subjectClick = function (subj) {
        $scope.selectedSubId = subj.subjectId;
        $scope.assignSubjectToElectiveGroup();
    }

    $scope.selectCourseClassAssignment = function (courseId, classId, classCourseId, crsyr, isClassChecked) {
        console.log(isClassChecked);
        var isActStatus = 0;
        if (isClassChecked == true) {
            isActStatus = 1;
        }
        var obj = {
            "classId": classId,
            "courseId": courseId,
            "branchId": $scope.selectedBranchForMap.branchId,
            "isActive": isActStatus,
            "userId": localStorage.getItem("userId"),
            "classCourseId": classCourseId
        }
        if ($scope.classCourseArr.length == 0) {
            $scope.classCourseArr.push(obj);
        } else {
            for (i = 0; i < $scope.classCourseArr.length; i++) {
                if ($scope.classCourseArr[i].classId === classId && $scope.classCourseArr[i].courseId == courseId) {
                    $scope.checkStatus = 1;
                    break;
                }
            }
            if ($scope.checkStatus == 1) {
                $scope.classCourseArr.splice(i, 2);
            } else {
                $scope.classCourseArr.push(obj);
            }
        }
    }

    $scope.changeAssignSubjStatus = function (subStatus) {
        $scope.assignSubjStatus = subStatus;
    }
    $scope.subjectGroupAvail = [];
    $scope.getSubjectGroups = function () {
        httpFactory.getResult("getSubjectGroups?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.subjectGroupAvail = data.SubGroups;
            }
        });
    }
    $scope.getSubjectGroups();

    $scope.enableCCTab = function (tab) {
        $scope.enableCC = tab;
        $scope.enableCCmapping = false;
        $scope.enableBranchmapping = false;
        if (tab == 'others') {
            $scope.tabName = 'WhatsApp';
            $scope.getWebhookDetails();
        }
    }

    $scope.latestCurrentInstTab = "branchSettingtab";
    $scope.redirectToCurrentInstTab = function (tabName) {
        $scope.latestCurrentInstTab = tabName;
        console.log($scope.latestCurrentInstTab);
        $scope.getAllBranches();
    }
    $scope.selectedCourseClassList = [];
    $scope.selectedCourseId = "";
    $scope.selectedClassSubjectsList = [];
    $scope.showCourseClassList = function (curs) {
        console.log(curs);
        $scope.selectedCourseClassList = [];
        $scope.selectedClassSubjectsList = [];
        $scope.selectedCourseId = curs.courseId;
        $scope.selectedCourseClassList = curs.classes;
    }
    $scope.selectedBranchDetails = '';
    $scope.getSelectedBranchDetails = function (brch) {
        $scope.selectedBranchForMap = brch;
        $scope.getBranchInstTypes($scope.selectedBranchForMap);
        //console.log($scope.selectedBranchForMap);
        $scope.getBranchClassCourse();
        $scope.classCourseArr = [];
        $scope.branchSubjectsArr = [];
    }
    $scope.enableCCmappingTab = function () {
        $scope.enableCCmapping = !$scope.enableCCmapping;
    }
    $scope.enableBranchmappingTab = function () {
        $scope.enableBranchmapping = !$scope.enableBranchmapping;
        if (!$scope.enableBranchmapping)
            $scope.wbDetails = angular.copy($scope.tempWbDetails);
    }

    $scope.saveClassCourseAssignment = function () {

        if ($scope.classCourseArr.length > 0) {
            var params = {
                "schemaName": localStorage.getItem("sname"),
                "updatedRecords": $scope.classCourseArr
            };
            console.log(params);

            httpFactory.executePost("updateClassCourseBranch", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    $scope.classCourseArr = [];
                    alert("successfully updated");
                    $scope.enableCCmappingTab();
                } else {
                    $scope.errorMsg = data.message;
                }
            });
        }
    }

    $scope.addCourseModal = function () {
        $("#addCourse").modal('show');
    }
    $scope.updateCourseModal = function (crs) {
        $scope.courseUpdate = crs;
        $scope.courseNameText = crs.courseName;
        $("#updateCourse").modal('show');
    }
    $scope.assignClassModal = function () {
        $scope.showAddClassTag = "0";
        console.log($scope.clsListCrsInstType);
        $scope.getAllClassesByInstType();
        $("#assignClass").modal('show');
    }
    $scope.assignSubjectModal = function () {
        // $scope.getAllClassesByInstType();
        $scope.subjAddArr = [];
        $scope.assignedSubjOb = [];
        $scope.assignSubjStatus = 'none';
        $("#assignSubjects").modal('show');
        $scope.getElectiveGroupsByInstType();
    }
    $scope.assignElectiveModal = function (subj) {
        $scope.selectedElectiveSbj = subj.subjectId;
        $scope.getElectiveGroupsByInstType();
        if ($scope.electiveGroupList.length > 0) {
            $("#assignElectiveModal").modal('show');
        } else {
            alert("No Elective groups were added till now. Go to Assign Subjects below and Go to Add Elective Group ");
        }
    }

    $scope.addElectiveGroupModal = function () {
        $("#addElectiveGroupModal").modal('show');
    }

    $scope.courseSelected = function (crs) {
        $scope.crsObj = JSON.parse(crs);
        $scope.assignClsList = [];
        $scope.showClsBycrsInstypeAssign(crs);
    }


    $scope.showClsBycrsInstypeAssign = function (instCrs) {
        $scope.instCrsObAssign = instCrs;
        console.log($scope.instCrsObAssign);
        httpFactory.getResult("getAllClassesByInstTypeAndCourseId?instType=" + $scope.instTypeOb.instTypeId + "&courseId=" + instCrs + "&schemaName=" + localStorage.getItem("sname") + "&instId=" + localStorage.getItem("inst_id"), function (data) {
            console.log(data);
            $scope.assignClsList = [];
            if (data.StatusCode == 200) {
                $scope.assignClsList = data.Classes;

                console.log($scope.assignCLassList);
            } else {
                console.log("No Courses");
            }
        });
    }
    $scope.classSelected = function (cls) {
        if (typeof cls == 'string') {
            $scope.clasObj = JSON.parse(cls);
        } else {
            $scope.clasObj = cls;
        }
        console.log($scope.clasObj);
        $scope.getCourseClassSubjectsAssign();
        $scope.getDefaultSubjectsByClass();
    }

    $scope.getDefaultSubjectsByClass = function () {
        httpFactory.getResult("getDefaultSubjectsByClass?classId=" + $scope.clasObj.classId + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            $scope.assignSubjList = [];
            if (data.StatusCode == 200) {
                $scope.assignSubjList = data.Subjects;
            } else {
                console.log("No Courses");
            }
        });
    }

    $scope.getCourseClassSubjectsAssign = function () {
        httpFactory.getResult("getCourseClassSubjects?classId=" + $scope.clasObj.classId + "&courseId=" + $scope.selectedCrs + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            $scope.assignSubjList = [];
            if (data.StatusCode == 200) {
                $scope.assignSubjList = data.Classes;
            } else {
                console.log("No Courses");
            }
        });
    }

    $scope.getCourseClassSubjectsAssign = function () {
        httpFactory.getResult("getClassSubjects?classId=" + $scope.clasObj.classId + "&courseId=" + $scope.selectedCrs + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            $scope.assignSubjList = [];
            if (data.StatusCode == 200) {
                $scope.assignSubjList = data.Classes;
            } else {
                console.log("No Courses");
            }
        });
    }


    $scope.subSelected = function (subject) {
        alert(subject);
    }

    $scope.classArrAdd = [];
    $scope.classArrDel = [];

    $scope.assignClassMethod = function (classOb) {
        // var cls = {
        // 	"classId":classOb.classId
        // };
        // remove($scope.classArr,cls);
        if (classOb.isMapped == 1) {
            if ($scope.classArrDel.includes(classOb.classId)) {
                const index = $scope.classArrDel.indexOf(classOb.classId);
                if (index !== -1) {
                    $scope.classArrDel.splice(index, 1);
                }
            } else {
                $scope.classArrDel.push(classOb.classId);
            }
        } else {
            if ($scope.classArrAdd.includes(classOb.classId)) {
                const index = $scope.classArrAdd.indexOf(classOb.classId);
                if (index !== -1) {
                    $scope.classArrAdd.splice(index, 1);
                }
            } else {
                $scope.classArrAdd.push(classOb.classId);
            }
        }

        console.log($scope.classArrAdd);
        console.log($scope.classArrDel);
    }

    // 	function remove(array, element) {
    //   const index = array.indexOf(element.classId);
    // console.log(index);
    //   if (index !== -1) {
    //     $scope.classArrAdd.splice(index, 1);
    //   }else{
    // 		$scope.classArrAdd.push(element.classId);
    // 		console.log($scope.classArr);
    // 	}
    // }


    $scope.assignClassesToCourseTypeInst = function () {
        $scope.classArrAddObj = [];
        for (var i = 0; i < $scope.classArrAdd.length; i++) {
            var addobj = {
                "classId": $scope.classArrAdd[i]
            }
            $scope.classArrAddObj.push(addobj);
        }
        $scope.classArrDelObj = [];
        for (var i = 0; i < $scope.classArrDel.length; i++) {
            var delobj = {
                "classId": $scope.classArrDel[i]
            }
            $scope.classArrDelObj.push(delobj);
        }
        //console.log($scope.classArrObj);

        if ($scope.classArrAddObj.length > 0 || $scope.classArrDelObj.length > 0) {
            var params = {
                "schemaName": localStorage.getItem("sname"),
                "instTypeId": $scope.instTypeOb.instTypeId,
                "instId": localStorage.getItem("inst_id"),
                "updateRecords": [{
                    "courseId": $scope.instCrsOb.courseId,
                    "classes": $scope.classArrAddObj
                }],
                "deleteRecords": [{
                    "courseId": $scope.instCrsOb.courseId,
                    "classes": $scope.classArrDelObj
                }]
            };
            console.log(params);

            httpFactory.executePost("addOrUpdateClassCourseForInstType", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200 || data.statusCode == 200) {
                    $scope.classArrAdd = [];
                    alert("successfully updated");
                    $("#assignClass").modal('hide');
                    $scope.showClsBycrsInstype($scope.instCrsOb);
                    $scope.classArrDel = [];

                } else {
                    //TODO : Show Error
                    $scope.errorMsg = data.message;
                }
            });
        }
    }

    $scope.subjAddArr = [];
    $scope.assignSubjectsMethod = function (subjOb) {
        console.log(subjOb);

        if ($scope.subjAddArr.includes(subjOb.subjectId)) {
            const index = $scope.subjAddArr.indexOf(subjOb.subjectId);
            if (index !== -1) {
                $scope.subjAddArr.splice(index, 1);
            }
        } else {
            $scope.subjAddArr.push(subjOb.subjectId);
        }
        console.log($scope.subjAddArr);
    }
    $scope.assignSubjectsToClassCourse = function () {
        $scope.assignedSubjOb = [];
        if ($scope.assignSubjList.length == 0) {
            alert("please Select Appropriate Course and Class ");
            return true;
        }
        for (var i = 0; i < $scope.assignSubjList.length; i++) {
            var obj = {};
            if ($scope.assignSubjList[i].selected == true && $scope.allGeneElecSubjList.indexOf('' + $scope.assignSubjList[i].subjectId) == -1) {
                obj = {
                    "subjectId": $scope.assignSubjList[i].subjectId,
                    "isActive": 1,
                }
                if ($scope.assignSubjList[i].isElectiveSelected == true) {
                    obj.isElective = 1;
                    obj.electiveGroupId = $scope.assignSubjList[i].electiveGrpId;
                } else {
                    obj.isElective = 0;
                }
                $scope.assignedSubjOb.push(obj);
            }
        }
        console.log($scope.assignedSubjOb);
        if ($scope.assignedSubjOb.length == 0) {
            alert("please Select Subjects");
            return true;
        }
        $scope.mapSubjectToClassCourse();
    }
    $scope.mapSubjectToClassCourse = function () {
        if ($scope.assignedSubjOb.length > 0) {
            console.log($scope.instCrsOb);

            var params = {
                "schemaName": localStorage.getItem("sname"),
                "subjectRecords": $scope.assignedSubjOb,
                "classId": $scope.instClsObj.classId,
                "courseId": $scope.instCrsOb.courseId,
                "instId": $scope.instTypeOb.instTypeId,
                "createdBy": localStorage.getItem("userId")
            };
            console.log(params);
            httpFactory.executePost("mapSubjectToClassCourse", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200 || data.statusCode == 200) {
                    $scope.assignSubjList = [];
                    alert("successfully updated");
                    $("#assignSubjects").modal('hide');
                    $scope.showClassSubjList($scope.instClsObj);

                } else {
                    //TODO : Show Error
                    $scope.errorMsg = data.message;
                }
            });
        }
    }
    $scope.contentList = [];
    $scope.getContentOwner = function () {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentList = data.ContentOwner;
                console.log($scope.contentList);
            } else {
                console.log("No ContentList");
            }
        });
    }
    $scope.getContentOwner();
    $scope.contentSelectMethod = function (content) {
        console.log(content);
        $scope.contentType = content.contentType;
        console.log($scope.contentType);
    }
    $scope.addNewCourse = function () {
        if ($scope.contentType == undefined) {
            alert("Please Select Content Type");
            return true;
        }

        var params = {
            "courseName": $scope.courseNameText,
            "contentType": $scope.contentType,
            "instType": $scope.instTypeOb.instTypeId,
            "instId": localStorage.getItem("inst_id"),
            "userId": localStorage.getItem("userId"),
            "schemaName": localStorage.getItem("sname")
        }
        console.log(params);
        httpFactory.executePost("addNewCourse", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("NewCourse added");
                console.log($scope.instSubjs);
                $scope.showCourseByInstType();
                $("#addCourse").modal("hide");
            } else if (data.StatusCode == 300) {
                alert("Please Check Course Name ");
            } else {
                alert("Please Try again Later");
            }

        });
    }

    $scope.groupNameText = "";
    $scope.addNewSubjGroup = function (gNameTxt) {
        $scope.groupNameText = gNameTxt;
        if ($scope.groupNameText.length) {
            var params = {

                "instType": $scope.instTypeOb.instTypeId,
                "instId": localStorage.getItem("inst_id"),
                "userId": localStorage.getItem("userId"),
                "schemaName": localStorage.getItem("sname"),
                "isActive": 1,
                "createdBy": localStorage.getItem("userId"),
                "insertRecords": [{
                    "subjectGroupName": $scope.groupNameText
                }]
            }
            console.log(params);
            httpFactory.executePost("insertSubjectGroups", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    alert("New Subject Group Added");
                    $("#subjectsGroup").modal("hide");
                    $scope.assignSubjStatus = 'subg';
                    $scope.getSubjectGroups();
                } else {
                    alert("Please Try Again Later");
                }
            });
        }
    }


    $scope.selectedClsMethod = function (clsOb) {
        console.log(clsOb);
        $scope.instClsObj = JSON.parse(clsOb);
    }

    $scope.addNewSubject = function () {

        if ($scope.newsubjectName == "" || $scope.newsubjectName == undefined || $scope.newsubGrp == undefined || $scope.newsubGrp == "") {
            alert("Fill All Details");
            return true;
        }
        if ($scope.isOptional == true) {
            $scope.isOptional = 1;
        }
        else {
            $scope.isOptional = 0;

        }

        var params = {
            "schemaName": localStorage.getItem("sname"),
            "courseId": $scope.instCrsOb.courseId,
            "classId": $scope.instClsObj.classId,
            "isActive": 1,
            "createdBy": localStorage.getItem("userId"),
            "userId": localStorage.getItem("userId"),
            "instId": $scope.instTypeOb.instTypeId,
            "isOptional": $scope.isOptional,
            "insertRecords": [{
                "subjectName": $scope.newsubjectName,
                "subjectGroup": $scope.newsubGrp
            }]
        }
        console.log(params);
        httpFactory.executePost("insertSubjects", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("subject added");
                $("#subjectsManage").modal('hide');
                console.log($scope.instSubjs);
                $scope.changeAssignSubjStatus('none');
                $scope.showClassSubjList($scope.instClsObj);
                $scope.isOptional = 0;
                // $scope.classSelected($scope.instClsObj);
                //$scope.classSelected($scope.clasObj)
            }
        });
    }

    $scope.electiveGroupName = "";
    $scope.createNewElectiveGroup = function (eGrpName) {
        $scope.electiveGroupName = eGrpName;
        var params = {
            "schemaName": $scope.schemaName,
            "electiveGroupName": $scope.electiveGroupName,
            "instId": localStorage.getItem("inst_id"),
            "instType": $scope.instTypeOb.instTypeId,
            "isActive": 1,
            "createdBy": localStorage.getItem("userId")
        }
        console.log(params);
        httpFactory.executePost("createNewElectiveGroup", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Elective group added");
                console.log($scope.instSubjs);
                $scope.assignSubjStatus = 'none';
                $("#addElectiveGroupModal").modal("hide");
            }
        });
    }

    $scope.subjectClick = function (subj) {
        $scope.selectedSubId = subj.subjectId;
        $scope.assignSubjectToElectiveGroup();
    }

    $scope.getElectiveGroupsByInstType = function () {
        console.log($scope.instTypeOb);
        httpFactory.getResult("getElectiveGroupsByInstType?instType=" + $scope.instTypeOb.instTypeId + "&schemaName=" + localStorage.getItem("sname"), function (data) {
            console.log(data);
            $scope.electiveGroupList = [];
            if (data.StatusCode == 200) {
                $scope.electiveGroupList = data.electiveGroups;
            } else {
                console.log("No Courses");
            }
        });
    }

    $scope.selectedElectiveGroup = function (elective) {
        $scope.electiveGId = elective.electiveGroupId;
        console.log($scope.electiveGId);
        //$scope.assignSubjectToElectiveGroup();
    }
    $scope.movetoGeneralSubject = function (subj) {
        $scope.selectedElectiveSbj = subj.subjectId;
        $scope.electiveGId = 0;
        $scope.assignSubjectToElectiveGroup();
    }
    $scope.assignSubjectToElectiveGroup = function () {
        var isElectiveCheck = 1;
        if ($scope.electiveGId == 0) {
            isElectiveCheck = 0;
        }
        var params = {
            "schemaName": $scope.schemaName,
            "classId": $scope.instClsObj.classId,
            "courseId": $scope.instCrsOb.courseId,
            "electiveGrpId": $scope.electiveGId,
            "subId": $scope.selectedElectiveSbj,
            "isElective": isElectiveCheck,
            "updatedBy": localStorage.getItem("userId")
        }
        console.log(params);
        httpFactory.executePost("assignSubjectToElectiveGroup", params, function (data) {
            console.log(data);
            if (data.statusCode == 200) {
                alert("Updated Successfully");
                $("#assignElectiveModal").modal("hide");
                console.log($scope.instSubjs);
                $scope.showClassSubjList($scope.instClsObj);
            } else {
                alert("Please try again later...");
            }
        });
    }
    $scope.assignSubjects = function () {
        $scope.mapNewSubjectToCourseAndClass();
    }
    $scope.updateSubjectNameModal = function (subject) {
        console.log(subject);
        $("#updateSubjectNameModal").modal("show");
        $scope.selSubjectName = subject.subjectName;
        console.log($scope.selSubjectName);
        $scope.selSubId = subject.subjectId;
    }


    $scope.updateSubjectName = function () {
        var params = {
            "subjectId": $scope.selSubId,
            "subjectName": $scope.selSubjectName,
            "schemaName": localStorage.getItem("sname"),
            "updatedBy": localStorage.getItem("userId")
        }
        console.log(params);
        httpFactory.executePost("updateSubjectName", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Subject name successfully updated");
                $("#updateSubjectNameModal").modal("hide");
                $scope.showClassSubjList($scope.instClsObj);
            } else {
                alert("error updating name. Please make sure its unique");
            }
        });
    }

    //repeated for diff html view subjects

    $scope.viewClassCourseSubjList = function () {

        httpFactory.getResult("getAllCourseClassSubjectsForSA?classId=" + $scope.viewSubjectId + "&courseId=" + $scope.brnchCourseId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + $scope.selectedBranchForMap.branchId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.generalSubj = [];
                $scope.electiveSubj = [];
                $scope.optionalSubj = [];
                $scope.subjList = data.Subjects;

                for (var i = 0; i < $scope.subjList.length; i++) {
                    for (var j = 0; j < $scope.subjList[i].subjects.length; j++) {
                        if ($scope.subjList[i].electiveGroupId == 0 && $scope.subjList[i].subjects[j].isOptional == 0) {
                            $scope.generalSubj.push($scope.subjList[i].subjects[j]);
                        }
                        if ($scope.subjList[i].subjects[j].isOptional == 1) {
                            $scope.optionalSubj.push($scope.subjList[i].subjects[j]);
                        }
                        else {
                            $scope.electiveSubj.push($scope.subjList[i]);
                        }
                    }
                }
                console.log($scope.generalSubj);
                console.log($scope.electiveSubj);
                $("#availableSubjectsModal").modal("show");

            } else {
                alert("No Subject Records");
            }
        });
    }

    $scope.showElectiveGroupSubj = function (elec) {
        console.log(elec);
    }


    // updateCourseName

    $scope.updateCourseName = function () {
        var params = {
            "courseId": $scope.courseUpdate.courseId,
            "courseName": $scope.courseNameText,
            "schemaName": localStorage.getItem("sname"),
            "updatedBy": localStorage.getItem("userId")
        }
        console.log(params);
        httpFactory.executePost("updateCourseName", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Course updated");
                console.log($scope.instSubjs);
                $("#updateCourse").modal('hide');
                $scope.showCourseByInstType($scope.instTypeOb);
            } else {
                alert("error updating name. Please make sure its unique");
            }
        });
    }

    $scope.addNewClass = function () {
        console.log(document.getElementById("classNameAdd").value);
        $scope.newCLassName = document.getElementById("classNameAdd").value;
        if ($scope.newCLassName == undefined || $scope.newCLassName == "") {
            alert("Add Class Name");
            return true;
        }

        var params = {
            "schemaName": localStorage.getItem("sname"),
            "instType": $scope.instTypeOb.instTypeId,
            "instId": localStorage.getItem("inst_id"),
            "userId": localStorage.getItem("userId"),
            "className": $scope.newCLassName
        }
        console.log(params);
        httpFactory.executePost("addNewClass", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.classArrAdd.push(data.classId);
                //$scope.assignClassesToCourseTypeInst();
                alert("class added");
            } else {
                alert("error updating name. Please make sure its unique");
            }
        });
    }

    $scope.showAddClass = function () {
        $scope.showAddClassTag = "1";
    }

    $scope.instTypeBranchMethod = function (instTypeObId, subTab) {
        if ($scope.enableCC == 'others') {
            $scope.tabName = subTab;
            if (subTab == 'WhatsApp')
                $scope.getWebhookDetails();
            if (subTab == 'Store')
                $scope.getBranchAssignedWithStore();
            if (subTab == 'lessonPlan')
                $scope.getLessonPlanCourseClassDetails($scope.instTypeObId);
            $scope.enableLPmapping = true;
        } else {
            $scope.instTypeObId = instTypeObId;
            $scope.getBranchClassCourse();
        }
    }

    $scope.goToElectiveSubjStu = function () {
        $location.path("electiveStudents");
    }

    // Methods for electiveStudents route start

    $scope.changeBranch = function (branchId) {
        $scope.branchId = localStorage.getItem("bnchId");
        httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.courseList = data.Courses;
                console.log($scope.courseList);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.courseChange = function (course) {
        $scope.courseId = course;
        $scope.getClassByCourseId();
        $scope.getContentOwner();
    }
    $scope.getClassByCourseId = function () {
        httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.classList = data.Classes;
                console.log($scope.classList);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.getContentOwner = function () {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                if ($scope.selInstCrs) {
                    $scope.courseId = $scope.selInstCrs;
                }
                $scope.contentOwnerList = [];
                $scope.contentList = data.ContentOwner;
                console.log($scope.contentList);
                for (var i = 0; i < $scope.contentList.length; i++) {
                    console.log($scope.contentList[i].courseId);
                    console.log($scope.courseId);
                    if ($scope.contentList[i].courseId == $scope.courseId) {
                        $scope.contentOwnerList.push($scope.contentList[i]);
                    }
                }
                console.log($scope.contentOwnerList);
            } else {
                console.log("No ContentList");
            }
        });
    }

    $scope.classChange = function (classObj) {
        $scope.classId = classObj.classId;
        $scope.classCourseId = classObj.classCourseId;
        $scope.viewSubjectId = $scope.classId;
        $scope.brnchCourseId = $scope.courseId;
    }

    $scope.goMethod = function () {
        $scope.sectionList = [];
        $scope.subjectList = [];

        httpFactory.getResult("selectSectionsByBranchCourseClass?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classCourseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionList = data.Sections;
                console.log($scope.sectionList);
                // $scope.getSubjectsByCourse();
                $scope.selectSection($scope.sectionList[0].sectionId);
            } else {
                console.log("No Sections");
            }
        });
    }



    $scope.selectSection = function (sectionId) {
        $scope.sectionId = sectionId;
        console.log($scope.sectionId);
        $scope.viewClassCourseSubjList();

        // $scope.getChapterTopicAccessBySubject();
    }

    $scope.getStudentBySubj = function (subjectId, elecGrpId) {
        $scope.elecSubjId = subjectId;
        $scope.elecGroupId = elecGrpId;
        $scope.isElectiveVal = 1;
        $scope.getStudents();
        $("#assignStudents").modal("show");

    }

    $scope.getStudents = function () {
        httpFactory.getResult("getSectionElectiveStudents?sectionId=" + $scope.sectionId + "&electiveGroupId=" + $scope.elecGroupId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.studentListHW = data.studentElectiveSubArray;
            } else {
                $scope.studentListHW = [];
            }
        });
    }

    $scope.closePopUpHW = function () {
        $("#assignStudents").modal("hide");
    }
    $scope.stuArr = [];
    $scope.studentsArr = [];
    $scope.studentSelected = function (studentStatus) {
        console.log(studentStatus.studentStatus);
        console.log(studentStatus);
        console.log($scope.stuArr);
        if ($scope.stuArr.includes(studentStatus.studentId)) {
            const index = $scope.stuArr.indexOf(studentStatus.studentId);
            if (index !== -1) {
                $scope.stuArr.splice(index, 1);
                $scope.studentsArr.splice(index, 1);
            }
        } else {
            var obj = {
                "studentId": studentStatus.studentId,
                "studentelectiveSubId": studentStatus.studentelectiveSubId
            }
            console.log(obj);
            $scope.stuArr.push(studentStatus.studentId);
            $scope.studentsArr.push(obj);
        }
        console.log($scope.studentsArr);
    }

    $scope.assignStudentsForSubject = function () {
        var params = {
            "schemaName": $scope.schemaName,
            "subjectId": $scope.elecSubjId,
            "electiveGroupId": $scope.elecGroupId,
            "sectionId": $scope.sectionId,
            "branchId": localStorage.getItem("bnchId"),
            "isActive": 1,
            "createdBy": localStorage.getItem("userId"),
            "studentIdRec": $scope.studentsArr
        }
        console.log(params);

        httpFactory.executePost("assignElectiveSubjectToStudents", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                console.log(data);
            }
        });
    }


    // Methods for electiveStudents route ends


    //Code for Content Details management start
    $scope.contentUsersList = [];

    $scope.getUsersForContent = function () {
        httpFactory.getResult("getUsersForContent?branchId=0&roleId=" + $scope.userRoleId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentUsersList = data.UserObject;
            } else {
                $scope.contentUsersList = [];
            }
        });
        $('#userDetailsPopup').modal("show");
    };
    $scope.getUsersForContentForDates = function () {

        var frmDate = document.getElementById('frmDate').value;
        var tDate = document.getElementById('tDate').value;
        // if(frmDate.getDate() < 10){
        // 	$scope.dbFrmDate = frmDate.getFullYear()+'-'+frmDate.getMonth()+'-0'+frmDate.getDate();
        // }else{
        // 	$scope.dbFrmDate = frmDate.getFullYear()+'-'+frmDate.getMonth()+'-'+frmDate.getDate();
        // }
        // if(tDate.getDate() < 10){
        // 	$scope.dbTDate = tDate.getFullYear()+'-'+tDate.getMonth()+'-0'+tDate.getDate();
        // }else{
        // 	$scope.dbTDate = tDate.getFullYear()+'-'+tDate.getMonth()+'-'+tDate.getDate();
        // }

        httpFactory.getResult("getUsersForContent?branchId=0&roleId=" + $scope.userRoleId + "&schemaName=" + $scope.schemaName + "&fromDate=" + frmDate + "&toDate=" + tDate, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentUsersList = data.UserObject;
            } else {
                $scope.contentUsersList = [];
            }
        });
    }
    //$scope.getUsersForContent();

    $scope.contUserId = "";
    $scope.getUserContentDetailsBySubject = function (uid, uname) {

        $scope.contUserId = uid;
        $scope.contUserName = uname;
        httpFactory.getResult("getUserContentDetailsBySubject?userId=" + $scope.contUserId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentListBySubject = data.UserObject;
            } else {
                $scope.contentListBySubject = [];
            }
        });
    }


    $scope.getUserContentDetailsBySubjectForDate = function () {

        var frmDate = document.getElementById('frmSubDate').value;
        var tDate = document.getElementById('tSubDate').value;
        httpFactory.getResult("getUserContentDetailsBySubject?userId=" + $scope.contUserId + "&schemaName=" + $scope.schemaName + "&fromDate=" + frmDate + "&toDate=" + tDate, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentListBySubject = data.UserObject;
            } else {
                $scope.contentListBySubject = [];
            }
        });
    }

    $scope.getUserContentDetailsByChapter = function (subid) {

        httpFactory.getResult("getUserContentDetailsByChapter?userId=" + $scope.contUserId + "&schemaName=" + $scope.schemaName + "&subjectId=" + subid, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.chapterTopicsList = data.UserObject;
            } else {
                $scope.chapterTopicsList = [];
            }
        });
    }
    $scope.getSelectedPaymentBranchDetails = function (brch) {

        $scope.getPaymentBranchDetails(brch);
        $scope.selectedBranchForMap = $scope.paymentBranchDetails;
        //$scope.getBranchInstTypes($scope.selectedBranchForMap);
        //console.log($scope.selectedBranchForMap);
        //$scope.getBranchClassCourse();
        //$scope.classCourseArr=[];
    }

    $scope.activateBranch = function (brch) {
        debugger;
        httpFactory.getResult("updateBranchStatus?isActive=1&branchId=" + brch.branchId + "&userId=" + $scope.userId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
                $scope.getAllBranches();
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.deActivateBranch = function (brch) {
        debugger;
        httpFactory.getResult("updateBranchStatus?isActive=0&branchId=" + brch.branchId + "&userId=" + $scope.userId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
                $scope.getAllBranches();
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.getPaymentBranchDetails = function (brch) {

        httpFactory.getResult("getBranchPaymentDetails?schemaName=" + localStorage.getItem("sname") + "&branchId=" + brch.branchId, function (data) {
            console.log(data);
            $scope.paymentBranchDetails = [];
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                if (typeof data.branchPaymentDetails != "undefined") {
                    if (data.branchPaymentDetails.length > 0) {
                        $scope.paymentBranchDetails = data.branchPaymentDetails[0];
                    } else {
                        alert("Payment Details Not Found");
                    }
                } else {
                    alert("Payment Details Not Found");
                }
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.updatePaymentBranchDetails = function (brch) {
        var params = {
            "academicYear": brch.academicYear,
            "chargedAmount": brch.chargedAmount,
            "paidAmount": brch.paidAmount,
            "paymentDate": brch.paymentDate,
            "discountAmount": brch.discountAmount,
            "sourceOfPayment": brch.sourceOfPayment,
            "paymentTransId": brch.paymentTransId,
            "branchId": $scope.paymentBranchDetails.branchId,
            "instId": localStorage.getItem("inst_id"),
            "schemaName": localStorage.getItem("sname")
        }
        httpFactory.executePost("updateBranchPaymentDetails", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("successfully updated");
                $scope.enableBranchmappingTab();
            } else {
                $scope.errorMsg = data.message;
            }
        });
    }

    //Code for Content Details management end
    //multiple variable log parameters
    var sureshlog = (function () {
        return {
            log: function () {
                var args = Array.prototype.slice.call(arguments);
                console.log.apply(console, args);
            },
            warn: function () {
                var args = Array.prototype.slice.call(arguments);
                console.warn.apply(console, args);
            },
            error: function () {
                var args = Array.prototype.slice.call(arguments);
                console.error.apply(console, args);
            }
        }
    });
    $scope.closeSubjectModal = function () {
        $("#availableSubjectsModal").modal("hide");
    }

    $scope.saveBranchOptionalSubjects = function () {
        var params = {
            "updatedRecords": $scope.branchSubjectsArr,
            "schemaName": localStorage.getItem("sname")
        }
        httpFactory.executePost("updateBranchOptionalSubjects", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("successfully updated");
                $scope.branchSubjectsArr = [];
            } else {
                $scope.errorMsg = data.message;
            }
        });

    }
    $scope.selectBranchSubjectAssignment = function (subjectId, optionalSubjectId, subj, isSubjectChecked) {
        console.log(isSubjectChecked);
        var isActStatus = 0;
        if (isSubjectChecked == true) {
            isActStatus = 1;
        }
        if (subj.isActive == 1) {
            subActive = true;
        }
        else {
            subActive = false;
        }
        if (subActive != isSubjectChecked) {
            var obj = {
                "branchId": $scope.selectedBranchForMap.branchId,
                "subjectId": subjectId,
                "isActive": isActStatus,
                "userId": localStorage.getItem("userId"),
                "optionalSubjectId": optionalSubjectId
            }
            $scope.branchSubjectsArr.push(obj);
        }
    }

    $scope.selectBranchBilingualSubjectAssignment = function (subjectId, subj, isSubjectChecked) {
        console.log(isSubjectChecked);
        var isActStatus = 0;
        if (isSubjectChecked == true) {
            isActStatus = 1;
        }
        if (subj.isBrchOptlVideoContent == 1) {
            subActive = true;
        }
        else {
            subActive = false;
        }
        if (subActive != isSubjectChecked) {
            var obj = {
                "branchId": $scope.selectedBranchForMap.branchId,
                "subjectId": subjectId,
                "isContentOptional": isActStatus,
                "branchOptVideoContentId": subj.branchOptVideoContentId,
                "userId": localStorage.getItem("userId"),
                "instId": localStorage.getItem("inst_id"),
                "courseId": $scope.brnchCourseId,
                "classId": $scope.viewSubjectId
            }
            $scope.branchBilingualSubjectsArr.push(obj);
        }
    }
    $scope.saveBranchBilingualSubjects = function () {
        var params = {
            "insertRecords": $scope.branchBilingualSubjectsArr,
            "schemaName": localStorage.getItem("sname"),

        }
        httpFactory.executePost("updateBranchBilingualSubjects", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("successfully updated");
                $scope.branchBilingualSubjectsArr = [];
            } else {
                $scope.errorMsg = data.message;
            }
        });

    }

    $scope.editBranchBilingualSubjectAssignment = function (course) {
        console.log(course);
        $scope.courseDetails = course;
        $scope.branchId = $scope.selectedBranchForMap.branchId
        $scope.courseId = course.courseId;
        $scope.getClassByCourseId();
        $scope.classes = $scope.classList;
        $scope.classList = [];
        $scope.bilingualClassArr = [];
        for (i = 0; i < $scope.classes.length; i++) {
            if ($scope.classes[i].checked == true) {
                $scope.classList.push($scope.classes[i]);
            }
        }
        for (j = 0; j < $scope.classList.length; j++) {
            var count = 0;
            var generalSubj = [];
            $scope.subjects = $scope.classList[j].Subjects;
            for (k = 0; k < $scope.subjects.length; k++) {
                if ($scope.subjects[k].electiveGroupId == 0 && $scope.subjects[k].isOptional == 0) {
                    generalSubj.push($scope.subjects[k]);
                    if ($scope.subjects[k].isBranchOptVideoContent == 1)
                        count++;
                }
            }
            if (count == generalSubj.length) {
                $scope.classList[j]["isClassChecked"] = true;
                $scope.bilingualClassArr.push($scope.classList[j]);
            }
        }
        console.log($scope.classList);
        var count = 0;
        for (k = 0; k < $scope.classList.length; k++) {
            if ($scope.classList[k].isClassChecked == true)
                count++;
        }
        if (count == $scope.classList.length) {
            $scope.classList["isSelectAll"] = true;
        }
        $("#availableClassesModal").modal("show");
    }

    $scope.classesArr = [];
    $scope.updateBilingualCourseAssignment = function (course) {
        selectAll = document.getElementById('selectAllClasses').checked;
        $scope.isActStatus = 0;
        $scope.branchBilingualSubjectsArr = [];
        if (selectAll == true) {
            $scope.isActStatus = 1;
            for (j = 0; j < $scope.classList.length; j++) {
                document.getElementsByName('selectClass')[j].checked = true;
            }
        } else if (selectAll == false) {
            for (j = 0; j < $scope.classList.length; j++) {
                document.getElementsByName('selectClass')[j].checked = false;
            }
        }
    }

    $scope.updateBilingualCourseClassAssignment = function (clss, isClassChecked) {
        for (i = 0; i < $scope.classList.length > 0; i++) {
            if (document.getElementsByName('selectClass')[i].checked == false) {
                document.getElementById('selectAllClasses').checked = false;
            }
        }
    }

    $scope.saveBranchCourseClassBilingualSubjects = function () {
        $scope.selectedClassArr = [];
        $scope.unSelectedClassArr = [];
        $scope.branchBilingualSubjectsArr = [];
        for (i = 0; i < $scope.classList.length; i++) {
            if (document.getElementsByName('selectClass')[i].checked == true) {
                if ($scope.classList[i].hasOwnProperty("isClassChecked")) {

                } else {
                    $scope.selectedClassArr.push($scope.classList[i].classId);
                }
            } else if (document.getElementsByName('selectClass')[i].checked == false) {
                if ($scope.classList[i].hasOwnProperty("isClassChecked")) {
                    $scope.unSelectedClassArr.push($scope.classList[i].classId);
                }
            }
        }
        if ($scope.selectedClassArr.length > 0) {
            var bobj = {
                "branchId": $scope.selectedBranchForMap.branchId,
                "courseId": $scope.courseId,
                "userId": localStorage.getItem("userId"),
                "isContentOptional": 1,
                "classes": $scope.selectedClassArr
            }
            $scope.branchBilingualSubjectsArr.push(bobj);
        }
        if ($scope.unSelectedClassArr.length > 0) {
            var obj = {
                "branchId": $scope.selectedBranchForMap.branchId,
                "courseId": $scope.courseId,
                "userId": localStorage.getItem("userId"),
                "isContentOptional": 0,
                "classes": $scope.unSelectedClassArr
            }
            $scope.branchBilingualSubjectsArr.push(obj);
        }

        var params = {
            "insertRecords": $scope.branchBilingualSubjectsArr,
            "schemaName": localStorage.getItem("sname")
        }
        httpFactory.executePost("updateBranchBilingualSubjects", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("successfully updated");
                $scope.branchBilingualSubjectsArr = [];
            } else {
                $scope.errorMsg = data.message;
            }
        });
    }

    $scope.getWebhookDetails = function () {
        httpFactory.getResult("getWebhookDetails?schemaName=" + localStorage.getItem("sname") + "&branchId=" + $scope.selectedBranchForMap.branchId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.wbDetails = data.wbDetails[0];
                $scope.tempWbDetails = angular.copy($scope.wbDetails);
                console.log($scope.wbDetails);
            } else if (data.StatusCode == 300) {
                $scope.wbDetails = {
                    "webhookId": 0,
                    "webhookUrl": '',
                    "waNumber": '',
                    "licenseKey": ''
                }
                $scope.tempWbDetails = angular.copy($scope.wbDetails);
            } else {

            }
        });
    }

    $scope.updateWebhookDetailsForBranch = function () {
        if ($scope.wbDetails.webhookUrl == '' || $scope.wbDetails.waNumber == '') {
            alert("Mandatory fields can't be empty.");
            return;
        }
        var params = {
            "schemaName": localStorage.getItem("sname"),
            "webhookId": $scope.wbDetails.webhookId,
            "branchId": $scope.selectedBranchForMap.branchId
        }
        if ($scope.tempWbDetails.webhookUrl != $scope.wbDetails.webhookUrl)
            params["webhookUrl"] = $scope.wbDetails.webhookUrl;
        if ($scope.tempWbDetails.waNumber != $scope.wbDetails.waNumber)
            params["waNumber"] = $scope.wbDetails.waNumber;
        if ($scope.tempWbDetails.licenseKey != $scope.wbDetails.licenseKey && $scope.wbDetails.licenseKey != '')
            params["licenseKey"] = $scope.wbDetails.licenseKey;
        if (params.hasOwnProperty("webhookUrl") || params.hasOwnProperty("waNumber") || params.hasOwnProperty("licenseKey")) {
            httpFactory.executePost("updateWebhookDetailsForBranch", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    alert("Successfully Updated");
                    $scope.enableBranchmappingTab();
                    $scope.getWebhookDetails();
                } else {
                    alert(data.message);
                }
            });
        } else {
            alert("No Changes");
            $scope.enableBranchmappingTab();
        }
    }

    $scope.assignBranchToStore = function () {
        if ($scope.assignedBranchWithStore.isStoreAssigned == document.getElementById("isStoreAssigned").checked) {
            alert("No Changes");
            return;
        }
        var params = {
            "schemaName": localStorage.getItem("sname"),
            "branchStoreId": $scope.assignedBranchWithStore.hasOwnProperty("branchStoreId") ? $scope.assignedBranchWithStore.branchStoreId : 0,
            "branchId": $scope.selectedBranchForMap.branchId,
            "isStoreAssigned": document.getElementById("isStoreAssigned").checked == true ? 1 : 0,
            "createdBy": localStorage.getItem("userId")
        }
        httpFactory.executePost("assignBranchToStore", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.getBranchAssignedWithStore();
                alert("Changes Saved");
            } else {
                alert(data.message);
            }
        });
    }

    $scope.getBranchAssignedWithStore = function () {
        $scope.isBranchAssigned = false;
        $scope.assignedBranchWithStore = {};
        httpFactory.getResult("getBranchStoreStatus?schemaName=" + localStorage.getItem("sname") + "&branchId=" + $scope.selectedBranchForMap.branchId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.assignedBranchWithStore = data.assignedBranchWithStore;
                $scope.isStoreAssigned = data.assignedBranchWithStore.isStoreAssigned;
            } else {

            }
        });
    }

    $scope.getLessonPlanCourseClassDetails = function (instituteTyp) {
        $scope.lessonPlanCourseClassList = [];
        if($scope.lpAssignList.length > 0){
            if(!confirm("Your changes will not be saved. Are you ok?")){
                return;
            }
        }
        $scope.lpAssignList = [];
        $scope.instTypeObId = instituteTyp;
        httpFactory.getResult("getLessonPlanCourseClass?schemaName=" + localStorage.getItem("sname") + "&branchId=" + $scope.selectedBranchForMap.branchId + "&instId=" + localStorage.getItem("inst_id") + "&instType=" + instituteTyp, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.lessonPlanCourseClassList = data.ClassCourses;
            } else {

            }
        });
    }

    $scope.lpAssignList = [];

    $scope.selectLessonPlanCourseClassAssignment = function (lpSelOb) {
        var lpObj = {};
        if ($scope.lpAssignList.findIndex(lpAssignList => lpAssignList.classCourseId === lpSelOb.classCourseId) == -1) {
            lpObj = {
                "isAssigned": lpSelOb.isAssigned,
                "classCourseId": lpSelOb.classCourseId,
                "lpId": lpSelOb.lpId
            }
            $scope.lpAssignList.push(lpObj);
        } else {
            $scope.lpAssignList.splice($scope.lpAssignList.findIndex(lpAssignList => lpAssignList.classCourseId === lpSelOb.classCourseId), 1);
        }

    }

    $scope.updateLessonPlanCourseClassDetails = function () {

        var params = {
            "schemaName": localStorage.getItem("sname"),
            "userId": localStorage.getItem("userId"),
            "updatedRecords": $scope.lpAssignList
        };
        console.log(params);

        httpFactory.executePost("updateLessonPlanCourseClass", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.lpAssignList = [];
                $scope.getLessonPlanCourseClassDetails($scope.instTypeObId);                
                alert("successfully updated");
                $scope.enableCCmappingTab();
            } else {
                alert(data.message);
            }
        });
    }
    
});