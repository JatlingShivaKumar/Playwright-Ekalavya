projectModule.controller('contentManagementController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
    $scope.$ = $;
    $scope.instituteId = localStorage.getItem("inst_id");
    $scope.schemaName = localStorage.getItem("sname");

    $scope.contentInit = function() {
        // $scope.getAllBranches();
        $scope.changeBranch();

    }
    $scope.contentChapterInit = function() {
        $scope.getInstituteTypes();
    }
    $scope.redirectToChapterManagement = function() {
        $location.path("/contentManagement");
    }
    $scope.redirectToQuestionsManagement = function() {
        $location.path("/questions");
    }
    $scope.redirectToAddQuestionsContent = function() {
        console.log($scope.contentOwnerList);
        $("#addquesModal").modal("show");
    }

    $scope.getAllBranches = function() {
        httpFactory.getResult("getAllBranches?instId=" + localStorage.getItem("inst_id") + "&schemaName=" + localStorage.getItem("sname") + "&roleId=" + localStorage.getItem("RD") + "&branchId=" + localStorage.getItem("bnchId"), function(data) {
            if (data.StatusCode == 200) {
                $scope.branchList = data.collegeBranches;
                console.log($scope.branchList);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.changeBranch = function(branchId) {
        $scope.branchId = localStorage.getItem("bnchId");
        httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.courseList = data.Courses;
                console.log($scope.courseList);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.courseChange = function(course) {
        $scope.contentList = [];
        console.log(course);
        $scope.courseId = course.courseId;
        $scope.courseName = course.courseName;
        $scope.getClassByCourseId();
        $scope.getContentOwner();
    }
    $scope.getClassByCourseId = function() {
        httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
               var classes = data.Classes;
               $scope.classList =[];
                for(var i =0;i<classes.length ;i++){
                	if(classes[i].isActive == 1){
                		$scope.classList.push(classes[i]);
                	}
                }
                console.log($scope.classList);
            } else {
                console.log("No Classes");
            }
        });
    }
    $scope.getContentOwner = function() {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                if ($scope.selInstCrs) {
                    $scope.courseId = $scope.selInstCrs;
                }
                $scope.contentOwnerList = [];
                $scope.contentList = data.ContentOwner;
                console.log($scope.contentList);
                for (var i = 0; i < $scope.contentList.length; i++) {
                    console.log($scope.contentList[i].courseId);
                    console.log($scope.courseId);
                    if ($scope.contentList[i].courseId == $scope.courseId) {
                        $scope.contentOwnerList.push($scope.contentList[i]);
                    }
                }
                console.log($scope.contentOwnerList);
            } else {
                console.log("No ContentList");
            }
        });
    }
    $scope.getSchemaContentOwner = function() {
        httpFactory.getResult("getSchemaContentOwner?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.schemaContent = [];
                $scope.schemaContent = data.schemaContent;
                console.log($scope.schemaContent);
            } else {
                console.log("No ContentList");
            }
        });
    }
    $scope.getCourseByInstType = function() {
        httpFactory.getResult("getAllCoursesByInstType?instType=" + $scope.selInstTypeId + "&schemaName=" + localStorage.getItem("sname"), function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.instCourseList = data.Courses;
            } else {
                console.log("No Courses");
            }
        });
    }
    $scope.getClsByInstCrs = function() {
        httpFactory.getResult("getAllClassesByInstTypeAndCourseId?instType=" + $scope.selInstTypeId + "&courseId=" + $scope.selInstCrs + "&schemaName=" + localStorage.getItem("sname"), function(data) {
            console.log(data);
            $scope.clsListCrsInstType = [];
            if (data.StatusCode == 200) {
                $scope.instCrsclsList = data.Classes;
            } else {
                console.log("No Courses");
            }
        });
    }
    $scope.getSubjectQuestionsCount = function() {
        var params = {
            "classId": $scope.selInstCrsCls,
            "contentOwner": $scope.selectedContentOwner,
            "courseId": $scope.selInstCrs,
            "contentType": $scope.selContentType,
            "schemaName": localStorage.getItem("sname")
        }
        httpFactory.executePost("getSubjectQuestionsCount", params, function(data) {

            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success");
                $scope.subjectList = data.Questions;
                console.log($scope.subjectList);
            } else {
                alert('No Data Found.')

            }
        });
    }
    $scope.classAcadamicSelectDump = {};
    $scope.classChange = function(classObj) {
        $scope.contentList = [];
        $scope.classId = classObj.classId;
        $scope.classCourseId = classObj.classCourseId;
        $scope.classAcadamicSelectDump = classObj;
    }

    $scope.goMethod = function() {
        $scope.sectionList = [];
        $scope.subjectList = [];



        httpFactory.getResult("selectSectionsByBranchCourseClass?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classCourseId+ "&instId=" + $scope.instituteId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.sectionList = data.Sections;
                console.log($scope.sectionList);
                $scope.getSubjectsByCourse();
                $scope.selectSection($scope.sectionList[0].sectionId);
            } else {
                alert("No sections Added");
                console.log("No Sections");
            }
        });
        $scope.classAcadamicSelectChange($scope.classAcadamicSelectDump);
    }

    $scope.selectSection = function(sectionId) {
        $scope.sectionId = sectionId;
        console.log($scope.sectionId);
        $scope.getChapterTopicAccessBySubject();
    }

    $scope.getSubjectsByCourse = function() {
        $scope.subjectList = [];
        $scope.classAcadamicSelect = $scope.classList[$scope.classList.indexOf($scope.classAcadamicSelectDump)];
        httpFactory.getResult("getSubjectsByCourse?schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId+"&branchId=" + $scope.branchId , function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.subjectList = data.classeSubjects;
                console.log($scope.subjectList);
                $scope.selectedSubjectId = $scope.subjectList[0].subjectId;
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.selSubjListDump = [];
    $scope.classAcadamicSelectChange = function(classObj) {
        $scope.selSubjListDump = [];
        $scope.classAcadamicSelectId = classObj.classId;
        for (var i = 0; i < $scope.subjectList.length; i++) {
            if ($scope.classAcadamicSelectId == $scope.subjectList[i].classId) {
                $scope.selSubjListDump.push($scope.subjectList[i]);
            }
        }
        console.log($scope.selSubjListDump);
        $scope.selectSubject($scope.selSubjListDump[0].subjectId);
    }

    $scope.selectSubject = function(subjectId) {
        $scope.selectedSubjectId = subjectId;
        $scope.getChapterTopicAccessBySubject();
    }
    $scope.topicIds = [];


    $scope.getChapterTopicAccessBySubject = function() {
        $scope.topicIds = [];
        var contentType = $scope.courseName +","+ $scope.contentType;
        httpFactory.getResult("contentAccessBySection?contentType=" + contentType + "&schemaName=" + $scope.schemaName + "&subjectId=" + $scope.selectedSubjectId + "&sectionId=" + $scope.sectionId+ "&branchId=" + $scope.branchId+"&courseId=" + $scope.courseId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentList = data.ContentOwner;
                for (var k = 0; k < $scope.contentList.length; k++) {
                    for (var j = 0; j < $scope.contentList[k].ChapterTopic.length; j++) {
                        if ($scope.contentList[k].ChapterTopic[j].chaptertopicAccessId == 0) {
                            $scope.contentList[k].ChapterTopic[j].selected = false;
                        } else {
                            $scope.contentList[k].ChapterTopic[j].selected = true;
                        }
                    }
                    $scope.chapterCheckStatus($scope.contentList[k]);
                }
                console.log($scope.contentList);
            } else {
                $scope.contentList = [];
                console.log("No branches");
            }
        });
    }

    $scope.allChapterAccess = function() {
        $scope.topicIds = [];
        for (var k = 0; k < $scope.contentList.length; k++) {
            for (var j = 0; j < $scope.contentList[k].ChapterTopic.length; j++) {
                if ($scope.contentList[k].ChapterTopic[j].chaptertopicAccessId == 0) {
                    var obj = {
                        "topicId": $scope.contentList[k].ChapterTopic[j].topicId,
                        "chapterAccessId": $scope.contentList[k].ChapterTopic[j].chaptertopicAccessId
                    }
                    $scope.topicIds.push(obj);
                    $scope.contentList[k].ChapterTopic[j].selected = true;
                }
            }
            $scope.contentList[k].selected = true;
        }
    }
    $scope.resetChapterAccess = function() {
        $scope.getChapterTopicAccessBySubject();
    }

    $scope.chapterCheckStatus = function(chapter) {
        for (var k = 0; k < $scope.contentList.length; k++) {
            if ($scope.contentList[k].chapterId == chapter.chapterId) {
                var checkStat = true;
                for (var j = 0; j < $scope.contentList[k].ChapterTopic.length; j++) {
                    if ($scope.contentList[k].ChapterTopic[j].selected == undefined || $scope.contentList[k].ChapterTopic[j].selected == false) {
                        checkStat = false;
                    }
                }
                $scope.contentList[k].selected = checkStat;
            }
        }
    }

    $scope.chapterSelected = function(chapter) {
        console.log(chapter.selected);
        var selectChapIndex = 0;
        for (var k = 0; k < $scope.contentList.length; k++) {
            if ($scope.contentList[k].chapterId == chapter.chapterId) {
                selectChapIndex = k;
                break;
            }
        }

        for (var i = 0; i < chapter.ChapterTopic.length; i++) {
            if (chapter.ChapterTopic[i].chaptertopicAccessId > 0) {
                var obj = {
                    "topicId": chapter.ChapterTopic[i].topicId,
                    "chapterAccessId": chapter.ChapterTopic[i].chaptertopicAccessId
                }
                $scope.tagStatusC = true;
                for (var j = 0; j < $scope.topicIds.length; j++) {
                    if ($scope.topicIds[j].topicId == chapter.ChapterTopic[i].topicId) {
                        $scope.tagStatusC = false;
                        $scope.topicIds.splice(j, 1);
                        $scope.contentList[selectChapIndex].ChapterTopic[i].selected = true;
                    }
                }
                if ($scope.tagStatusC == true) {
                    if (chapter.selected == true) {
                        $scope.topicIds.push(obj);
                        $scope.contentList[selectChapIndex].ChapterTopic[i].selected = false;
                    }
                }
            } else {
                var obj = {
                    "topicId": chapter.ChapterTopic[i].topicId,
                    "chapterAccessId": chapter.ChapterTopic[i].chaptertopicAccessId
                }
                $scope.tagStatusC = true;
                for (var j = 0; j < $scope.topicIds.length; j++) {
                    if ($scope.topicIds[j].topicId == chapter.ChapterTopic[i].topicId) {
                        $scope.tagStatusC = false;
                        $scope.topicIds.splice(j, 1);
                        $scope.contentList[selectChapIndex].ChapterTopic[i].selected = false;
                    }
                }
                if ($scope.tagStatusC == true) {
                    $scope.topicIds.push(obj);
                    $scope.contentList[selectChapIndex].ChapterTopic[i].selected = true;
                }
            }
            console.log($scope.topicIds);
        }
        //$scope.chapterCheckStatus(chapter);
    }


    $scope.topicSelected = function(topicData) {
        console.log(topicData);
        var obj = {
            "topicId": topicData.topicId,
            "chapterAccessId": topicData.chaptertopicAccessId
        }
        $scope.tagStatus = true;
        for (var i = 0; i < $scope.topicIds.length; i++) {
            if ($scope.topicIds[i].topicId == topicData.topicId) {
                $scope.tagStatus = false;
                $scope.topicIds.splice(i, 1);
            }
        }
        if ($scope.tagStatus == true) {
            $scope.topicIds.push(obj);
        }
        //$scope.chapterCheckStatus(chapter);
        console.log($scope.topicIds);
    }

    $scope.acadamicTimeIntituteTypes = [];
    /*$scope.getInstituteTypes = function() {
        httpFactory.getResult("getCollegeInstituteTypes?schemaName=" + localStorage.getItem("sname") +"&instId=" + localStorage.getItem("inst_id"), function(data) {
            if (data.statusCode == '200') {
                $scope.instituteTypes = data.data;
                console.log($scope.instituteTypes);
                $scope.acadamicTimeIntituteTypes = data.data;
                // $scope.latestCurrentInstTab = $scope.instituteTypes[0].instTypeId;
            }
        });
    }*/
    $scope.getInstituteTypes = function() {
    	debugger;
        httpFactory.getResult("getBranchInstituteTypes?schemaName=" + localStorage.getItem("sname") +"&branchId=" + localStorage.getItem("bnchId"), function(data) {
            if (data.statusCode == '200') {
                $scope.instituteTypes = data.data;
                console.log($scope.instituteTypes);
                $scope.acadamicTimeIntituteTypes = data.data;
                // $scope.latestCurrentInstTab = $scope.instituteTypes[0].instTypeId;
            }
        });
    }
    $scope.selectedInstTypeMethod = function(instType) {
        if (typeof instType == 'string') {
            $scope.instTypeOb = JSON.parse(instType);

        } else {
            $scope.instTypeOb = instType;
        }
        console.log($scope.instTypeOb);
        $scope.getAllClassesByInstType();
    }

    $scope.getAllClassesByInstType = function() {

        httpFactory.getResult("getAllClassesByInstType?instType=" + $scope.instTypeOb.instTypeId + "&schemaName=" + localStorage.getItem("sname"), function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.classList = data.Classes;
                console.log($scope.classList);
            } else {}
        });
    }

    $scope.getSubjectsByClassChange = function(cls) {
        console.log(cls);
        httpFactory.getResult("getSubjectByClass?classId=" + $scope.selctedCls + "&schemaName=" + localStorage.getItem("sname"), function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.subjList = data.Subjects;
                console.log($scope.subjList);
            } else {}
        });
    }
    $scope.subjectChange = function() {
        $scope.contentList = [];

    }
    $scope.getChapterTopicsBySubjectChangeques = function(subjectId) {
    	var contentType = $scope.courseName+","+ $scope.selContentType;
        httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selInstCrsCls + "&subjectId=" + subjectId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&contentType=" + contentType +"&branchId="+localStorage.getItem("bnchId")+"&courseId="+$scope.courseId+"&instId="+$scope.instituteId, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.chapterListByClassSubject = data.Chaptertopics;
                console.log($scope.chapterListByClassSubject);
            } else {}
        });
    }

    $scope.getChapterTopicsBySubjectChange = function() {
        httpFactory.getResult("getChapterTopicsBySubIdForCM?classId=" + $scope.selctedCls + "&subjectId=" + $scope.selectedSbj + "&schemaName=" + localStorage.getItem("sname") + "&contentType=EAMCET", function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.chapterContent = data.Chaptertopics;
                console.log($scope.chapterListByClassSubject);
            } else {}
        });
    }

    $scope.getTopicsByChapterContent = function(chap) {
        if (typeof chap == 'string') {
            $scope.chapTopicList = JSON.parse(chap);
        } else {
            $scope.chapTopicList = chap;
        }
        $scope.selChapId = $scope.chapTopicList.chapterId;
        $scope.subChapterListByChapter = $scope.chapTopicList.Topics;
        console.log($scope.subChapterListByChapter);
    }

    $scope.getQuestionsByTopicId = function(subjectId) {
    	 var branchId = $scope.branchId + "," + "0";
        httpFactory.getResult("getQuestionsByTopicId?topicId=" + $scope.selectedTopicId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.selectedContentOwner +"&branchId=" + branchId, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.ques = data.Questions[0];
                console.log($scope.ques);
                $scope.questionsArray = $scope.ques.questionArray;
                console.log($scope.questionsArray);
            } else {}
        });
    }

    $scope.selectTopicMethod = function(topic) {
        console.log(topic);
        $scope.selectedTopicId = topic;
    }

    $scope.contentEdit = function(topics, chapterName) {
        console.log(topics);
        $location.path("/contentEdit/" + topics.topicId);
    }

    $scope.displayAddChapterModal = function() {
        $("#addChapterModal").modal("show");
    }

    $scope.updateChapterAccess = function() {
        if ($scope.topicIds.length == 0) {
            alert("You have not done any Changes");
            return true;
        }
        var params = {
            "schemaName": localStorage.getItem("sname"),
            "createdBy": localStorage.getItem("userId"),
            "isActive": 1,
            "branchId": localStorage.getItem("bnchId"),
            "sectionId": $scope.sectionId,
            "updatedRecords": $scope.topicIds
        }
        console.log(params);
        httpFactory.executePost("updateContentAccess", params, function(data) {
            $("#divLoading").removeClass('hide').addClass('show');
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success");
                $scope.topicIds = [];
                $scope.getChapterTopicAccessBySubject();
            } else {
                alert('No Data Found.')

            }
        });
    }
    $scope.addNewChapterForContent = function() {
        var params = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "createdBy": localStorage.getItem("userId"),
                "isActive": 1,
                "subjectId": $scope.selectedSbj,
                "chapterName": $scope.chapterName,
                "instId": localStorage.getItem("inst_id"),
                "classId": $scope.selctedCls,
                "chapterOwner": "COLLEGE",
                "contentType": "EAMCET",
                "branchId":localStorage.getItem("bnchId")
            }]
        };
        console.log(params);

        httpFactory.executePost("addChapters", params, function(data) {
            $("#divLoading").removeClass('hide').addClass('show');
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("chapter added successfully");
                $("#addChapterModal").modal("hide");
                $scope.chapterName = "";
                $scope.getChapterTopicsBySubjectChange();
            } else {
                alert('No Data Found.')

            }
        });
    }

    $scope.displayAddTopicModal = function(chapId) {
        $scope.addingChapId = chapId;
        console.log($scope.addingChapId);
        $("#addTopicModal").modal("show");
    }
    $scope.addNewTopicForContent = function() {
        var params = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "createdBy": localStorage.getItem("userId"),
                "isActive": 1,
                "topicName": $scope.topicName,
                "instId": localStorage.getItem("inst_id"),
                "contentOwner": "COLLEGE",
                "chapterId": $scope.addingChapId,
                "contentType": $scope.courseName,
                "courseId": $scope.courseId
            }]
        };
        console.log(params);

        httpFactory.executePost("addTopic", params, function(data) {
            $("#divLoading").removeClass('hide').addClass('show');
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("chapter added successfully");
                $("#addTopicModal").modal("hide");
                $scope.topicName = "";
                $scope.getChapterTopicsBySubjectChange();

            } else {
                alert('No Data Found.')

            }
        });
    }

    $scope.getTopicContent = function() {
        httpFactory.getResult("getTopicContent?topicId=" + $routeParams.topicId + "&schemaName=" + localStorage.getItem("sname") + "&chapterOwner=" + $routeParams.own, function(data) {
            // httpFactory.getResult("getTopicContent?topicId=1&schemaName=rankr&chapterOwner=RANKR1", function(data) {

            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.ImportantContent = data.ImportantContent;
                $scope.QuestionAndAnswers = data.QuestionAndAnswers;
                $scope.TextBookContent = data.TextBookContent;
                console.log($scope.ImportantContent);
                console.log($scope.QuestionAndAnswers);

            } else {}
        });
    }
    $scope.contentEditInit = function() {
        $scope.getTopicContent();
    }

    // suresh -- to save content
    $scope.saveContent = function(tag) {
        var requestParams = "";
        if (tag == "textBook") {
            $scope.textBookContent = $scope.TextBookContent;
            $scope.impPointsContent = "";
            $scope.QandAContent = "";
            requestParams = {
                "schemaName": $scope.schemaName,
                "topicId": $routeParams.topicId,
                "updatedBy": localStorage.getItem("userId"),
                "TextBookContent": $scope.textBookContent
            };
        } else if (tag == "important") {
            $scope.textBookContent = "";
            $scope.impPointsContent = "";
            $scope.QandAContent = $scope.QuestionAndAnswers;
            requestParams = {
                "schemaName": $scope.schemaName,
                "topicId": $routeParams.topicId,
                "updatedBy": localStorage.getItem("userId"),
                "QuestionAndAnswers": $scope.QandAContent
            };
        } else if (tag == "synopsis") {
            $scope.textBookContent = "";
            $scope.impPointsContent = $scope.ImportantContent;
            $scope.QandAContent = "";
            requestParams = {
                "schemaName": $scope.schemaName,
                "topicId": $routeParams.topicId,
                "updatedBy": localStorage.getItem("userId"),
                "ImportantContent": $scope.impPointsContent,
            };
        }
        console.log(requestParams);
        httpFactory.executePost("updateTopicContent", requestParams, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Topic Content added succesfully");
            } else {

            }
        });
    }


    $scope.insertCollegeQuestionContent = function() {

        // $scope.selectedChapter=1;
        // $scope.selectedTopic=1;
        console.log($scope.selChapId);
        console.log($scope.selectedTopicId);

        $scope.question = CKEDITOR.instances['question'].getData();
        $scope.option1 = CKEDITOR.instances['option1'].getData();
        $scope.option2 = CKEDITOR.instances['option2'].getData();
        $scope.option3 = CKEDITOR.instances['option3'].getData();
        $scope.option4 = CKEDITOR.instances['option4'].getData();
        $scope.explanation = CKEDITOR.instances['explanation'].getData();
        $scope.correctAnswer = $("#correctAnswer").val();
        // $scope.questionCat = $("#questionCat").val();
        $scope.diffLevel = $("#diffLevel").val();
        $scope.qstnAppeared = $("#questionAppeared").val();
        if (!$scope.qstnAppeared) {
            $scope.qstnAppeared = "";
        }

        if ($scope.selectedContentOwner == 'CEDZ') {
            alert("cedz" + $scope.selectedContentOwner);
            $scope.questionAdded = 1;
        } else {
            $scope.questionAdded = 0;
        }
        // alert($scope.selTopicId);
        // $scope.diffLevel='1';

        var params = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "question": $scope.question,
                "option1": $scope.option1,
                "option2": $scope.option2,
                "option3": $scope.option3,
                "option4": $scope.option4,
                "explanation": $scope.explanation,
                "correctAnswer": $scope.correctAnswer,
                "questionType": $scope.questionCategory,
                "topicId": $scope.selectedTopicId,
                "chapterId": $scope.selChapId,
                "difficultyLevel": $scope.diffLevel,
                "questionOwner": "COLLEGE",
                "questionAdded": $scope.questionAdded,
                "createdBy": localStorage.getItem("userId")
            }]
        };
        httpFactory.executePost("addQuestion", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Topic Content added succesfully");
            } else {

            }
        });
    }

    $scope.contentSelectMethod = function(content) {
        console.log(content);
        $scope.contentList = [];
        $scope.contentType = content.contentType;
        console.log($scope.contentType);
    }

    var view = $("#tslshow");
    var move = "200px";
    var sliderLimit = -750;

    $("#rightArrow").click(function() {
        console.log("right");
        var currentPosition = parseInt(view.css("left"));
        if (currentPosition >= sliderLimit) view.stop(false, true).animate({
            left: "-=" + move
        }, {
            duration: 400
        })

    });

    $("#leftArrow").click(function() {
        console.log("right");
        var currentPosition = parseInt(view.css("left"));
        if (currentPosition < 0) view.stop(false, true).animate({
            left: "+=" + move
        }, {
            duration: 400
        })

    });
});