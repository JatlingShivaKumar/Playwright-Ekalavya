projectModule.controller('feeDetailsAssignmentController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourse = "";
	$scope.selectedCourseName = "";
	$scope.selectedClassObj = "";
	$scope.selectedClass = "";

	$scope.getCoursesByBranch = function() {

		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedCourseOb = "";
		$scope.selectedClassObj = "";
		$scope.selectedClass = "";

			httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.selectedBranch , function(data) {
			console.log(data);
			if (data.StatusCode == 200){
					$scope.courseList = data.Courses;
					console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function() {

		console.log($scope.selectedCourseOb);
		if($scope.selectedCourseOb == null || $scope.selectedCourseOb == ""){
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse=$scope.selectedCourseObj.courseId;
		$scope.selectedCourseName=$scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
				httpFactory.getResult("getClassByCoursesID?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch + "&courseId="+$scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200){
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);

			} else {
				console.log("No classes found");
			}
		});
	}
	$scope.getAllFeeCategories = function(){
		httpFactory.getResult("getAcademicFeeInformation?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.allFeeCatglist = data.data;
			}
			else{
				$scope.allFeeCatglist = [];
			}

		});
	}
	$scope.clsFeeCatglist = [];
	//http://localhost:9000/getClassCourseAcademicFeeInfo?schemaName=coo5293&courseId=5&classId=3&branchId=4
	$scope.showFeeAssignDetails = function(cls){
		console.log(cls);
		$scope.selectedClass = cls.classId;

		httpFactory.getResult("getClassCourseAcademicFeeInfo?schemaName="+$scope.schemaName+"&courseId="+$scope.selectedCourse+"&classId="+$scope.selectedClass+"&branchId="+ $scope.selectedBranch, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.clsFeeCatglist = data.data;
			}
			else{
				$scope.clsFeeCatglist = [];
			}

		});
		$scope.sortFeeList();
	}

	$scope.sortFeeList = function(){
			for(var i=0; i< $scope.allFeeCatglist.length; i++){
				var found = 0;
				for(var j=0; j<$scope.clsFeeCatglist.length; j++){
					if($scope.allFeeCatglist[i].acadFeeId == $scope.clsFeeCatglist[j].acadFeeId){
						found++;
					}
				}
				if(found == 0){
					$scope.clsFeeCatglist.push($scope.allFeeCatglist[i]);
				}

			}
	}

	$scope.getCoursesByBranch();
	$scope.getAllFeeCategories();
	$scope.saveClsFeeChangesDetails = function(){

			var detailsArray = [];
			for(var i=0;i<$scope.clsFeeCatglist.length;i++){
				if($scope.clsFeeCatglist[i].isChecked != undefined && $scope.clsFeeCatglist[i].isChecked == true){
					var detObj = {
						"acadFeeDetailId":"",
						"amount":"",
						"isDiscount":"",
						"feeDiscountTypeId":"",
						"feeDiscountPerc":""
					};

				}
			}

			var params= {
			    "classId":$scope.selectedClass ,
			    "courseId":$scope.selectedCourse,
			    "branchId":$scope.selectedBranch,
			    "createdBy":$scope.user_id,
			    "schemaName":$scope.schemaName,
			    "isDefault":1,
			    "detailsArray":[{
			        "acadFeeDetailId":2,
			        "amount":"45000",
			        "isDiscount":1,
			        "feeDiscountTypeId":1,
			        "feeDiscountPerc":10.5
			    }]
			};





	}

});
