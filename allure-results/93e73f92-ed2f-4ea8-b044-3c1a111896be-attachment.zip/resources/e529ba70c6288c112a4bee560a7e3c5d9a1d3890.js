projectModule.controller('adminAnalyticsController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");

	$scope.activeTpcTab = "ota";

	$scope.showOnlineDiv = function(tab){
		$scope.activeTpcTab = tab;
	}


	// $scope.studentReportCardDetails =  [
  //       {
  //           "sectionName": "EAMCET1",
  //           "sectionTests": [
  //               {
  //                   "instTestTypeId": "1",
  //                   "gradeArray": [
  //                       {
  //                           "instGradeId": "1",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "M",
  //                                   "gradePercentage": "89.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 89,
  //                           "instGrade": "A1",
  //                           "gradeWiseStudentCount": 1
  //                       },
  //                       {
  //                           "instGradeId": "2",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "F",
  //                                   "gradePercentage": "92.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 92,
  //                           "instGrade": "A2",
  //                           "gradeWiseStudentCount": 1
  //                       }
  //                   ],
  //                   "testType": "FA1"
  //               },
  //               {
  //                   "instTestTypeId": "2",
  //                   "gradeArray": [
  //                       {
  //                           "instGradeId": "1",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "F",
  //                                   "gradePercentage": "75.0"
  //                               },
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "M",
  //                                   "gradePercentage": "84.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 79.5,
  //                           "instGrade": "A1",
  //                           "gradeWiseStudentCount": 2
  //                       }
  //                   ],
  //                   "testType": "FA2"
  //               }
  //           ],
  //           "sectionId": "1"
  //       },
  //       {
  //           "sectionName": "EAMCET1",
  //           "sectionTests": [
  //               {
  //                   "instTestTypeId": "1",
  //                   "gradeArray": [
  //                       {
  //                           "instGradeId": "1",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "M",
  //                                   "gradePercentage": "78.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 78,
  //                           "instGrade": "A1",
  //                           "gradeWiseStudentCount": 1
  //                       },
  //                       {
  //                           "instGradeId": "2",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "F",
  //                                   "gradePercentage": "70.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 70,
  //                           "instGrade": "A2",
  //                           "gradeWiseStudentCount": 1
  //                       }
  //                   ],
  //                   "testType": "FA1"
  //               },
  //               {
  //                   "instTestTypeId": "2",
  //                   "gradeArray": [
  //                       {
  //                           "instGradeId": "1",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "F",
  //                                   "gradePercentage": "70.0"
  //                               },
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "M",
  //                                   "gradePercentage": "60.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 65,
  //                           "instGrade": "A1",
  //                           "gradeWiseStudentCount": 2
  //                       },
	// 					{
  //                           "instGradeId": "2",
  //                           "genderWiseMarks": [
  //                               {
  //                                   "studentCount": 1,
  //                                   "gender": "F",
  //                                   "gradePercentage": "70.0"
  //                               }
  //                           ],
  //                           "gradeWiseStudentsPercentage": 70,
  //                           "instGrade": "A2",
  //                           "gradeWiseStudentCount": 1
  //                       }
  //                   ],
  //                   "testType": "FA2"
  //               }
  //           ],
  //           "sectionId": "2"
  //       },
  //   ];
	$scope.InstTestGrades = [
        {
            "instGradeId": 1,
            "grade": "A1",
            "gradeMarksPercenTo": 100,
            "gradeMarksPercenFrom": 90,
            "isActive": 1
        },
        {
            "instGradeId": 2,
            "grade": "A2",
            "gradeMarksPercenTo": 90,
            "gradeMarksPercenFrom": 80,
            "isActive": 1
        },
        {
            "instGradeId": 3,
            "grade": "B1",
            "gradeMarksPercenTo": 80,
            "gradeMarksPercenFrom": 75,
            "isActive": 1
        },
        {
            "instGradeId": 4,
            "grade": "B2",
            "gradeMarksPercenTo": 75,
            "gradeMarksPercenFrom": 70,
            "isActive": 1
        },
        {
            "instGradeId": 5,
            "grade": "C1",
            "gradeMarksPercenTo": 70,
            "gradeMarksPercenFrom": 65,
            "isActive": 1
        },
        {
            "instGradeId": 6,
            "grade": "C2",
            "gradeMarksPercenTo": 65,
            "gradeMarksPercenFrom": 60,
            "isActive": 1
        }
		,
        {
            "instGradeId": 7,
            "grade": "D1",
            "gradeMarksPercenTo": 60,
            "gradeMarksPercenFrom": 55,
            "isActive": 1
        },
        {
            "instGradeId": 8,
            "grade": "D2",
            "gradeMarksPercenTo": 55,
            "gradeMarksPercenFrom": 36,
            "isActive": 1
        },
        {
            "instGradeId": 9,
            "grade": "E",
            "gradeMarksPercenTo": 35,
            "gradeMarksPercenFrom": 0,
            "isActive": 1
        }
    ];
		$scope.instTestTypesServer = [];
	$scope.getInstTestGrades=function(){
		httpFactory.getResult("getInstGrades?schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.instTestTypesServer = data.InstTestGrades;
		}
		});
	}
	$scope.getInstTestGrades();
	$scope.generatedGwsts = [];
	$scope.selectedSections = [{"sectionId":"1"},{"sectionId":"2"}];
	$scope.selectedExams = [{"examName":"FA1"},{"examName":"FA2"}];
	$scope.studentReportCardDetailsDoop = [{"examName":"FA1"},{"examName":"FA2"}];

	$scope.validateGrade=function(perc){

		$scope.perc = Number(perc);
		console.log(Number($scope.perc));
		for(var i=0;i<$scope.instTestTypesServer.length;i++){
			if ($scope.perc>=$scope.instTestTypesServer[i].gradeMarksPercenFrom && $scope.perc<=$scope.instTestTypesServer[i].gradeMarksPercenTo) {
				return $scope.instTestTypesServer[i].grade;
			}
		}
	}

$scope.analyticInit=function(){
	$scope.getCourseBranchId();
	$scope.getInstTestTypes();
}
	$scope.generateGwsts = function(){
		$scope.generatedGwsts = [];
		for(var i=0; i<$scope.selectedExams.length; i++){
			$scope.selectedExams[i].testWiseSec = [];
			console.log($scope.studentReportCardDetails);

			for(var j=0; j<$scope.studentReportCardDetails.length; j++){

				for(var k=0; k<$scope.studentReportCardDetails[j].sectionTests.length; k++){
					if($scope.studentReportCardDetails[j].sectionTests[k].testType == $scope.selectedExams[i].examName){
						var gradeArrayCount = 0;
						var gradeBoysCount = 0;
						var gradeGirlsCount = 0;
						var gbCount = 0;
						var ggCount = 0;
						$scope.overAllBoys=0;
						$scope.overallGirls=0;
						var gradeArray = $scope.studentReportCardDetails[j].sectionTests[k].gradeArray;
						for(var l =0 ; l<gradeArray.length; l++){
							gradeArrayCount = Number(gradeArrayCount) + Number(gradeArray[l].gradeWiseStudentsPercentage);
							for(var m=0; m<gradeArray[l].genderWiseMarks.length; m++){
								if(gradeArray[l].genderWiseMarks[m].gender == "M"){
									gradeBoysCount = gradeBoysCount + Number(gradeArray[l].genderWiseMarks[m].gradePercentage);

									gbCount++;
								}
								if(gradeArray[l].genderWiseMarks[m].gender == "F"){
									gradeGirlsCount = gradeGirlsCount + Number(gradeArray[l].genderWiseMarks[m].gradePercentage);
									ggCount++;
								}
							}
						}
						var gradeBoysCountDoop = 0;
						if(gbCount  > 0){
							gradeBoysCountDoop = gradeBoysCount/gbCount;
						}
						var gradeGirlsCountDoop = 0;
						if(ggCount  > 0){
							gradeGirlsCountDoop = gradeBoysCount/ggCount;
						}
						var gradeArrayDump = {
							"secName": $scope.studentReportCardDetails[j].sectionName,
							"secId": $scope.studentReportCardDetails[j].sectionId,
							"testWiseTotal" : gradeArrayCount/gradeArray.length,
							"gradeBoysCount": gradeBoysCountDoop,
							"gradeGirlsCount": gradeGirlsCountDoop,
							"testWiseTotalGrade" :"",
							"gradeBoysCountGrade": "",
							"gradeGirlsCountGrade":""
						};
						gradeArrayDump.testWiseTotalGrade = $scope.validateGrade(gradeArrayDump.testWiseTotal);
						gradeArrayDump.gradeBoysCountGrade = $scope.validateGrade(gradeArrayDump.gradeBoysCount);
						gradeArrayDump.gradeGirlsCountGrade = $scope.validateGrade(gradeArrayDump.gradeGirlsCount);
						$scope.selectedExams[i].testWiseSec.push(gradeArrayDump);
					}
				}
			}
		}
		console.log($scope.selectedExams);
	}

	$scope.gradeWiseChartDataObj = [];
	$scope.gradeWiseChartData = function(){
		$scope.gradeWiseChartDataObj = [];
		for(var i=0; i<$scope.InstTestGrades.length; i++){
			var instgrdPec = 0;
			var instgrdPecIndx = 0;
			for(var j=0; j<$scope.studentReportCardDetails.length; j++){
				for(var k=0; k<$scope.studentReportCardDetails[j].sectionTests.length; k++){
					for(var l=0; l<$scope.studentReportCardDetails[j].sectionTests[k].gradeArray.length; l++){
						if($scope.InstTestGrades[i].grade == $scope.studentReportCardDetails[j].sectionTests[k].gradeArray[l].instGrade){
							instgrdPec = instgrdPec + Number($scope.studentReportCardDetails[j].sectionTests[k].gradeArray[l].gradeWiseStudentsPercentage);
							instgrdPecIndx++;
						}
					}
				}
			}
			if(instgrdPecIndx > 0){
				var grdObj ={ y: instgrdPec/instgrdPecIndx, name: $scope.InstTestGrades[i].grade};
				$scope.gradeWiseChartDataObj.push(grdObj)
			}
		}
		console.log($scope.gradeWiseChartDataObj);
		$scope.renderChartsForGradesWise();
	}
	$scope.renderChartsForGradesWise = function(){
		var chart = new CanvasJS.Chart("chartForGradesWiseContainer", {
			theme: "",
			animationEnabled: true,
			legend:{
				cursor: "pointer",
				itemclick: explodePie
			},
			data: [{
				type: "doughnut",
				innerRadius: 30,
				indexLabelFontSize: 17,
				toolTipContent: "<b>{name}</b>: {y}%",
				indexLabel: "{name}-{y}%",
				dataPoints: $scope.gradeWiseChartDataObj
			}]
		});
		chart.render();
	}
	function explodePie (e) {
		if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
			e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
		} else {
			e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
		}
		e.chart.render();
	}

	$scope.studentReportCardDetailsDump = [];
	$scope.generateObjDump = function(){
		$scope.gradeWiseChartData();
		$scope.studentReportCardDetailsDump = $scope.studentReportCardDetails.slice();
		console.log($scope.studentReportCardDetailsDump);


		for(var i=0; i<$scope.studentReportCardDetails.length; i++){
			for(var j=0; j<$scope.studentReportCardDetails[i].sectionTests.length; j++){
				for(var k=0; k<$scope.studentReportCardDetails[i].sectionTests[j].gradeArray.length; k++ ){
					if($scope.studentReportCardDetails[i].sectionTests[j].gradeArray[k].genderWiseMarks.length == 1){
		$scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].grade = $scope.validateGrade($scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].gradePercentage);

						if($scope.studentReportCardDetails[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].gender == "M"){
							var genObj = {
								"studentCount": 0,
								"gender": "F",
								"gradePercentage": "0",
								"grade":"E",
							};
							$scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks.unshift(genObj);

						}

						else if($scope.studentReportCardDetails[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].gender == "F"){
							var genObj = {
								"studentCount": 0,
								"gender": "M",
								"gradePercentage": "0",
								"grade":"E",
							};
							$scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks.push(genObj);
						}

					}
					else{
					$scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].grade = $scope.validateGrade($scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[0].gradePercentage);
					$scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[1].grade = $scope.validateGrade($scope.studentReportCardDetailsDump[i].sectionTests[j].gradeArray[k].genderWiseMarks[1].gradePercentage);

					}


				}

			}
		}
		console.log($scope.studentReportCardDetailsDump);

		$scope.generateStudentReportCardDetailsDoop();
		$scope.reportCardOverAllDetailsDoop();
	}

	$scope.generateStudentReportCardDetailsDoop = function(){
		for(var i=0; i<$scope.studentReportCardDetailsDoop.length; i++){
			$scope.studentReportCardDetailsDoop[i].sectionTests = [];
			for(var j=0; j<$scope.studentReportCardDetailsDump.length; j++){
				for(var k=0; k<$scope.studentReportCardDetailsDump[j].sectionTests.length; k++){
					if($scope.studentReportCardDetailsDump[j].sectionTests[k].testType == $scope.studentReportCardDetailsDoop[i].examName){
						$scope.studentReportCardDetailsDoop[i].sectionTests.push($scope.studentReportCardDetailsDump[j].sectionTests[k]);
					}
				}
			}
		}
		console.log($scope.studentReportCardDetailsDoop);
		$scope.overallPassAvg();
	}
	$scope.ovPassAvg = 0;
	$scope.overallPassAvg = function(){
		var opa = 0;
		var opaIndex = 0;
		for(var i=0; i<$scope.studentReportCardDetailsDoop.length;i++ ){
			for(var j=0; j<$scope.studentReportCardDetailsDoop[i].sectionTests.length;j++){
				for(var k=0; k<$scope.studentReportCardDetailsDoop[i].sectionTests[j].gradeArray.length;k++){

					if($scope.studentReportCardDetailsDoop[i].sectionTests[j].gradeArray[k].instGrade != "E"){
						opa = opa  + Number($scope.studentReportCardDetailsDoop[i].sectionTests[j].gradeArray[k].gradeWiseStudentsPercentage);
						opaIndex++;
					}

				}

			}
		}
		$scope.ovPassAvg = Math.round(opa / opaIndex);
		console.log($scope.ovPassAvg);
	}
	$scope.totalBoysAvgMarks = 0;
	$scope.totalGirlssAvgMarks = 0;
	$scope.sectionWiseMarks = [];
	$scope.reportCardOverAllDetailsDoop = function(){
		for(var i=0; i<$scope.studentReportCardDetailsDump.length; i++){
			$scope.totalBoysAvgMarks = 0;
			$scope.totalGirlssAvgMarks = 0;
			for(var j=0; j<$scope.studentReportCardDetailsDump[i].sectionTests.length; j++){
				$scope.totalGirlssAvgMarks = Number($scope.totalGirlssAvgMarks) + Number($scope.studentReportCardDetailsDump[i].sectionTests[j].female.totalPercentage);
				$scope.totalBoysAvgMarks = Number($scope.totalBoysAvgMarks) + Number($scope.studentReportCardDetailsDump[i].sectionTests[j].male.totalPercentage);
			}
			/* var secWavg = {
				"secname":$scope.studentReportCardDetailsDump[i].sectionName,
				"bAvg":$scope.totalBoysAvgMarks,
				"gAvg":$scope.totalGirlssAvgMarks,
			}; */
			var secWavg = {
				"secname":$scope.studentReportCardDetailsDump[i].sectionName,
				"bAvg":Math.round(Number($scope.totalBoysAvgMarks) / $scope.studentReportCardDetailsDump[i].sectionTests.length),
				"gAvg":Math.round(Number($scope.totalGirlssAvgMarks) / $scope.studentReportCardDetailsDump[i].sectionTests.length),
				"tSecAvg":Math.round(((Number($scope.totalBoysAvgMarks)/ $scope.studentReportCardDetailsDump[i].sectionTests.length)+(Number($scope.totalGirlssAvgMarks)/$scope.studentReportCardDetailsDump[i].sectionTests.length))/2),
				"bAvgGrade":"",
				"gAvgGrade":"",
				"tSecAvgGrade":"",
			};
			secWavg.bAvgGrade = $scope.validateGrade(secWavg.bAvg);
			secWavg.gAvgGrade = $scope.validateGrade(secWavg.gAvg);
			secWavg.tSecAvgGrade = $scope.validateGrade(secWavg.tSecAvg);
			$scope.sectionWiseMarks.push(secWavg);
		}

		console.log($scope.sectionWiseMarks);
		$scope.displayFinalAvgValues();
	}



	$scope.sectionWiseFinalAvg = {
		"fsecAvg":"",
		"fbAvg":"",
		"fgAvg":"",
	};
	$scope.displayFinalAvgValues = function(){
		var fsecAvg = 0;
		var fbAvg = 0;
		var fgAvg = 0;
		for(var i=0; i<$scope.sectionWiseMarks.length;i++){
			fsecAvg = fsecAvg + Number($scope.sectionWiseMarks[i].tSecAvg);
			fbAvg = fbAvg + Number($scope.sectionWiseMarks[i].bAvg);
			fgAvg = fgAvg + Number($scope.sectionWiseMarks[i].gAvg);
		}
		$scope.sectionWiseFinalAvg = {
			"fsecAvg":Math.round(fsecAvg/$scope.sectionWiseMarks.length),
			"fbAvg":Math.round(fbAvg/$scope.sectionWiseMarks.length),
			"fgAvg":Math.round(fgAvg/$scope.sectionWiseMarks.length),
		};
	}
	// new methods

	// $scope.getInstituteTypes = function(){
	// 	httpFactory.getResult("getCollegeInstituteTypes?schemaName="+localStorage.getItem("sname"), function(data){
	// 		if(data.statusCode == '200'){
	// 			$scope.instituteTypes = data.data;
	// 			console.log($scope.instituteTypes);
	// 			$scope.instTypeStr="";
	// 			for (var i = 0; i < $scope.instituteTypes.length; i++) {
	// 				if($scope.instTypeStr == ""){
	// 					$scope.instTypeStr = ""+$scope.instituteTypes[i].instTypeId;
	// 				}else{
	// 					$scope.instTypeStr = $scope.instTypeStr+","+$scope.instituteTypes[i].instTypeId;
	// 				}
	// 				}
	// 		}
	// 	});
	// }


	$scope.getCourseBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId=" +$scope.selectedBranch+"&schemaName="+localStorage.getItem("sname"), function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				 $scope.branchCourses = data.Courses;
				 if($scope.branchCourses.length==1) {
					 $scope.selectedCourse = JSON.stringify($scope.branchCourses[0].courseId);
				 }				 
				 $scope.getCLassesByCourse();				
			}
			 else {
			}
		});
	}



		$scope.getCLassesByCourse=function(){
		$scope.selectedCourse = $scope.selectedCourse;
			httpFactory.getResult("getCLassesByCourse?branchId=" +$scope.selectedBranch+"&schemaName="+localStorage.getItem("sname")+"&courseId="+$scope.selectedCourse, function(data) {
				console.log(data);
				if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
					 $scope.courseClasses = data.Classes;
				}
				 else {
				}
			});
		}

		$scope.getSectionsByClassCourse=function(classOb){
			console.log(classOb);
			if (typeof classOb == 'string') {
				$scope.selectedClassOb = JSON.parse(classOb);
			}else{
				$scope.selectedClassOb = classOb;
			}
			$scope.selectedCCId = $scope.selectedClassOb.classCourseId;
			$scope.selectedClassId = $scope.selectedClassOb.classId;

			console.log($scope.selectedCCId);
			httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch +"&classCourseId="+$scope.selectedCCId, function(data) {
				console.log(data);
				if (data.StatusCode == 200){
					$scope.allSecStr="";
					$scope.allSectionslist = data.Sections;
					console.log($scope.allSectionslist);
					// for (var i = 0; i < $scope.allSectionslist.length; i++) {
					// 	$scope.allSecStr+=$scope.allSectionslist[i].sectionName+",";
					// }
				} else {

				}
			});
		}

		$scope.sectionChange=function(selectedSection){
			console.log(selectedSection);
			$scope.getInstTestTypes();
		}


		$scope.allInstTestTypes = [];
		$scope.testTypesSelected = "";
		$scope.getInstTestTypes=function(){
			httpFactory.getResult("getInstTestTypes?schemaName="+$scope.schemaName, function(data) {
				console.log(data);
				if (data.StatusCode == 200){
					$scope.instTestTypes = data.InstTestTypes;
					for(var i=0; i<$scope.instTestTypes.length; i++){
						for(var j=0; j<$scope.instTestTypes[i].tests.length; j++){
							$scope.allInstTestTypes.push($scope.instTestTypes[i].tests[j]);
						}
					}
				} else {

				}
			});
		}

		$scope.testTypeChange=function(testType){
			console.log(testType);
			console.log($scope.testType);
			// $scope.getStudentsReportCardDetails();
			//$scope.getInstSectionTestAnalysis();
		}

		$scope.getStudentsReportCardDetails=function(){
			//$scope.selectedSection="1,2";
			var selectedSections = "";
			for(var i=0;i<$scope.selectedSection.length;i++){
				if(selectedSections == ""){
					selectedSections = ""+$scope.selectedSection[i].sectionId;
				}else{
					selectedSections = selectedSections+","+$scope.selectedSection[i].sectionId;
				}
			}
			var testTypesSelectedForAnalytics = "";
			for(var i=0;i<$scope.testTypesSelected.length;i++){
				if(testTypesSelectedForAnalytics == ""){
					testTypesSelectedForAnalytics = $scope.testTypesSelected[i].instTestTypeId;
				}else{
					testTypesSelectedForAnalytics = testTypesSelectedForAnalytics+","+$scope.testTypesSelected[i].instTestTypeId;
				}
			}
			var saveParams={
				"schemaName":$scope.schemaName,
				"sectionId":selectedSections,
				"testTypeId":testTypesSelectedForAnalytics,
				"classId":$scope.selectedClassId,
				"courseId":$scope.selectedCourse
			}
			console.log(saveParams);
			httpFactory.executePost("getStudentsReportCardDetails", saveParams, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {

				} else {

				}
			});
		}
		$scope.getInstSectionTestAnalysis=function(){
			console.log($scope.testTypesSelected);

			var selectedSections = "";
			for(var i=0;i<$scope.selectedSection.length;i++){
				if(selectedSections == ""){
					selectedSections = ""+$scope.selectedSection[i].sectionId;
					$scope.selSections=""+$scope.selectedSection[i].sectionName;
				}else{
					selectedSections = selectedSections+","+$scope.selectedSection[i].sectionId;
					$scope.selSections=$scope.selSections+","+$scope.selectedSection[i].sectionName;
				}
			}
			var testTypesSelectedForAnalytics = "";
			for(var i=0;i<$scope.testTypesSelected.length;i++){
				if(testTypesSelectedForAnalytics == ""){
					testTypesSelectedForAnalytics = $scope.testTypesSelected[i].instTestTypeId;
					$scope.selExamType=$scope.testTypesSelected[i].testType;

				}else{
					testTypesSelectedForAnalytics = testTypesSelectedForAnalytics+","+$scope.testTypesSelected[i].instTestTypeId;
					$scope.selExamType=$scope.selExamType+","+$scope.testTypesSelected[i].testType;

				}
			}
			// $scope.selSections=selectedSections;
			// $scope.selExamType = testTypesSelectedForAnalytics;
			$scope.selClass= $scope.selectedClassOb.className;
			var saveParams={
				"schemaName":$scope.schemaName,
				"sectionId":selectedSections,
				"instTestTypeId":testTypesSelectedForAnalytics
			}
			console.log(saveParams);
			httpFactory.executePost("getInstSectionTestAnalysis", saveParams, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.studentReportCardDetails=data.studentReportCardDetails;
					$scope.generateGwsts();
					$scope.generateObjDump();

				} else {
					$scope.studentReportCardDetails=[];
				}
			});
			//$scope.gradeWiseChartData();
		}


		$scope.getCompletedExams=function(){
			console.log($scope.selectedCCId);
			httpFactory.getResult("getAdminCompletedTestsForAnalysis?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch, function(data) {
				console.log(data);
				if (data.StatusCode == 200){
					$scope.completedTests = data.completedTest;
					console.log($scope.completedTests);
					// for (var i = 0; i < $scope.allSectionslist.length; i++) {
					// 	$scope.allSecStr+=$scope.allSectionslist[i].sectionName+",";
					// }
				} else {

				}
			});
		}


		  $scope.redirectToResult=function(test){
			    console.log(test);
			    $location.path("testResult/"+ test.testId+"/"+localStorage.getItem("bnchId"));
			  };


});
