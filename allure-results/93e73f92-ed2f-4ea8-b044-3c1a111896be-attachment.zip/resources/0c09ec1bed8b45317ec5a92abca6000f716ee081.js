projectModule.controller('reportCardController', function ($scope, $rootScope, $compile, $timeout, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.getItem("branchName");
	$scope.attendanceMonthsArray = [];
	$scope.rcTemplateList = [];
	$scope.tableColumnOptions = ['Test', 'Average', 'Sum', 'Grade', 'Grade Points', 'Co-Curricular', 'Total Percentage'];
	$scope.newColumn = true;
	$scope.change = false;
	$scope.inputBox = true;

	$scope.getReportCardAttendance = function () {
		httpFactory.getResult("getBranchReportCardAttendance?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.monthsAttendanceArray = data.monthsAttendanceArray;
				$scope.attendanceCount = 0;
				for (i = 0; i < $scope.monthsAttendanceArray.length; i++) {
					if ($scope.monthsAttendanceArray[i].branchMonthId > 0) {
						$scope.attendanceCount++;
					}
				}
				document.getElementById("studentListDiv").style.display = "block";
				$scope.getStudentsWithAttendanceForReportCard();
			} else if (data.StatusCode == 300) {
				$scope.monthsAttendanceArray = [];
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.updateReportCardAttendance = function () {
		var insertAttendanceArray = [];
		var updateAttendanceArray = [];
		for (i = 1; i < 2; i++) {
			for (j = 1; j < $scope.monthsAttendanceArray.length + 1; j++) {
				if (($scope.monthsAttendanceArray[j - 1].branchMonthId == 0) && (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value > 0)) {
					var monthAttendanceObj = {
						"monthId": $scope.monthsAttendanceArray[j - 1].monthId,
						"monthName": $scope.monthsAttendanceArray[j - 1].monthName,
						"totalWorkingDays": document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value
					}
					insertAttendanceArray.push(monthAttendanceObj);
				} else if (($scope.monthsAttendanceArray[j - 1].branchMonthId > 0) && (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value != $scope.monthsAttendanceArray[j - 1].totalWorkingDays)) {
					var monthAttendanceObj = {
						"monthId": $scope.monthsAttendanceArray[j - 1].monthId,
						"monthName": $scope.monthsAttendanceArray[j - 1].monthName,
						"branchMonthId": $scope.monthsAttendanceArray[j - 1].branchMonthId,
						"totalWorkingDays": document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").totalWorkingDays.value
					}
					updateAttendanceArray.push(monthAttendanceObj);
				}
			}
		}
		if (insertAttendanceArray.length == 0 && updateAttendanceArray.length == 0) {
			alert("No Changes");
			return;
		} else {
			var params = {
				"schemaName": $scope.schemaName,
				"branchId": $scope.branchId,
				"userId": localStorage.getItem("userId")
			}
			if (insertAttendanceArray.length > 0) {
				params["insertAttendanceArray"] = insertAttendanceArray;
			}
			if (updateAttendanceArray.length > 0) {
				params["updateAttendanceArray"] = updateAttendanceArray;
			}
			console.log(params);
			httpFactory.executePost("updateBranchReportCardAttendance", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getReportCardAttendance();
				} else {
					alert('Error while updating attendance records');
				}
			});
		}
	}

	$scope.deleteReportCardAttendance = function () {
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId
		}
		console.log(params);
		httpFactory.executePost("deleteBranchReportCardAttendance", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Deleted");
				$scope.getReportCardAttendance();
			} else if (data.StatusCode == 300) {
				alert(data.MESSAGE);
			} else {
				alert('Error while deleting');
			}
		});
	}

	$scope.getCourseByBranchId = function () {
		$scope.reportCardStudents = [];
		httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if (sessionStorage.getItem('courseId') != null && sessionStorage.getItem('courseId') != undefined && sessionStorage.getItem('courseId') != '') {
					for (i = 0; i < $scope.courseList.length; i++) {
						if ($scope.courseList[i].courseId == sessionStorage.getItem('courseId')) {
							$scope.selectedCourseOb = JSON.stringify($scope.courseList[i]);
							$scope.courseSelect($scope.selectedCourseOb);
							sessionStorage.removeItem("courseId");
							break;
						}
					}
				} else if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					if (window.location.href.includes('reportCardTemplate'))
						$scope.getTemplatesByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('addReportCardTestDetails'))
						$scope.getTestsDetailsByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('reportCardSubjectManagement'))
						$scope.getSubjectsByCourse($scope.selectedCourseOb);
					else if (window.location.href.includes('reportCardMap') || window.location.href.includes('reportCardGeneration'))
						$scope.courseSelect($scope.selectedCourseOb);
				}
			}
		});
	}

	$scope.getStudentReportCard = function () {
		$scope.getBranchDetailsForRC();
		$scope.getStudentDetailsForReportCard();
		$scope.getTemplateToUse();
		$scope.getGradesandGradePointsForReportCard();
		var temp = {
			"courseId": sessionStorage.getItem("courseId"),
			"classId": sessionStorage.getItem("classId")
		}
		$scope.getSubjectsByCourseClass(temp, temp);
		$scope.getReportCardTestMarks();
		$scope.getRCPresentAttendance();
		$scope.totalWorkingDays = $scope.sum($scope.reportCardPresentDays, 'totalWorkingDays');
		$scope.totalPresentDays = $scope.sum($scope.reportCardPresentDays, 'presentDays');
	}

	$scope.calculatePresents = function () {
		$scope.studentArray.forEach(function (student) {
			student.totalPresentDays = $scope.sum(student.studentReportCardPresentDays, 'presentDays');
		});
	}

	$scope.courseSelect = function (selectedCourseOb) {
		$scope.selectedCourse = JSON.parse(selectedCourseOb);
		$scope.reportCardStudents = [];
		httpFactory.getResult("getCLassesByCourse?courseId=" + $scope.selectedCourse.courseId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
				if (sessionStorage.getItem('classId') != null && sessionStorage.getItem('classId') != undefined && sessionStorage.getItem('classId') != '') {
					for (i = 0; i < $scope.classList.length; i++) {
						if ($scope.classList[i].classId == sessionStorage.getItem('classId')) {
							$scope.selectedClassObj = JSON.stringify($scope.classList[i]);
							$scope.courseClassSelect($scope.selectedClassObj);
							sessionStorage.removeItem("classId");
							break;
						}
					}
				}
			}
		});
	}

	$scope.courseClassSelect = function (selectedClsOb) {
		console.log(selectedClsOb);
		if (typeof selectedClsOb == 'string')
			$scope.selectedClass = JSON.parse(selectedClsOb);
		else
			$scope.selectedClass = selectedClsOb;
		$scope.templateObj = '';
		$scope.classTemplateList = [];
		$scope.reportCardStudents = [];
		httpFactory.getResult("selectSectionsByBranchCourseClass?branchId=" + $scope.branchId + "&classCourseId=" + $scope.selectedClass.classCourseId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
				if (sessionStorage.getItem('sectionId') != null && sessionStorage.getItem('sectionId') != undefined && sessionStorage.getItem('sectionId') != '') {
					for (i = 0; i < $scope.sectionList.length; i++) {
						if ($scope.sectionList[i].sectionId == sessionStorage.getItem('sectionId')) {
							$scope.selectedSectionObj = JSON.stringify($scope.sectionList[i]);
							$scope.getClassWiseTemplates($scope.selectedCourse.courseId, $scope.selectedClass.classId);
							sessionStorage.removeItem("sectionId");
							break;
						}
					}
				}
			}
		});
	}

	$scope.updateCrsClsSec = function (selectedSectionObj) {
		if (typeof selectedSectionObj == 'string')
			$scope.selectedSection = JSON.parse(selectedSectionObj);
		else
			$scope.selectedSection = selectedSectionObj;
		if (typeof $scope.templateObj == 'string')
			$scope.selectedtemplate = JSON.parse($scope.templateObj);
		else
			$scope.selectedtemplate = $scope.templateObj;
		$scope.templateId = $scope.selectedtemplate.templateId;
		$scope.getStudentsForReportCard();
		$scope.getSubjectsByCourseClass($scope.selectedCourseOb, $scope.selectedClassObj);
		$scope.selectedTestOb = JSON.parse($scope.testObj)
		$scope.getStudentSubjectMarks();
		$scope.testTotalMarks = $scope.selectedTestOb.totalMarks;
		$scope.synchronizeStudentOrder();
	}

	$scope.getStudentSubjectMarks = function () {
		httpFactory.getResult("getStudentReportCardDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + $scope.selectedSection.sectionId + "&testId=" + $scope.selectedTestOb.testId, function (data) {
			console.log(data);
			$scope.studentArray = [];
			if (data.StatusCode == 200) {
				$scope.studentArray = data.studentArray;
				$scope.originalValues = angular.copy($scope.studentArray);
			}
		});
	}

	$scope.generateStudentReportCard = function (student) {
		$scope.selectStudentList = [];
		if (student != undefined) {
			$scope.selectStudentList.push(student);
		}
		else {
			for (var i = 0; i < $scope.reportCardStudents.length; i++) {
				// Check if the student is selected
				if ($scope.reportCardStudents[i].selected) {
					$scope.selectStudentList.push($scope.reportCardStudents[i])
				}
			}
		}
		if ($scope.selectStudentList.length > 0) {
			console.log(student);
			sessionStorage.setItem("selectStudentList", JSON.stringify($scope.selectStudentList));
			sessionStorage.setItem("sectionId", $scope.selectedSection.sectionId);
			sessionStorage.setItem("classId", $scope.selectedClass.classId);
			sessionStorage.setItem("className", $scope.selectedClass.className);
			sessionStorage.setItem("courseId", $scope.selectedCourse.courseId);
			sessionStorage.setItem("templateId", $scope.templateId);
			sessionStorage.setItem("testId", JSON.parse($scope.testObj).testId);
			$location.path("addStuRprt/" + $scope.selectedClass.classId + "/" + $scope.selectedCourse.courseId + "/" + $scope.selectedSection.sectionId);
		}
		else {
			alert("Please select students")
		}
	}

	$scope.getTestsDetailsByCourse = function (course) {
		if (typeof course == 'string')
			var selectedCourse = JSON.parse(course);
		else
			var selectedCourse = course;
		httpFactory.getResult("getTestsDetailsForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + selectedCourse.courseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.testsDetailsArray = data.testDetailsArray;
			} else if (data.StatusCode == 300) {
				$scope.testsDetailsArray = [];
			} else {
				alert("Error while retrieving the records");
			}
		});
	}

	$scope.addTestTypeDetails = function () {
		if (document.getElementById("courseOb").value == "" || document.getElementById("courseOb").value == "undefined" ||
			document.getElementById("testName").value == "" || document.getElementById("testName").value == "undefined" ||
			document.getElementById("totalMarks").value == "" || document.getElementById("totalMarks").value == "undefined") {
			alert("Enter all details");
			return;
		}
		if (typeof $scope.courseOb == 'string')
			var selectedCourse = JSON.parse($scope.courseOb);
		else
			var selectedCourse = $scope.courseOb;
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId,
			"createdBy": localStorage.getItem("userId"),
			"courseId": selectedCourse.courseId,
			"testName": $scope.testName,
			"totalMarks": $scope.totalMarks
		}
		console.log(params);
		httpFactory.executePost("addTestDetailsForReportCard", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Successfully Updated");
				document.getElementById("courseOb").value = "";
				document.getElementById("testName").value = "";
				document.getElementById("totalMarks").value = "";
				$("#addNewTestTypeModal").modal("hide");
				if ($scope.selectedCourseOb != undefined)
					$scope.getTestsDetailsByCourse($scope.selectedCourseOb);
			} else {
				alert('Error while saving tests details');
			}
		});
	}

	$scope.deleteTestsArr = [];
	$scope.updateSelectedTest = function (selectedTest) {
		if ($scope.deleteTestsArr.includes(selectedTest.testId)) {
			for (i = 0; i < $scope.deleteTestsArr.length; i++) {
				if ($scope.deleteTestsArr[i] == selectedTest.testId) {
					$scope.deleteTestsArr.splice(i, 1);
					break;
				}
			}
		} else {
			$scope.deleteTestsArr.push(selectedTest.testId);
		}
		if ($scope.deleteTestsArr.length == $scope.testsDetailsArray.length) {
			$('#isAllSelected').prop("checked", true);
		} else {
			$('#isAllSelected').prop("checked", false);
		}
	}

	$scope.selectAll = function () {
		$scope.deleteTestsArr = [];
		if (document.getElementById('isAllSelected').checked == true) {
			for (j = 0; j < $scope.testsDetailsArray.length; j++) {
				if (!$scope.deleteTestsArr.includes($scope.testsDetailsArray[j].testId)) {
					document.getElementsByName('selectedTest')[j].checked = true;
					$scope.deleteTestsArr.push($scope.testsDetailsArray[j].testId);
				}
			}
		} else {
			for (j = 0; j < $scope.testsDetailsArray.length; j++) {
				document.getElementsByName('selectedTest')[j].checked = false;
			}
		}
	}

	$scope.deleteTests = function () {
		if ($scope.deleteTestsArr.length == 0) {
			alert("Nothing selected");
			return;
		}
		if (!confirm('The test will get deleted.'))
			return;
		if (typeof $scope.selectedCourseOb == 'string')
			var selectedCourse = JSON.parse($scope.selectedCourseOb);
		else
			var selectedCourse = $scope.selectedCourseOb;
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId,
			"courseId": selectedCourse.courseId,
			"deleteTestsArray": $scope.deleteTestsArr
		}
		httpFactory.executePost("deleteTestsForReportCard", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Deleted");
				document.getElementById("select").value = "";
				$scope.select = "";
				$scope.deleteTestsArr = [];
				$scope.getTestsDetailsByCourse($scope.selectedCourseOb);
			} else if (data.StatusCode == 302) {
				alert(data.MESSAGE);
			} else {
				alert('Error while deleting');
			}
		});
	}

	$scope.getSubjectsByCourse = function (selectedCourseOb) {
		if (typeof selectedCourseOb == 'string')
			var selectedCourse = JSON.parse(selectedCourseOb)
		else
			var selectedCourse = selectedCourseOb;
		httpFactory.getResult("getSubjectsByCourseForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + selectedCourse.courseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.subjectsList = data.subjectsArray;
			} else if (data.StatusCode == 300)
				$scope.subjectsList = [];
		});
	}

	$scope.getSubjectsByCourseClass = function (selectedCrs, selectedCls) {
		if (typeof selectedCrs == 'string' && selectedCrs != '')
			var selectedCourse = JSON.parse(selectedCrs)
		else
			var selectedCourse = selectedCrs;
		if (typeof selectedCls == 'string' && selectedCls != '')
			var selectedClass = JSON.parse(selectedCls)
		else
			var selectedClass = selectedCls;
		$scope.classSubjectsList = [];
		$scope.subjectsList = [];
		httpFactory.getResult("getSubjectsByCourseForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + selectedCourse.courseId + "&classId=" + selectedClass.classId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.subjectsList = data.subjectsArray;
				for (i = 0; i < $scope.subjectsList.length; i++) {
					$scope.classSubjectsList.push($scope.subjectsList[i]);
					if ($scope.subjectsList[i].isAssigned == 1) {
						$scope.subjectsList[i]["selected"] = true;
					}
					else {
						$scope.subjectsList[i]["selected"] = false;
					}
				}
			} else if (data.StatusCode == 300)
				$scope.subjectsList = [];
		});
	}

	$scope.assignSubjectsModal = function () {
		$scope.assignSubjStatus = "none";
		$scope.deleteSubjectsArr = [];
		$('#isAllSelected').prop("checked", false);
		if ($scope.subjectsList != undefined) {
			for (j = 0; j < $scope.subjectsList.length; j++) {
				document.getElementsByName('selectedSubject')[j].checked = false;
			}
		}
		$("#assignSubjectModal").modal("show");
	}

	$scope.changeAssignSubjStatus = function (val) {
		$scope.assignSubjStatus = val;
		if (document.getElementById("selectedCrs").value != "" && document.getElementById("selectedCrs").value != "undefined" &&
			document.getElementById("selectedCls").value != "" && document.getElementById("selectedCls").value != "undefined") {
			$scope.getSubjectsByCourseClass(document.getElementById("selectedCrs").value, document.getElementById("selectedCls").value);
		}
	}

	$scope.closeAssignSubjectsModal = function (selectedCourseOb) {
		document.getElementById("selectedCrs").value = "";
		document.getElementById("selectedCls").value = "";
		$scope.selectedCrs = "";
		$scope.selectedCls = "";
	}

	$scope.addSubjectsForReportCard = function () {
		if (document.getElementById("courseOb").value == "" || document.getElementById("courseOb").value == "undefined" ||
			document.getElementById("subjectType").value == "" || document.getElementById("subjectType").value == "undefined" ||
			document.getElementById("subject").value == "" || document.getElementById("subject").value == "undefined") {
			alert("Enter all details");
			return;
		}
		if (typeof $scope.courseOb == 'string')
			var selectedCourse = JSON.parse($scope.courseOb);
		else
			var selectedCourse = $scope.courseOb;
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId,
			"createdBy": localStorage.getItem("userId"),
			"courseId": selectedCourse.courseId,
			"subject": $scope.subject,
			"subjectType": $scope.subjectType
		}
		console.log(params);
		httpFactory.executePost("addSubjectsForReportCard", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Successfully Updated");
				document.getElementById("courseOb").value = "";
				document.getElementById("subject").value = "";
				document.getElementById("subjectType").value = "";
				if (document.getElementById("selectedCrs").value != "" || document.getElementById("selectedCrs").value != "undefined" ||
					document.getElementById("selectedCls").value != "" || document.getElementById("selectedCls").value != "undefined") {
					$scope.getSubjectsByCourseClass(document.getElementById("selectedCrs").value, document.getElementById("selectedCls").value);
				}
				$scope.getSubjectsByCourse(selectedCourse);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.selectedFunction = function (val) {
		if (val == 'subject') {
			var a = document.getElementById('select');
			var option = a.options[a.selectedIndex].value;
			if (option == "delete")
				$scope.deleteSubjects();
		} else if (val == 'test') {
			var a = document.getElementById('select');
			var option = a.options[a.selectedIndex].value;
			if (option == "delete")
				$scope.deleteTests();
		}
		document.getElementById('select').selectedIndex = 0;
	}

	$scope.deleteSubjectsArr = [];
	$scope.updateSelectedSubject = function (selectedSubject) {
		if ($scope.deleteSubjectsArr.includes(selectedSubject)) {
			for (i = 0; i < $scope.deleteSubjectsArr.length; i++) {
				if ($scope.deleteSubjectsArr[i].subjectId == selectedSubject.subjectId) {
					$scope.deleteSubjectsArr.splice(i, 1);
					break;
				}
			}
		} else {
			$scope.deleteSubjectsArr.push(selectedSubject);
		}
		if ($scope.deleteSubjectsArr.length == $scope.subjectsList.length) {
			$('#isAllSelected').prop("checked", true);
		} else {
			$('#isAllSelected').prop("checked", false);
		}
	}

	$scope.selectAllSubs = function () {
		$scope.deleteSubjectsArr = [];
		if (document.getElementById('isAllSelected').checked == true) {
			for (j = 0; j < $scope.subjectsList.length; j++) {
				document.getElementsByName('selectedSubject')[j].checked = true;
				$scope.deleteSubjectsArr.push($scope.subjectsList[j]);
			}
		} else {
			for (j = 0; j < $scope.subjectsList.length; j++) {
				document.getElementsByName('selectedSubject')[j].checked = false;
			}
		}
	}

	$scope.deleteSubjects = function () {
		if ($scope.deleteSubjectsArr.length == 0) {
			alert("Nothing selected");
			return;
		}
		if (!confirm('The subject will get deleted.'))
			return;
		if (typeof $scope.selectedCourseOb == 'string')
			var selectedCourse = JSON.parse($scope.selectedCourseOb);
		else
			var selectedCourse = $scope.selectedCourseOb;

		for(let subjectArray of $scope.deleteSubjectsArr){
			for(let classSubjectIdArray of subjectArray.classSubjectIdsArray)
			if(classSubjectIdArray.isAssigned == 1){
				alert("You cannot delete the select subject. Subject is already assigned to a class.");
				return;
			}
		}

		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId,
			"courseId": selectedCourse.courseId,
			"deleteSubjectsArray": $scope.deleteSubjectsArr
		}
		if ($scope.deleteSubjectsArr.length > 0) {
			console.log(params);
			httpFactory.executePost("deleteSubjectsForReportCard", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Deleted");
					document.getElementById("select").value = "";
					$scope.select = "";
					$scope.deleteSubjectsArr = [];
					$scope.getSubjectsByCourse(selectedCourse);
				} else if (data.StatusCode == 302) {
					alert(data.MESSAGE);
				} else {
					alert('Error while deleting');
				}
			});
		}
	}

	$scope.assignSubjectsArr = [];
	$scope.deleteAssignedSubjectsArr = [];
	$scope.updateSubjectSelectedStatus = function (selectedSubject) {
		if (typeof selectedSubject == 'string')
			var subject = JSON.parse(selectedSubject);
		else
			var subject = selectedSubject;
		if (subject.selected == true) {
			subject.selected = false;
			for (i = 0; i < $scope.assignSubjectsArr.length; i++) {
				if ($scope.assignSubjectsArr[i].subjectId == subject.subjectId)
					$scope.assignSubjectsArr.splice(i, 1);
			}
			$scope.deleteAssignedSubjectsArr.push(subject);
		} else if (subject.selected == false) {
			subject.selected = true;
			for (i = 0; i < $scope.deleteAssignedSubjectsArr.length; i++) {
				if ($scope.deleteAssignedSubjectsArr[i].subjectId == subject.subjectId)
					$scope.deleteAssignedSubjectsArr.splice(i, 1);
			}
			$scope.assignSubjectsArr.push(subject);
		}
	}

	$scope.assignSubjects = function () {
		if (document.getElementById("selectedCrs").value == "" || document.getElementById("selectedCrs").value == "undefined" ||
			document.getElementById("selectedCls").value == "" || document.getElementById("selectedCls").value == "undefined") {
			alert("Please select course and class");
			return;
		}
		var course = JSON.parse(document.getElementById("selectedCrs").value);
		var classs = JSON.parse(document.getElementById("selectedCls").value);
		var params = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.branchId,
			"courseId": course.courseId,
			"classId": classs.classId,
			"createdBy": $scope.userId,
		}
		if ($scope.assignSubjectsArr.length > 0) {
			params["assigningSubjectsArray"] = $scope.assignSubjectsArr;
		}
		if ($scope.deleteAssignedSubjectsArr.length > 0) {
			params["deleteAssigningSubjectsArray"] = $scope.deleteAssignedSubjectsArr;
		}
		console.log(params);
		httpFactory.executePost("assignSubjectsToClassForReportCard", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Successfully Updated");
				$scope.assignSubjectsArr = [];
				$scope.deleteAssignedSubjectsArr = [];
				$scope.getSubjectsByCourseClass(document.getElementById("selectedCrs").value, document.getElementById("selectedCls").value);
				$scope.getSubjectsByCourse(document.getElementById("selectedCrs").value);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.headerNum = 1;
	$scope.addNewColToReportCard = function (selectedOption) {
		if (selectedOption == "" || selectedOption == undefined) {
			alert("Select any option provided");
			return;
		}
		if (selectedOption == "Test") {
			if (document.getElementById("selectedTest").value == "" || document.getElementById("selectedTest").value == undefined) {
				alert("Select Test");
				return;
			}
			if (document.getElementById("colName").value == "" || document.getElementById("colName").value == undefined) {
				alert("Enter Column Name");
				return;
			}
			if (typeof document.getElementById("selectedTest").value == 'string') {
				var selectedTest = JSON.parse(document.getElementById("selectedTest").value);
			} else {
				var selectedTest = document.getElementById("selectedTest").value;
			}
			if ($scope.newColumn) {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].testId == selectedTest.testId) {
						alert("Test has already added");
						return;
					}
				}

				var testObj = {
					"colType": selectedOption,
					"colName": document.getElementById("colName").value,
					"colNum": $scope.testsArray.length + 1,
					"testId": selectedTest.testId
				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].testId == selectedTest.testId) {
						$scope.testsArray[i].colName = document.getElementById("colName").value;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.testsArray[i].testId === $scope.updateArray[j].testId) {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else if ($scope.testsArray[i].testId !== $scope.updateArray[j].testId && j === $scope.updateArray.length - 1) {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			document.getElementById("selectedTest").value = "";
			document.getElementById("colName").value = ""
			$scope.selectedOption = "";
			$scope.selectedTest = "";
			$scope.columnName = "";
		} else if (selectedOption == "Average") {
			if ($scope.testIds.length <= 1) {
				alert("Please add valid test for average calculation");
				return;
			}
			if ($scope.colName == '') {
				alert("Please enter column name");
				return;
			}
			if ($scope.newColumn) {
				var testObj = {
					"colType": 'Avg',
					"colName": document.getElementById("colName").value,
					"colNum": $scope.testsArray.length + 1,
					"testId": $scope.testIds

				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colNum === $scope.selCol && $scope.testsArray[i].colType === 'Avg') {
						$scope.testsArray[i].colName = document.getElementById("colName").value;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.testsArray[i].colNum === $scope.updateArray[j].colNum && $scope.testsArray[i].colType === 'Avg') {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else if ($scope.testsArray[i].colNum !== $scope.updateArray[j].colNum && $scope.testsArray[i].colType === 'Avg' && j === $scope.updateArray.length - 1) {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		} else if (selectedOption == "Sum") {
			if ($scope.testIds.length <= 1) {
				alert("Please add valid test for sum calculation");
				return;
			}
			if ($scope.colName == '') {
				alert("Please enter column name");
				return;
			}
			if ($scope.newColumn) {
				var testObj = {
					"colType": selectedOption,
					"colName": document.getElementById("colName").value,
					"colNum": $scope.testsArray.length + 1,
					"testId": $scope.testIds
				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colNum === $scope.selCol && $scope.testsArray[i].colType === 'Sum') {
						$scope.testsArray[i].colName = document.getElementById("colName").value;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.testsArray[i].colNum === $scope.updateArray[j].colNum && $scope.testsArray[i].colType === 'Sum') {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else if ($scope.testsArray[i].colNum !== $scope.updateArray[j].colNum && $scope.testsArray[i].colType === 'Sum' && j === $scope.updateArray.length - 1) {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		} else if (selectedOption == "Grade") {
			if ($scope.newColumn) {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType === 'Grade') {
						alert("Grade already added");
						return;
					}
				}
				var testObj = {
					"colType": selectedOption,
					"colName": $scope.colName,
					"colNum": $scope.testIds.colNum,
					"testId": ''
				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType == 'Grade') {
						$scope.testsArray[i].colNum = $scope.testIds.colNum;
						$scope.testsArray[i].colName = $scope.colName;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.updateArray[j].colType == 'Grade') {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		} else if (selectedOption == "Grade Points") {
			if ($scope.newColumn) {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType === 'Grade Points') {
						alert("Grade Points already added");
						return;
					}
				}
				var testObj = {
					"colType": selectedOption,
					"colName": $scope.colName,
					"colNum": $scope.testIds.colNum,
					"testId": ''
				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType == 'Grade Points') {
						$scope.testsArray[i].colNum = $scope.testIds.colNum;
						$scope.testsArray[i].colName = $scope.colName;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.updateArray[j].colType == 'Grade Points') {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		} else if (selectedOption == "Co-Curricular") {
			if ($scope.testIds.length == 0) {
				alert("No Test Selected");
				return;
			}
			for (i = 0; i < $scope.testIds.length; i++) {
				var testObj = {
					"colType": 'Co-Curricular',
					"colName": $scope.testIds[i].colName,
					"colNum": $scope.testsArray.length + 1,
					"testId": $scope.testIds[i].testId
				}
				$scope.testsArray.push(testObj);
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		} else if (selectedOption == "Total Percentage") {
			if ($scope.newColumn) {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType === 'Total Percentage') {
						alert("Total Percentage already added");
						return;
					}
				}
				var testObj = {
					"colType": selectedOption,
					"colName": $scope.colName,
					"colNum": $scope.testIds.colNum,
					"testId": ''
				}
				$scope.testsArray.push(testObj);
			} else {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].colType == 'Total Percentage') {
						$scope.testsArray[i].colNum = $scope.testIds.colNum;
						$scope.testsArray[i].colName = $scope.colName;
						for (j = 0; j < $scope.updateArray.length; j++) {
							if ($scope.updateArray[j].colType == 'Total Percentage') {
								$scope.updateArray[j] = $scope.testsArray[i];
								break;
							} else {
								$scope.updateArray.push($scope.testsArray[i]);
							}
						}
						if ($scope.updateArray.length == 0)
							$scope.updateArray.push($scope.testsArray[i]);
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		}
		for (i = 0; i < $scope.testsArray.length; i++) {
			if ($scope.testsArray[i].hasOwnProperty("selected")) {
				$scope.testsArray[i].selected = false;
			}
		}
		$scope.colName = '';
		$scope.testIds = [];
		$("#addNewColumn").modal("hide");
	}

	$scope.testNamess = function (testSelected) {
		if ($scope.colName == '' && selectedOption.value == 'Average') {
			$scope.colName = 'Avg of ';
		} else if ($scope.colName == '' && selectedOption.value == 'Sum') {
			$scope.colName = 'Sum of ';
		} else if (selectedOption.value == 'Grade' || selectedOption.value == 'Grade Points') {
			for (i = 0; i < $scope.testsArray.length; i++) {
				if ($scope.testsArray[i].hasOwnProperty("selected"))
					$scope.testsArray[i].selected = false;
			}
			$scope.testIds = testSelected;
			$scope.colName = testSelected.colType;
			return;
		} else if (selectedOption.value == 'Co-Curricular') {
			if ($scope.testIds.length == 0) {
				$scope.testIds.push(testSelected);
			} else {
				for (i = 0; i < $scope.testIds.length; i++) {
					if ($scope.testIds[i].testId == testSelected.testId) {
						$scope.testIds.splice(i, 1);
						break;
					} else if ($scope.testIds[i].testId != testSelected.testId && ($scope.testIds.length - 1 == i)) {
						$scope.testIds.push(testSelected);
						break;
					}
				}
			}
			return;
		} else if (selectedOption.value == 'Total Percentage') {
			for (i = 0; i < $scope.testsArray.length; i++) {
				if ($scope.testsArray[i].hasOwnProperty("selected"))
					$scope.testsArray[i].selected = false;
			}
			$scope.testIds = testSelected;
			$scope.colName = testSelected.colType;
			return;
		}
		if ($scope.testIds.length == 0) {
			$scope.testIds.push(testSelected.testId);
			$scope.colName += testSelected.colName;
		} else {
			for (i = 0; i < $scope.testIds.length; i++) {
				if ($scope.testIds[i] == testSelected.testId) {
					$scope.testIds.splice(i, 1);
					if ($scope.testIds.length == 0) {
						$scope.colName = '';
					} else {
						if ($scope.colName.includes(' & ' + testSelected.colName) || $scope.colName.includes(testSelected.colName + ' & ')) {
							$scope.colName = $scope.colName.replace(' & ' + testSelected.colName, '');
							$scope.colName = $scope.colName.replace(',', ' & ');
						}
						$scope.colName = $scope.colName.replace(testSelected.colName + ' & ', '');
						$scope.colName = $scope.colName.replace(',' + testSelected.colName, '');
						$scope.colName = $scope.colName.replace(testSelected.colName + ',', '');
					}
					break;
				} else if (!$scope.testIds.includes(testSelected.testId)) {
					$scope.testIds.push(testSelected.testId);
					//					$scope.testIds.sort((firstItem, secondItem) => firstItem - secondItem);
					if ($scope.testIds.length > 2) {
						$scope.colName = $scope.colName.replace(' & ', ',');
						$scope.colName += " & " + testSelected.colName;
					} else {
						$scope.colName += " & " + testSelected.colName;
					}
					break;
				}
			}
		}
	}

	$scope.selectTest = function (testSelected) {
		if (typeof testSelected == 'String')
			var selectedTestAvg = JSON.parse(testSelected);
		else
			var selectedTestAvg = testSelected;
		for (i = 0; i < $scope.testsArray.length; i++) {
			if (selectedTestAvg.testName == $scope.testsArray[i]["testName"]) {
				$scope.testsArray[i]["selected"] = true;
			}
		}
	}

	$scope.changeTemplateMode = function (indx) {
		$scope.templateMode = indx;
		$scope.testsArray = [];
	}

	$scope.addnewReportCardTemplate = function () {
		if (document.getElementById("templateName").value == "" || document.getElementById("templateName").value == undefined) {
			alert("Enter Template Name of Report Card");
			return;
		}
		if ($scope.testsArray.length > 0) {
			var params = {
				"schemaName": $scope.schemaName,
				"courseId": $scope.selectedCourse.courseId,
				"branchId": $scope.branchId,
				"createdBy": $scope.user_id,
				"templateName": document.getElementById("templateName").value,
				"testsArray": $scope.testsArray
			}
			httpFactory.executePost("addReportCardTemplate", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					document.getElementById("templateName").value = "";
					$scope.testsArray = [];
					$scope.getRCTemplateNames($scope.selectedCourse.courseId, data.templateId);
				} else {
					alert(data.MESSAGE);
				}
			});
		} else {
			alert("Add columns to template");
		}
	}

	$scope.modifyReportCardTemplate = function (selTemplate) {
		if ($scope.testsArray.length > $scope.columnLength || $scope.updateArray.length > 0) {
			for (i = 0; i < $scope.columnLength; i++) {
				$scope.testsArray.splice(0, 1);
			}
			var params = {
				"schemaName": $scope.schemaName,
				"templateId": selTemplate.templateId,
				"courseId": $scope.selectedCourse.courseId,
				"branchId": $scope.branchId,
				"createdBy": $scope.user_id,
				"testsArray": $scope.testsArray,
				"updateArray": $scope.updateArray
			}
			httpFactory.executePost("modifyReportCardTemplate", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getTemplateToUse(selTemplate);
				} else {
					alert(data.MESSAGE);
				}
			});
		} else {
			alert("Add columns to template");
		}
	}

	$scope.getTemplatesByCourse = function (course) {
		$scope.showTemplate = true;
		if (typeof course == 'string')
			$scope.selectedCourse = JSON.parse(course);
		else
			$scope.selectedCourse = course;
		$scope.templateDetailsArray = [];
		$scope.getRCTemplateNames($scope.selectedCourse.courseId, 0);
		$scope.getTestsDetailsByCourse($scope.selectedCourse);
		/*httpFactory.getResult("getReportCardTemplatesByCourse?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&courseId="+selectedCourse.courseId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.testsDetailsArray = data.testDetailsArray;
			}else if(data.StatusCode == 300){
				$scope.testsDetailsArray = [];
			}else{
				alert("Error while retrieving the records");
			}
		});*/
	}

	$scope.goToDashbord = function () {
		sessionStorage.removeItem('courseId');
		$location.path("reportAnalysis");
	}

	$scope.goToGenerateReportCard = function () {
		sessionStorage.removeItem('courseId');
		sessionStorage.removeItem('classId');
		sessionStorage.removeItem('sectionId');
		sessionStorage.removeItem('templateId');
		$location.path("generateReportCard");
	}

	$scope.gotoAddTestDetails = function () {
		$scope.newColumn = true;
		$("#addNewColumn").modal("hide");
		$location.path("addTestDetails");
	}

	$scope.closeAddColumnModal = function () {
		$scope.newColumn = true;
		if (document.getElementById("selectedOption").value != "" || document.getElementById("selectedOption").value != undefined) {
			if (document.getElementById("selectedOption").value == "Test") {
				if (document.getElementById("selectedTest").value != "" || document.getElementById("selectedTest").value != undefined) {
					document.getElementById("selectedTest").value = "";
					$scope.selectedTest = "";
				}
				if (document.getElementById("colName").value != "" || document.getElementById("colName").value != undefined) {
					document.getElementById("colName").value = "";
					$scope.colName = "";
				}
			} else if (document.getElementById("selectedOption").value == "Average" || document.getElementById("selectedOption").value == "Sum") {
				if ($scope.testsArray.length > 0) {
					for (i = 0; i < $scope.testsArray.length; i++) {
						$scope.testsArray[i]["selected"] = false;
					}
					if (document.getElementById("colName").value != "" || document.getElementById("colName").value != undefined) {
						document.getElementById("colName").value = "";
						$scope.colName = "";
					}
				}
			}
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
			$scope.colName = '';
			$scope.testIds = [];
		}
	}

	$scope.closeAddTestModal = function () {
		if (document.getElementById("courseOb").value != "" || document.getElementById("courseOb").value != undefined) {
			document.getElementById("courseOb").value = "";
			$scope.courseOb = "";
		}
		if (document.getElementById("testName").value != "" || document.getElementById("testName").value != undefined) {
			document.getElementById("testName").value = "";
			$scope.testName = "";
		}
		if (document.getElementById("totalMarks").value != "" || document.getElementById("totalMarks").value != undefined) {
			document.getElementById("totalMarks").value = "";
			$scope.totalMarks = "";
		}
	}

	$scope.getRCTemplateNames = function (course, selTemplate) {
		httpFactory.getResult("getReportCardTemplateNames?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + course, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.rcTemplateList = data.ReportCardTemplate.slice();
				if (selTemplate == undefined) {

				} else if (selTemplate == 0) {
					$scope.getTemplateToUse($scope.rcTemplateList[0]);
				} else if (!selTemplate.hasOwnProperty("templateId")) {
					for (i = 0; i < $scope.rcTemplateList.length; i++)
						if ($scope.rcTemplateList[i].templateId == selTemplate)
							$scope.getTemplateToUse($scope.rcTemplateList[i]);
				} else {
					$scope.getTemplateToUse(selTemplate);
				}

			}
		});
	}

	$scope.getTemplateToUse = function (stf) {
		if (stf == undefined) {
			$scope.templateId = sessionStorage.getItem("templateId");
		} else {
			$scope.templateId = stf.templateId;
			$scope.selectedTemplate = stf;
		}
		$scope.testIds = [];
		$scope.updateArray = [];
		$scope.colName = '';
		if ($scope.selectedTemplate != "") {
			httpFactory.getResult("getGenericRCT?templateId=" + $scope.templateId + "&schemaName=" + $scope.schemaName, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.changeTemplateMode('1');
					$scope.testsArray = data.workingDays.slice();
					$scope.columnLength = $scope.testsArray.length;
					$scope.colName = '';
				}


			});
		}
	}
	//    $scope.selectTestForReportCard = function(testObj){
	////	var testObj = JSON.parse(testObj)
	////	$scope.testTotalMarks = testObj.totalMarks;
	//	}

	$scope.getTestTemplateToUse = function (templateObj) {
		var templateObj = JSON.parse(templateObj)
		if (templateObj == undefined) {
			$scope.templateId = sessionStorage.getItem("templateId");
		} else {
			$scope.templateId = templateObj.templateId;
			$scope.selectedTemplate = templateObj;
		}
		$scope.testIds = [];
		$scope.updateArray = [];
		$scope.colName = '';
		if ($scope.selectedTemplate != "") {
			httpFactory.getResult("getGenericRCT?templateId=" + $scope.templateId + "&schemaName=" + $scope.schemaName, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.changeTemplateMode('1');
					$scope.testsArray = data.workingDays.slice();
					$scope.columnLength = $scope.testsArray.length;
					$scope.colName = '';
				}
			});
		}
		if (sessionStorage.getItem('testId') != null && sessionStorage.getItem('testId') != undefined && sessionStorage.getItem('testId') != '') {
			for (i = 0; i < $scope.testsArray.length; i++) {
				if ($scope.testsArray[i].templateId == sessionStorage.getItem('testId')) {
					$scope.testObj = JSON.stringify($scope.testsArray[i]);
					$scope.updateCrsClsSec($scope.selectedSectionObj);
					sessionStorage.removeItem('testId');
					break;
				}
			}
		}
	}

	$scope.changeTemplateMode = function (indx) {
		$scope.templateMode = indx;
		$scope.testsArray = [];
	}

	$scope.addBranchDetailsForRc = function () {
		if ($scope.branchReportCardData == undefined) {
			$("#addBranchDetails").modal("show");
		} else {
			if ($scope.branchReportCardData != undefined) {
				$("#addBranchDetails").modal("show");
			}
		}
		$scope.getBranchDetailsForRC();
	}

	$scope.getBranchDetailsForRC = function () {
		httpFactory.getResult("getBranchDetailsForHalltickets?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.branchReportCardData = data.hallticketData;
				$scope.branchName = $scope.branchReportCardData.branchName;
				$scope.branchAddress = $scope.branchReportCardData.branchAddress;
				$scope.academicYear = $scope.branchReportCardData.academicYear;
				if ($scope.branchReportCardData.logo !== '') {
					$scope.logo = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.branchReportCardData.logo;
				} else {
					$scope.logo = '';
				}
				if ($scope.branchReportCardData.principleSignature !== '') {
					$scope.principleSignature = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.branchReportCardData.principleSignature;
				} else {
					$scope.principleSignature = '';
				}
			} else {
				$scope.branchReportCardData = undefined;
				$scope.principleSignature = '';
			}
		});
	}

	$scope.changeBranch = function (branchDetail) {
		if (typeof branchDetail == 'string')
			$scope.selectedBranch = JSON.parse(branchDetail);
		else
			$scope.selectedBranch = branchDetail;
	}

	$scope.saveBranchDetailsForRC = function () {
		var fdd = new FormData();
		if (document.getElementById("branchName").value != undefined) {
			fdd.append('branchName', document.getElementById("branchName").value);
		} else {
			alert("Enter Branch Name")
			return true
		}
		if (document.getElementById("branchAddress").value != undefined) {
			fdd.append("branchAddress", document.getElementById("branchAddress").value);
		} else {
			alert("Enter Branch Address")
			return true
		}
		if (document.getElementById("academicYear").value != undefined) {
			fdd.append("academicYear", document.getElementById("academicYear").value);
		} else {
			alert("Enter acedamicYear")
			return true
		}
		if (document.getElementById("logo").files.length != 0 && document.getElementById("logo").files.length != undefined) {
			var logo = document.getElementById("logo").files;
			fdd.append("logo", logo[0]);
		}
		if (document.getElementById("principleSignature").files.length != 0 && document.getElementById("principleSignature").files.length != undefined) {
			var logo = document.getElementById("principleSignature").files;
			fdd.append("principleSignature", logo[0]);
		}
		if (document.getElementById("phoneNumber").value != undefined) {
			fdd.append("phoneNumber", document.getElementById("phoneNumber").value);
		} else {
			alert("Enter Phone Number")
			return true
		}
		if (document.getElementById("emailId").value != undefined) {
			fdd.append("emailId", document.getElementById("emailId").value);
		} else {
			alert("Enter email id")
			return true
		}
		fdd.append("branchId", $scope.branchId);
		fdd.append("createdBy", $scope.user_id);
		fdd.append("schemaName", $scope.schemaName);
		httpFactory.executeFileUpload("saveBranchDetailsForHallTicket", fdd, function (data) {
			console.log(data);
			if (data.StatusCode == '200') {
				$scope.logo = '';
				document.getElementById("logo").value = "";
				$scope.principleSignature = '';
				document.getElementById("principleSignature").value = "";
				alert("Details Updated Successfully");
				$("#addBranchDetails").modal("hide");
			} else {
				alert("Error while updating");
			}
		});
	}

	$scope.getStudentsForReportCard = function () {
		httpFactory.getResult("getStudentsForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + $scope.selectedSection.sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardStudents = data.reportCardStudents;
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					$scope.reportCardStudents[i].selected = false;
					if ($scope.reportCardStudents[i].profilePic != 'NA' && $scope.reportCardStudents[i].profilePic != '') {
						$scope.reportCardStudents[i].profilePic = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.reportCardStudents[i].profilePic;
					}
				}
			} else {

			}
		});
	}

	$scope.getStudentsWithAttendanceForReportCard = function () {
		httpFactory.getResult("getStudentsWithAttendanceForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + JSON.parse($scope.selectedSectionObj).sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentAndAttList = data.reportCardStudents;
				for (i = 0; i < $scope.studentAndAttList.length; i++) {
					if ($scope.studentAndAttList[i].profilePic != 'NA' && $scope.studentAndAttList[i].profilePic != '') {
						$scope.studentAndAttList[i].profilePic = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.studentAndAttList[i].profilePic;
					}
				}
				$scope.originalStudentAttList = angular.copy($scope.studentAndAttList);
			} else {

			}
		});
	}


	$scope.getStudentDetailsForReportCard = function (student) {
		var studentId = "";
		if (student != undefined) {
			studentId = student.studentId;
		}
		else {
			studentId = sessionStorage.getItem("studentId");
		}
		httpFactory.getResult("getStudentDetailsForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + sessionStorage.getItem("sectionId") + "&studentId=" + studentId + "&templateId=" + sessionStorage.getItem("templateId"), function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardStudentDetails = data.reportCardStudentDetails[0];
				$scope.classSection = sessionStorage.getItem("className") + '-' + $scope.reportCardStudentDetails.sectionName;
				$scope.tempReportCardStudentDetails = angular.copy($scope.reportCardStudentDetails);
				$scope.reportCardId = $scope.reportCardStudentDetails.reportCardId;
				if ($scope.reportCardStudentDetails.profilePic != 'NA' && $scope.reportCardStudentDetails.profilePic != '') {
					$scope.reportCardStudentDetails.profilePic = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.reportCardStudentDetails.profilePic;
				}
			} else {

			}
		});
		return $scope.reportCardStudentDetails;
	}

	function hasDataChanged(existingArray, updatedArray) {
		if (existingArray.length !== updatedArray.length) {
			return true;  // If lengths are different, data has changed
		}

		for (var i = 0; i < existingArray.length; i++) {
			var existingItem = existingArray[i];
			var updatedItem = updatedArray[i];

			// Assuming a simple comparison for illustration
			// You may need to customize this based on your data structure
			if (!angular.equals(existingItem, updatedItem)) {
				return true;  // If items are not equal, data has changed
			}
		}

		return false;  // If no differences found, data has not changed
	}


	$scope.saveReportCardDetails = function (students) {
		if (hasDataChanged($scope.existingStudentAttArray, $scope.studentAttArray)) {
			var reportCardDetails = [];

			$scope.studentAttArray.forEach(function (student) {
				// Check if student details are empty
				if (
					!student.studentDetails.fatherName ||
					!student.studentDetails.motherName ||
					!student.studentDetails.DOB
				) {
					alert("Please enter all details for student: " + student.studentDetails.studentName);
					return;
				}

				// Check if student details have changed
				var dob = student.studentDetails.DOB.toString();

				if (dob && !dob.includes('-')) {
					var date = new Date(student.studentDetails.DOB);
					var genMon = date.getMonth() + 1;

					if (genMon < 10) {
						genMon = "0" + genMon;
					}

					var genDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
					student.studentDetails.DOB = genDate;
				}

				var studentData = {
					"DOB": student.studentDetails.DOB,
					"fatherName": student.studentDetails.fatherName,
					"motherName": student.studentDetails.motherName,
					"studentId": student.studentDetails.studentId,
					"reportCardId": student.studentDetails.reportCardId
				};

				reportCardDetails.push(studentData);
			});

			// Check if any changes were made
			if (reportCardDetails.length === 0) {
				alert("No changes detected for any student");
				return;
			}

			var params = {
				"schemaName": $scope.schemaName,
				"branchId": $scope.branchId,
				"templateId": sessionStorage.getItem("templateId"),
				"courseId": sessionStorage.getItem("courseId"),
				"createdBy": localStorage.getItem("userId"),
				"studentDetails": reportCardDetails
			};

			console.log(params);

			//Call your API with the params object
			httpFactory.executePost("saveReportCardDetails", params, function (data) {
				console.log(data);

				if (data.StatusCode == 200) {
					alert("Changes Saved for multiple students");
					// Add any additional logic if needed
				} else {
					alert("Something went wrong");
				}
			});
		} else {
			alert("No Data Changed");
		}

	};

	$scope.getGradesandGradePointsForReportCard = function () {
		httpFactory.getResult("getGradesandGradePointsForReportCard?schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.gradeArray = data.gradesArray;
			} else {

			}
		});
	}

	$scope.getReportCardTestMarks = function (student) {
		var studentId = "";
		if (student != undefined) {
			studentId = student.studentId;
		}
		else {
			studentId = sessionStorage.getItem("studentId");
		}
		$scope.rcMarks = [];
		httpFactory.getResult("getReportCardTestMarks?schemaName=" + $scope.schemaName + "&studentId=" + studentId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardMarksArray = data.reportCardMarks;
				$scope.subjectsAndMarks();
			} else {

			}
		});
		return $scope.rcMarks;
	}

	$scope.subjectsAndMarks = function () {
		$scope.totalCalculation = [];
		$scope.totalCalculation.push({ "header": "Total" }, { "header": "Grade" }, { "header": "GPA" });
		var inx = -1;
		var tempSubId = 0;
		$scope.practicalMarks = false;
		for (i = 0; i < $scope.classSubjectsList.length; i++) {
			if ($scope.classSubjectsList[i].isAssigned == 1) {
				var sub = {
					"subjectId": $scope.classSubjectsList[i].subjectId,
					"subjectName": $scope.classSubjectsList[i].subjectName,
					"subjectType": $scope.classSubjectsList[i].subjectType
				}
				$scope.rcMarks.push(sub);
				inx++;
				var number = 0;
				for (j = 0; j < $scope.testsArray.length; j++) {
					if ($scope.rcMarks[inx].subjectType === 'General' && !($scope.testsArray[j].colType === 'Co-Curricular')) {
						if (tempSubId == 0)
							tempSubId = $scope.classSubjectsList[i].subjectId;

						var marks = {
							"colType": $scope.testsArray[j].colType,
							"colNum": $scope.testsArray[j].colNum,
							"testId": $scope.testsArray[j].testId,
							"totalMarks": $scope.testsArray[j].totalMarks,
							"mark": ''
						}
						if (tempSubId == $scope.rcMarks[inx].subjectId) {
							var totMarks = [];
							totMarks.push(marks);
							if ($scope.totalCalculation[0].hasOwnProperty("marks")) {
								$scope.totalCalculation[0].marks.push(angular.copy(totMarks[0]));
								$scope.totalCalculation[1].marks.push(angular.copy(totMarks[0]));
								$scope.totalCalculation[2].marks.push(angular.copy(totMarks[0]));
							} else {
								$scope.totalCalculation[0]["marks"] = angular.copy(totMarks);
								$scope.totalCalculation[1]["marks"] = angular.copy(totMarks);
								$scope.totalCalculation[2]["marks"] = angular.copy(totMarks);
							}
						}
					} else {
						if (!($scope.testsArray[j].colType === 'Co-Curricular') || $scope.rcMarks[inx].subjectType === 'General') {
							continue;
						}
						var marks = {
							"colType": $scope.testsArray[j].colType,
							"colNum": $scope.testsArray[j].colNum,
							"colName": $scope.testsArray[j].colName,
							"testId": $scope.testsArray[j].testId,
							"totalMarks": $scope.testsArray[j].totalMarks,
							"mark": '',
							"grade": ''
						}
						$scope.practicalMarks = true;
					}
					var subMarks = [];
					subMarks.push(marks);
					if ($scope.rcMarks[inx].hasOwnProperty("marks")) {
						$scope.rcMarks[inx].marks.push(subMarks[0]);
						if ($scope.rcMarks[inx].hasOwnProperty("markGrade") && $scope.rcMarks[inx].subjectType === 'Co-Curricular') {
							var markObj = {
								"testId": $scope.testsArray[j].testId,
								"mark": ''
							}
							$scope.rcMarks[inx].markGrade.push(markObj);
							var gradeObj = {
								"testId": $scope.testsArray[j].testId,
								"grade": ''
							}
							$scope.rcMarks[inx].markGrade.push(gradeObj);
						}
					} else {
						$scope.rcMarks[inx]["marks"] = subMarks;
						if (!$scope.rcMarks[inx].hasOwnProperty("markGrade") && $scope.rcMarks[inx].subjectType === 'Co-Curricular') {
							var markObj = {
								"testId": $scope.testsArray[j].testId,
								"mark": ''
							}
							$scope.rcMarks[inx]["markGrade"] = [];
							var markGrade = [];
							$scope.rcMarks[inx].markGrade.push(markObj);
							var gradeObj = {
								"testId": $scope.testsArray[j].testId,
								"grade": ''
							}
							$scope.rcMarks[inx].markGrade.push(gradeObj);
						}
					}

					for (k = 0; k < $scope.reportCardMarksArray.length; k++) {
						if ($scope.reportCardMarksArray[k].subjectId === Number($scope.classSubjectsList[i].subjectId) && $scope.reportCardMarksArray[k].testId == $scope.testsArray[j].testId && $scope.testsArray[j].colType === 'Co-Curricular') {
							$scope.rcMarks[inx].marks[number].mark = $scope.reportCardMarksArray[k].marks;
							if ($scope.rcMarks[inx].marks[number].colType === 'Co-Curricular') {
								$scope.rcMarks[inx].marks[number].grade = $scope.reportCardMarksArray[k].grade;

								for (a = 0; a < $scope.rcMarks[inx].markGrade.length; a++) {
									if ($scope.rcMarks[inx].markGrade[a].testId == $scope.reportCardMarksArray[k].testId && a % 2 == 0) {
										$scope.rcMarks[inx].markGrade[a].mark = $scope.reportCardMarksArray[k].marks;
									} else if ($scope.rcMarks[inx].markGrade[a].testId == $scope.reportCardMarksArray[k].testId && a % 2 == 1) {
										$scope.rcMarks[inx].markGrade[a].grade = $scope.reportCardMarksArray[k].grade;
									}
								}
							}
							number++;
							break;
						} else if ($scope.reportCardMarksArray[k].subjectId === Number($scope.classSubjectsList[i].subjectId) && $scope.reportCardMarksArray[k].testId == $scope.testsArray[j].testId && $scope.testsArray[j].colType !== 'Co-Curricular' && $scope.testsArray[j].colType !== 'Total Percentage') {
							$scope.rcMarks[inx].marks[j].mark = $scope.reportCardMarksArray[k].marks;
							if ($scope.rcMarks[inx].marks[j].colType === 'Co-Curricular') {
								$scope.rcMarks[inx].marks[j].grade = $scope.reportCardMarksArray[k].grade;
							}
							break;
						}
					}
				}
			}
		}

		console.log($scope.rcMarks);
		console.log($scope.totalCalculation);
		$scope.avgAndSumMarks();
		$scope.tempRCMarks = [];
		$scope.tempRCMarks = angular.copy($scope.rcMarks);
		//  	$scope.setTabIndex();
	}

	$scope.avgAndSumMarks = function () {
		for (i = 0; i < $scope.rcMarks.length; i++) {
			if ($scope.rcMarks[i].subjectType === 'General') {
				for (j = 0; j < $scope.rcMarks[i].marks.length; j++) {
					if ($scope.rcMarks[i].marks[j].colType === 'Avg' || $scope.rcMarks[i].marks[j].colType === 'Sum') {
						$scope.rcMarks[i].marks[j].totalMarks = '';
						$scope.rcMarks[i].marks[j].mark = '';
						for (t = 0; t < $scope.testsArray.length; t++) {
							if ($scope.rcMarks[i].marks[j].colType === $scope.testsArray[t].colType && $scope.rcMarks[i].marks[j].colNum === $scope.testsArray[t].colNum) {
								if (i == 0) {
									$scope.testsArray[t].totalMarks = '';
								}
								for (k = 0; k < $scope.rcMarks[i].marks.length; k++) {
									if ($scope.rcMarks[i].marks[j].testId.includes($scope.rcMarks[i].marks[k].testId) && $scope.rcMarks[i].marks[k].colType === 'Test') {
										$scope.rcMarks[i].marks[j].mark = Number($scope.rcMarks[i].marks[j].mark) + Number($scope.rcMarks[i].marks[k].mark);
										$scope.rcMarks[i].marks[j].totalMarks = Number($scope.rcMarks[i].marks[j].totalMarks) + Number($scope.rcMarks[i].marks[k].totalMarks);
										if (i == 0) {
											$scope.testsArray[t].totalMarks = Number($scope.testsArray[t].totalMarks) + Number($scope.rcMarks[i].marks[k].totalMarks);
											$scope.totalCalculation[0].marks[j].totalMarks = $scope.rcMarks[i].marks[j].totalMarks;
										}
									}
								}
								if ($scope.rcMarks[i].marks[j].colType === 'Avg') {
									$scope.rcMarks[i].marks[j].mark = Math.round(Number($scope.rcMarks[i].marks[j].mark) / $scope.rcMarks[i].marks[j].testId.length);
									$scope.rcMarks[i].marks[j].totalMarks = Math.round(Number($scope.rcMarks[i].marks[j].totalMarks) / $scope.rcMarks[i].marks[j].testId.length);
									if (i == 0) {
										$scope.testsArray[t].totalMarks = Math.round(Number($scope.testsArray[t].totalMarks) / $scope.testsArray[t].testId.length);
										$scope.totalCalculation[0].marks[j].totalMarks = $scope.rcMarks[i].marks[j].totalMarks;
									}
								}
							}
						}
					}
					if ($scope.rcMarks[i].marks[j].colType.includes('Grade')) {
						$scope.rcMarks[i].marks[j].mark = '';
						for (k = 0; k < $scope.rcMarks[i].marks.length; k++) {
							if ($scope.rcMarks[i].marks[j].colNum === $scope.rcMarks[i].marks[k].colNum && $scope.rcMarks[i].marks[k].colType !== 'Total Percentage' && $scope.rcMarks[i].marks[k].colType !== 'Grade' && $scope.rcMarks[i].marks[k].colType !== 'Grade Points') {
								for (m = 0; m < $scope.gradeArray.length; m++) {
									if (Math.round(($scope.rcMarks[i].marks[k].mark * 100) / ($scope.rcMarks[i].marks[k].totalMarks)) >= $scope.gradeArray[m].marksFrom && Math.round(($scope.rcMarks[i].marks[k].mark * 100) / ($scope.rcMarks[i].marks[k].totalMarks)) <= $scope.gradeArray[m].marksTo) {
										if ($scope.rcMarks[i].marks[j].colType === 'Grade') {
											$scope.rcMarks[i].marks[j].mark = $scope.gradeArray[m].grade;
										}
										if ($scope.rcMarks[i].marks[j].colType === 'Grade Points') {
											$scope.rcMarks[i].marks[j].mark = $scope.gradeArray[m].gradePoints;
										}
										break;
									}
								}
							}
						}

					}
				}
			}
		}
		$scope.totalPercentage = 0;
		$scope.totalGPA = '';
		for (k = 0; k < $scope.rcMarks[0].marks.length; k++) {
			$scope.totalCalculation[0].marks[k].mark = '';
			var count = 0;
			for (l = 0; l < $scope.rcMarks.length; l++) {
				if ($scope.rcMarks[l].subjectType === 'General') {
					$scope.totalCalculation[0].marks[k].mark = Number($scope.totalCalculation[0].marks[k].mark) + Number($scope.rcMarks[l].marks[k].mark);
					count++;
				}
			}
			for (m = 0; m < $scope.gradeArray.length; m++) {
				if (Math.round(($scope.totalCalculation[0].marks[k].mark * 100) / ($scope.totalCalculation[0].marks[k].totalMarks * (count))) >= $scope.gradeArray[m].marksFrom && Math.round(($scope.totalCalculation[0].marks[k].mark * 100) / ($scope.totalCalculation[0].marks[k].totalMarks * (count))) <= $scope.gradeArray[m].marksTo) {
					$scope.totalCalculation[1].marks[k].mark = $scope.gradeArray[m].grade;
					$scope.totalCalculation[2].marks[k].mark = $scope.gradeArray[m].gradePoints;
					break;
				}
				if ($scope.totalCalculation[0].marks[k].colType === 'Total Percentage' && m == 0) {
					for (n = 0; n < $scope.totalCalculation[0].marks.length; n++) {
						if ($scope.totalCalculation[0].marks[n].colNum === $scope.totalCalculation[0].marks[k].colNum && $scope.totalCalculation[0].marks[n].colType !== 'Total Percentage' && $scope.totalCalculation[0].marks[n].colType !== 'Grade' && $scope.totalCalculation[0].marks[n].colType !== 'Grade Points') {
							$scope.totalPercentage = ($scope.totalCalculation[0].marks[n].mark * 100) / ($scope.totalCalculation[0].marks[n].totalMarks * (count));
						}
					}
				}
				if (Math.round($scope.totalPercentage) >= $scope.gradeArray[m].marksFrom && Math.round($scope.totalPercentage) <= $scope.gradeArray[m].marksTo) {
					$scope.totalGPA = $scope.gradeArray[m].gradePoints;
				}
			}
		}
	}

	$scope.practicalMarksAndGrade = function () {
		for (i = 0; i < $scope.rcMarks.length; i++) {
			if ($scope.rcMarks[i].subjectType !== 'General') {
				for (j = 0; j < $scope.rcMarks[i].marks.length; j++) {
					for (k = 0; k < $scope.rcMarks[i].markGrade.length; k++) {
						if ($scope.rcMarks[i].marks[j].testId == $scope.rcMarks[i].markGrade[k].testId) {
							if ($scope.rcMarks[i].markGrade[k].hasOwnProperty('mark'))
								$scope.rcMarks[i].marks[j].mark = $scope.rcMarks[i].markGrade[k].mark;
							else
								$scope.rcMarks[i].marks[j].grade = $scope.rcMarks[i].markGrade[k].grade;
						}
					}
				}
			}
		}
	}

	$scope.getRCPresentAttendance = function (student) {
		var studentId = "";
		if (student != undefined) {
			studentId = student.studentId;
		}
		else {
			studentId = sessionStorage.getItem("studentId");
		}
		httpFactory.getResult("getRCPresentAttendance?schemaName=" + $scope.schemaName + "&studentId=" + studentId + "&branchId=" + $scope.branchId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.reportCardPresentDays = data.reportCardPresentDays;
				$scope.tempReportCardPresentDays = angular.copy($scope.reportCardPresentDays);
			} else {

			}
		});
		return $scope.reportCardPresentDays;
	}

	$scope.backMethod = function () {
		$location.path("reportCardGeneration");
	}

	$scope.makeReportCardPDF = function () {
		var mywindow = window.open('', '', '', '');
		mywindow.document.write('<!doctype html> <html style="width:100%"><head><title></title>');
		mywindow.document.write('</head><body>');
		mywindow.document.write(document.getElementById("printReportCard").innerHTML);
		mywindow.document.write('</body></html>');
		var is_chrome = Boolean(mywindow.chrome);
		mywindow.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
		if (is_chrome) {
			mywindow.onload = function () { // wait until all resources loaded 
				mywindow.focus(); // necessary for IE >= 10
				mywindow.print();  // change window to mywindow
			};
		}
		else {
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10
			mywindow.print();
		}
	}

	$scope.sum = function (items, prop) {
		if(items)
			return items.reduce(function (a, b) {
				return Number(a) + Number(b[prop]);
			}, 0);
	};

	$scope.selectAllTemplates = function () {
		$scope.classTemplateArr = [];
		if (document.getElementById('isAllChecked').checked == true) {
			for (i = 0; i < $scope.classTemplateList.length; i++) {
				document.getElementsByName('selectedTemplate')[j].checked = true;
			}
		} else {
			for (j = 0; j < $scope.classTemplateList.length; j++) {
				document.getElementsByName('selectedTemplate')[j].checked = false;
			}
		}
	}

	$scope.getClassWiseTemplates = function (courseId, classId) {
		$scope.classTemplateList = [];
		$scope.tempclassTemplateList = [];
		$scope.reportCardStudents = [];
		httpFactory.getResult("getClassWiseTemplates?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + courseId + "&classId=" + classId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.classTemplateList = data.classWiseTemplate.slice();
				for (j = 0; j < $scope.classTemplateList.length; j++) {
					if ($scope.classTemplateList[j].checked == 1)
						$scope.classTemplateList[j].checked = true;
					else
						$scope.classTemplateList[j].checked = false;
				}
				$scope.tempclassTemplateList = angular.copy($scope.classTemplateList);
				if (sessionStorage.getItem('templateId') != null && sessionStorage.getItem('templateId') != undefined && sessionStorage.getItem('templateId') != '') {
					for (i = 0; i < $scope.classTemplateList.length; i++) {
						if ($scope.classTemplateList[i].templateId == sessionStorage.getItem('templateId')) {
							$scope.templateObj = JSON.stringify($scope.classTemplateList[i]);
							//$scope.getTestTemplateToUse($scope.templateObj);
							$scope.getRCTestsByTemplate($scope.templateObj);
							sessionStorage.removeItem('templateId');
							break;
						}
					}
				}
			}
		});
	}

	$scope.addTemplateForClass = function () {
		$scope.classTemplateArr = [];
		if (!(JSON.stringify($scope.tempclassTemplateList) === JSON.stringify($scope.classTemplateList))) {
			for (i = 0; i < $scope.classTemplateList.length; i++) {
				if ($scope.classTemplateList[i].checked != $scope.tempclassTemplateList[i].checked) {
					if ($scope.classTemplateList[i].checked == true) {
						$scope.classTemplateList[i].checked = 1;
					} else {
						$scope.classTemplateList[i].checked = 0;
					}
					$scope.classTemplateArr.push($scope.classTemplateList[i]);
				}
			}
		}

		if ($scope.classTemplateArr.length == 0) {
			alert("Nothing changed");
			return;
		}
		var params = {
			"schemaName": $scope.schemaName,
			"courseId": $scope.selectedCourse.courseId,
			"classId": $scope.selClassId,
			"branchId": $scope.branchId,
			"templateArray": $scope.classTemplateArr,
			"createdBy": $scope.user_id
		}
		httpFactory.executePost("addTemplateForClass", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Changes Saved");
				$scope.getClassWiseTemplates($scope.selectedCourse.courseId, $scope.selClassId);
			} else {
				alert("Something went wrong");
			}
		});
	}


	$scope.editColumn = function (selectedColumn, col) {
		for (i = 0; i < $scope.testsArray.length; i++) {
			if ($scope.testsArray[i].hasOwnProperty("selected"))
				$scope.testsArray[i].selected = false;
			else
				$scope.testsArray[i]["selected"] = false;
		}
		$scope.newColumn = false;
		$scope.selCol = col;
		$("#addNewColumn").modal("show");
		document.getElementById("selectedOption").value = selectedColumn.colType;
		$scope.selectedOption = selectedColumn.colType;
		if (selectedColumn.colType === 'Test') {
			for (i = 0; i < $scope.testsDetailsArray.length; i++) {
				if (selectedColumn.testId == Number($scope.testsDetailsArray[i].testId)) {
					delete $scope.testsDetailsArray[i].$$hashKey;
					$scope.selectedTest = JSON.stringify($scope.testsDetailsArray[i]);
				}
			}
			$scope.colName = selectedColumn.colName;
		} else if (selectedColumn.colType === 'Avg') {
			document.getElementById("selectedOption").value = 'Average';
			$scope.selectedOption = 'Average';
			for (i = 0; i < $scope.testsArray.length; i++) {
				for (j = 0; j < selectedColumn.testId.length; j++) {
					if (selectedColumn.testId[j] == Number($scope.testsArray[i].testId) && $scope.testsArray[i].colType === 'Test') {
						$scope.testIds.push(selectedColumn.testId[j]);
						$scope.testsArray[i].selected = true;
						break;
					}
				}
			}
			$scope.colName = selectedColumn.colName;
		} else if (selectedColumn.colType === 'Sum') {
			document.getElementById("selectedOption").value = 'Sum';
			$scope.selectedOption = 'Sum';
			for (i = 0; i < $scope.testsArray.length; i++) {
				for (j = 0; j < selectedColumn.testId.length; j++) {
					if (selectedColumn.testId[j] == Number($scope.testsArray[i].testId) && $scope.testsArray[i].colType === 'Test') {
						$scope.testIds.push(selectedColumn.testId[j]);
						$scope.testsArray[i].selected = true;
						break;
					}
				}
			}
			$scope.colName = selectedColumn.colName;
		} else if (selectedColumn.colType === 'Grade' || selectedColumn.colType === 'Grade Points') {
			for (j = 0; j < $scope.testsArray.length; j++) {
				if ($scope.testsArray[col - 1].colNum === $scope.testsArray[j].colNum) {
					$scope.testsArray[j].selected = true;
				}
			}
		} else if (selectedColumn.colType === 'Co-Curricular') {
			for (i = 0; i < $scope.testsArray.length; i++) {
				if ($scope.testsArray[i].colType === 'Co-Curricular') {
					for (j = 0; j < $scope.testsArray.length; j++) {
						if ($scope.testsArray[j].colType === 'Test' && JSON.stringify($scope.testsArray[j].testId).includes(JSON.stringify($scope.testsArray[i].testId))) {
							$scope.testsArray[j].selected = true;
						}
					}
				}
			}
		} else if (selectedColumn.colType === 'Total Percentage') {
			for (j = 0; j < $scope.testsArray.length; j++) {
				if ($scope.testsArray[col - 1].colNum === $scope.testsArray[j].colNum) {
					$scope.testsArray[j].selected = true;
				}
			}
		}
	}

	$scope.makePdfForReportCard = function() {
		const loadingIndicator = document.getElementById("loadingOverlay");
		console.log("PDF generation started");

		if (!confirm('Make sure your page resolution is 100%.')) return;
		loadingIndicator.style.display = "block";

		const studDOB = document.getElementById("studDOB");
		const studDOBDisplay = document.getElementById("studDOBDisplay");
		studDOBDisplay.value = new Date(studDOB.value).toLocaleDateString();
		studDOB.style.display = "none";
		studDOBDisplay.style.display = "block";
		$scope.inputBox = false;

		const studentsDivsLength =  $scope.studentAttArray.length

		const filename = $scope.classSection;
		console.log("Number of student divs found:", studentsDivsLength);

		function generatePdfChunk(startIndex, endIndex, chunkIndex) {
			return new Promise((resolve, reject) => {
				try {
					const pdf = new window.jspdf.jsPDF('l', 'pt', 'a4');
					const PDF_Width = pdf.internal.pageSize.width;
					const tasks = [];

					function processDiv(div, idx) {
						return new Promise((res, rej) => {
							html2canvas(div, { allowTaint: true, scale: 1 })
								.then(canvas => {
								const scaleFactor = PDF_Width / canvas.width;
								const HTML_Width = PDF_Width;
								const HTML_Height = canvas.height * scaleFactor;
								if (idx > startIndex) {
									pdf.addPage();
								}
								pdf.addImage(canvas.toDataURL("image/jpeg", 1), 'JPEG', 0, 0, HTML_Width, HTML_Height);
								console.log(`  JS Heap Size Limit: ${performance.memory.jsHeapSizeLimit / 1024 / 1024} MB`);
								console.log(`  Total JS Heap: ${performance.memory.totalJSHeapSize / 1024 / 1024} MB`);
								console.log(`  Used JS Heap: ${performance.memory.usedJSHeapSize / 1024 / 1024} MB`);
								res();
							})
								.catch(error => {
								console.error(`Error processing student div ${idx + 1}:`, error);
								rej(error);
							});
						});

					}

					for (let i = startIndex; i < endIndex; i++) {
						console.log(`Processing student div ${i + 1}/${studentsDivsLength}`);
						tasks.push(processDiv(document.getElementById(`reportCardPdfContent-${i}`), i));
					}

					Promise.all(tasks)
						.then(async () => {
						try {
							console.log(`Saving PDF chunk ${chunkIndex}`)
							await pdf.save(`${filename}_part${chunkIndex}.pdf`)
							console.log(`After Saving PDF chunk ${chunkIndex}`)
							resolve()
						} catch(error) {
							console.error("Error while waiting for download to complete", error)
							reject(error)
						}
					})
						.catch(error => {
						console.error(`Error saving PDF chunk ${chunkIndex}:`, error);
						reject(error);
					});
				} catch (error) {
					console.error("Unexpected error during PDF generation:", error);
					reject(error);
				}
			});
		}

		async function processChunks(chunkSize) {
			try {
				for (let i = 0; i < studentsDivsLength; i += chunkSize) {
					const endIndex = Math.min(i + chunkSize, studentsDivsLength);
					console.log(`Processing chunk ${i / chunkSize + 1}: students ${i + 1} to ${endIndex}`);
					await generatePdfChunk(i, endIndex, i / chunkSize + 1);
					console.log(`Chunk ${i / chunkSize + 1} processed successfully`);
				}
				console.log("All chunks processed successfully");
			} catch (error) {
				console.error("Error during chunk processing:", error);
			}
		}

		processChunks(1).then(() => {
			loadingIndicator.style.display = "none";
			$scope.inputBox = true;
			studDOB.style.display = "block";
			studDOBDisplay.style.display = "none";
			alert("All PDFs have been downloaded.");
			console.log("PDF generation completed successfully");
		}).catch((error) => {
			console.error("Failed to complete PDF generation:", error);
			loadingIndicator.style.display = "none";
			$scope.inputBox = true;
		});
	};

	$scope.deleteReportCardTemplate = function (tempId) {
		if (!confirm('The template will get deleted.'))
			return;
		var params = {
			"schemaName": $scope.schemaName,
			"templateId": tempId,
			"deletedBy": $scope.user_id
		}
		httpFactory.executePost("deleteReportCardTemplate", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.getTemplatesByCourse($scope.selectedCourse);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.changeColor = function () {
		if ($scope.change)
			$scope.change = false;
		else
			$scope.change = true;
	}

	$scope.mySearchFunction = function () {
		html2canvas($("#reportCardPdfContent")[0], { allowTaint: true }).then(function (canvas) {
			var PDF_Width = 841.89;
			var PDF_Height = 595.28;
			var HTML_Height = $("#reportCardPdfContent").height();
			var scaleFactor = PDF_Width / $("#reportCardPdfContent").width();
			var HTML_Width = PDF_Width;
			HTML_Height *= scaleFactor;
			var imgData = canvas.toDataURL("image/png", 1.0);
			var pdf = new jsPDF('l', 'pt', [PDF_Width, PDF_Height], true);
			pdf.setPage(1);
			pdf.addImage(imgData, 'JPG', 0, 20, HTML_Width, HTML_Height);
			setTimeout(function () {
				pdf.save(previewFilename + ".pdf");
			}, 500);
		});
		$scope.inputBox = true;
		document.getElementById("studDOB").style.display = "block";
		document.getElementById("studDOBDisplay").style.display = "none";
	}

	$scope.deleteReportCardTemplate = function (tempId) {
		if (!confirm('The template will get deleted.'))
			return;
		var params = {
			"schemaName": $scope.schemaName,
			"templateId": tempId,
			"deletedBy": $scope.user_id
		}
		httpFactory.executePost("deleteReportCardTemplate", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.getTemplatesByCourse($scope.selectedCourse);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.changeColor = function () {
		if ($scope.change)
			$scope.change = false;
		else
			$scope.change = true;
	}

	$scope.mySearchFunction = function () {
		// Declare variables
		var input, filter, table, tr, td, i, txtValue;
		input = document.getElementById("searchRCStudents");
		filter = input.value.toUpperCase();
		table = document.getElementById("rcStudents");
		tr = table.getElementsByTagName("tr");

		// Loop through all table rows, and hide those who don't match the search query
		for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[1];
			if (td) {
				txtValue = td.textContent || td.innerText;
				if (txtValue.toUpperCase().indexOf(filter) > -1) {
					tr[i].style.display = "";
				} else {
					tr[i].style.display = "none";
				}
			}
		}
	}

	$scope.setTabIndex = function () {
		const inputs = document.querySelectorAll('#marksTable input');

		inputs.forEach((input, index) => {
			input.setAttribute('tabindex', index + 1);
		});
		//  	$scope.nextTD();
	}

	$scope.nextTD = function () {
		const inputs = document.querySelectorAll('#marksTable input');
		inputs.forEach((input) => {
			input.addEventListener('keydown', (e) => {
				if (e.key === 'Tab') {
					e.preventDefault();
					const row = input.parentNode.parentNode;
					const nextInput = row.nextElementSibling.querySelector('#marksTable input');
					if (nextInput) {
						nextInput.focus();
					}
				}
			});
		});
	}
	$scope.getRCTestsByTemplate = function (templateObj) {
		httpFactory.getResult("getRCTestsByTemplate?schemaName=" + $scope.schemaName + "&templateId=" + JSON.parse(templateObj).templateId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.testsArray = data.testsArray;
			} else {
				alert(data.MESSAGE);
			}
			if (sessionStorage.getItem('testId') != null && sessionStorage.getItem('testId') != undefined && sessionStorage.getItem('testId') != '') {
				for (i = 0; i < $scope.testsArray.length; i++) {
					if ($scope.testsArray[i].testId == sessionStorage.getItem('testId')) {
						$scope.testObj = JSON.stringify($scope.testsArray[i]);
						$scope.updateCrsClsSec($scope.selectedSectionObj);
						sessionStorage.removeItem('testId');
						break;
					}
				}
			}
		});
	}
	$scope.downloadCSV = function (type) {
		var fileName;
		if (confirm("Please do not edit column names.\n Are you sure want to download")) {
			if (type == "marks") {
				var excelData = getExcelData();
				fileName = "reportCardMarks.xlsx"
			}
			else if (type == "attendance") {
				var excelData = getAttendanceExcelData();
				fileName = "reportCardAttendance.xlsx"
			}
			// Create a worksheet
			var ws = XLSX.utils.aoa_to_sheet(excelData);

			// Create a workbook
			var wb = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, 'Sheet 1');

			// Save the workbook to a file
			XLSX.writeFile(wb, fileName);
		}
		else
			return;
	};

	function getExcelData() {
		// Headers
		var headers = ['Roll No', 'Student Name'];
		var selectedSubjects = $scope.classSubjectsList.filter(function (clssubList) {
			return clssubList.selected == true;
		});

		selectedSubjects.forEach(function (clssubList) {
			headers.push(clssubList.subjectName + "-" + $scope.testTotalMarks);
		});

		// Data rows
		var dataRows = $scope.reportCardStudents.map(function (secStud) {
			var row = [
				secStud.rollNumber,
				secStud.studentName,
			];

			selectedSubjects.forEach(function (clssubList) {
				var subjectId = clssubList.subjectId;
				var marksValue = $scope.getMarks(secStud.studentId, subjectId);
				row.push(marksValue);
			});

			return row;
		});

		// Combine headers and data rows
		var excelData = [headers].concat(dataRows);

		return excelData;
	}

	function getAttendanceExcelData() {
		// Headers
		var headers = ['Roll No', 'Student Name'];
		var selectedMonths = $scope.monthsAttendanceArray.filter(function (selectedMonth) {
			return selectedMonth.totalWorkingDays > 0;
		});
		selectedMonths.forEach(function (month) {
			headers.push(month.monthName + "-" + month.totalWorkingDays);
		});

		// Data rows
		var dataRows = $scope.studentAndAttList.map(function (student) {
			var row = [
				student.rollNumber,
				student.studentName,
			];

			selectedMonths.forEach(function (month) {
				var presentDays = $scope.getStudentPresentDays(student.studentId, month.monthId);
				row.push(presentDays);
			});

			return row;
		});

		// Combine headers and data rows
		var excelData = [headers].concat(dataRows);

		return excelData;
	}


	$scope.getMarks = function (studentId, subjectId) {
		// Find the student in studentArray
		var student = $scope.studentArray.find(function (student) {
			return student.studentId === studentId;
		});

		// Find the subject in the student's subjects array
		var subject = student.subjects.find(function (sub) {
			return sub.subjectId === subjectId;
		});

		// Return marks if found, otherwise return 0
		return subject ? parseFloat(subject.marks) || 0 : 0;
	};



	$scope.uploadExcel = function (element) {
		var file = document.getElementById("fileInput").files[0];
		if (file == undefined) {
			alert("Please choose the file.")
			return;
		}
		if (confirm("Please re-check your data before uploading, any subject miss match leads to error.\n Are you sure want to continue?")) {
			var reader = new FileReader();
			reader.onload = function (e) {
				var data = e.target.result;
				var workbook = XLSX.read(data, { type: 'binary' });
				var sheetName = workbook.SheetNames[0];
				var worksheet = workbook.Sheets[sheetName];

				// Process the uploaded data and update the table
				$scope.processUploadedData(XLSX.utils.sheet_to_json(worksheet, { header: 1 }));
			};

			reader.readAsBinaryString(file);
			alert("Upload Successfull");
		}
		else
			return;

	};

	$scope.processUploadedData = function (excelData) {
		try {
			$rootScope.$apply(function () {
				var subjectList = [];
				$scope.classSubjectsList.forEach(function(sub){
					if(sub.isAssigned == 1)
					   subjectList.push(sub);
				});
				for (var i = 1; i < excelData.length; i++) {
					var rollNumber = excelData[i][0];
					var marksColumnIndex = 2; // Adjust based on your data structure

					for (var j = 0; j < $scope.reportCardStudents.length; j++) {
						if ($scope.reportCardStudents[j].rollNumber === rollNumber) {
							for (var k = 0; k < subjectList.length; k++) {
								var subjectId = subjectList[k].subjectId;
								var marks = parseFloat(excelData[i][marksColumnIndex + k]) || 0;

								// Update marks in $scope.reportCardStudents[j] for the corresponding subject
								$scope.updateMarks($scope.reportCardStudents[j], subjectId, marks);
							}
							break;
						}
					}
				}

				$scope.reportCardStudents = [];

			});
			setTimeout(function () {
				$scope.getStudentsForReportCard();
				$scope.synchronizeStudentOrder();
				var element = angular.element(document.getElementById('myTable'));
				if (element) {
					$compile(element)($rootScope.$new());
					$rootScope.$digest();
				}
			});


		} catch (error) {
			// Handle any exceptions that might occur during $apply
			console.error("Error during $apply:", error);
		}
	};

	$scope.uploadExcelAtt = function (element) {
		var file = document.getElementById("fileInput").files[0];
		if (file == undefined) {
			alert("Please choose the file.")
			return;
		}
		if (confirm("Please re-check your data before uploading, any month miss match leads to error.\n Are you sure want to continue?")) {
			var reader = new FileReader();
			reader.onload = function (e) {
				var data = e.target.result;
				var workbook = XLSX.read(data, { type: 'binary' });
				var sheetName = workbook.SheetNames[0];
				var worksheet = workbook.Sheets[sheetName];

				// Process the uploaded data and update the table
				$scope.processUploadedDataOfAtt(XLSX.utils.sheet_to_json(worksheet, { header: 1 }));
			};

			reader.readAsBinaryString(file);
			alert("Upload Successfull");
		}
		else
			return;

	};

	$scope.processUploadedDataOfAtt = function (excelData) {
		try {
			$scope.$apply(function () {
				for (var i = 1; i < excelData.length; i++) {
					var rollNumber = excelData[i][0];
					var presentDaysColIndex = 2; // Adjust based on your data structure

					for (var j = 0; j < $scope.studentAndAttList.length; j++) {
						if ($scope.studentAndAttList[j].rollNumber === rollNumber) {
							for (var k = 0; k < $scope.monthsAttendanceArray.length; k++) {
								var presentDays = parseFloat(excelData[i][presentDaysColIndex + k]) || 0;
								// Update presentDays
								$scope.updateAtt($scope.studentAndAttList[j], $scope.monthsAttendanceArray[k], presentDays);
							}
							break;
						}
					}
				}
			});
			setTimeout(function () {
				$scope.getStudentsWithAttendanceForReportCard ();
				var element = angular.element(document.getElementById('myTable'));
				if (element) {
					$compile(element)($rootScope.$new());
					$rootScope.$digest();
				}
			});

		} catch (error) {
			console.error("Error during $apply:", error);
		}
	};


	$scope.synchronizeStudentOrder = function () {
		if ($scope.studentArray && $scope.reportCardStudents) {
			$scope.reportCardStudents = $scope.studentArray.map(function (student) {
				var studentInReportCard = $scope.reportCardStudents.find(function (s) {
					return s.studentId === student.studentId;
				});
				return studentInReportCard || {};
			});
		} else {
			console.error("Invalid studentArray, reportCardStudents, or classSubjectsList:", $scope.studentArray, $scope.reportCardStudents, $scope.classSubjectsList);
		}
	};

	$scope.updateMarks = function (student, subjectId, marks) {
		// Update the marks in $scope.studentArray
		if (student && student.studentId) {
			var studentInArray = $scope.studentArray.find(function (s) {
				return s.studentId === student.studentId;
			});

			if (studentInArray) {
				var subjectIndexInArray = studentInArray.subjects.findIndex(function (sub) {
					return sub.subjectId === subjectId;
				});

				if (subjectIndexInArray !== -1) {
					studentInArray.subjects[subjectIndexInArray].marks = marks.toString();
				} else {
					// Subject not found, insert the subject if marks are greater than 0
					if (marks > 0) {
						var newSubject = {
							subjectId: subjectId,
							marks: marks.toString(),
							totalMarks: $scope.testTotalMarks // Set the default total marks value
						};
						studentInArray.subjects.push(newSubject);
					}
				}
			} else {
				// Handle the case where studentInArray is undefined
				console.error("Invalid student object in studentArray:", studentInArray);
			}
		} else {
			// Handle the case where student or student.studentId is undefined
			console.error("Invalid student object in studentArray:", student);
		}
	};

	$scope.updateAtt = function (student, month, presentDays) {
		// Update the marks in $scope.studentArray
		if (student && student.studentId) {
			var studentInArray = $scope.studentAndAttList.find(function (s) {
				return s.studentId === student.studentId;
			});

			if (studentInArray) {
				var presentDaysIndex = studentInArray.months.findIndex(function (mon) {
					return mon.monthId == month.monthId;
				});

				if (presentDaysIndex !== -1) {
					studentInArray.months[presentDaysIndex].presentDays = presentDays;
				} else {
					// Subject not found, insert the subject if marks are greater than 0
					if (presentDays > 0) {
						var newMonth = {
							monthId: monthId,
							presentDays: presentDays.toString(),
							totalWorkingDays: month.totalWorkingDays
						};
						studentInArray.months.push(newMonth);
					}
				}
			} else {
				// Handle the case where studentInArray is undefined
				console.error("Invalid student object in studentArray:", studentInArray);
			}
		} else {
			// Handle the case where student or student.studentId is undefined
			console.error("Invalid student object in studentArray:", student);
		}
	};

	function getTestSubjectId(studentId, subjectId) {
		var student = $scope.studentArray.find(s => s.studentId === studentId);

		if (student) {
			var subject = student.subjects.find(sub => sub.subjectId === subjectId);

			if (subject) {
				return subject.hasOwnProperty("testSubjectId") ? subject.testSubjectId : 0;
			}
			else
				return 0;
		}

		// If student or subject not found, return a default value (you can adjust this based on your requirements)
		return 0;
	}


	function getStudentPresentDayId(studentId, monthId) {
		var student = $scope.studentAndAttList.find(s => s.studentId === studentId);

		if (student) {
			var month = student.months.find(mon => mon.monthId === monthId);

			if (month) {
				return month.hasOwnProperty("studentPresentDayId") ? month.studentPresentDayId : 0;
			}
			else
				return 0;
		}

		// If student or subject not found, return a default value (you can adjust this based on your requirements)
		return 0;
	}


	$scope.saveMarks = function () {
		var result = {
			"schemaName": $scope.schemaName,
			"testId": $scope.selectedTestOb.testId,
			"createdBy": $scope.userId,
			"studentArray": []
		};
		outerLoop:
		angular.forEach($scope.reportCardStudents, function (student) {
			var studentObj = {
				"studentId": student.studentId,
				"subjectArray": []
			};

			angular.forEach($scope.classSubjectsList, function (subject) {
				if (subject.selected) {
					var marksValue = getMarksInput(student.studentId, subject.subjectId);
					var originalValue = getOriginalMarksValue(student.studentId, subject.subjectId);
					if (marksValue > $scope.testTotalMarks) {

						alert("Please enter the marks less than " + $scope.testTotalMarks);
						return outerLoop;

					}
					if (originalValue != marksValue) {
						// If marks are modified, add the subject details to the student's subjectArray
						var subjectObj = {
							"testSubjectId": getTestSubjectId(student.studentId, subject.subjectId),
							"subjectId": subject.subjectId,
							"totalMarks": $scope.testTotalMarks,
							"marks": marksValue
						};

						studentObj.subjectArray.push(subjectObj);
					}
				}
			});

			// If the student has modified subjects, add the student details to the result array
			if (studentObj.subjectArray.length > 0) {
				result.studentArray.push(studentObj);
			}
		});
		if (result.studentArray.length > 0) {
			httpFactory.executePost("updateStudentSubjectTestMarks", result, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getStudentsForReportCard();
					$scope.getSubjectsByCourseClass($scope.selectedCourseOb, $scope.selectedClassObj);
					$scope.getStudentSubjectMarks();
					$scope.synchronizeStudentOrder();
				} else {
					alert(data.MESSAGE);
				}
			});
		}
		else {
			alert("No Changes")
		}
	};

	// Function to get the input field for a specific student and subject using AngularJS ng-model
	function getMarksInput(studentId, subjectId) {
		var inputId = studentId + "_" + subjectId;
		var marksInput = angular.element(document.getElementById(inputId));

		// Check if the input element is found before attempting to get its value
		var marksValue = marksInput.length > 0 ? marksInput.val() : undefined;

		return marksValue;
	}

	function getAttPresentDays(studentId, monthId) {
		var inputId = studentId + "_" + monthId;
		var attPDInput = angular.element(document.getElementById(inputId));

		// Check if the input element is found before attempting to get its value
		var PDValue = attPDInput.length > 0 ? attPDInput.val() : undefined;

		return PDValue;
	}

	function getOriginalMarksValue(studentId, subjectId) {
		var originalStudent = $scope.originalValues.find(item => item.studentId === studentId);

		if (originalStudent) {
			var originalSubject = originalStudent.subjects.find(sub => sub.subjectId === subjectId);

			if (originalSubject) {
				return originalSubject.marks;
			}
			else
				return 0;
		}

		// If the original value is not found, return undefined
		return undefined;
	}

	function getOriginalPresentDays(studentId, monthId) {
		var originalStudent = $scope.originalStudentAttList.find(item => item.studentId === studentId);

		if (originalStudent) {
			var originalMonth = originalStudent.monthArray.find(sub => sub.subjectId === subjectId);

			if (originalMonth) {
				return originalMonth.marks;
			}
			else
				return 0;
		}

		// If the original value is not found, return undefined
		return undefined;
	}

	$scope.saveStudentAttendance = function () {
		var result = {
			"schemaName": $scope.schemaName,
			"createdBy": $scope.userId,
			"studentArray": []
		};
		outerLoop:
		angular.forEach($scope.studentAndAttList, function (student) {
			var studentObj = {
				"studentId": student.studentId,
				"monthsArray": []
			};

			angular.forEach($scope.monthsAttendanceArray, function (month) {
				if (month.totalWorkingDays > 0) {
					var PDValue = getAttPresentDays(student.studentId, month.monthId);
					var originalPDValue = getOriginalPresentDays(student.studentId, month.monthId);
					if (Number(PDValue) > Number(month.totalWorkingDays)) {

						alert("Please enter the present days less than the total working days");
						return outerLoop;

					}
					if (originalPDValue != PDValue) {
						// If marks are modified, add the subject details to the student's subjectArray
						var monthObj = {
							"studentPresentDayId": getStudentPresentDayId(student.studentId, month.monthId),
							"monthId": month.monthId,
							"presentDays": PDValue
						};

						studentObj.monthsArray.push(monthObj);
					}
				}
			});

			// If the student has modified subjects, add the student details to the result array
			if (studentObj.monthsArray.length > 0) {
				result.studentArray.push(studentObj);
			}
		});
		if (result.studentArray.length > 0) {
			httpFactory.executePost("updateStudentRCAttendance", result, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Successfully Updated");
					$scope.getReportCardAttendance();
				} else {
					alert(data.MESSAGE);
				}
			});
		}
		else {
			alert("No Changes")
		}
	};

	function getOriginalPresentDays(studentId, monthId) {
		var originalStudent = $scope.originalStudentAttList.find(item => item.studentId === studentId);

		if (originalStudent) {
			var originalMonth = originalStudent.months.find(sub => sub.monthId === monthId);

			if (originalMonth) {
				return originalMonth.presentDays;
			}
			else
				return 0;
		}

		// If the original value is not found, return undefined
		return undefined;
	}

	$scope.getStudentPresentDays = function (studentId, monthId) {
		// Find the student in studentArray
		var student = $scope.studentAndAttList.find(function (student) {
			return student.studentId === studentId;
		});

		// Find the subject in the student's subjects array
		var month = student.months.find(function (sub) {
			return sub.monthId === monthId;
		});

		// Return marks if found, otherwise return 0
		return month ? parseFloat(month.presentDays) || 0 : 0;
	};

	$scope.selectedStudentsArray = [];

	$scope.selectStudents = function (studentDetail, studentIndex) {
		if (studentDetail == "" || studentDetail == undefined) {
			if (document.getElementById("isAllChecked").checked == true) {
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					if ($scope.reportCardStudents[i].selected == false || $scope.reportCardStudents[i].selected == undefined)
						$scope.reportCardStudents[i].selected = true;
				}
				$scope.selectedStudentsCount = $scope.reportCardStudents.length;
			} else if (document.getElementById("isAllChecked").checked == false) {
				for (i = 0; i < $scope.reportCardStudents.length; i++) {
					if ($scope.reportCardStudents[i].selected == true || $scope.reportCardStudents[i].selected == undefined)
						$scope.reportCardStudents[i].selected = false;
				}
				$scope.selectedStudentsCount = 0;
			}
		} else {
			if ($scope.reportCardStudents[studentIndex].selected == true) {
				$scope.reportCardStudents[studentIndex].selected = false;
				$scope.selectedStudentsCount--;
				document.getElementById("isAllChecked").checked = false;
			} else {
				$scope.reportCardStudents[studentIndex].selected = true;
				$scope.selectedStudentsCount++;
			}
		}
		var countIsSelected = 0;
		for (i = 0; i < $scope.reportCardStudents.length; i++) {
			if ($scope.reportCardStudents[i].selected == true)
				countIsSelected++;
		}
		if (countIsSelected == $scope.reportCardStudents.length)
			$scope.isAllChecked = true;
		else
			$scope.isAllChecked = false;
	}

	$scope.getReportCardDetailsForStudents = function () {
		$scope.getBranchDetailsForRC();
		$scope.getTemplateToUse();
		$scope.getGradesandGradePointsForReportCard();
		var temp = {
			"courseId": sessionStorage.getItem("courseId"),
			"classId": sessionStorage.getItem("classId")
		};
		$scope.getSubjectsByCourseClass(temp, temp);

		$scope.studentAttArray = [];

		$scope.selectStudentList = JSON.parse(sessionStorage.getItem("selectStudentList"));
		// Loop through each student and fetch their report card
		$scope.selectStudentList.forEach(function (student) {
			// Function to get report card for a student
			$scope.getStudentReportCard = function (student) {

				var studentDetails = {};

				studentDetails["studentDetails"] = $scope.getStudentDetailsForReportCard(student);

				var studentRcMarks = [];
				studentRcMarks = $scope.getReportCardTestMarks(student);
				studentDetails["studentRcMarks"] = studentRcMarks;

				var studentReportCardPresentDays = [];
				studentReportCardPresentDays = $scope.getRCPresentAttendance(student);
				studentDetails["studentReportCardPresentDays"] = studentReportCardPresentDays;

				// Calculate total working days and present days
				studentDetails["totalWorkingDays"] = $scope.sum($scope.reportCardPresentDays, 'totalWorkingDays');
				studentDetails["totalPresentDays"] = $scope.sum($scope.reportCardPresentDays, 'presentDays');


				// Add the studentDetails object to studentArray
				$scope.studentAttArray.push(studentDetails);
				// Iterate through the student array
				$scope.studentAttArray.forEach(function (student) {
					// Iterate through each subject
					student.studentRcMarks.forEach(function (subject) {
					if(subject.marks !== undefined){
						// Iterate through each mark
						subject.marks.forEach(function (mark) {
                            // Add 'originalValue' property if not already present
                            if (typeof mark.originalValue === 'undefined') {
                                mark.originalValue = mark.mark;
                            }
						});
						}
					});
				});

			};

			// Call the getStudentReportCard function for each student
			$scope.getStudentReportCard(student);
		});

		$scope.existingStudentAttArray = angular.copy($scope.studentAttArray);
	}
});
