projectModule.controller('matchTheImageController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
$scope=$;
	

	
});
