projectModule.controller('manageStudentsController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");

	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchList = [];
	$scope.selectedCourse = "";
	$scope.selectedBranch = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.getItem("branchName");
	$scope.courseClasses = "";
	$scope.selecteSecforStudent = "";
	$scope.selectedClassCourseId = "";
	$scope.initLoad = function () {
		$scope.getCoursesByBranch();
	}
	$scope.navCourseId = sessionStorage.getItem("navCourseId");
	$scope.navClassId = sessionStorage.getItem("navClassId");
	$scope.navSectionId = sessionStorage.getItem("navSectionId");

	$scope.selectedCourse = $scope.navCourseId;
	$scope.selectedClassId = $scope.navClassId;

	sessionStorage.removeItem("navCourseId");
	sessionStorage.removeItem("navClassId");
	sessionStorage.removeItem("navSectionId");


	$scope.getAllBranches = function () {
		//$scope.courseList = [];
		$scope.courseClasses = [];
		httpFactory.getResult("getAllBranches?instId=" + $scope.instituteId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data.collegeBranches);
			if (data.StatusCode == 200) {
				$scope.branchList = data.collegeBranches;
				console.log($scope.branchList);
			} else {
				console.log("No courses");
			}
		});
	}

	$scope.getCoursesByBranch = function () {
		$scope.selectedCourse = "";
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedClassCourseId = "";
		$scope.showSection = false;
		$scope.allSectionslist = [];
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					$scope.getClassesByCourse($scope.selectedCourseOb);
				}
				console.log($scope.courseList);
				if ($scope.navCourseId) {
					for (var i = 0; i < $scope.courseList.length; i++) {
						if ($scope.courseList[i].courseId == $scope.navCourseId) {
							console.log(JSON.stringify($scope.courseList[i]));
							$scope.selectedCourseOb = JSON.stringify($scope.courseList[i]);
							$scope.selectedCourse = $scope.courseList[i].courseId;
							$scope.getClassesByCourse($scope.courseList[i]);
							break;
						}
					}
				}
			} else {
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function (course) {
		console.log(course);
		if (typeof course == 'string')
			$scope.selCourseObj = JSON.parse(course);
		else
			$scope.selCourseObj = course;

		$scope.selectedCourse = $scope.selCourseObj.courseId;
		$scope.selectedCourseName = $scope.selCourseObj.courseName;
		//$scope.selectedCourse = "";
		$scope.showSection = false;
		$scope.selectedClassCourseId = "";
		$scope.courseClasses = [];
		$scope.allSectionslist = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
				if ($scope.navCourseId) {
					for (var i = 0; i < $scope.courseClasses.length; i++) {
						if ($scope.courseClasses[i].classId == $scope.navClassId) {
							console.log(JSON.stringify($scope.courseClasses[i]));
							$scope.selectedClassObj = JSON.stringify($scope.courseClasses[i]);
							$scope.selectedClassCourseId = $scope.courseClasses[i].classCourseId;
							$scope.getSectionsByClass();
							break;
						}
					}
				}
			} else {
				console.log("No classes found");
			}
		});
	}
	$scope.allSectionslist = new Array();
	$scope.showSection = false;

	$scope.getSectionsByClass = function () {
		if ($scope.selectedBranch == undefined || $scope.selectedBranch == "" || $scope.selectedCourse == undefined || $scope.selectedCourse == "" || $scope.selectedClassCourseId == undefined || $scope.selectedClassCourseId == "") {
			alert("Select All Details");
			return true;
		}
		if ($scope.courseClasses.length > 0) {
			$scope.showSection = true;
		}
		$scope.allSectionslist = [];
		$scope.sectionStudents = [];
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&classCourseId=" + $scope.selectedClassCourseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.allSectionslist = data.Sections;
				console.log($scope.allSectionslist[0]);
				$scope.getSectionStudents($scope.allSectionslist[0]);
			} else {

			}
		});
	}
	$scope.selectedSecId;

	$scope.goToElectiveSubjStu = function () {
		$scope.viewClassCourseSubjList();
		$scope.studentsArrElec = [];
	}
	$scope.getSeleClassId = function (selcls) {
		if (typeof selcls == 'string') {
			var selcls = JSON.parse(selcls);
		}
		$scope.selectedClassCourseId = selcls.classCourseId;
		$scope.selectedClassId = selcls.classId;

		$scope.selectedClassName = selcls.className;
		$scope.viewClsId = selcls.classId;
	}

	$scope.viewClassCourseSubjList = function () {
		httpFactory.getResult("getAllCourseClassSubjects?classId=" + $scope.viewClsId + "&courseId=" + $scope.selectedCourse + "&schemaName=" + localStorage.getItem("sname"), function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.generalSubj = [];
				$scope.electiveSubj = [];
				$scope.subjList = data.Subjects;

				for (var i = 0; i < $scope.subjList.length; i++) {
					if ($scope.subjList[i].electiveGroupId == 0) {
						$scope.generalSubj = $scope.subjList[i].subjects;
					} else {
						$scope.electiveSubj.push($scope.subjList[i]);
					}
				}
				console.log($scope.generalSubj);
				console.log($scope.electiveSubj);

				if ($scope.electiveSubj.length > 0) {
					$("#assignStudents").modal("show");
				} else {
					alert("No Elective Subjects");
				}
			} else {
				alert("No Subject Records");
			}
		});
	}

	$scope.getStudentBySubj = function (subjectId, elecGrpId) {
		$scope.elecSubjId = subjectId;
		$scope.elecGroupId = elecGrpId;
		$scope.isElectiveVal = 1;
		$scope.studentsArrElec = [];
		$scope.getStudents();

	}

	$scope.getStudents = function () {
		httpFactory.getResult("getSectionElectiveStudents?sectionId=" + $scope.selectedSecId + "&electiveGroupId=" + $scope.elecGroupId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentListHW = data.studentElectiveSubArray;
			} else {
				$scope.studentListHW = [];
			}
			console.log($scope.studentListHW);
			console.log($scope.elecSubjId);
			console.log($scope.electiveSubj);
		});
	}

	$scope.hidePopUp = function () {
		$("#addStudents").modal("hide");
	}


	$scope.assignStudentsForSubject = function () {
		var params = {
			"schemaName": $scope.schemaName,
			"subjectId": $scope.elecSubjId,
			"electiveGroupId": $scope.elecGroupId,
			"sectionId": $scope.selectedSecId,
			"branchId": localStorage.getItem("bnchId"),
			"isActive": 1,
			"createdBy": localStorage.getItem("userId"),
			"studentIdRec": $scope.studentsArrElec
		}
		console.log(params);

		httpFactory.executePost("assignElectiveSubjectToStudents", params, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				console.log(data);
				alert("Updated Succesfully");
				$scope.closePopUpHW();
			}
		});
	}
	$scope.closePopUpHW = function () {
		$("#assignStudents").modal("hide");
	}


	$scope.getSectionStudents = function (selectedSec) {
		console.log(selectedSec);
		$scope.selectedSec = selectedSec;
		$scope.selectedSecId = selectedSec.sectionId;
		$scope.sectionName = selectedSec.sectionName;
		$scope.selecteSecforStudent = selectedSec;
		$scope.sectionStudents = [];

		$scope.selectStudentsBySection();

	}
	$scope.selectStudentsBySection = function (selectedSecId) {
		if (selectedSecId != undefined)
			var sectionId = selectedSecId;
		else
			var sectionId = $scope.selectedSecId;
		$scope.maxRollNumber = 0;
		httpFactory.getResult("getStudentsBySection?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&classCourseId=" + $scope.selectedClassCourseId + "&sectionId=" + sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionStudents = data.sectionStudents;
				$scope.maxRollNumber = Math.max.apply(Math, $scope.sectionStudents.map(function (item) { return item.rollNumber; }));
				for (var i = 0; i < $scope.sectionStudents.length; i++) {
					if ($scope.sectionStudents[i].profilePic == 'NA') {
						$scope.sectionStudents[i].profilePicPath = "";
					} else {
						$scope.sectionStudents[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/studentProfileDownload?filePath=" + $scope.sectionStudents[i].profilePic;
					}
				}
				$('#isAllSelected').prop("checked", false);
			} else {
			}

		});

	}



	$scope.getAllClassStudents = function () {
		$scope.selectedSecId = 0;
		$scope.sectionStudents = [];
		$scope.sectionName = "All Students";
		httpFactory.getResult("selectStudentsByClassCourse?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&classCourseId=" + $scope.selectedClassCourseId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionStudents = data.sectionStudents;
			} else {

			}
		});
	}

	$scope.phoneValidation = function(numb) {
		// Check if numb is a string and not empty
		if (typeof numb === 'string' && numb.trim() !== "") {
			// Regular expression to match Indian phone numbers starting with 6, 7, 8, or 9 and having 10 digits
			var phoneRegex = /^[6789][0-9]{9}$/;
			// Test the numb against the regular expression
			return phoneRegex.test(numb);
		}
		else if (numb == undefined || numb == ""){
			return true;
		  }
		  else{
		  // Return false for invalid or empty inputs
				  return false;
		  }
	}

	$scope.aadhaarValidation = function(numb) {
		// Check if numb is a string and not empty
		if (typeof numb === 'string' && numb.trim() !== "") {
			// Regular expression to match Indian phone numbers starting with 6, 7, 8, or 9 and having 10 digits
			var phoneRegex = /^[1-9][0-9]{11}$/;
			// Test the numb against the regular expression
			return phoneRegex.test(numb);
		}
	 else if (numb == undefined || numb == ""){
		return true;
		}
		else{
		// Return false for invalid or empty inputs
        		return false;
		}

	}

	$scope.emailValidation = function (emilId) {
		var myEmailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if (emilId != "" && emilId != undefined) {
			return myEmailFormat.test(emilId);
		}
	}

	$scope.pincodeValidation = function(numb) {
		// Check if numb is a string and not empty
		if (typeof numb === 'string' && numb.trim() !== "") {
			// Regular expression to match Indian phone numbers starting with 6, 7, 8, or 9 and having 10 digits
			var phoneRegex = /^[0-9]{6}$/;
			// Test the numb against the regular expression
			return phoneRegex.test(numb);
		}else if (numb == undefined || numb == ""){
			return true;
		  }
		  else{
		  // Return false for invalid or empty inputs
				  return false;
		  }
	}

	$scope.newsectionName = "";
	$scope.addSection = function () {
		//insertSections
		var reqParams = {
			"schemaName": $scope.schemaName,
			"insertRecords": [{
				"branchId": $scope.selectedBranch,
				"classCourseId": $scope.selectedClassCourseId,
				"sectionName": $scope.newsectionName,
				"createdBy": $scope.user_id
			}]
		};
		httpFactory.executePost("insertSections", reqParams, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$("#addSection").modal("hide");
				$scope.getSectionsByClass();
				$scope.newsectionName = "";
			}
		});
	}

	$scope.sectionDetails = {};

	$scope.selectedSectionForEdit = function (sec) {
		$scope.sectionDetails = sec;
	}

	$scope.updateSectionName = function () {
		var reqParams = {
			"schemaName": $scope.schemaName,
			"branchId": $scope.selectedBranch,
			"classCourseSecId": $scope.sectionDetails.sectionId,
			"sectionName": $scope.sectionDetails.sectionName,
			"updatedBy": $scope.user_id
		};
		httpFactory.executePost("updateSectionRecords", reqParams, function (data) {

			console.log(data);
			if (data.StatusCode == 200) {
				$("#editSection").modal("hide");
				$scope.getSectionsByClass();
				$scope.sectionDetails = {};
			}
		});
	}

	$scope.studentsArr = [];
	$scope.allowAddIngStudent = function () {
		$scope.studentsArr = [];
		$scope.addStudentEmptyObj();
		$scope.getCourseCategories();
		$("#addStudents").modal("show");
	}

	$scope.courseCategoriesList = [];
	$scope.getCourseCategories = function () {

		console.log($scope.selectedCourse);
		httpFactory.getResult("getCourseCategories?schemaName=" + $scope.schemaName + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseCategoriesList = data.Classes;
			} else {

			}
		});
	}
	$scope.studentsArrObj = {};
	$scope.addStudentEmptyObj = function () {
		$scope.studentsArr = [];
		var stuObj = {
			"admissionNumber": "",
			"rollNumber": "",
			"studentName": "",
			"phoneNumber": "",
			"studentEmail": "",
			"gender": "",
			"DOB": "",
			"adharNumber": "",
			"parentName": "",
			"parentContact": "",
			"parentEmail": "",
			"parentAadhar": "",
			"motherName": "",
			"motherContact": "",
			"motherEmail": "",
			"motherAadhar": "",
			"guardianName": "",
			"guardianContact": "",
			"guardianEmail": "",
			"guardianAadhar": "",
			"motherTongue": "",
			"mole": "",
			"childId": "",
			"govtChildId": "",
			"bankAccNo": "",
			"ifscCode": "",
			"bankName": "",
			"religion": "",
			"caste": "",
			"subCaste": "",
			"homeAddress": "",
			"pinCode": "",
			"joiningYear": "",
			"endingYear": "",
			"joinDate": new Date(),
			"courseCategoryId": $scope.selectedCourseCategory,
			"classCourseSectionId": $scope.selecteSecforStudent,
			"branchId": $scope.selectedBranch,
			"classCourseId": $scope.selectedClassCourseId,
			"createdBy": $scope.user_id
		};
		$scope.studentsArr.push(stuObj);
		$scope.studentsArrObj = stuObj;
		var other = {
			"otherReligion": "",
			"otherCaste": ""
		};
		$scope.studentsOther = other;
		console.log($scope.studentsArr);
	}
	$scope.manualAdding;
	$scope.enterStudManually = function () {
		//$scope.studentsArrSucRec = [];
		if ($scope.manualAdding > 0) {
			$scope.studentsArr = [];
			for (var i = 0; i < $scope.manualAdding; i++) {
				var stuObj = {
					"stuDupId": $scope.studentsArr.length,
					"studentName": "",
					"studentEmail": "",
					"phoneNumber": "",
					"rollNumber": "",
					"parentName": "",
					"parentContact": "",
					"parentEmail": "",
					"parentAadhar": "",
					"motherName": "",
					"motherContact": "",
					"motherEmail": "",
					"motherAadhar": "",
					"guardianName": "",
					"guardianContact": "",
					"guardianEmail": "",
					"guardianAadhar": "",
					"motherTongue": "",
					"mole": "",
					"childId": "",
					"govtChildId": "",
					"bankAccNo": "",
					"ifscCode": "",
					"bankName": "",
					"religion": "",
					"caste": "",
					"subCaste": "",
					"courseCategoryId": $scope.selectedCourseCategory,
					"classCourseSectionId": $scope.selectedSecId,
					"branchId": $scope.selectedBranch,
					"classCourseId": $scope.selectedClassCourseId,
					"createdBy": $scope.user_id
				};
				$scope.studentsArr.push(stuObj);

			}

			$("#addStudentsManually").modal("show");
		} else {
			alert("Select No'of students to be Added");
		}
	}
	$scope.editDetails = function () {
		alert("Enter all Details")
	}
	$scope.alphaNumCheck = function (alNum) {
		if (alNum.match(/^[A-Za-z0-9]+$/)) {
			return true;
		} else {
			return false;
		}
	}

	$scope.selectedCourseCategory = "";
	$scope.studentsArrDoopRec = [];
	$scope.studentsArrSucRec = [];
	$scope.stuaddChk = true;

	$scope.addStudents = function () {
		$scope.studentsArr[0] = Object.assign({}, $scope.studentsArrObj);
		if ($scope.selecteSecforStudent == "" || $scope.selectedCourseCategory == "") {
			alert("Select Section and Category");
			return true;
		}
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			//console.log($scope.phoneValidation($scope.studentsArr[i].parentContact) +" - "+ $scope.emailValidation($scope.studentsArr[i].parentEmail) );
			//$scope.studentsArr[i].admissionNumber == "" || $scope.studentsArr[i].rollNumber == ""  || $scope.studentsArr[i].studentName == ""  || $scope.studentsArr[i].gender == "" || $scope.studentsArr[i].DOB == "" ||  $scope.studentsArr[i].parentName == "" || $scope.studentsArr[i].parentContact == "" || $scope.phoneValidation($scope.studentsArr[i].parentContact) == false ||  $scope.studentsArr[i].parentEmail == "" || $scope.emailValidation($scope.studentsArr[i].parentEmail) == false || $scope.studentsArr[i].primaryAddress == "" || $scope.studentsArr[i].pinCode == ""
			if ($scope.studentsArr[i].admissionNumber == "" || $scope.studentsArr[i].studentName == "" || $scope.studentsArr[i].rollNumber == "") {
				alert("Please add mandatory fields");
				return true;
			}
			if ($scope.alphaNumCheck($scope.studentsArr[i].admissionNumber) == false) {
				alert("Add Admission Number with alphabets and numbers only");
				return true;
			}
			if ($scope.alphaNumCheck($scope.studentsArr[i].rollNumber) == false) {
				alert("Add Roll Number with alphabets and numbers only");
				return true;
			}
			if ($scope.studentsArr[i].adharNumber != undefined && $scope.studentsArr[i].adharNumber != "") {
				if ($scope.aadhaarValidation($scope.studentsArr[i].adharNumber) == false) {
					alert("Add aadhaar number with numbers only and length of 12");
					return true;
				}
			}
			if ($scope.studentsArr[i].phoneNumber != undefined && $scope.studentsArr[i].phoneNumber.trim() != "" && $scope.studentsArr[i].phoneNumber.trim() != "NA") {
				if ($scope.phoneValidation($scope.studentsArr[i].phoneNumber) == false) {
					alert("Enter valid student Phone number");
					return true;
				}
			}
			if ($scope.studentsArr[i].studentEmail != undefined && $scope.studentsArr[i].studentEmail.trim() != "" && $scope.studentsArr[i].studentEmail.trim() != "NA") {
				if ($scope.emailValidation($scope.studentsArr[i].studentEmail) == false) {
					alert("Enter valid student Email");
					return true;
				}
			}
			if ($scope.studentsArr[i].pinCode != undefined && $scope.studentsArr[i].pinCode != "" && $scope.pincodeValidation($scope.studentsArr[i].pinCode) == false) {
				alert("Enter valid pincode with numbers only");
				return true;
			}
		}
		for (var j = 0; j < $scope.studentsArr.length; j++) {
			$scope.studentsArr[j].classCourseSectionId = $scope.selecteSecforStudent;
			$scope.studentsArr[j].courseCategoryId = $scope.selectedCourseCategory;
			$scope.studentsArr[j].classCourseId = $scope.selectedClassCourseId;
			$scope.studentsArr[j].branchId = $scope.selectedBranch;
			if ($scope.studentsArr[j].studentName.startsWith(" ")) {
				$scope.studentsArr[j].studentName = $scope.studentsArr[j].studentName.trim();
			}
			if ($scope.studentsArr[j].phoneNumber == "" || $scope.studentsArr[j].phoneNumber == undefined) {
				$scope.studentsArr[j].phoneNumber = "NA";
			}
			if ($scope.studentsArr[j].studentEmail == "" || $scope.studentsArr[j].studentEmail == undefined) {
				$scope.studentsArr[j].studentEmail = "ekalavya.app@gmail.com";
			}
			if ($scope.studentsArr[j].pinCode == "" || $scope.studentsArr[j].pinCode == undefined) {
				$scope.studentsArr[j].pinCode = "123456";
			}
		}

		var reqParams = {
			"schemaName": $scope.schemaName,
			"insertRecords": $scope.studentsArr
		};

		//only do checks if date entered by user
		var dob = $scope.studentsArr[0].DOB;
		if (dob != "" && dob != undefined) {
			var date = new Date($scope.studentsArr[0].DOB);
			var genMon = date.getMonth() + 1;
			if (genMon < 10) {
				genMon = "0" + genMon
			}
			var genDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
			reqParams.insertRecords[0].DOB = genDate;
		}

		var jdate = new Date($scope.studentsArr[0].joinDate);
		var jgenMon = jdate.getMonth() + 1;
		if (jgenMon < 10) {
			jgenMon = "0" + jgenMon
		}
		var jgenDate = jdate.getFullYear() + "-" + jgenMon + "-" + jdate.getDate();

		reqParams.insertRecords[0].joiningDate = jgenDate;
		console.log(reqParams);
		$scope.stuaddChk = false;
		//return true;
		httpFactory.executePost("insertStudentRecords", reqParams, function (data) {
			console.log(data);
			$scope.studentsArrDoopRec = [];
			$scope.studentsArrSucRec = [];
			if (data.StatusCode == "200") {
				if (data.SuccessRecords.length > 0) {
					for (var k = 0; k < data.SuccessRecords.length; k++) {
						$scope.studentsArrSucRec.push(data.SuccessRecords[k]);
					}
				}
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
				}
				$scope.stuaddChk = true;
				$scope.getSectionStudents($scope.selecteSecforStudent);
			} else if (data.StatusCode == "400") {
				alert(data.Message);
				$scope.stuaddChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
					for (l = 0; l < $scope.studentsArrDoopRec.length; l++) {
						if (data.DupAdmNum != undefined) {
							$scope.admNum.push(data.DupAdmNum[l]);
							if (data.DupRollNum != undefined) {
								$scope.rollNum.push(data.DupRollNum[l]);
							}
							if (data.DupChildId != undefined) {
								$scope.childId.push(data.DupChildId[l]);
							}
						} else if (data.DupRollNum == undefined) {
							$scope.rollNum.push(data.DupRollNum[l]);
							if (data.DupChildId != undefined) {
								$scope.childId.push(data.DupChildId[l]);
							}
						} else if (data.DupChildId != undefined) {
							$scope.childId.push(data.DupChildId[l]);
						}
					}
				}
			} else {
				$scope.stuaddChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
				}
			}
			//$scope.saveDoopStudents();
			$("#afterAdding").modal("show");
		});

	}
	$scope.saveStudents = function () {
		var val;
		$scope.admNum = [];
		$scope.rollNum = [];
		$scope.childId = [];
		console.log($scope.studentsArrObj);
		if ($scope.studentsArrObj.caste == "Others") {
			$scope.studentsArrObj.caste = $scope.studentsOther.otherCaste;
		}
		if ($scope.studentsArrObj.religion == "Others") {
			$scope.studentsArrObj.religion = $scope.studentsOther.otherReligion;
		}
		if ($scope.studentsArrObj.userLoginPermitions != undefined) {
			if ($scope.studentsArrObj.userLoginPermitions == "Father") {
				if ($scope.studentsArrObj.parentContact == "") {
					val = confirm("Without " + $scope.studentsArrObj.userLoginPermitions + " contact user cannot be created.\nDo you want to create a user")
					if (val) { $scope.addStudents(); }
				}
				else { $scope.addStudents(); }
			}
			if ($scope.studentsArrObj.userLoginPermitions == "Guardian") {
				if ($scope.studentsArrObj.guardianContact == "") {
					val = confirm("Without " + $scope.studentsArrObj.userLoginPermitions + " contact user cannot be created.\nDo you want to create a user")
					if (val) { $scope.addStudents(); }
				}
				else { $scope.addStudents(); }

			}
			if ($scope.studentsArrObj.userLoginPermitions == "Mother") {
				if ($scope.studentsArrObj.motherContact == "") {
					val = confirm("Without " + $scope.studentsArrObj.userLoginPermitions + " contact user cannot be created.\nDo you want to create a user")
					if (val) { $scope.addStudents(); }
				}
				else { $scope.addStudents(); }

			}
		}
		else { $scope.addStudents(); }

	}

	$scope.closeVerifyPopup = function () {
		$scope.stuaddChk = true;
		$("#afterAdding").modal("hide");
		$("#addStudents").modal("hide");
		$("#addByFile").modal("hide");
	}

	$scope.admissionNoDupChk = function (admissionNo) {
		$scope.studentdup = [];
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			for (var j = i + 1; j < $scope.studentsArr.length; j++) {
				if ($scope.studentsArr[i].admissionNumber == $scope.studentsArr[j].admissionNumber) {
					$scope.studentdup.push($scope.studentsArr[j].admissionNumber);
					if ($scope.studentdup.includes(admissionNo)) {
						$scope.stuaddMultiChk = true;
						return true;
					}
				}
			}
		}
	}
	$scope.childIdNoDupChk = function (childId) {
		$scope.studentdup = [];
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			for (var j = i + 1; j < $scope.studentsArr.length; j++) {
				if ($scope.studentsArr[i].childId == $scope.studentsArr[j].childId) {
					$scope.studentdup.push($scope.studentsArr[j].childId);
					if ($scope.studentdup.includes(childId)) {
						$scope.stuaddMultiChk = true;
						return true;
					}
				}
			}
		}
	}

	$scope.rollNoDupChk = function (rollNo) {
		$scope.studentdup = [];
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			for (var j = i + 1; j < $scope.studentsArr.length; j++) {
				if ($scope.studentsArr[i].rollNumber == $scope.studentsArr[j].rollNumber) {
					$scope.studentdup.push($scope.studentsArr[j].rollNumber);
					if ($scope.studentdup.includes(rollNo)) {
						$scope.stuaddMultiChk = true;
						return true;
					}
				}
			}
		}
	}
	$scope.stuaddMultiChk = true;
	$scope.saveMultipleStudents = function () {
		$scope.stuaddMultiChk = false;
		$scope.admNum = [];
		$scope.rollNum = [];
		$scope.childId = [];
		if ($scope.selecteSecforStudent == "" || $scope.selectedCourseCategory == "") {
			alert("Select Section and Category");
			$scope.stuaddMultiChk = true;
			return true;
		}
		/* for(var i=0; i<$scope.studentsArr.length; i++){
			if($scope.studentsArr[i].studentName == "" || $scope.studentsArr[i].studentName == undefined || $scope.studentsArr[i].rollNumber == "" || $scope.studentsArr[i].rollNumber == undefined|| $scope.phoneValidation($scope.studentsArr[i].phoneNumber) == false || $scope.emailValidation($scope.studentsArr[i].studentEmail) == false || $scope.studentsArr[i].parentName == "" || $scope.studentsArr[i].parentName == undefined || $scope.studentsArr[i].parentContact == undefined || $scope.studentsArr[i].parentContact == "" || $scope.phoneValidation($scope.studentsArr[i].parentContact) == false || $scope.studentsArr[i].parentEmail == undefined || $scope.studentsArr[i].parentEmail == "" ||  $scope.emailValidation($scope.studentsArr[i].parentEmail) == false  ){
				alert("Please add the data correctly");
				return;
			}
		} */
		$scope.errorDetail = "";
		for (var i = 0; i < $scope.studentsArr.length; i++) {
			console.log($scope.phoneValidation($scope.studentsArr[i].parentContact) + " - " + $scope.emailValidation($scope.studentsArr[i].parentEmail));
			if ($scope.studentsArr[i].admissionNumber == "" || $scope.studentsArr[i].rollNumber == "" || $scope.studentsArr[i].studentName == "") {
				alert("Please add the data correctly");
				$scope.stuaddMultiChk = true;
				return true;
			}

			if ($scope.alphaNumCheck($scope.studentsArr[i].admissionNumber) == false || $scope.admissionNoDupChk($scope.studentsArr[i].admissionNumber)) {
				if (!$scope.errorDetail.includes(" Admission Number,")) {
					$scope.errorDetail = $scope.errorDetail + " Admission Number,";
				}
			}
			if ($scope.alphaNumCheck($scope.studentsArr[i].rollNumber) == false || $scope.rollNoDupChk($scope.studentsArr[i].rollNumber)) {
				if (!$scope.errorDetail.includes(" Roll Number")) {
					$scope.errorDetail = $scope.errorDetail + " Roll Number";
				}
			}
			if ($scope.studentsArr[i].adharNumber != undefined && $scope.studentsArr[i].adharNumber != "") {
				if ($scope.aadhaarValidation($scope.studentsArr[i].adharNumber) == false) {
					if (!$scope.errorDetail.includes(" Adhar Number,")) {
						$scope.errorDetail = $scope.errorDetail + " Adhar Number,";
					}
				}
			}
			if ($scope.studentsArr[i].phoneNumber != undefined && $scope.studentsArr[i].phoneNumber.trim() != "" && $scope.studentsArr[i].phoneNumber.trim() != "NA") {
				if ($scope.phoneValidation($scope.studentsArr[i].phoneNumber) == false) {
					if (!$scope.errorDetail.includes(" Student phone number,")) {
						$scope.errorDetail = $scope.errorDetail + " Student phone number,";
					}
				}
			}
			if ($scope.studentsArr[i].studentEmail != undefined && $scope.studentsArr[i].studentEmail.trim() != "" && $scope.studentsArr[i].studentEmail.trim() != "NA") {
				if ($scope.emailValidation($scope.studentsArr[i].studentEmail) == false) {
					if (!$scope.errorDetail.includes(" Student email id,")) {
						$scope.errorDetail = $scope.errorDetail + " Student email id,";
					}
				}
			}
			if ($scope.studentsArr[i].parentContact != undefined && $scope.studentsArr[i].parentContact.trim() != "" && $scope.studentsArr[i].parentContact.trim() != "NA") {
				if ($scope.phoneValidation($scope.studentsArr[i].parentContact) == false) {
					if (!$scope.errorDetail.includes(" Parent Mobile,")) {
						$scope.errorDetail = $scope.errorDetail + " Parent Mobile,";
					}
				}
			}
			if ($scope.studentsArr[i].parentEmail != undefined && $scope.studentsArr[i].parentEmail.trim() != "" && $scope.studentsArr[i].parentEmail.trim() != "NA") {
				if ($scope.emailValidation($scope.studentsArr[i].parentEmail) == false) {
					if (!$scope.errorDetail.includes(" Parent email id,")) {
						$scope.errorDetail = $scope.errorDetail + " Parent email id,";
					}
				}
			}
			if ($scope.pincodeValidation($scope.studentsArr[i].pinCode) == false) {
				if (!$scope.errorDetail.includes(" Pin code,")) {
					$scope.errorDetail = $scope.errorDetail + " Pin code,";
				}
			}
			if ($scope.dateValidation($scope.studentsArr[i].DOB) == false) {
				if (!$scope.errorDetail.includes(" DOB,")) {
					$scope.errorDetail = $scope.errorDetail + " DOB,";
				}
			}
		}
		if ($scope.errorDetail.length > 0) {
			if ($scope.errorDetail.endsWith(",")) {
				$scope.errorDetail = $scope.errorDetail.replace(/,$/, '.');
			}
			alert("We found some error in" + $scope.errorDetail);
			$scope.stuaddMultiChk = true;
			return true;
		}

		console.log($scope.studentsArr);
		for (var j = 0; j < $scope.studentsArr.length; j++) {
			$scope.studentsArr[j].classCourseSectionId = $scope.selecteSecforStudent;
			$scope.studentsArr[j].courseCategoryId = $scope.selectedCourseCategory;
			$scope.studentsArr[j].classCourseId = $scope.selectedClassCourseId;
			$scope.studentsArr[j].branchId = $scope.selectedBranch;
			if ($scope.studentsArr[j].studentName.startsWith(" ")) {
				$scope.studentsArr[j].studentName = $scope.studentsArr[j].studentName.trim();
			}
			if ($scope.studentsArr[j].phoneNumber == "" || $scope.studentsArr[j].phoneNumber == undefined) {
				$scope.studentsArr[j].phoneNumber = "NA";
			}
			if ($scope.studentsArr[j].studentEmail == "" || $scope.studentsArr[j].studentEmail == undefined) {
				$scope.studentsArr[j].studentEmail = "ekalavya.app@gmail.com";
			}
			if ($scope.studentsArr[j].pinCode == "" || $scope.studentsArr[j].pinCode == undefined) {
				$scope.studentsArr[j].pinCode = "123456";
			}

			var jdate = new Date();
			var jgenMon = jdate.getMonth() + 1;
			if (jgenMon < 10) {
				jgenMon = "0" + jgenMon
			}
			var jgenDate = jdate.getFullYear() + "-" + jgenMon + "-" + jdate.getDate();
			$scope.studentsArr[j].joinDate = new Date();
			$scope.studentsArr[j].joiningDate = jgenDate;

		}

		var reqParams = {
			"schemaName": $scope.schemaName,
			"insertRecords": $scope.studentsArr
		};


		console.log(reqParams);

		//return true;
		httpFactory.executePost("insertStudentRecords", reqParams, function (data) {

			console.log(data);

			$("#afterAdding").modal("show");
			$scope.stuaddMultiChk = true;
			$scope.studentsArrDoopRec = [];
			$scope.studentsArrSucRec = [];
			if (data.StatusCode == "200") {
				if (data.SuccessRecords.length > 0) {
					for (var k = 0; k < data.SuccessRecords.length; k++) {
						$scope.studentsArrSucRec.push(data.SuccessRecords[k]);
					}
				}
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
					for (var i = 0; i < $scope.studentsArrDoopRec.length; i++) {
						$scope.studentsArrDoopRec[i];
					}
				}
				$scope.stuaddMultiChk = true;
				$scope.getSectionStudents($scope.selecteSecforStudent);
			} else if (data.StatusCode == "400") {
				alert(data.Message);
				$scope.stuaddMultiChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
					for (l = 0; l < $scope.studentsArrDoopRec.length; l++) {
						if ((data.DupAdmNum == undefined) || (data.DupChildId == undefined)) {
							$scope.rollNum.push(data.DupRollNum[l]);
						} else if ((data.DupRollNum == undefined) || (data.DupChildId == undefined)) {
							$scope.admNum.push(data.DupAdmNum[l]);
						} else if ((data.DupAdmNum == undefined) || (data.DupRollNum == undefined)) {
							$scope.childId.push(data.DupChildId[l]);
						}
						else {
							$scope.admNum.push(data.DupAdmNum[l]);
							$scope.rollNum.push(data.DupRollNum[l]);
							$scope.childId.push(data.DupChildId[l]);
						}
					}
				}
			} else if (data.StatusCode == "300") {
				alert(data.Sql_Message);
				$scope.stuaddMultiChk = true;
				if (data.DuplicateRecords.length > 0)
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
			}
			else {
				$scope.stuaddMultiChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
				}
			}

		});

	}
	$scope.stuaddMultiDoopChk = true;
	$scope.saveDoopStudents = function () {

		/* var stuObj = {
					"stuDupId":$scope.studentsArr.length,
					"studentName":"",
					"studentEmail":"",
					"phoneNumber":"",
					"rollNumber":"",
					"courseCategoryId":$scope.selectedCourseCategory,
					"classCourseSectionId":$scope.selectedSecId,
					"branchId":$scope.selectedBranch,
					"classCourseId":$scope.selectedClass,
					"createdBy":$scope.user_id
				}; */
		$scope.errorDetail = "";
		$scope.admNum = [];
		$scope.rollNum = [];
		for (var i = 0; i < $scope.studentsArrDoopRec.length; i++) {
			console.log($scope.phoneValidation($scope.studentsArrDoopRec[i].parentContact) + " - " + $scope.emailValidation($scope.studentsArrDoopRec[i].parentEmail));
			if ($scope.studentsArrDoopRec[i].admissionNumber == "" || $scope.studentsArrDoopRec[i].rollNumber == "" || $scope.studentsArrDoopRec[i].studentName == "") {
				alert("Please add the data correctly");
				$scope.stuaddMultiChk = true;
				return true;
			}

			if ($scope.alphaNumCheck($scope.studentsArrDoopRec[i].admissionNumber) == false) {
				if (!$scope.errorDetail.includes(" Admission Number,")) {
					$scope.errorDetail = $scope.errorDetail + " Admission Number,";
				}
			}
			if ($scope.alphaNumCheck($scope.studentsArrDoopRec[i].rollNumber) == false) {
				if (!$scope.errorDetail.includes(" Roll Number")) {
					$scope.errorDetail = $scope.errorDetail + " Roll Number";
				}
			}
			if ($scope.studentsArrDoopRec[i].adharNumber != undefined && $scope.studentsArrDoopRec[i].adharNumber != "") {
				if ($scope.aadhaarValidation($scope.studentsArrDoopRec[i].adharNumber) == false) {
					if (!$scope.errorDetail.includes(" Adhar Number,")) {
						$scope.errorDetail = $scope.errorDetail + " Adhar Number,";
					}
				}
			}
			if ($scope.studentsArrDoopRec[i].phoneNumber != undefined && $scope.studentsArrDoopRec[i].phoneNumber.trim() != "" && $scope.studentsArrDoopRec[i].phoneNumber.trim() != "NA") {
				if ($scope.phoneValidation($scope.studentsArrDoopRec[i].phoneNumber) == false) {
					if (!$scope.errorDetail.includes(" Student phone number,")) {
						$scope.errorDetail = $scope.errorDetail + " Student phone number,";
					}
				}
			}
			if ($scope.studentsArrDoopRec[i].studentEmail != undefined && $scope.studentsArrDoopRec[i].studentEmail.trim() != "" && $scope.studentsArrDoopRec[i].studentEmail.trim() != "NA") {
				if ($scope.emailValidation($scope.studentsArrDoopRec[i].studentEmail) == false) {
					if (!$scope.errorDetail.includes(" Student email id,")) {
						$scope.errorDetail = $scope.errorDetail + " Student email id,";
					}
				}
			}
			if ($scope.studentsArrDoopRec[i].parentContact != undefined && $scope.studentsArrDoopRec[i].parentContact.trim() != "" && $scope.studentsArrDoopRec[i].parentContact.trim() != "NA") {
				if ($scope.phoneValidation($scope.studentsArrDoopRec[i].parentContact) == false) {
					if (!$scope.errorDetail.includes(" Parent Mobile,")) {
						$scope.errorDetail = $scope.errorDetail + " Parent Mobile,";
					}
				}
			}
			if ($scope.studentsArrDoopRec[i].parentEmail != undefined && $scope.studentsArrDoopRec[i].parentEmail.trim() != "" && $scope.studentsArrDoopRec[i].parentEmail.trim() != "NA") {
				if ($scope.emailValidation($scope.studentsArrDoopRec[i].parentEmail) == false) {
					if (!$scope.errorDetail.includes(" Parent email id,")) {
						$scope.errorDetail = $scope.errorDetail + " Parent email id,";
					}
				}
			}
			if ($scope.pincodeValidation($scope.studentsArrDoopRec[i].pinCode) == false) {
				if (!$scope.errorDetail.includes(" Pin code,")) {
					$scope.errorDetail = $scope.errorDetail + " Pin code,";
				}
			}
			if ($scope.dateValidation($scope.studentsArrDoopRec[i].DOB) == false) {
				if (!$scope.errorDetail.includes(" DOB,")) {
					$scope.errorDetail = $scope.errorDetail + " DOB,";
				}
			}
		}
		if ($scope.errorDetail.length > 0) {
			if ($scope.errorDetail.endsWith(",")) {
				$scope.errorDetail = $scope.errorDetail.replace(/,$/, '.');
			}
			alert("We found some error in" + $scope.errorDetail);
			$scope.stuaddMultiChk = true;
			return true;
		}
		for (var i = 0; i < $scope.studentsArrDoopRec.length; i++) {
			$scope.studentsArrDoopRec[i].classCourseSectionId = $scope.selecteSecforStudent;
			$scope.studentsArrDoopRec[i].courseCategoryId = $scope.selectedCourseCategory;
			$scope.studentsArrDoopRec[i].classCourseId = $scope.selectedClassCourseId;
			$scope.studentsArrDoopRec[i].branchId = $scope.selectedBranch;
			$scope.studentsArrDoopRec[i].createdBy = $scope.user_id;
			if ($scope.studentsArrDoopRec[i].admissionNumber == "" || $scope.studentsArrDoopRec[i].admissionNumber == undefined || $scope.studentsArrDoopRec[i].studentName == "" || $scope.studentsArrDoopRec[i].studentName == undefined || $scope.studentsArrDoopRec[i].rollNumber == "" || $scope.studentsArrDoopRec[i].rollNumber == undefined) {
				alert("Please fill the mandatory fields");
				return true;
			}
		}
		for (var j = 0; j < $scope.studentsArrDoopRec.length; j++) {
			$scope.studentsArrDoopRec[j].classCourseSectionId = $scope.selecteSecforStudent;
			$scope.studentsArrDoopRec[j].courseCategoryId = $scope.selectedCourseCategory;
			$scope.studentsArrDoopRec[j].classCourseId = $scope.selectedClassCourseId;
			$scope.studentsArrDoopRec[j].branchId = $scope.selectedBranch;
			if ($scope.studentsArrDoopRec[j].studentName.startsWith(" ")) {
				$scope.studentsArrDoopRec[j].studentName = $scope.studentsArrDoopRec[j].studentName.trim();
			}
			if ($scope.studentsArrDoopRec[j].phoneNumber == "" || $scope.studentsArrDoopRec[j].phoneNumber == undefined) {
				$scope.studentsArrDoopRec[j].phoneNumber = "NA";
			}
			if ($scope.studentsArrDoopRec[j].studentEmail == "" || $scope.studentsArrDoopRec[j].studentEmail == undefined) {
				$scope.studentsArrDoopRec[j].studentEmail = "ekalavya.app@gmail.com";
			}
			if ($scope.studentsArrDoopRec[j].pinCode == "" || $scope.studentsArrDoopRec[j].pinCode == undefined) {
				$scope.studentsArrDoopRec[j].pinCode = "123456";
			}
			var jdate = new Date();
			var jgenMon = jdate.getMonth() + 1;
			if (jgenMon < 10) {
				jgenMon = "0" + jgenMon
			}
			var jgenDate = jdate.getFullYear() + "-" + jgenMon + "-" + jdate.getDate();
			$scope.studentsArr[j].joinDate = new Date();
			$scope.studentsArrDoopRec[j].joiningDate = jgenDate;
		}
		var reqParams = {
			"schemaName": $scope.schemaName,
			"insertRecords": $scope.studentsArrDoopRec
		};
		console.log(reqParams);
		$scope.stuaddMultiDoopChk = false;
		httpFactory.executePost("insertStudentRecords", reqParams, function (data) {
			console.log(data);
			$scope.studentsArrDoopRec = [];
			if (data.StatusCode == "200") {
				if (data.SuccessRecords.length > 0) {
					for (var k = 0; k < data.SuccessRecords.length; k++) {
						$scope.studentsArrSucRec.push(data.SuccessRecords[k]);
					}
				}
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
				}
				$scope.stuaddMultiDoopChk = true;
				$scope.getSectionStudents($scope.selecteSecforStudent);
			} else if (data.StatusCode == "400") {
				alert(data.Message);
				$scope.stuaddMultiDoopChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
					for (l = 0; l < $scope.studentsArrDoopRec.length; l++) {
						if (data.DupAdmNum == undefined) {
							$scope.rollNum.push(data.DupRollNum[l]);
						} else if (data.DupRollNum == undefined) {
							$scope.admNum.push(data.DupAdmNum[l]);
						} else {
							$scope.admNum.push(data.DupAdmNum[l]);
							$scope.rollNum.push(data.DupRollNum[l]);
						}
					}
				}
			} else if (data.StatusCode == "300") {
				alert(data.Sql_Message);
				$scope.stuaddMultiChk = true;
				if (data.DuplicateRecords.length > 0)
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
			}
			else {
				$scope.stuaddMultiDoopChk = true;
				if (data.DuplicateRecords.length > 0) {
					$scope.studentsArrDoopRec = data.DuplicateRecords.slice(0);
				}
			}
		});
	}


	$scope.studentList = [];
	$scope.uploadStudents = function () {
		$scope.studentsArrSucRec = [];
		var files = document.getElementById("choosenFile").files;
		if (files[0] == undefined) {
			return;
		}
		//console.log(document.getElementById("choosenFile"));
		console.log(files);
		var fd = new FormData();
		fd.append("file", files[0]);
		$scope.studentList = [];
		httpFactory.executeFileUpload("uploadStudents", fd, function (data) {
			console.log(data);
			if (data.length > 0) {
				$scope.studentsArr = [];
				$scope.studentList = data.slice(0);
				for (var i = 0; i < $scope.studentList.length; i++) {
					if ($scope.studentList[i].admissionNumber == 'NA' && $scope.studentList[i].rollNumber == 'NA' && $scope.studentList[i].studentName == 'NA') {
						$scope.studentList.splice(i, 1);
						i--;
					} else {
						if ($scope.studentList[i].admissionNumber != undefined && $scope.studentList[i].studentName != undefined) {
							if ($scope.studentList[i].gender != undefined && $scope.studentList[i].gender != "") {
								if ($scope.studentList[i].gender.trim() == "Male" || $scope.studentList[i].gender == "m" || $scope.studentList[i].gender == "male") {
									$scope.studentList[i].gender = "M";
								}
								if ($scope.studentList[i].gender == "Female" || $scope.studentList[i].gender == "f" || $scope.studentList[i].gender == "female") {
									$scope.studentList[i].gender = "F";
								}
							}
							var stuObj = {
								"stuDupId": $scope.studentsArr.length,
								"admissionNumber": $scope.studentList[i].admissionNumber,
								"studentName": $scope.studentList[i].studentName,
								"studentEmail": $scope.studentList[i].emailId,
								"phoneNumber": $scope.studentList[i].phoneNumber,
								"rollNumber": $scope.studentList[i].rollNumber,
								"gender": $scope.studentList[i].gender,
								"DOB": $scope.ExcelDateToJSDate($scope.studentList[i].DOB),
								"adharNumber": $scope.studentList[i].aadharNumber,
								"parentName": $scope.studentList[i].parentName,
								"parentContact": $scope.studentList[i].parentContact,
								"parentEmail": $scope.studentList[i].parentEmail,
								"parentAadhar": $scope.studentList[i].parentAadhar,
								"motherName": $scope.studentList[i].motherName,
								"motherContact": $scope.studentList[i].motherContact,
								"motherEmail": $scope.studentList[i].motherEmail,
								"motherAadhar": $scope.studentList[i].motherAadhar,
								"guardianName": $scope.studentList[i].guardianName,
								"guardianContact": $scope.studentList[i].guardianContact,
								"guardianEmail": $scope.studentList[i].guardianEmail,
								"guardianAadhar": $scope.studentList[i].guardianAadhar,
								"childId": $scope.studentList[i].childId,
								"govtChildId": $scope.studentList[i].govtChildId,
								"bankAccNo": $scope.studentList[i].bankAccNo,
								"mole": $scope.studentList[i].mole,
								"motherTongue": $scope.studentList[i].motherTongue,
								"ifscCode": $scope.studentList[i].ifscCode,
								"bankName": $scope.studentList[i].bankName,
								"userLoginPermitions": $scope.studentList[i].userLoginPermitions,
								"religion": $scope.studentList[i].religion,
								"caste": $scope.studentList[i].caste,
								"subCaste": $scope.studentList[i].subCaste,
								"joiningClassWithAcademicYear": $scope.studentList[i].joiningClassWithAcademicYear,
								"endingClassWithAcademicYear": $scope.studentList[i].endingClassWithAcademicYear,
								"homeAddress": $scope.studentList[i].primaryAddress,
								"pinCode": $scope.studentList[i].pincode,
								"courseCategoryId": $scope.selectedCourseCategory,
								"classCourseSectionId": $scope.selecteSecforStudent,
								"branchId": $scope.selectedBranch,
								"classCourseId": $scope.selectedClassCourseId,
								"createdBy": $scope.user_id
							};
							$scope.studentsArr.push(stuObj);
						}
					}
				}
				console.log($scope.studentsArr);
				$("#addByFile").modal("show");

			} else {
				alert('Please select a valid XLS file');
			}
		});
	}
	$scope.dateValidation = function (numb) {
		if (numb != undefined && numb != "") {
			if (numb.match(/^\d{4}\-(0?[1-9]|1[012])\-(0?[1-9]|[12][0-9]|3[01])$/)) {
				return true;
			} else {
				return false;
			}
		}
	}

	$scope.ExcelDateToJSDate = function (serialDate) {
		if (serialDate != undefined && serialDate != "") {
			var utc_days = Math.floor(serialDate - 25569);
			var utc_value = utc_days * 86400;
			var date_info = new Date(utc_value * 1000);
			month = '' + (date_info.getMonth() + 1),
				day = '' + date_info.getDate(),
				year = '' + date_info.getFullYear();
			if (month.length < 2)
				month = '0' + month;
			if (day.length < 2)
				day = '0' + day;
			return [year, month, day].join('-');
		}
	}

	$scope.studentsArr = [];
	$scope.studentsArrElec = [];
	$scope.studentSelected = function (studentStatus) {
		console.log(studentStatus);
		if ($scope.studentsArrElec.includes(studentStatus.studentId)) {
			const index = $scope.studentsArrElec.indexOf(studentStatus);
			if (index !== -1) {
				$scope.studentsArrElec.splice(index, 1);
			}
		} else {
			$scope.studentsArrElec.push(studentStatus);
		}
		console.log($scope.studentsArrElec);
	}

	$scope.goToProfile = function (student) {
		console.log(student);
		$scope.studentId = student.studentId;
		sessionStorage.setItem("navCourseId", $scope.selectedCourse);
		sessionStorage.setItem("navClassId", $scope.selectedClassId);
		$location.path("studentDetails/" + student.studentId);

		// $scope.studentDetailsById();
		// $scope.getStudentOverallAttendance();
		// $scope.getStudentOverallHWForAnalysis();
		// $scope.getStudentTestCountForAnalysis();
		// $("#studentProfileModal").modal("show");
	}
	$scope.closePopUp = function () {
		$("#studentProfileModal").modal("hide");
	}
	// student profile service callings

	$scope.studentDetailsById = function () {
		httpFactory.getResult("studentDetailsById?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentProfileData = data;
			} else {
				// alert(data.MESSAGE);
			}
		});
	}
	$scope.getStudentOverallAttendance = function () {
		$scope.studentAttendance = [];
		httpFactory.getResult("getStudentOverallAttendance?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentAttendance = data;
				$scope.stuAtt = (($scope.studentAttendance.wokingDays - $scope.studentAttendance.studentLeaves) / $scope.studentAttendance.wokingDays) * 100;
				// alert($scope.stuAtt);
			} else {
				// alert(data.MESSAGE);
				$scope.studentAttendance = [];
			}
		});
	}
	$scope.getStudentOverallHWForAnalysis = function () {
		$scope.studentHomeWorks = [];
		httpFactory.getResult("getStudentOverallHWForAnalysis?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentHomeWorks = data;
				console.log($scope.studentHomeWorks);
			} else {
				// alert(data.MESSAGE);
				$scope.studentHomeWorks = [];
				var obj = {
					"completedHW": 0,
					"pendingHW": 0,
					"totalHW": 0
				}
				$scope.studentHomeWorks = obj;
			}
		});
	}

	$scope.getStudentTestCountForAnalysis = function () {
		httpFactory.getResult("getStudentTestCountForAnalysis?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentTests = data;
			} else {
				// alert(data.MsESSAGE);
				$scope.studentTests = [];
				var obj = {
					"testCompleted": 0
				}
				$scope.studentTests = obj;
			}
		});
	}
	$scope.getStudentsForElectiveSubjects = function () {
		httpFactory.getResult("getStudentsForHomeworkBySubject?sectionId=" + $scope.selectedSection + "&branchId=" + $scope.branchId + "&isElective=" + $scope.isElectiveVal + "&subjectId=" + $scope.selectedSubjId + "&schemaName=" + $scope.schemaName, function (data) {
			if (data.StatusCode == 200) {
				$scope.studentListHW = data.studentHomeWork;

				for (var i = 0; i < $scope.studentListHW.length; i++) {
					$scope.studentListHW[i]["checked"] = "0";
				}
				console.log($scope.studentListHW);
			} else {
				$scope.studentListHW = [];
				alert("No students for elective");
			}
		});
	}

	$scope.studentPicSel = function (path) {
		$scope.profPicPath = path;
	}


	$scope.deleteStudentModal = function (sectionStudents) {
		$scope.selectedStudentList = [];
		for (var i = 0; i < sectionStudents.length; i++) {
			if (document.getElementsByName('selectedStudents')[i].checked == true) {
				$scope.selectedStudentList.push(JSON.parse(document.getElementsByName('selectedStudents')[i].value));
			}
		}
		if ($scope.selectedStudentList.length)
			$("#deleteStudent").modal("show");
		else
			alert("Select Student");
	}

	$scope.deleteStudent = function () {
		$scope.studentList = [];
		for (var i = 0; i < $scope.selectedStudentList.length; i++) {
			$scope.studentList.push($scope.selectedStudentList[i].studentId);
		}
		var parms = {
			"studentList": $scope.studentList,
			"userId": $scope.user_id,
			"schemaName": $scope.schemaName
		}

		httpFactory.executePost("deleteStudent", parms, function (data) {
			console.log(data);
			if (data.StatusCode == 200 || data.StatusCode == 205) {
				alert(data.MESSAGE);
				$("#deleteStudent").modal("hide");
				$scope.getSectionStudents($scope.selectedSec);
			} else {
				alert(data.MESSAGE);
			}
		});
	}

	$scope.enableStudent = function (student) {
		$scope.updateStudentStatus(1, student.studentId);
	}

	$scope.disableStudent = function (student) {
		$scope.updateStudentStatus(0, student.studentId);
	}

	$scope.updateStudentDetails = function (studentProfileData) {
		alert(studentProfileData);
	}

	$scope.updateSelectedStudentList = function (sectionStudents) {
		var count = 0;
		for (var i = 0; i < sectionStudents.length; i++) {
			if (document.getElementsByName('selectedStudents')[i].checked == true) {
				count++;
			}
		}
		if (count == sectionStudents.length) {
			$('#isAllSelected').prop("checked", true);
		} else {
			$('#isAllSelected').prop("checked", false);
		}
	}
	$scope.selectAllStudents = function (sectionStudents) {
		$("#deleteAll").modal("show");
		if (document.getElementById('isAllSelected').checked == true) {
			for (j = 0; j < sectionStudents.length; j++) {
				document.getElementsByName('selectedStudents')[j].checked = true;
			}
		} else {
			for (j = 0; j < sectionStudents.length; j++) {
				document.getElementsByName('selectedStudents')[j].checked = false;
			}

		}
	}
	$scope.selectedStudentList = [];
	$scope.studentSectionSms = function (sectionStudents) {
		$("#main-test").modal("show");
	}

	$scope.getTemplateDetails = function () {
		httpFactory.getResult("getTemplateDetails?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			//console.log(data);
			if (data.StatusCode == '200') {
				$scope.templateList = data.templateDetails;
			}
		});
	}

	$scope.smsTypeSelect = function (value) {
		if (value == 'customSMS') {
			$scope.getTemplateDetails();
		}
	}

	$scope.selectedTemplt = undefined;
	$scope.selectedTemplate = function (tmplt) {
		if (typeof tmplt == 'string') {
			$scope.selectedTemplt = JSON.parse(tmplt);
		} else {
			$scope.selectedTemplt = tmplt;
		}
		document.getElementById("tmsg").value = $scope.selectedTemplt.smsTemplateMsg;
	}

	$scope.createLoginMsg = function (sectionStudents) {
		var sendxel = {
			messages: [],
			schemaName: localStorage.getItem("sname"),
			//				templateId : "1507165398237140632",
			//templateId : "1207161596251733453",
			templateId: "1507165496936767644",
			branchId: $scope.selectedBranch
		}
		for (i = 0; i < $scope.selectedStudentList.length; i++) {
			$scope.selectedContacts = "";
			if ($scope.selectedStudentList[i].parentContact != null && $scope.selectedStudentList[i].parentContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].parentContact;
			} else if ($scope.selectedStudentList[i].motherContact != null && $scope.selectedStudentList[i].motherContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].motherContact;
			} else if ($scope.selectedStudentList[i].guardianContact != null && $scope.selectedStudentList[i].guardianContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].guardianContact;
			} else {
				if ($scope.selectedStudentList[i].phoneNumber != null && $scope.selectedStudentList[i].phoneNumber.length == 10) {
					$scope.selectedContacts = $scope.selectedStudentList[i].phoneNumber;
				}
			}
			//			if($scope.selectedContacts != null || $scope.selectedContacts != ""){
			//				var tmpmsg = "Dear "+ $scope.selectedStudentList[i].studentName + " ,Greetings from " + $scope.branchName + ". Your login credintials are given below. " + "\nApp Link : https://bit.ly/3zqMTjQ " + "\nUser Id: " + $scope.selectedStudentList[i].LoginName  + "\nPassword: " + $scope.selectedStudentList[i].LoginName + "\nPlease Contact Ekalavya : 9573859884 for queries " + "\nPowered By EkaLavya.";
			//				sendxel.messages.push({
			//					"numbers":"+91" + $scope.selectedContacts,
			//					"message":tmpmsg
			//				})
			//			}
			/*if($scope.selectedStudentList[i].phoneNumber.length == 10){
				var tmpmsg = "Dear "+$scope.selectedStudentList[i].studentName +" EkaLavya is offering your login credentials. To avail the services, please contact ekalavya.online at User Id:"+$scope.selectedStudentList[i].LoginName+"  Password:"+$scope.selectedStudentList[i].LoginName;
				sendxel.messages.push({
					"numbers":"+91" + $scope.selectedContacts,
					"message":tmpmsg
				})
			}*/
			if ($scope.selectedStudentList[i].phoneNumber.length == 10) {
				var tmpmsg = "OTP to login to mobile app is ID&Pswd: " + $scope.selectedStudentList[i].LoginName + "\r\n"
					+ "Fourth Rev Edu Pvt Ltd";
				sendxel.messages.push({
					"numbers": "+91" + $scope.selectedContacts,
					"message": tmpmsg
				})
			}
		}
		httpFactory.executePost("sendSMSFromExcel", sendxel, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("SMS Sent Successfully");
				for (j = 0; j < sectionStudents.length; j++) {
					document.getElementsByName('selectedStudents')[j].checked = false;
				}
				document.getElementById('isAllSelected').checked = false;
				$scope.selectedStudentList = [];
				$("#main-test").modal("hide");
			} else {
				alert("Something went wrong");
				return;
			}

		});
	}

	$scope.sendWhatsAppMessage = function (sectionStudents, langFlag) {
		var params = {
			numberMessageArray: [],
			schemaName: localStorage.getItem("sname"),
			branchId: $scope.selectedBranch,
			lang: langFlag
		}
		for (var i = 0; i < $scope.selectedStudentList.length; i++) {
			var stu = $scope.selectedStudentList[i];
			var num = stu.parentContact || stu.phoneNumber || stu.motherContact || stu.guardianContact;
			if (num && num.length === 10) {
				params.numberMessageArray.push({
					"number": num,
					"messageValues": [$scope.branchName, stu.studentName, stu.LoginName]
				});
			}
		}
		if (params.numberMessageArray.length > 0) {
			httpFactory.executePost("sendWhatsAppMessage", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Whatsapp Message Sent Successfully");
					for (j = 0; j < sectionStudents.length; j++) {
						document.getElementsByName('selectedStudents')[j].checked = false;
					}
					document.getElementById('isAllSelected').checked = false;
					$scope.selectedStudentList = [];
					$("#main-test").modal("hide");
				} else {
					alert("Something went wrong");
					return;
				}

			});
		}
		else {
			alert("No numbers to send");
		}
	}

	$scope.createCustomMsg = function (sectionStudents) {
		var sendxel = {
			messages: [],
			schemaName: localStorage.getItem("sname"),
			//				templateId : "1507165398237140632",
			templateId: "1207161596251733453",
			branchId: $scope.selectedBranch
		}
		for (var i = 0; i < $scope.selectedStudentList.length; i++) {
			$scope.selectedContacts = "";
			if ($scope.selectedStudentList[i].parentContact != null && $scope.selectedStudentList[i].parentContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].parentContact;
			} else if ($scope.selectedStudentList[i].motherContact != null && $scope.selectedStudentList[i].motherContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].motherContact;
			} else if ($scope.selectedStudentList[i].guardianContact != null && $scope.selectedStudentList[i].guardianContact.length == 10) {
				$scope.selectedContacts = $scope.selectedStudentList[i].guardianContact;
			} else {
				if ($scope.selectedStudentList[i].phoneNumber != null && $scope.selectedStudentList[i].phoneNumber.length == 10) {
					$scope.selectedContacts = $scope.selectedStudentList[i].phoneNumber;
				}
			}
			if ($scope.selectedContacts != null || $scope.selectedContacts != "") {
				var tmpmsg = document.getElementById("tmsg").value;
				sendxel.messages.push({
					"numbers": "+91" + $scope.selectedContacts,
					"message": tmpmsg
				})
			}
		}

		httpFactory.executePost("sendSMSFromExcel", sendxel, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("SMS Sent Successfully");
				for (j = 0; j < sectionStudents.length; j++) {
					document.getElementsByName('selectedStudents')[j].checked = false;
				}
				document.getElementById('isAllSelected').checked = false;
				$scope.selectedStudentList = [];
				$("#main-test").modal("hide");
			} else {
				alert("Something went wrong");
				return;
			}

		});
	}

	$scope.sendSMS = function (value, sectionStudents) {
		$scope.selectedStudentList = [];
		for (var i = 0; i < sectionStudents.length; i++) {
			if (document.getElementsByName('selectedStudents')[i].checked == true) {
				$scope.selectedStudentList.push(JSON.parse(document.getElementsByName('selectedStudents')[i].value));
			}
		}
		if ($scope.selectedStudentList.length > 0) {
			if (value == 'loginSMS') {
				$scope.createLoginMsg(sectionStudents);
			}
			else if (value == 'customSMS') {
				$scope.createCustomMsg(sectionStudents);
			}
			else if (value == 'whatsAppE') {
				$scope.sendWhatsAppMessage(sectionStudents, "en");
			} else if (value == 'whatsAppT') {
				$scope.sendWhatsAppMessage(sectionStudents, "te");
			} else if (value == 'whatsAppH') {
				$scope.sendWhatsAppMessage(sectionStudents, "hi");
			}
			/*else if(value == 'excelSMS'){
					$scope.uploadTemplates();
				}*/
		} else {
			alert("Please Select Students");
		}

	}

	$scope.promoteStudentsView = function (sectionStudents) {
		$("#promote-stu").modal("show");
	}

	$scope.studentDetails = function (sectionStudents) {
		$("#bulkupdate-stu").modal("show");
	}

	$scope.promoteClassSelect = function (promoteClass) {
		var sccid = JSON.parse(promoteClass);
		$scope.getSectionsByClassInPromote(sccid.classCourseId);
	}

	$scope.promoteStudents = function (sectionStudents, pSec) {
		$scope.selectedStudentList = [];
		for (var i = 0; i < sectionStudents.length; i++) {
			if (document.getElementsByName('selectedStudents')[i].checked == true) {
				$scope.selectedStudentList.push(JSON.parse(document.getElementsByName('selectedStudents')[i].value));
			}
		}
		if ($scope.selectedStudentList.length > 0) {

		}
		promoteSec = JSON.parse(pSec);
		var params = {
			"schemaName": $scope.schemaName,
			"stuList": $scope.selectedStudentList,
			"classCourseId": promoteSec.classCourseId,
			"sectionId": promoteSec.sectionId,
			"branchId": $scope.selectedBranch,
			"userId": $scope.user_id
		}
		httpFactory.executePost("promoteStudents", params, function (data) {
			//console.log(data);
			if (data.StatusCode == 200) {
				alert("Promote Successfully");
				$scope.getSectionsByClass();
				$scope.closePromoteModal();
			} else {
				alert("Something went wrong");
			}

		});
	}

	$scope.closePromoteModal = function () {
		$("#promote-stu").modal("hide");
		document.getElementById('class2').selectedIndex = 0;
		document.getElementById('sec2').selectedIndex = 0;
	}

	$scope.getSectionsByClassInPromote = function (sccid) {
		$scope.allPromoteSectionslist = [];
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&classCourseId=" + sccid, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.allPromoteSectionslist = data.Sections;
			} else {

			}
		});
	}

	$scope.updateStudentStatus = function (isActive, studentId) {
		var studentIds = [];
		if (studentId == undefined) {
			$scope.selectedStudentList = [];
			for (var i = 0; i < $scope.sectionStudents.length; i++) {
				if (document.getElementsByName('selectedStudents')[i].checked == true) {
					$scope.selectedStudentList.push(JSON.parse(document.getElementsByName('selectedStudents')[i].value));
				}
			}

			for (var i = 0; i < $scope.selectedStudentList.length; i++) {
				if (isActive == 1) {
					if ($scope.selectedStudentList[i].isActive == 0) {
						studentIds.push($scope.selectedStudentList[i].studentId);
					}
				} else {
					if ($scope.selectedStudentList[i].isActive == 1) {
						studentIds.push($scope.selectedStudentList[i].studentId);
					}
				}
			}

			var parms = {
				"studentList": studentIds,
				"userId": localStorage.getItem("userId"),
				"schemaName": $scope.schemaName,
				"isActive": isActive
			}
		}
		else {
			studentIds.push(studentId);
			var parms = {
				"studentList": studentIds,
				"userId": localStorage.getItem("userId"),
				"schemaName": $scope.schemaName,
				"isActive": isActive
			}
		}
		if (studentIds.length > 0) {
			httpFactory.executePost("updateStudentStatus", parms, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert(data.MESSAGE);
					$scope.getSectionStudents($scope.selectedSec);
					for (j = 0; j < sectionStudents.length; j++) {
						document.getElementsByName('selectedStudents')[j].checked = false;
					}
					document.getElementById('isAllSelected').checked = false;
				} else {
					alert(data.MESSAGE);

				}
			});
		}
		else {
			alert("Nothing to update");
		}
	}
	$scope.selectAllFun = function () {
		var a = document.getElementById('select');
		var option = a.options[a.selectedIndex].value;
		if (option == "sendSMS") {
			$scope.studentSectionSms($scope.sectionStudents);
		} else if (option == "promote") {
			$scope.promoteStudentsView($scope.sectionStudents);
		} else if (option == "delete") {
			$scope.deleteStudentModal($scope.sectionStudents);
		} else if (option == "disable") {
			$scope.updateStudentStatus(0);
		} else if (option == "enable") {
			$scope.updateStudentStatus(1);
		} else if (option == "bulkEdit") {
			$scope.selectedStudentList = [];
			for (var i = 0; i < $scope.sectionStudents.length; i++) {
				if (document.getElementsByName('selectedStudents')[i].checked == true) {
					$scope.selectedStudentList.push(JSON.parse(document.getElementsByName('selectedStudents')[i].value));
				}
			}
			sessionStorage.setItem("selectedStudentList", JSON.stringify($scope.selectedStudentList));
			sessionStorage.setItem('selectedCourse', $scope.selectedCourse);
			sessionStorage.setItem('selectedClassCourseId', $scope.selectedClassCourseId);
			sessionStorage.setItem('selectedClassObj', $scope.selectedClassObj);
			sessionStorage.setItem("navCourseId", $scope.selectedCourse);
			sessionStorage.setItem("navClassId", $scope.selectedClassId);
			$location.path("selectFields");
		}
		document.getElementById('select').selectedIndex = 0;
	}

	//$scope.saveStudents();
	$scope.selectStudentDetails = function (studentDetail, studentIndex) {
		if (studentDetail === undefined || studentDetail === "") {
			if (document.getElementById("isAllChecked").checked) {
				for (var i = 0; i < $scope.studentsArr.length; i++) {
					$scope.studentsArr[i].selected = true;
				}
				$scope.selectedStudentsCount = $scope.studentsArr.length;
			} else {
				for (var i = 0; i < $scope.studentsArr.length; i++) {
					$scope.studentsArr[i].selected = false;
				}
				$scope.selectedStudentsCount = 0;
			}
		} else {
			if ($scope.studentsArr[studentIndex].selected) {
				$scope.studentsArr[studentIndex].selected = false;
				$scope.selectedStudentsCount--;

				// Uncheck "Select All" if any individual checkbox is unchecked
				document.getElementById("isAllChecked").checked = false;
			} else {
				$scope.studentsArr[studentIndex].selected = true;
				$scope.selectedStudentsCount++;
			}
		}

		var countIsSelected = $scope.studentsArr.filter(function (student) {
			return student.selected === true;
		}).length;

		$scope.isAllChecked = countIsSelected === $scope.studentsArr.length;
	};


	// $scope.selectStudentDetails = function (studentDetail, studentIndex) {
	//     // ... (your existing code)

	//     // Check if any student is not selected, uncheck "Select All" checkbox
	//     var anyStudentNotSelected = $scope.studentsArr.some(function (student) {
	//         return !student.selected;
	//     });

	//     $scope.isAllChecked = !anyStudentNotSelected;
	// };


	/*  	
		$scope.uploadTemplates = function() {
			if($scope.selectedStudentList.length > 0){
			$scope.studentsArrSucRec = [];
		var files = document.getElementById("choosenexcelFile").files;
		if($scope.selectedTemplt == undefined){
			alert("Please Select Template");
			return;
		}
		if (files[0] == undefined) {
			alert('Please select a Excel file');
			return;
		}
		var fd = new FormData();
		fd.append("file", files[0]);
		$scope.studentList = [];
		httpFactory.executeFileUpload("uploadTemplates", fd, function(data) {
			//console.log(data);
			if (data.length > 0) {
				$scope.studentsArr = [];
				$scope.studentList = data.slice(0);

				var tmptmsg = $scope.createExcelmsg($scope.studentList);
				httpFactory.executePost("sendSMSFromExcel", tmptmsg, function(data) {
					//console.log(data);
					if(data.StatusCode == 200){
						alert("SMS Sent Successfully");
					}else{
						alert("Something went wrong");
					}

				});

			} else {
				alert('Please select a valid Excel file');
			}
		});
			}
			else{
				alert("PLease Select STudents");
			}
	}
 $scope.createExcelmsg = function(msgArray){
	 var sendxel = {
			 messages: [],
			 schemaName : localStorage.getItem("sname"),
			 templateId : "1207161596251733453"
	 }
	 $scope.totalCols = msgArray[msgArray.length-1];
	 var tmsg = document.getElementById("tmsg").value;
	 tmpMsgValArr = [];
	 n = 65;
	 for(var z = 0; z < $scope.totalCols; z++){
		 x  = String.fromCharCode(n);
		 t = "#"+x+"#";
		 n++;
		 tmpMsgValArr.push(t);
	 }

	 for(w = 0; w < $scope.selectedStudentList.length; w++){
		 for(var k = 0; k < tmpMsgValArr.length; k++){
			 if(tmsg.includes(tmpMsgValArr[k])){
				 tempval = tmpMsgValArr[k].charAt(1);
				 tmsg = tmsg.replaceAll(tmpMsgValArr[k], msgArray[w][tempval]);
			 }

		 }
		 sendxel.messages.push({
			 "numbers":$scope.selectedStudentList[w].phoneNumber,
			 "message":tmsg
		 })
		 tmsg = document.getElementById("tmsg").value;
	 }
	 return sendxel;
 }*/

	$scope.exportToCsv = function () {
		//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
		var arrData = typeof $scope.sectionStudents != 'object' ? JSON.parse($scope.sectionStudents) : $scope.sectionStudents;
		var CSV = '';
		var header = "";
		//This condition will generate the Label/Header
		if (CSV == '') {
			header = "Student Name,Student Admission Number,LoginName,Roll Number,Section Name,Student Email,Phone Number,Home Address,Gender,Aadhar No,Pincode,DOB,Age,caste,subCaste,Religion,Mother Tongue,Child Id,Govt Child Id,Bank Name,Bank AccNo,IFSC Code,joiningClassWithAccadamicYear,endingClassWithAccadamicYear,Parent Name,Parent Email,Parent Contact,Parent Aadhar,Mother Name,Mother Email,Mother Contact,Mother Aadhar,Guardian Name,Guardian Email,Guardian Contact,Guardian Aadhar,Mole";
			//append Label row with line break
			CSV += header + '\r\n';
		}
		//1st loop is to extract each row
		for (var i = 0; i < arrData.length; i++) {
			var row = "";
			for (var j = 0; j < header.split(",").length; j++) {
				var count = 0;
				//This loop will extract each column and convert it in string comma-seprated
				for (var index in arrData[i]) {
					count++;
					if (header.split(",")[j].replace(/\s/g, '').toUpperCase() === index.toUpperCase()) {
						row += '"' + arrData[i][index] + '",';
						break;
					}
					if (count == Object.keys(arrData[i]).length) {
						row += '"' + '",';
					}
				}
			}
			//add a line break after each row
			CSV += row + '\r\n';
		}

		blob = new Blob([CSV], {
			type: 'text/csv'
		});

		if (window.navigator && window.navigator.msSaveOrOpenBlob) {
			window.navigator.msSaveOrOpenBlob(blob, "Demo");
		} else {
			const url = URL.createObjectURL(blob);
			const link = document.createElement('a');
			link.href = url;
			$scope.selectedClassName = $scope.selectedClassName.replaceAll('.', '_');
			link.setAttribute('download', $scope.selectedClassName + "-" + $scope.sectionStudents[0].sectionName);
			document.body.appendChild(link);
			link.click();
		}
	}

	$(document).ready(function () {
		// Add click event listener to the "Select All" checkbox
		$('#isAllChecked').click(function () {
			var isChecked = $(this).prop('checked');
			// Set all checkboxes' checked property to the value of the "Select All" checkbox
			$('input[type="checkbox"]').not('#isAllChecked').prop('checked', isChecked);
			updateSelectedFields();
		});
	
		// Add change event listener to individual checkboxes
		$('input[type="checkbox"]').not('#isAllChecked').change(function () {
			updateSelectAllCheckbox();
			updateSelectedFields();
		});
	
		// Function to update selectedStudentFields array
		function updateSelectedFields() {
			$scope.selectedStudentFields = [];
			// Loop through all checkboxes
			$('input[type="checkbox"]').not('#isAllChecked').each(function () {
				if ($(this).prop('checked')) {
					// If checkbox is checked, add its ID to selectedStudentFields
					$scope.selectedStudentFields.push($(this).attr('id'));
				}
			});
		}
	
		// Function to update the state of the "Select All" checkbox
		function updateSelectAllCheckbox() {
			var allChecked = true;
			// Check if all individual checkboxes are checked
			$('input[type="checkbox"]').not('#isAllChecked').each(function () {
				if (!$(this).prop('checked')) {
					allChecked = false;
					return false; // Exit the loop early if any checkbox is unchecked
				}
			});
			// Update the state of the "Select All" checkbox based on the checked status of individual checkboxes
			$('#isAllChecked').prop('checked', allChecked);
		}
	});
	
	$scope.selectAllCheckboxes = function () {
		// Loop through each property in checkboxModel object
		for (var key in $scope.checkboxModel) {
			// Check if the property is not a function (AngularJS adds some internal properties)
			if ($scope.checkboxModel.hasOwnProperty(key)) {
				// Set the value of each property to the state of the "Select All" checkbox
				$scope.checkboxModel[key] = $scope.checkboxModel.isAllChecked;
			}
		}
	
		// If "Select All" checkbox is checked, add all checkbox IDs to selectedStudentFields
		if ($scope.checkboxModel.isAllChecked) {
			$scope.selectedStudentFields = Object.keys($scope.checkboxModel);
		} else {
			// If "Select All" checkbox is unchecked, clear selectedStudentFields
			$scope.selectedStudentFields = [];
		}
	};
	
	$scope.goToselectFields = function () {
		$location.path("selectFields");
	}

	$scope.goToStudentManagement = function () {
		$scope.selectedCourse = sessionStorage.getItem('selectedCourse');
		$scope.selectedClassObj = JSON.parse(sessionStorage.getItem('selectedClassObj'));
		//$scope.getSeleClassId($scope.selectedClassObj);
		//$scope.getSectionsByClass();
		$location.path("manageStudent");
	}

    $scope.selectFieldInit = function () {
		
	}
	$scope.getStudentSelectedFiels = function () {
		var selectedStudentFieldsTemp = sessionStorage.getItem("selectedStudentFields");
		$scope.selectedStudentFields = JSON.parse(selectedStudentFieldsTemp.split(','));
		$scope.selectedStudentList = JSON.parse(sessionStorage.getItem('selectedStudentList'));
		$scope.originalStudentSelectedStudentList = angular.copy($scope.selectedStudentList);
		compareData();

		console.log($scope.selectedStudentFields); // Output: ['fullName', 'subCaste']
	}

	$scope.studentBulkUpdate = function () {
		if ($scope.selectedStudentFields != undefined) {
			if ($scope.selectedStudentFields.length > 0) {
				// Store the selectedStudentFields array in sessionStorage
				sessionStorage.setItem("selectedStudentFields", JSON.stringify($scope.selectedStudentFields));

				// Redirect to the studentBulkUpdate page
				$location.path("studentBulkUpdate");
			}
			else alert("Please select fields");
		}
		else alert("Please select fields");
	};


	$scope.downloadCSV = function () {
		if(confirm("Make sure you are not editing the Login Name")){
			var studentListExcelData = getExcelData();

			// Create a worksheet
			var ws = XLSX.utils.aoa_to_sheet(studentListExcelData);
	
			// Create a workbook
			var wb = XLSX.utils.book_new();
			XLSX.utils.book_append_sheet(wb, ws, 'StudentList');
	
			// Define the file name
			var fileName = "student_list.xlsx";
	
			// Save the workbook to a file
			XLSX.writeFile(wb, fileName);
		}
		else return;
	};


	$scope.uploadStudentListExcel = function () {
		if (confirm("Please do not edit the column names and admission number of the student which leads to errors.")) {
			var fileInput = document.getElementById('studentListFile');
			var file = fileInput.files[0];

			if (!file) {
				alert("Please select a file.");
				return;
			}

			var reader = new FileReader();

			reader.onload = function (e) {
				var data = new Uint8Array(e.target.result);
				var workbook = XLSX.read(data, { type: 'array' });
				var sheetName = workbook.SheetNames[0];

				if (!sheetName) {
					alert("No sheet found in the Excel file.");
					return;
				}

				var sheet = workbook.Sheets[sheetName];
				var excelData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

				if (excelData.length < 2) {
					alert("No data found in the Excel file.");
					return;
				}

				// Assuming the first row contains headers, so skipping it
				var headers = excelData[0];
				var newData = excelData.slice(1);

				// Match and update student data
				newData.forEach(function (row) {
					var studentToUpdate = {}; // Object to store updated student data
					$scope.selectedStudentFields.forEach(function (field, index) {
						studentToUpdate[field] = row[index] || ''; // If cell is empty, set as empty string
					});

					// Find the student in selectedStudentList and update the data
					var indexToUpdate = $scope.selectedStudentList.findIndex(function (student) {
						return student.LoginName === studentToUpdate.LoginName; // Assuming rollNumber is unique
					});

					if (indexToUpdate !== -1) {
						$scope.selectedStudentList[indexToUpdate] = studentToUpdate; // Update student data
					}
				});

				// Apply changes to the scope
				$scope.$apply();
			};

			reader.readAsArrayBuffer(file);
		} else {
			return;
		}
	};


	function getExcelData() {
		var excelData = [];
		var headers = angular.copy($scope.selectedStudentFields);
		excelData.push(headers);

		$scope.selectedStudentList.forEach(function (student) {
			var rowData = [];
			$scope.selectedStudentFields.forEach(function (field) {
				rowData.push(student[field]);
			});
			excelData.push(rowData);
		});

		return excelData;
	}



	function compareData() {
		var isDataChanged = false;

		for (var i = 0; i < $scope.selectedStudentList.length; i++) {
			var originalStudent = $scope.originalStudentSelectedStudentList[i];
			var modifiedStudent = $scope.selectedStudentList[i];

			// Compare each field of the student object
			for (var key in modifiedStudent) {
				if (modifiedStudent[key] !== originalStudent[key]) {
					isDataChanged = true;
					break;
				}
			}

			// If data is changed for any student, break the loop
			if (isDataChanged) {
				break;
			}
		}

		return isDataChanged;
	}

	$scope.saveStudentDetails = function () {
		var data = {
			branchId: localStorage.getItem('bnchId'), // Replace with the actual branch ID
			schemaName: $scope.schemaName, // Replace with the actual schema name
			studentList: []
		};

		// Loop through the modified student data and add it to the studentList array
		for (var i = 0; i < $scope.selectedStudentList.length; i++) {
			var modifiedStudent = angular.copy($scope.selectedStudentList[i]);
			var originalStudent = angular.copy($scope.originalStudentSelectedStudentList[i]);

			// Create an object to store the changes for the current student
			var studentChanges = {
				studentId: originalStudent.studentId
			};

			// Compare each field of the modifiedStudent object with the originalStudent object
			for (var key in modifiedStudent) {
					if (originalStudent.hasOwnProperty(key)) {
						if(modifiedStudent[key] !== originalStudent[key])
						// Add the modified field to the studentChanges object
						   studentChanges[key] = modifiedStudent[key];						  
					}
					else studentChanges[key] = modifiedStudent[key];
			}

			// If any changes are detected, add the studentChanges object to the studentList array
			if (Object.keys(studentChanges).length > 1) { // Check if there are changes other than studentId
				data.studentList.push(studentChanges);
			}
		}

		if (data.studentList.length > 0) {
			httpFactory.executePost("updateStudentDetails", data, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("Details Updated Successfully");
					$location.path("manageStudent/");
				} else if (data.StatusCode == 300) {
					alert(data.MESSAGE);
				} else {
					alert("Something went wrong");
				}
			});
		} else {
			alert("No changes");
		}

		return data;
	};



});

