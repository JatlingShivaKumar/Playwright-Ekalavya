projectModule.controller('teacherTimeTableController', function($scope, $location, $timeout, $routeParams, httpFactory,Excel, $rootScope) {
  $scope.$ = $;
  $scope.instituteId = parseInt(localStorage.getItem("inst_id"));
  $scope.instituteTypes = [];
  $scope.latestCurrentInstTab = "";
  $scope.schemaName = localStorage.getItem("sname");
  $scope.userRoleId = localStorage.getItem("RD");
  $scope.branchId=$routeParams.branchId;
  $scope.teacherId=$routeParams.userId;


  $scope.getCourseByBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.courseList = data.Courses;
	    }
	  });
	}
  $scope.courseSelect = function(){
    $scope.classList=[];
    $scope.sectionList=[];
    httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.classList = data.Classes;

      }
    });
  }

  $scope.courseClassSelect = function(selectedClass){
    console.log(selectedClass);
    $scope.selectedClassOb = JSON.parse(selectedClass);
    console.log($scope.selectedClasOb);
    $scope.selectedCCId=$scope.selectedClassOb.classCourseId;
    $scope.selectedClassId = $scope.selectedClassOb.classId;
    httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      $scope.sectionList=[];
      if (data.StatusCode == 200) {
        $scope.sectionList = data.Sections;
      }
    });
  }
  $scope.timeTableForSection=function(section){
    $scope.getTeacherTimetable();
  }
  $scope.getTeacherTimetable=function(){
    httpFactory.getResult("getTeacherTimetable?userId="+$scope.teacherId+"&branchId="+$scope.branchId+ "&schemaName="+localStorage.getItem("sname"), function(data) {
      console.log(data);
			$scope.mainTimeTableObj=[];
			if (data.StatusCode == 200) {
					$scope.allWorkingDays = data.teacherTimeTable;
					$scope.timeTableView=true;
					$scope.timeTable=false;
			}
			else{
			  $scope.allWorkingDays = [];
			  $scope.timeTable=true;
			  $scope.timeTableView=false;
			}
    });
  }

});
