	'use strict';
	angular.module('httpFactory', []).factory(
	'httpFactory',
	function($http, $rootScope) {

	var baseUrl = '/';

	return {
		executePost : executePost,
		executePostLogin:executePostLogin,
		getResult : getResult,
		getResultAsync : getResultAsync,
		executeFileUpload : executeFileUpload
	};

	// Func desc : Execute POST Method
	// Written by : Ak
	// Last updated by :
	function executePost(url, requestParams, callback) {

		var httpStr = "http://";
		var domainHost = location.host;
		var hostPath = httpStr.concat(domainHost);

		var localItem = localStorage.getItem("inst_id");
		var studentLocal = localStorage.getItem("stuid");

		$("#smallLoad").removeClass('hide').addClass('show');
		$http({
		url : baseUrl + url,
		method : "POST",
		data : requestParams,
		headers : {
		'Content-Type' : 'application/json'
		}
		}).then(function(response) {
				callback(response.data);
				$("#smallLoad").removeClass('show').addClass('hide');

		}, function(response) {
				callback(response);
				$("#smallLoad").removeClass('show').addClass('hide');

		});

}

function executePostLogin(url, requestParams, callback) {

	$("#smallLoad").removeClass('hide').addClass('show');
	$http({
	url : baseUrl + url,
	method : "POST",
	data : requestParams,
	headers : {
	'Content-Type' : 'application/json'
	}
	}).then(function(response) {
			callback(response.data);
			$("#smallLoad").removeClass('show').addClass('hide');

	}, function(response) {
			callback(response);
			$("#smallLoad").removeClass('show').addClass('hide');

	});
}


	// Func desc : Get Result (Fetch Data Using GET)
	// Written by : Ak
	// Last updated by :
	function getResult(url, callback) {

		$("#smallLoad").removeClass('hide').addClass('show');
		$.ajax({
		url : baseUrl + url,
		async : false,
		dataType : 'json',
		success : function(json) {
		callback(json);
		$("#smallLoad").removeClass('show').addClass('hide');


		},
		error : function(data, errorThrown) {
		callback("ERROR :: " + errorThrown);
		$("#smallLoad").removeClass('show').addClass('hide');

		}
		});

	}

	// Func desc : Get Result (Fetch Data Using GET, ASYNC Function)
	// Written by : Ak
	// Last updated by :
	function getResultAsync(url, callback) {

		$("#smallLoad").removeClass('hide').addClass('show');

		$.ajax({
		url : baseUrl + url,
		dataType : 'json',
		success : function(json) {
		callback(json);
		$("#smallLoad").removeClass('show').addClass('hide');
		},
		error : function(data, errorThrown) {
		callback("ERROR :: " + errorThrown);
		$("#smallLoad").removeClass('show').addClass('hide');
		}
		});
}

	// Func desc : File Upload POST Method
	// Written by : Ak
	// Last updated by :
	function executeFileUpload(url, formData, callback) {
		$.ajax({
		url :  baseUrl + url,
		type : "POST",
		async : false,
		dataType : "json",
		data : formData,
		cache : false,
		contentType : false,
		processData : false,
		success : function(json) {
		callback(json);
		},
		error : function(data, errorThrown) {
		callback("ERROR :: " + errorThrown);
		}
		});
	}

	});
