projectModule.controller('feeReportController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.branchName
			$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourseOb = {};
	$scope.selectedClassObj = {};
	$scope.selectedClass = "";

	$scope.labels = ["Discount", "Paid Amount", "Due Amount"];
	$scope.data = [450, 280, 220];
	$scope.colors = ['#16a085', '#e74b3b', '#f1c30f'];
	$scope.options = {
			legend: {
				display: true,
				position: 'left'
			}
	};

	$scope.getCoursesByBranch = function() {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if($scope.courseList.length==1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
					$scope.getClassesByCourse();
				}			
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.dataForFeeAnalysisTab = function() {
		$scope.allAmounts = [$scope.secTotalDiscount, $scope.secTotalPaidAmount, $scope.secTotalDueAmount];
		$scope.labels = ["Discount", "Paid Amount", "Due Amount"];
	}

	$scope.goToDashbord = function(){
		$location.path("feemanagement");
	}

	$scope.getClassesByCourse = function() {
		console.log($scope.selectedCourseOb);
		if ($scope.selectedCourseOb == null) {
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.selectedCourseObj.courseId;
		$scope.selectedCourseName = $scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + $scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);

			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();

	$scope.getSectionByClass = function(selectedClassObj) {
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("Got Error");
			}
		});
	}

	$scope.latestCurrentTabTest = 'examAnalysis';
	$scope.redirectToCurrentTabTest = function(currentTab) {
		$scope.latestCurrentTabTest = currentTab;
	}
	$scope.updateCrsClsSec = function(selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}

	$scope.getStudentsBySection = function() {
		$scope.sectionFeeReports = [];
		$scope.sectionStudentFeeReportDetails = [];
		$scope.totalCategoryDetails = [];
		$scope.fineReceipt=false;
		$scope.oldDueReceipt=false;
		$scope.oldDueCol=false;
		httpFactory.getResult("getSectionFeeReport?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId +"&classCourseId=" + $scope.classObj.classCourseId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.getStudentsSummarizedDataOnCategories();
				$scope.sectionFeeReports = data.feeReportDetails;
				for(j=0;j<$scope.sectionFeeReports.length;j++){
					$scope.sectionFeeReports[j]["selected"] = false;
					if($scope.sectionFeeReports[j].fineArr.length>0)
						$scope.fineReceipt=true;
					if($scope.sectionFeeReports[j].oldDueArr.length>0)
						$scope.oldDueReceipt=true;
					if($scope.sectionFeeReports[j].hasOwnProperty('oldDueAmount'))
						$scope.oldDueCol=true;
				}
				$scope.sectionStudentFeeReportDetails = $scope.sectionFeeReports;
				$scope.selectedStudentsCount = 0;
				if($scope.latestCurrentTabTest == "studentReportList"){
					document.getElementById("isAllChecked").checked = false;
				}
				$scope.sectionTotalFeeDetails();				
				$scope.getSectionReportAnalysis();
				$scope.dataForFeeAnalysisTab();
				//$scope.getBranchDetails();
				console.log($scope.sectionFeeReports);
				$scope.excelFileName = $scope.classObj.className + "_" + $scope.sectionObj.sectionName + ".xls";

			} else if(data.StatusCode == 300){
				$scope.sectionFeeReports = [];
			}else{
				alert(data.MESSAGE);
			}
		});
	}
	$scope.getStudentsSummarizedDataOnCategories = function() {
		$scope.totalCategoryDetails = [];
		httpFactory.getResult("getStudentsSummarizedDataOnCategories?schemaName=" + $scope.schemaName + "&sectionId=" + $scope.sectionId + "&classcourseId=" +$scope.classObj.classCourseId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.totalCategoryDetails = data.feeReportDetails;
			}else{
				console.log(data.MESSAGE);
			}
		});
	}

	$scope.getSectionReportAnalysis = function() {
		$scope.secTotalAmount = 0; $scope.secTotalPayAmount = 0; $scope.secTotalPaidAmount = 0; $scope.secTotalDueAmount = 0; $scope.secTotalDiscount = 0;
		for (i = 0; i < $scope.sectionFeeReports.length; i++) {
			if($scope.sectionFeeReports[i].hasOwnProperty("studentId")) {
				$scope.secTotalAmount = parseInt($scope.secTotalAmount) + parseInt($scope.sectionFeeReports[i].totalAmount);
				$scope.secTotalPayAmount = parseInt($scope.secTotalPayAmount) + parseInt($scope.sectionFeeReports[i].netAmount);
				$scope.secTotalPaidAmount = parseInt($scope.secTotalPaidAmount) + parseInt($scope.sectionFeeReports[i].paidAmount);
				$scope.secTotalDueAmount = parseInt($scope.secTotalDueAmount) + parseInt($scope.sectionFeeReports[i].dueAmount);
				$scope.secTotalDiscount = parseInt($scope.secTotalDiscount) + parseInt($scope.sectionFeeReports[i].discount);
			}
		}
	}

	$scope.printOldReceipt = function(receiptId, studentId) {
		$scope.studentId = studentId;
		httpFactory.getResult("getFeeReceiptDetails?schemaName=" + $scope.schemaName + "&receiptId=" + receiptId + "&branchId=" + $scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.feeReceiptDetailsObj = data.feeReceiptDetailsObj;

				$scope.pReceiptNumber = $scope.feeReceiptDetailsObj.receiptId;
				$scope.pReceiptDate = $scope.feeReceiptDetailsObj.receiptDate;
				$scope.pStudentName = $scope.feeReceiptDetailsObj.studentName;
				$scope.pFatherName = $scope.feeReceiptDetailsObj.fatherName;
				$scope.pCourseName = $scope.feeReceiptDetailsObj.courseName;
				$scope.pClassName = $scope.feeReceiptDetailsObj.className;
				$scope.pSectionName = $scope.feeReceiptDetailsObj.sectionName;
				$scope.pTransactionType = $scope.feeReceiptDetailsObj.transactionType;
				$scope.fine = $scope.feeReceiptDetailsObj.fine;
				$scope.totalAmount = $scope.feeReceiptDetailsObj.totalAmount;
				$scope.receiptPaidAmount = $scope.feeReceiptDetailsObj.paidAmount;
				$scope.discount = $scope.feeReceiptDetailsObj.discount;
				$scope.totalDueAmount = $scope.feeReceiptDetailsObj.totalDueAmount;
				$scope.receiptDueAmount = $scope.feeReceiptDetailsObj.dueAmount;
				$scope.netAmount = $scope.feeReceiptDetailsObj.payableAmount;

				$scope.receiptBillingName = $scope.feeReceiptDetailsObj.billingName;
				$scope.receiptBillingAddress = $scope.feeReceiptDetailsObj.billingAddress;
				if($scope.feeReceiptDetailsObj.hasOwnProperty("billingLogo")){
					document.getElementById("billingProfile1").src = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.feeReceiptDetailsObj.billingLogo+"&embedded=true";
				}else{
					document.getElementById("billingProfile1").style.visibility = "hidden";
				}
				$("#printReceiptPreview").modal("show");
			} else {
				alert("Something went wrong")
			}
		});
	}

	$scope.closePopUp = function() {
		$("#viewFeeReceipt").modal("hide");
		$scope.totalAmount = "";
		$scope.paidAmount = "";
		$scope.discount = "";
		$scope.dueAmount = "";
		$scope.netAmount = "";
		$scope.getStudentsBySection();
	}

	$scope.makeFeePDF = function() {
		$scope.receiptBillingName = $scope.feeReceiptDetailsObj.billingName;
		$scope.receiptBillingAddress = $scope.feeReceiptDetailsObj.billingAddress;
		if($scope.feeReceiptDetailsObj.hasOwnProperty("billingLogo")){
			document.getElementById("billingProfile").src = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.feeReceiptDetailsObj.billingLogo+"&embedded=true";
		}else{
			document.getElementById("billingProfile").style.visibility = "hidden";
		}
		var mywindow = window.open('', '', '','');
    	mywindow.document.write('<!doctype html> <html style="height:49%;">');
    	mywindow.document.write('<body>');
    	mywindow.document.write(document.getElementById("printReceipt1").innerHTML);
    	mywindow.document.write('<br>');
    	mywindow.document.write(document.getElementById("printReceipt1").innerHTML);
    	mywindow.document.write('</body></html>');
    	var is_chrome = Boolean(mywindow.chrome);
		mywindow.document.close(); // necessary for IE >= 10 and necessary before onload for chrome
		if (is_chrome) {
			mywindow.onload = function() { // wait until all resources loaded 
				mywindow.focus(); // necessary for IE >= 10
				mywindow.print();  // change window to mywindow
			};
		}
		else {
			mywindow.document.close(); // necessary for IE >= 10
			mywindow.focus(); // necessary for IE >= 10
			mywindow.print();
		}
		$("#printReceiptPreview").modal("hide");
	}

	$scope.getBranchDetails = function(){
		httpFactory.getResult("getBranchDetails?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.statusCode == 200) {
				$scope.branchDetails = data.data;
			}else{

			}
		});
	}

	$("#fromDateDiv").datepicker({
		format: "yyyy:mm:dd",
		autoclose: true,
		endDate:new Date(),
		todayHighlight: true
	}).on('changeDate', function(){
		$("#toDateDiv").datepicker({
			format: "yyyy:mm:dd",
			autoclose: true,
			startDate : $("#fromDate").val(),
			endDate:new Date(),
			todayHighlight:false
		});
	});

	$scope.feeHistory = function(){
		$scope.fromDate = $("#fromDate").val();
		$scope.toDate = $("#toDate").val();
		if($scope.fromDate == "" || $scope.fromDate == undefined || $scope.toDate == undefined || $scope.toDate == ""){
			alert("Please Select Dates");
			return;
		}
		$scope.studentReceiptsHistory = [];
		$scope.selectTT = '';
		$scope.selectRT='Fee Receipt';
		if(document.getElementById('selectRT')!=null)
			document.getElementById('selectRT').selectedIndex=0;
		httpFactory.getResult("getAllFeeReportsByDates?schemaName="+$scope.schemaName+"&branchId="+$scope.branchId+"&fromDate="+$scope.fromDate+"&toDate="+$scope.toDate, function(data) {
			console.log(data);
    		if (data.StatusCode == 200) {
    			$scope.receiptTable=true;
      			$scope.studentReceiptsHistory = data.feeReportDetails;
      			$scope.tempStudentReceiptsHistory = angular.copy($scope.studentReceiptsHistory);
      			$scope.totalReceiptArray= {
						"totalDiscount":0,
						"totalPrevDueAmount":0,
						"totalDueAmount":0,
						"totalNetAmount":0,
						"totalPaidAmount":0,
						"totalOfTotalAmounts":0
				};
      			$scope.filterReceipt();
      			//$scope.getBranchDetails();
        		$scope.excelFileName = $scope.fromDate + " to " + $scope.toDate + ".xls";
  			}else{
  				$scope.receiptTable=false;
  			}
		});
	}

	$scope.excelOnClick = function() {
		//If JSONData is not an object then JSON.parse will parse the JSON string in an Object
		var arrData = typeof $scope.sectionStudentFeeReportDetails != 'object' ? JSON.parse($scope.sectionStudentFeeReportDetails) : $scope.sectionStudentFeeReportDetails;
		var arrData2 = typeof $scope.totalCategoryDetails != 'object' ? JSON.parse($scope.totalCategoryDetails) : $scope.totalCategoryDetails;
		var CSV = '';
		var header="";
		var header2 = "";
		//This condition will generate the Label/Header
		if (CSV=='') {
			header="Student Name,Total Amount,Discount,Net Amount,Paid Amount,Due Amount,Receipts History";
			//append Label row with line break
			CSV += header + '\r\n';
		}
		//1st loop is to extract each row
		for (var i = 0; i < arrData.length; i++) {
			var row = "";
			for (var j = 0; j < header.split(",").length; j++) {
				var count=0;
				//This loop will extract each column and convert it in string comma-seprated
				for (var index in arrData[i]) {
					count ++;
					if(header.split(",")[j].replace(/\s/g,'').toUpperCase() ===index.toUpperCase()) {
						row += '"' + arrData[i][index] + '",';
						break;
					}else if(header.split(",")[j].replace(/\s/g,'').toUpperCase()==='RECEIPTSHISTORY' && index.toUpperCase()==='RECEIPTARR') {
						//	        			row += '"' + JSON.stringify(arrData[i][index]).replace(/[\[\]']+/g,'') + '",';
						if(JSON.stringify(arrData[i][index]).replace(/[\[\]']+/g,'')==='0' || JSON.stringify(arrData[i][index]).replace(/[\[\]']+/g,'')==='') {
							//	        				arrData[i][index]='No Receipt';
							row += '"' + 'No Receipt' + '",';
						}else {
							row += '"' + JSON.stringify(arrData[i][index]).replace(/[\[\]']+/g,'') + ',"';
						}
						break;
					}
					if(count==Object.keys(arrData[i]).length) {
						row += '"' + '",';
					}
				}
			}
			//add a line break after each row
			CSV += row + '\r\n';


			if (i==arrData.length-1) {
				header2="Total,"+$scope.totalOfTotalAmounts+","+$scope.totalDiscount+","+$scope.totalNetAmount+","+$scope.totalPaidAmount+","+$scope.totalDueAmount+",NA"+ '\r\n';
				//append Label row with line break
				CSV +=header2 + '\r\n';
				header2=" ,TOTAL CATEGORY AMOUNT, ";
				//append Label row with line break
				CSV +='\r\n\r\n' +header2 + '\r\n';
				header2="Fee Category Name,Number Of Allocated Students,Total Allocated Amount";
				//append Label row with line break
				CSV +=header2 + '\r\n';
				//1st loop is to extract each row
				for (var j = 0; j < arrData2.length; j++) {
					var row = "";
					for (var k = 0; k < header2.split(",").length; k++) {
						var count=0;
						//This loop will extract each column and convert it in string comma-seprated
						for (var index in arrData2[j]) {
							count ++;
							if(header2.split(",")[k].replace(/\s/g,'').toUpperCase() ===index.toUpperCase()) {
								row += '"' + arrData2[j][index] + '",';
								break;
							}
							if(count==Object.keys(arrData2[j]).length) {
								row += '"' + '",';
							}
						}
					}
					//add a line break after each row
					CSV += row + '\r\n';
				}
			}
		}
		blob = new Blob([CSV], {
			type: 'text/csv'
		});

		if (window.navigator && window.navigator.msSaveOrOpenBlob) {
			window.navigator.msSaveOrOpenBlob(blob, "Demo");
		} else {
			const url = URL.createObjectURL(blob);
			const link = document.createElement('a');
			link.href = url;
			link.setAttribute('download',$scope.classObj.className+"-"+$scope.sectionObj.sectionName);
			document.body.appendChild(link);
			link.click();
		}
	}

	$scope.historyExcel = function(feeReport) {
		var link = document.createElement('a');
		link.download = $scope.excelFileName;
//		link.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(document.getElementById('studentsresultsTotal').outerHTML);
        var modifiedTable = document.getElementById('studentsresultsTotal').cloneNode(true);
        var lastHeader = modifiedTable.getElementsByTagName('th')[modifiedTable.getElementsByTagName('th').length-1];
        lastHeader.textContent = 'Transaction Type';
        link.href = 'data:application/vnd.ms-excel,' + encodeURIComponent(modifiedTable.outerHTML);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}
$scope.printHistoryReport = function(feeReport) {
    var modifiedTable = document.getElementById('studentsresultsTotal').cloneNode(true);
    var lastHeader = modifiedTable.getElementsByTagName('th')[modifiedTable.getElementsByTagName('th').length-1];
    lastHeader.textContent = 'Transaction Type';

    var styles = '';
    for (var i = 0; i < document.styleSheets.length; i++) {
        try {
            var rules = document.styleSheets[i].cssRules || document.styleSheets[i].rules;
            for (var j = 0; j < rules.length; j++) {
                styles += rules[j].cssText + '\n';
            }
        } catch (e) {
            // Some stylesheets might be inaccessible due to cross-origin restrictions
            console.warn("Could not access stylesheet: ", document.styleSheets[i].href);
        }
    }

    var printWindow = window.open('', '_blank');

    printWindow.document.write('<html><head><title>Fee Report</title>');
    printWindow.document.write('<style>' + styles + '</style>');
    printWindow.document.write('<style>@page { size: landscape; }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h1>Fee Report</h1>');
    printWindow.document.write(modifiedTable.outerHTML);
    printWindow.document.write('</body></html>');

    printWindow.document.close();

    printWindow.onload = function() {
        printWindow.print();
        printWindow.close();
    };
}


	$scope.datePicker = function(){
		document.getElementById("fromDate").setAttribute("max", new Date().toISOString().split("T")[0]);
		document.getElementById("toDate").setAttribute("max", new Date().toISOString().split("T")[0]);
	}

	$scope.fromDateChange = function(){
		if($scope.fromDate == "" || $scope.fromDate == undefined){
			alert("Please select From Date");
			return;
		}
		document.getElementById("toDate").setAttribute("min", new Date($scope.fromDate).toLocaleDateString('en-ca'));
	}

	$scope.selectedStudentsArray = [];
	
	$scope.selectStudents = function(studentDetail, studentIndex){
		if(studentDetail == "" || studentDetail == undefined){
			if(document.getElementById("isAllChecked").checked == true){
				for(i=0;i<$scope.sectionStudentFeeReportDetails.length;i++){
					if($scope.sectionStudentFeeReportDetails[i].selected == false)
						$scope.sectionStudentFeeReportDetails[i].selected = true;
				}
				$scope.selectedStudentsCount = $scope.sectionFeeReports.length;
			}else if(document.getElementById("isAllChecked").checked == false){
				for(i=0;i<$scope.sectionStudentFeeReportDetails.length;i++){
					if($scope.sectionStudentFeeReportDetails[i].selected == true)
						$scope.sectionStudentFeeReportDetails[i].selected = false;
				}
				$scope.selectedStudentsCount = 0;
			}

		}else{
			if($scope.sectionStudentFeeReportDetails[studentIndex].selected == true){
				$scope.sectionStudentFeeReportDetails[studentIndex].selected = false;
				$scope.selectedStudentsCount--;
				document.getElementById("isAllChecked").checked = false;
			}else{
				$scope.sectionStudentFeeReportDetails[studentIndex].selected = true;
				$scope.selectedStudentsCount++;
				if($scope.selectedStudentsCount == $scope.sectionStudentFeeReportDetails.length)
					document.getElementById("isAllChecked").checked = true;
				else
					document.getElementById("isAllChecked").checked = false;
			}
		}
	}

	$scope.sendSms = function() {
		var a = document.getElementById('select');
		var option = a.options[a.selectedIndex].value;
		$scope.selectedStudentsArray = [];
		if (document.getElementById("isAllChecked").checked == true)
			$scope.selectedStudentsArray = $scope.sectionStudentFeeReportDetails;
		else {
			for (i = 0; i < $scope.sectionStudentFeeReportDetails.length; i++) {
				if ($scope.sectionStudentFeeReportDetails[i].selected == true) {
					$scope.selectedStudentsArray.push($scope.sectionStudentFeeReportDetails[i]);
				}
			}
		}
		if ($scope.selectedStudentsArray.length == 0) {
				alert("Please select Students");
		} else {
			if (option == "sendMessage") {
				$('#sendMessageDueDate').val('');
				$("#sendSmsModal").modal("show");
			} else if (option == "printDueSlip") {
				$('#printDueSlipDueDate').val('');
				$("#printDueSlipModal").modal("show");
			}
		}

		// $('#printReceiptPreviewModal').on('hidden.bs.modal', function () {
		// 	$('#printDueSlipModal').modal('hide');            
		// });
		document.getElementById('select').selectedIndex = 0;
	};

	$(document).ready(function() {
		$('#printButton').click(function() {
			$('#printReceiptPreviewModal').modal('show');
		});
	});


	
	$scope.addExaminationForHallticket = function(){
		$("#addNewFeeCategory").modal("show");
	}
	$scope.sendMessageToStudents = function(value){
        	   var lang = "";
        	   if(value == 'whatsAppE'){
            				lang = "en";
            			}else if(value == 'whatsAppT'){
            				lang = "te";
            			}else if(value == 'whatsAppH'){
            				lang = "hi";
            			}
        		if(document.getElementById("sendMessageDueDate").value == "" || document.getElementById("sendMessageDueDate").value == undefined)
        			alert("Select due date");
        		else{
        			var params= {
        					"sectionId":$scope.sectionId,
        					"branchId":$scope.branchId,
        					"schemaName":$scope.schemaName,
        					"studentArray":$scope.selectedStudentsArray,
        					"dueDate":document.getElementById("sendMessageDueDate").value,
        					"messageType":$scope.selectedMessageType,
        					"lang" : lang
        			}
			httpFactory.executePost("sendFeeMessageToStudents", params, function(data) {
				console.log(data);
				if (data.StatusCode == "200") {
					alert(data.MESSAGE);
					$scope.selectedStudentsArray = [];
					document.getElementById("sendMessageDueDate").value = "";
					document.getElementById("isAllChecked").checked = "";
					$scope.dueDate = "";
					$scope.isAllChecked = false;
					$("#sendSmsModal").modal("hide");
					for(i=0;i<$scope.sectionFeeReports.length;i++){
						$scope.sectionFeeReports[i].selected = false;
					}
					$scope.selectedStudentsCount = 0;
				}else if(data.StatusCode == "300"){
					alert(data.MESSAGE);
					$scope.selectedStudentsArray = [];
					document.getElementById("sendMessageDueDate").value = "";
					$scope.dueDate = "";
					$("#sendSmsModal").modal("hide");
				}else {
					$scope.selectedStudentsArray = [];
					alert("Something went wrong.try again!");
				}
			});
		}
	}

	$scope.sectionTotalFeeDetails = function(){
		$scope.totalDueAmount = 0;
		$scope.totalDiscount = 0;
		$scope.totalPaidAmount = 0;
		$scope.totalNetAmount = 0;
		$scope.totalOfTotalAmounts = 0;
		$scope.totalOfOldDueAmounts = 0;
		for(var i=0;i<$scope.sectionStudentFeeReportDetails.length;i++){
			$scope.totalDueAmount+= Number($scope.sectionStudentFeeReportDetails[i].dueAmount);
			$scope.totalDiscount+=Number($scope.sectionStudentFeeReportDetails[i].discount);
			$scope.totalPaidAmount+=Number($scope.sectionStudentFeeReportDetails[i].paidAmount);
			$scope.totalNetAmount+=Number($scope.sectionStudentFeeReportDetails[i].netAmount);
			$scope.totalOfTotalAmounts+=Number($scope.sectionStudentFeeReportDetails[i].totalAmount);
			if($scope.sectionStudentFeeReportDetails[i].hasOwnProperty('oldDueAmount'))
			$scope.totalOfOldDueAmounts+= Number($scope.sectionStudentFeeReportDetails[i].oldDueAmount);
		}
	}

	$scope.filterStudentDetails = function(selectedOption){
		if(selectedOption == "1"){
			$scope.sectionStudentFeeReportDetails = [];
			for(i=0;i<$scope.sectionFeeReports.length;i++){
				$scope.sectionFeeReports[i].selected = false;
				if($scope.sectionFeeReports[i].dueAmount > 0){
					$scope.sectionStudentFeeReportDetails.push($scope.sectionFeeReports[i]);
				}
			}
		}else if(selectedOption == "2"){
			for(i=0;i<$scope.sectionFeeReports.length;i++){
				$scope.sectionFeeReports[i].selected = false;
			}
			$scope.sectionStudentFeeReportDetails = $scope.sectionFeeReports;
			document.getElementById("selectedOption").value = "";
			$scope.selectedOption = "";
		}
		document.getElementById("isAllChecked").checked = false;
		$scope.sectionTotalFeeDetails();
		$scope.selectedStudentsCount = 0;
	}

	$scope.shareFeeReceipt = function(socialIcon,lang){
		if(socialIcon == 'whatsApp'){	
			var Msg = "Greetings From "+$scope.branchName+"\n"
					+ "Dear "+$scope.pStudentName+"\n"
					+ "Thank you for the payment of \n"
					+ "Amount : "+$scope.receiptPaidAmount+"\n"
					+ "Receipt id "+$scope.pReceiptNumber+"\n"
					+ "Date : "+$scope.pReceiptDate+"\n"
					+ "Total Fee: " +($scope.feeReceiptDetailsObj.receiptType=='Fee Receipt'?$scope.netAmount:($scope.feeReceiptDetailsObj.receiptType=='Old Due'?$scope.totalAmount:$scope.receiptPaidAmount))+"\n"
					+ "Total Paid: "+ ($scope.netAmount-$scope.receiptDueAmount)+"\n"
					+ "Total Due : "+ $scope.receiptDueAmount+"\n"
					+ "Please Contact School Management For Any Queries."
                    const receiptDateFormatted = new Date($scope.pReceiptDate).toLocaleString("en-GB", {day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit"}).replace(",", "");
					var params = {
							"messageValues" : [$scope.branchName, $scope.pStudentName, $scope.receiptPaidAmount, $scope.pReceiptNumber, receiptDateFormatted, $scope.netAmount, $scope.netAmount-$scope.receiptDueAmount, $scope.receiptDueAmount],
							"schemaName" : localStorage.getItem("sname"),
							"studentId" : $scope.studentId,
							"branchId" :  $scope.branchId,
							"messageType" : socialIcon,
							"lang" : lang
			}
			httpFactory.executePost("shareFeeReceipt" ,params, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert(data.MESSAGE)
				}else if (data.StatusCode == 404){
					alert("Student Phone Number not found");

				} else{
					alert("Something went wrong");
					$scope.feeRefundDetails = [];
				}

			});
		}else if(socialIcon == 'gmail'){
			//var attachment = "http://"+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath=/home/devuser1/data/eka5398/BillingProfiles/3050_coupleSample.JPG&embedded=true";
			let url = 'https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=&su=' + $scope.pStudentName + " - Fee Receipt Details - " 
					+ $scope.pReceiptNumber + '&body=' + message + '&ui=2&tf=1&pli=1';
			window.open(url, 'sharer', 'toolbar=0,status=0,width=648,height=395');
		}
	}
	
	$scope.filterReceipt = function(){
		$scope.studentReceiptsHistory = angular.copy($scope.tempStudentReceiptsHistory);
		if(document.getElementById('selectRT')!=null) {
			$scope.selectRT=document.getElementById('selectRT').options[document.getElementById('selectRT').selectedIndex].value;
		}
		if(document.getElementById('selectTT')!=null) {
			$scope.selectTT='';
			document.getElementById('selectTT').selectedIndex=0;
		}
		for(i=0;i<$scope.studentReceiptsHistory.length;i++){
			for(j=0;j<$scope.studentReceiptsHistory[i].classArray.length;j++){
				for(k=0;k<$scope.studentReceiptsHistory[i].classArray[j].sectionArray.length;k++){
					for(l=0;l<$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length;l++){
						if($scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].receiptType.toUpperCase() !== $scope.selectRT.toUpperCase()) {
							$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.splice(l,1);
							l--;
						}
					}
					if($scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length==0) {
						$scope.studentReceiptsHistory[i].classArray[j].sectionArray.splice(k,1);
						k--;
					}
				}
				if($scope.studentReceiptsHistory[i].classArray[j].sectionArray.length==0) {
					$scope.studentReceiptsHistory[i].classArray.splice(j,1);
					j--;
				}
			}
			if($scope.studentReceiptsHistory[i].classArray.length==0) {
				$scope.studentReceiptsHistory.splice(i,1);
				i--;
			}
		}
		$scope.tempReceiptTypeStudentReceiptsHistory = angular.copy($scope.studentReceiptsHistory);
		$scope.totalReceiptArray.totalDiscount=0;
		$scope.totalReceiptArray.totalDueAmount=0;
		$scope.totalReceiptArray.totalPrevDueAmount=0;
		$scope.totalReceiptArray.totalNetAmount=0;
		$scope.totalReceiptArray.totalOfTotalAmounts=0;
		$scope.totalReceiptArray.totalPaidAmount=0;
		$scope.calculateTransaction();
	}
	
	$scope.filterTransaction = function(){
		$scope.studentReceiptsHistory = angular.copy($scope.tempReceiptTypeStudentReceiptsHistory);
		if(document.getElementById('selectTT').options[document.getElementById('selectTT').selectedIndex].value=="") {
			return;
		}else if(document.getElementById('selectTT').options[document.getElementById('selectTT').selectedIndex].value=="All") {
			$scope.totalReceiptArray.totalDiscount=0;
			$scope.totalReceiptArray.totalDueAmount=0;
			$scope.totalReceiptArray.totalPrevDueAmount=0;
			$scope.totalReceiptArray.totalNetAmount=0;
			$scope.totalReceiptArray.totalOfTotalAmounts=0;
			$scope.totalReceiptArray.totalPaidAmount=0;
			$scope.calculateTransaction();
			return;
		}
		for(i=0;i<$scope.studentReceiptsHistory.length;i++){
			for(j=0;j<$scope.studentReceiptsHistory[i].classArray.length;j++){
				for(k=0;k<$scope.studentReceiptsHistory[i].classArray[j].sectionArray.length;k++){
					for(l=0;l<$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length;l++){
						if($scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].transactionType.toUpperCase() !== document.getElementById('selectTT').options[document.getElementById('selectTT').selectedIndex].value.toUpperCase()) {
							$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.splice(l,1);
							l--;
						}
					}
					if($scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length==0) {
						$scope.studentReceiptsHistory[i].classArray[j].sectionArray.splice(k,1);
						k--;
					}
				}
				if($scope.studentReceiptsHistory[i].classArray[j].sectionArray.length==0) {
					$scope.studentReceiptsHistory[i].classArray.splice(j,1);
					j--;
				}
			}
			if($scope.studentReceiptsHistory[i].classArray.length==0) {
				$scope.studentReceiptsHistory.splice(i,1);
				i--;
			}
		}
		$scope.totalReceiptArray.totalDiscount=0;
		$scope.totalReceiptArray.totalDueAmount=0;
		$scope.totalReceiptArray.totalPrevDueAmount=0;
		$scope.totalReceiptArray.totalNetAmount=0;
		$scope.totalReceiptArray.totalOfTotalAmounts=0;
		$scope.totalReceiptArray.totalPaidAmount=0;
		$scope.calculateTransaction();
	}
	
	$scope.calculateTransaction = function(){
		for(i=0;i<$scope.studentReceiptsHistory.length;i++){
			for(j=0;j<$scope.studentReceiptsHistory[i].classArray.length;j++){
				for(k=0;k<$scope.studentReceiptsHistory[i].classArray[j].sectionArray.length;k++){
					for(l=0;l<$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length;l++){
						if($scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray.length-1].receiptId==$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].receiptId) {
							$scope.totalReceiptArray.totalDiscount+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].discount;
							$scope.totalReceiptArray.totalDueAmount+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].dueAmount;
							$scope.totalReceiptArray.totalPrevDueAmount+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].prevDueAmount;
							$scope.totalReceiptArray.totalNetAmount+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].netAmount;
							$scope.totalReceiptArray.totalOfTotalAmounts+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].totalAmount;
						}
						$scope.totalReceiptArray.totalPaidAmount+=$scope.studentReceiptsHistory[i].classArray[j].sectionArray[k].receiptArray[l].paidAmount;
					}
				}
			}
		}
	}

	$scope.makeBulkFeeDueMessage = function () {
		var printContent = document.getElementById("bulkPrintFeeDueMessage").outerHTML;
	
		var mywindow = window.open('', '', 'width=800,height=600');
		mywindow.document.write('<html><head><title>Print</title>');
	
		// Add styles for printing
		mywindow.document.write('<style>@media print { body { font-family: Arial, sans-serif; } .question-paper-div { padding: 1%; } .question-paper-div-header { border: 3px solid; } .column { display: flex; } .col-md-3, .col-md-2 { flex: 0 0 25%; } .col-md-9 { width: 75%; } }</style>');
	
		mywindow.document.write('</head><body>');
	
		mywindow.document.write(printContent);
	
		mywindow.document.write('</body></html>');
	
		mywindow.document.close();
		mywindow.print();
	};
	
	
	



});
