projectModule.controller('instituteReportCardController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;

	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.branchId=localStorage.getItem("bnchId");
	$scope.schemaName=localStorage.getItem("sname");
	$scope.userId=localStorage.getItem("userId");
	$scope.termName="";

	$scope.reportCardsInit=function(){
		$scope.getCourseByBranchId();
	}


	$scope.getCourseByBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.courseList = data.Courses;

	    }
	  });
	}

	$scope.courseSelect = function(selectedCourse){

		if (typeof selectedCourse=='string')
			$scope.selectedCourseOb = JSON.parse(selectedCourse);
			else
			$scope.selectedCourseOb = selectedCourse;

		$scope.selectedCourseId=$scope.selectedCourseOb.courseId;
		$scope.selCourseName=$scope.selectedCourseOb.courseName;
		httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourseId+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			$scope.selCourse=selectedCourse;
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
			}

		});
	}

	$scope.courseClassSelect = function(classOb){
//		alert("selected");
//		$scope.getInstTestTypes();
		console.log(classOb);
		if (typeof classOb=='string')
			$scope.selectedClassOb = JSON.parse(classOb);
			else
			$scope.selectedClassOb = classOb;

		$scope.selectedClassId=$scope.selectedClassOb.classId;
		$scope.getAssignedClassCourseExams();


	}

	$scope.getAssignedClassCourseExams=function(){

		var params = {
				"classId":$scope.selectedClassId,
				"courseId":$scope.selectedCourseId,
				"schemaName":$scope.schemaName
		}
		httpFactory.executePost("getAssignedClassCourseExams", params, function(data) {
			 // alert("in");
			 console.log(data);
				if (data.StatusCode == "200") {
					console.log(data);
					$scope.assignedTests = data.AssignedClassCourseExams;

					if($scope.assignedTests.length>0){
						$scope.selectedTermId = $scope.assignedTests[0].instTestTermId;
					}else{
						alert("No Records");
					}

				} else {
					// $scope.closePopUpHW();
					$scope.assignedTests="";
					alert(data.MESSAGE);
				}
			});
	}

	$scope.getTestByTerm=function(test){

		$scope.selectedTermId=test.instTestTermId;
		alert($scope.selectedTermId);
		console.log(test);
	}

	$scope.getInstTestTypes=function(tag){

		httpFactory.getResult("getInstTestTypes1?schemaName="+$scope.schemaName, function(data) {
		    console.log(data);
		    if (data.StatusCode == 200) {
		      $scope.examList = data.InstTestTypes;
		      if(!$scope.selectedTermId){
		      $scope.selectedTermId=$scope.examList[0].testTermId;
		      $scope.selectedTerm($scope.examList[0]);
		      }
		      else{
		      for(var i=0;i<$scope.examList.length;i++){
		    	  if($scope.examList[i].testTermId==$scope.selectedTermId){
				      $scope.selectedTerm($scope.examList[i]);
				      break;
		    	  }
		      }
		    }
		      alert(tag);
		      if(tag){
		    	  for(var i=0;i<$scope.examList.length;i++){
			    	for(var j=0;j<$scope.examList[i].testType.length;j++){
			    		$scope.examList[i].testType[j]["selected"]=false;
			    		console.log($scope.examList[i].testType[j]);
			    	}
			      }
		      }
		    }
		  });
	}

	$scope.assignTests=function(){
		$scope.getInstTestTypes("tag");
		$("#addTests").modal("show");
	}

	$scope.checkTestsToUpdate=function(outer,inner){

		console.log($scope.examList);
		if($scope.examList[outer].testType[inner].selected==false)
			$scope.examList[outer].testType[inner].selected=true;
		else if($scope.examList[outer].testType[inner].selected==true)
			$scope.examList[outer].testType[inner].selected=false;

		console.log($scope.examList);
	}

	$scope.addClassCourseExams=function(){

		$scope.ccExamArray=[];
		for(var i=0;i<$scope.examList.length;i++){
			console.log($scope.examList[i]);
			for(var j=0;j<$scope.examList[i].testType.length;j++){

				if($scope.examList[i].testType[j].selected==true){
				var ob = {
						"instTestType":$scope.examList[i].testType[j].instTestTypeId,
						"classId":3,
						"courseId":5,
						"classCourseExamId":0
				}
				$scope.ccExamArray.push(ob);
				}
			}
		}

		var params ={
				"schemaName":$scope.schemaName,
				"createdBy":$scope.userId,
				"classCourseExams":$scope.ccExamArray
		}
		httpFactory.executePost("addClassCourseExams", params, function(data) {
			 // alert("in");
			 console.log(data);
				if (data.StatusCode == "200") {
					alert(data.MESSAGE);
				} else {
					// $scope.closePopUpHW();
					alert(data.MESSAGE);
				}
			});
	}



	$scope.selectedTerm=function(exam){
		$scope.examTerm=exam;
		$scope.testList=[];
		$scope.testList=exam.testType;
		console.log($scope.testList);

		$scope.selectedTermId=exam.testTermId;
	}

	$scope.addTerm=function(){

		if($scope.termName.trim().length==0 || !$scope.startDate || !$scope.endDate){
			alert("Enter All Fields");
		}else{
			$scope.strtDate = formatDate($scope.startDate);
			$scope.endDt = formatDate($scope.endDate);
		var params = {
				"termName":$scope.termName,
				"startDate":$scope.strtDate,
				"endDate":$scope.endDt,
				"createdBy":$scope.userId,
				"schemaName":$scope.schemaName
				}

		console.log(params);
			httpFactory.executePost("addTestTerms", params, function(data) {
			 // alert("in");
			 console.log(data);
				if (data.StatusCode == "200") {
					$("#addTerms").modal("hide");
					$scope.termName="";
				} else {
					// $scope.closePopUpHW();
					alert(data.MESSAGE);
				}
			});
		}
	}

	$scope.addNewTest=function(){
		$("#addNewTest").modal("show");
	}

	$scope.hidePopUp = function(){
		$("#addTerms").modal("hide");
		$("#addNewTest").modal("hide");

	}
	$scope.testTypeName="";
	$scope.addInstTestType = function(){

		if($scope.testTypeName.trim().length==0){
			alert("Enter test type");

		}else{
		 var params= {
				"schemaName":$scope.schemaName,
				"createdBy":$scope.userId,
				"testTypeName":$scope.testTypeName,
				"instTestTermId":$scope.examTerm.testTermId
			}

		 console.log(params);
			httpFactory.executePost("addInstTestTypes", params, function(data) {
			 // alert("in");
			 console.log(data);
				if (data.StatusCode == "200") {
					$scope.hidePopUp();
					$scope.testTypeName="";
					$scope.getInstTestTypes();
				} else {
					// $scope.closePopUpHW();
					alert(data.MESSAGE);
				}
			});
	}
	}

//	$scope.getInstTestTerms=function(){
//		httpFactory.getResult("getInstTestTerms?schemaName="+$scope.schemaName, function(data) {
//		    console.log(data);
//		    if (data.StatusCode == 200) {
//
//		    	 $scope.examList = data.InstTestTypes;
//			      $scope.selectedTermId=$scope.examList[0].testTermId;
//		    }
//		  });
//	}

	$scope.openAddTermModal=function(){
		$("#addTerms").modal("show");

	}

	function formatDate(date) {
	    var d = new Date(date),
	        month = '' + (d.getMonth() + 1),
	        day = '' + d.getDate(),
	        year = d.getFullYear();

	    if (month.length < 2)
	        month = '0' + month;
	    if (day.length < 2)
	        day = '0' + day;

	    return [year, month, day].join('-');
	}
});
