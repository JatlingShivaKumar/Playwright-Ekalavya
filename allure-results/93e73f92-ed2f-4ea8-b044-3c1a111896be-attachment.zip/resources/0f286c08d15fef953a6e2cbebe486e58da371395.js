projectModule.controller('publishTestController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.instituteName = localStorage.getItem("instName");
 $scope.selBrName = localStorage.getItem("bnchnme");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };
 $scope.brnchSections = [];
 $scope.generate = false;
 $scope.configComplete = true;
 $scope.showPreview = true;
 $scope.assignArr=[];
 $scope.schemaName = localStorage.getItem("sname");
 $scope.testTypeTag=$routeParams.status;
 $scope.publishInit=function(){
	$scope.getTestInfo();
	$scope.getTestQuestions();
	$scope.getBranchCourseClassSectionsForTest();
 }

$scope.getTestQuestions = function(){
	var schema = $scope.schemaName;
	if(schema == undefined || schema == "" ){
		schema = $routeParams.testSchema;
	}
	
	console.log("Schemaaaaaa: "+schema);
  httpFactory.getResult("getTestQuestions?schemaName="+schema+ "&testId="+$routeParams.testId, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
        $scope.questionList = data.testQuestions;
        console.log($scope.questionList);
    } else {
      console.log("No courses");
    }
  });
}

$scope.getTestInfo = function() {
  httpFactory.getResult("getTestInfo?schemaName="+localStorage.getItem("sname") +"&testId="+$routeParams.testId , function(data) {
    console.log(data);
    if (data.StatusCode == 200){
        $scope.testInfo = data;
    } else {
    	console.log("Error Occured!");
    }
  });
}
$scope.startDate ;
$scope.endDate ;
 $scope.publishTest = function() {
	$scope.startDate = $("#startDate").val();
	$scope.endDate = $("#endDate").val();

	 if($scope.brnchSectionsSelDump.length == 0 || $scope.startDate == "" || $scope.startDate == undefined || $scope.endDate == undefined || $scope.endDate == ""){
		 alert("please select students and Dates");
		return;
	 }
	   var questionList='';
	   var sectionList = "";
	   var groupList = "";
   var isValid = true;
    isValid=true;
     var testParams = {
		"testId":$routeParams.testId,//test_id
		"schemaName":localStorage.getItem("sname"),
   	"testStartDate":$scope.startDate,
		"testEndDate":$scope.endDate,
		"updatedBy":localStorage.getItem("userId"),
		"isActive":1,
		"insertRecords": $scope.assignArr
     };
     console.log(testParams);
     httpFactory.executePost("publishTest", testParams, function(data) {
       console.log(data);
       if (data.STATUS == 'SUCCESS') {
         alert('Test Published')
         if(localStorage.getItem("RD") == 1 || localStorage.getItem("RD") == 2){
        	 $location.path("exams");
         }
         else if(localStorage.getItem("RD") == 3){
        	 $location.path("/tExams");
         }
       } else {
         //alert('There was a problem saving test. Please try again later.');
       }
     });
   }


// $scope.getBranchCourseClassSections = function(){
//   httpFactory.getResult("getAllBranchClassCourseSections?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id"), function(data) {
// 		console.log(data);
// 		if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
// 			// $scope.academicList = data.Classes;
//       $scope.brnchSections=data.collegesInfo;
//       console.log($scope.brnchSections);
//
// 		}
// 		 else {
// 		}
// 	});
// }

$scope.rePublishTest=function(){
  $scope.startDate = $("#startDate").val();
	$scope.endDate = $("#endDate").val();
	 console.log($scope.startDate);
	 console.log($scope.endDate);
   $scope.rePublishTestName=document.getElementById("testName").value;
   if($scope.rePublishTestName == "" || $scope.rePublishTestName == undefined){
     alert("Please Enter Test Name");
     return true;
   }
	 if($scope.brnchSectionsSelDump.length == 0 || $scope.startDate == "" || $scope.startDate == undefined || $scope.endDate == undefined || $scope.endDate == ""){
		 alert("please select students and Dates");
		return;
	 }
	   var questionList='';
	   var sectionList = "";
	   var groupList = "";
   var isValid = true;
    isValid=true;
     var testParams = {
		"testId":$routeParams.testId,//test_id
    "testName":$scope.rePublishTestName,
		"schemaName":localStorage.getItem("sname"),
   	"testStartDate":$scope.startDate,
		"testEndDate":$scope.endDate,
		"updatedBy":localStorage.getItem("userId"),
		"isActive":1,
    "createdBy":localStorage.getItem("userId"),
		"insertRecords": $scope.assignArr
     };
     console.log(testParams);
     httpFactory.executePost("rePublishTest", testParams, function(data) {
       console.log(data);
       if (data.STATUS == 'SUCCESS') {
         alert('Test Published')
         $location.path("exams");
       } else {
         //alert('There was a problem saving test. Please try again later.');
       }
     });
   }

$scope.getBranchCourseClassSectionsForTest = function(){
  httpFactory.getResult("getAllBranchClassCourseSectionsForTest?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id")+"&roleId="+localStorage.getItem("RD")+"&userId="+localStorage.getItem("userId")+"&branchId="+localStorage.getItem("bnchId")+"&testId="+$routeParams.testId, function(data) {
   console.log(data);
   if (data.StatusCode==200) {
      $scope.brnchSections=data.testSectionsObj;
      console.log($scope.brnchSections);
      for(var i=0; i<$scope.brnchSections.length; i++ ){
  				for(var j=0; j<$scope.brnchSections[i].courses.length; j++){
  						for(var k=0; k<$scope.brnchSections[i].courses[j].classes.length; k++){
  								for(var l=0; l<$scope.brnchSections[i].courses[j].classes[k].sections.length; l++){
                    if ($scope.testTypeTag!='republish') {

  									if($scope.brnchSections[i].courses[j].classes[k].sections[l].testAssignmentId!='0'){

                    var obj={
                  		"classId":$scope.brnchSections[i].courses[j].classes[k].classId,
                  		"courseId":$scope.brnchSections[i].courses[j].courseId,
                  		"branchId":$scope.brnchSections[i].branchId,
                  		"sectionId":$scope.brnchSections[i].courses[j].classes[k].sections[l].sectionId,
                  		"branchName":$scope.brnchSections[i].branchName,
                  		"courseName":$scope.brnchSections[i].courses[j].courseName,
                  		"className":$scope.brnchSections[i].courses[j].classes[k].className,
                  		"sectionName":$scope.brnchSections[i].courses[j].classes[k].sections[l].sectionName,
                  		"createdBy":localStorage.getItem("userId")
                  	}
                      $scope.updateSelectedSecTreeView(obj);
  									}
  								}else{
                    $scope.brnchSections[i].courses[j].classes[k].sections[l].testAssignmentId='0';
                  }
              }
            }
          }
        }
      }
    else {
   }
 });
}

$scope.selectedSections=function(branchId,branchName,courseId,courseName,classId,className,sectionId,sectionName){
	$scope.found=0;
	var obj={
		"classId":classId,
		"courseId":courseId,
		"branchId":branchId,
		"sectionId":sectionId,
		"branchName":branchName,
		"courseName":courseName,
		"className":className,
		"sectionName":sectionName,
		"createdBy":localStorage.getItem("userId")
	}

	if ($scope.assignArr.length==0) {
	  $scope.found=2;
	  $scope.assignArr.push(obj);
	  $scope.updateBrnchSections(obj,true);
	}else{
	  for(i=0;i<$scope.assignArr.length;i++){
		if($scope.assignArr[i].branchId == branchId && $scope.assignArr[i].courseId == courseId && $scope.assignArr[i].classId == classId && $scope.assignArr[i].sectionId == sectionId){
		  $scope.found=1;
		  $scope.assignArr.splice(i,1);
			$scope.updateBrnchSections(obj,false);
		  break;
		}
	  }
	}
	if ($scope.found==0) {
		$scope.assignArr.push(obj);
		$scope.updateBrnchSections(obj,true);
	}
	console.log($scope.assignArr);
	$scope.updateSelectedSecTreeView(obj);
}
$scope.brnchSectionsSelDump = [];
$scope.updateSelectedSecTreeView = function(obj){
  console.log(obj);
  console.log($scope.brnchSectionsSelDump);
	if($scope.brnchSectionsSelDump.length == 0){
		var brchObj =
		{
			'branchId':obj.branchId,
			'branchName':obj.branchName,
			'courses':[
				{
				'courseId': obj.courseId,
				'courseName': obj.courseName,
				'classes':[
					{
						'classId': obj.classId,
						'className':obj.className,
						'sections':[
							{
								'sectionId': obj.sectionId,
								'sectionName':obj.sectionName
							}
						]
					}
				]

				}
			]
		};
		$scope.brnchSectionsSelDump.push(brchObj);
	}
	else
	{
		var sectionfound=0;
		var branchFound =  0;
		var courseFound = 0;
		var classFound = 0
		for(var i=0; i<$scope.brnchSectionsSelDump.length; i++ ){
			if($scope.brnchSectionsSelDump[i].branchId == obj.branchId){
				branchFound =1;
				for(var j=0; j<$scope.brnchSectionsSelDump[i].courses.length; j++){
					if($scope.brnchSectionsSelDump[i].courses[j].courseId == obj.courseId){
						courseFound =1;
						for(var k=0; k<$scope.brnchSectionsSelDump[i].courses[j].classes.length; k++){
							if($scope.brnchSectionsSelDump[i].courses[j].classes[k].classId == obj.classId){
								classFound =1;
								for(var l=0; l<$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length; l++){
									if(	$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
										sectionfound = 1;
										$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.splice(l,1);

									}
								}
								if(sectionfound == 1){
									if($scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length==0){
										$scope.brnchSectionsSelDump[i].courses[j].classes.splice(k,1);
									}
								}
								else if(sectionfound == 0){
									var secObj = {
										'sectionId': obj.sectionId,
										'sectionName':obj.sectionName
									};
									$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.push(secObj);
								}
							}
						}
						if(classFound == 0){
							var clsObj = {
								'classId': obj.classId,
								'className':obj.className,
								'sections':[
									{
										'sectionId': obj.sectionId,
										'sectionName':obj.sectionName
									}
								]
							};
							$scope.brnchSectionsSelDump[i].courses[j].classes.push(clsObj);
						}
						else if(classFound ==1){
							if($scope.brnchSectionsSelDump[i].courses[j].classes.length == 0){
								$scope.brnchSectionsSelDump[i].courses.splice(j,1);
							}
						}

					}
				}
				if(courseFound == 0){
					var cursObj = {
						'courseId': obj.courseId,
						'courseName': obj.courseName,
						'classes':[
							{
								'classId': obj.classId,
								'className':obj.className,
								'sections':[
									{
										'sectionId': obj.sectionId,
										'sectionName':obj.sectionName
									}
								]
							}
						]

					}
					$scope.brnchSectionsSelDump[i].courses.push(cursObj);
				}else if(courseFound == 1){
					if($scope.brnchSectionsSelDump[i].courses.length == 0){
						$scope.brnchSectionsSelDump.splice(i,1);
					}
				}
			}
		}
		if(branchFound == 0){
				var brObj = {
				'branchId':obj.branchId,
				'branchName':obj.branchName,
				'courses':[
					{
					'courseId': obj.courseId,
					'courseName': obj.courseName,
					'classes':[
						{
							'classId': obj.classId,
							'className':obj.className,
							'sections':[
								{
									'sectionId': obj.sectionId,
									'sectionName':obj.sectionName
								}
							]
						}
					]

					}
				]
			};
			$scope.brnchSectionsSelDump.push(brObj);
		}
	}
  console.log($scope.brnchSectionsSelDump);
}
$scope.updateBrnchSections = function(obj, boolValue){
	for(var i=0; i<$scope.brnchSections.length; i++ ){
		if($scope.brnchSections[i].branchId == obj.branchId){
			for(var j=0; j<$scope.brnchSections[i].courses.length; j++){
				if($scope.brnchSections[i].courses[j].courseId == obj.courseId){
					for(var k=0; k<$scope.brnchSections[i].courses[j].classes.length; k++){
						if($scope.brnchSections[i].courses[j].classes[k].classId == obj.classId){
							for(var l=0; l<$scope.brnchSections[i].courses[j].classes[k].sections.length; l++){
								if(	$scope.brnchSections[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
									$scope.brnchSections[i].courses[j].classes[k].sections[l].isSelected = boolValue;
								}
							}
						}
					}
				}
			}
		}
	}
}
$scope.selectedGroupSubj ="";
$scope.showQuesbjWise = function(sbj){
	$scope.selectedGroupSubj = sbj;
}

//edit question in exampublish.html

$scope.editQuestion = function(question,index){
  $scope.questionOb = question;
 console.log($scope.questionOb);
  $scope.questId=question.questionId;
  $scope.questionAdv=question.question;
  console.log($scope.question);
  $scope.option1=question.option1;
  $scope.option2=question.option2;
  $scope.option3=question.option3;
  $scope.option4=question.option4;
  $scope.explanation=question.explanation;
  $scope.correctAnswer=question.correctAnswer;
  $scope.diffLevel=question.difficultyLevel;
  console.log(question.difficultyLevel);
  document.getElementById('diffLevel').value = question.difficultyLevel;

  $scope.questionType=question.questType;
  alert($scope.questionType);
  if($scope.questionType=='FIB'){
    $scope.FIBAnswer=question.correctAnswer;
  }else if($scope.questionType=='TOF'){
    $scope.correctAnswer=question.correctAnswer;
   }
   else if($scope.questionType=='MFQ'){
     console.log(question.questions);
     CKEDITOR.instances['editcolumn1a'].setData(question.questions[0].ColumnA);
     $scope.editcolumn1a = question.questions[0].ColumnA;
     CKEDITOR.instances['column2a'].setData(question.questions[1].ColumnA);
     $scope.column2a = question.questions[1].ColumnA;
     CKEDITOR.instances['column3a'].setData(question.questions[2].ColumnA);
     $scope.column3a = question.questions[2].ColumnA;
      if(question.questions.length > 3){
        CKEDITOR.instances['column4a'].setData(question.questions[3].ColumnA);
        $scope.column4a = question.questions[3].ColumnA;
    }
      if(question.questions.length > 4){
     CKEDITOR.instances['column5a'].setData(question.questions[4].ColumnA);
     $scope.column5a = question.questions[4].ColumnA;
   }
     console.log($scope.column4a);

     CKEDITOR.instances['column1b'].setData(question.questions[0].ColumnB);
     $scope.column1b = question.questions[0].ColumnB;
     CKEDITOR.instances['column2b'].setData(question.questions[1].ColumnB);
     $scope.column2b = question.questions[1].ColumnB;
     CKEDITOR.instances['column3b'].setData(question.questions[2].ColumnB);
     $scope.column3b = question.questions[2].ColumnB;
     if(question.questions.length > 3){
       CKEDITOR.instances['column4b'].setData(question.questions[3].ColumnB);
       $scope.column4b = question.questions[3].ColumnB;
     }
     if(question.questions.length > 4){
       CKEDITOR.instances['column5b'].setData(question.questions[4].ColumnB);
       $scope.column5b = question.questions[4].ColumnB;
     }

     $scope.correctAnswer = question.correctAnswer;
     var mfCrAnsList = question.correctAnswer.split(',');
     $scope.MFQ1 = mfCrAnsList[0].split('-')[1];
     if(mfCrAnsList.length>1){
       $scope.MFQ2 = mfCrAnsList[1].split('-')[1];
     }
     if(mfCrAnsList.length>2){
       $scope.MFQ3 = mfCrAnsList[2].split('-')[1];
     }
     if(mfCrAnsList.length>3){
       $scope.MFQ4 = mfCrAnsList[3].split('-')[1];
     }
     if(mfCrAnsList.length> 4){
       $scope.MFQ5 = mfCrAnsList[4].split('-')[1];
     }
     }else if($scope.questionType=='ITQ'){
       $scope.itqCorrectAns=question.correctAnswer;
     }
     $scope.diffLevel=question.difficultyLevel;
  $("#editAdvQuestion").modal("show");
}
$scope.selectedTestSection = {};
$scope.addAdvTestQuestion = function(){
  console.log($scope.selectedTestSection);
  if(typeof $scope.selectedTestSection == 'string'){
    $scope.selectedTestSection = JSON.parse($scope.selectedTestSection);
  }
  $scope.questionAdv = CKEDITOR.instances['questionAdv'].getData();
  $scope.option1 = "";
  $scope.option2 = "";
  $scope.option3 = "";
  $scope.option4 = "";
  $scope.explanation = CKEDITOR.instances['explanation'].getData();
  if ($scope.questionType=='MAQ') {
    $scope.maqCrct="";
    for (var i = 0; i < $scope.multiCorrectAnswer.length; i++) {
      if ($scope.maqCrct=="") {
          $scope.maqCrct=$scope.multiCorrectAnswer[i];
      }else{
        $scope.maqCrct +=','+$scope.multiCorrectAnswer[i];
      }
      $scope.correctAnswer=$scope.maqCrct;
    }
  }else{
    $scope.correctAnswer = $("#correctAnswer").val();
  }
  $scope.questionCat = $("#questionCategory").val();
  $scope.diffLevel = $("#diffLevel").val();
  $scope.qstnAppeared = $("#questionAppeared").val();
  $scope.selectedSchema=localStorage.getItem("addQuescontentOwner");
  if ($scope.questionType == 'MCQ' || $scope.questionType == 'MAQ') {
    $scope.option1 = CKEDITOR.instances['option1'].getData();
    $scope.option2 = CKEDITOR.instances['option2'].getData();
    $scope.option3 = CKEDITOR.instances['option3'].getData();
    $scope.option4 = CKEDITOR.instances['option4'].getData();
  }
  else if ($scope.questionType == 'TOF') {
    $scope.correctAnswer=$scope.TFOption;
    console.log($scope.correctAnswer);
  }else if($scope.questionType == 'ITQ'){
    $scope.option1 = CKEDITOR.instances['option1'].getData();
    $scope.correctAnswer=$scope.itqCorrectAns;
  }else if($scope.questionType=='FIB'){
    $scope.correctAnswer=$scope.FIBAnswer;
  }else if($scope.questionType == 'MFQ'){
    $scope.correctAnswer="NA";
    $scope.correctAnswer="1-"+$scope.MFQ1+","+"2-"+$scope.MFQ2+","+"3-"+$scope.MFQ3;
    if($scope.MFQ4)
    $scope.correctAnswer=$scope.correctAnswer+","+"4-"+$scope.MFQ4;

    if($scope.MFQ5)
    $scope.correctAnswer=$scope.correctAnswer+","+"5-"+$scope.MFQ5;

    console.log($scope.correctAnswer);

    $scope.column1a = CKEDITOR.instances['column1a'].getData();
    $scope.column2a = CKEDITOR.instances['column2a'].getData();
    $scope.column3a = CKEDITOR.instances['column3a'].getData();
    $scope.column4a = CKEDITOR.instances['column4a'].getData();
    $scope.column5a = CKEDITOR.instances['column5a'].getData();

    console.log($scope.column4a);

    $scope.column1b = CKEDITOR.instances['column1b'].getData();
    $scope.column2b = CKEDITOR.instances['column2b'].getData();
    $scope.column3b = CKEDITOR.instances['column3b'].getData();
    $scope.column4b = CKEDITOR.instances['column4b'].getData();
    $scope.column5b = CKEDITOR.instances['column5b'].getData();

    if($scope.column4a.length<=0){
        $scope.column4b="NA";
        $scope.column4a="NA";
    }
    if($scope.column5a.length<=0){
        $scope.column5b="NA";
        $scope.column5a="NA";
    }
  }

  if($scope.questionAdv == undefined || $scope.questionAdv  == ""){
    alert("Please Add question");
    return true;
  }
  if($scope.correctAnswer == undefined || $scope.correctAnswer == ""){
    alert("Please select correct answer");
    return true;
  }
  // if($scope.questionCat == undefined || $scope.questionCat == ""){
  //   alert("Please select question type");
  //   return true;
  // }
  if($scope.diffLevel == undefined || $scope.diffLevel == ""){
    alert("Please select Difficulty Level");
    return true;
  }
  if (!$scope.qstnAppeared) {
    $scope.qstnAppeared = "";
  }
  if ($scope.questionType=='MFQ') {
    if (!$scope.MFQ4) {
      $scope.MFQ4="NA";
    }
    if (!$scope.MFQ5) {
      $scope.MFQ5="NA";
    }
    var requestParams = {
      "schemaName":$scope.schemaName,
      "insertRecords": [{
        "testId": $routeParams.testId,
        "schemaName":localStorage.getItem("sname"),
        "instId" :  $scope.instituteId,
        "repo":localStorage.getItem("sname"),
        "question": $scope.questionAdv,
        "explanation": $scope.explanation,
        "correctAnswer": $scope.correctAnswer,
        "questionType": $scope.questionType,
        "topicId": $scope.questionOb.topicId ,
        "subjectId": $scope.questionOb.subjectId ,
        "chapterId": $scope.questionOb.chapterId,
        "difficultyLevel": $scope.diffLevel,
        "contentOwner": $scope.questionOb.contentOwner,
        "questionAppearedIn": $scope.qstnAppeared,
        "questType": $scope.questionOb.questionType,
         "testSectionName":$scope.selectedTestSection.testSectionName,
         "testSectionId":$scope.selectedTestSection.testSectionId,
        "createdBy": localStorage.getItem("userId"),
        "options":[
      {
        "columnA":$scope.column1a,
        "columnB":$scope.column1b,
        "correctAnswer":$scope.MFQ1
      },
      {
        "columnA":$scope.column2a,
        "columnB":$scope.column2b,
        "correctAnswer":$scope.MFQ2
      },	{
        "columnA":$scope.column3a,
        "columnB":$scope.column3b,
        "correctAnswer":$scope.MFQ3
      },	{
          "columnA":$scope.column4a,
          "columnB":$scope.column4b,
          "correctAnswer":$scope.MFQ4
        },	{
            "columnA":$scope.column5a,
            "columnB":$scope.column5b,
            "correctAnswer":$scope.MFQ5
            }
        ]
      }]
    }
    console.log(requestParams);
  }
  else
  {
    var requestParams = {
     "schemaName":$scope.schemaName,
     "insertRecords": [{
       "testId": $routeParams.testId,
       "schemaName":localStorage.getItem("sname"),
       "instId":$scope.instituteId,
       "repo":localStorage.getItem("sname"),
       "question": $scope.questionAdv,
       "option1": $scope.option1,
       "option2": $scope.option2,
       "option3": $scope.option3,
       "option4": $scope.option4,
       "explanation": $scope.explanation,
       "correctAnswer": $scope.correctAnswer,
       "questionType": $scope.questionType,
       "topicId": $scope.questionOb.topicId ,
       "subjectId": $scope.questionOb.subjectId ,
       "chapterId": $scope.questionOb.chapterId,
       "difficultyLevel": $scope.diffLevel,
       "contentOwner": "COLLEGE",
       "questionAppearedIn": $scope.qstnAppeared,
       "questType": $scope.questionOb.questionType,
       "testSectionName":$scope.selectedTestSection.testSectionName,
       "testSectionId":$scope.selectedTestSection.testSectionId,
       "createdBy": localStorage.getItem("userId")
     }]
   }
  }
  console.log(requestParams);
httpFactory.executePost("addTestQuestion", requestParams, function(data) {
  console.log(data);
 if (data.STATUS == 'SUCCESS') {
  alert("Success.Test question added");

  $scope.question = CKEDITOR.instances['question'].setData('');
  $scope.option1 = CKEDITOR.instances['option1'].setData('');
  $scope.option2 = CKEDITOR.instances['option2'].setData('');
  $scope.option3 = CKEDITOR.instances['option3'].setData('');
  $scope.option4 = CKEDITOR.instances['option4'].setData('');
  $scope.explanation = CKEDITOR.instances['explanation'].setData('');
  $('#correctAnswer').prop('selectedIndex', 0);
  // $('#questionCat').prop('selectedIndex',0);
  $('#diffLevel').prop('selectedIndex', 0);
  $('#testSubject').prop('selectedIndex', 0);
  $('#testChapter').prop('selectedIndex', 0);
  $('#testTopic').prop('selectedIndex', 0);

  window.scrollTo(0, 0);
  $("#addQuestion").modal("hide");
  $scope.questionList.push(requestParams.insertRecords[0]);
  $scope.getCustomTestDetails();
  $scope.generateQuestionObj();
}
else{
  alert("something went wrong");
}
});
}

$scope.randomQuestion=function(question){
  if (question.contentOwner=='CEDZ') {
      //$scope.questionSchema='rankr';
 	$scope.questionSchema=$scope.schemaName;
  }else{
      $scope.questionSchema=$scope.schemaName;
  }
  var requestParams = {
    "schemaName":$scope.schemaName,
      "testId": $routeParams.testId,
      "topicId": question.topicId,
      "questionId":question.questionId,
      "questionSchemaName":$scope.questionSchema
}
console.log(requestParams);

httpFactory.getResult("getRandomTopicQuestion?schemaName="+localStorage.getItem("sname")+ "&testId="+$routeParams.testId+"&topicId="+question.topicId+"&questionId="+question.questionId+"&questionSchemaName="+$scope.questionSchema, function(data) {
  console.log(data);
  if (data.StatusCode == 200) {
  } else {
    console.log("No courses");
  }
});
}

//multiple variable log parameters
// 	var sureshlog = (function () {
//     return {
//         log: function() {
//             var args = Array.prototype.slice.call(arguments);
//             console.log.apply(console, args);
//         },
//         warn: function() {
//             var args = Array.prototype.slice.call(arguments);
//             console.warn.apply(console, args);
//         },
//         error: function() {
//             var args = Array.prototype.slice.call(arguments);
//             console.error.apply(console, args);
//         }
//     }
// };

$scope.addStudentButton = function(){
    $("#addStudents").modal("show");
}
$scope.closeAddStudentsPopUp = function(){
  $("#addStudents").modal("hide");
}
 $("#startDateContainer").datetimepicker({
        format: "yyyy:mm:dd hh:ii",
        autoclose: true,
		     startDate : new Date(),
        todayHighlight: true

    }).on('changeDate', function(ev){
		    console.log(ev.date);
      $("#endDatecontainer").datetimepicker({
        format: "yyyy:mm:dd hh:ii",
        autoclose: true,
		    startDate : new Date(ev.date),
        todayHighlight:false

    });

});


$scope.printTestName = "";

$scope.printQpaper = function(){

  var mywindow = window.open('', '', '','');
      mywindow.document.write('<!doctype html> <html><head><title></title>');
      mywindow.document.write('<style>.optionSize{display:inline-block;width: auto;min-width:23%;	padding-right: 20px; vertical-align: text-top;} .optionSize>div>p,.optionSize>div,.quesPara>span>p,.quesPara>span,.quesPara>span>p{display: inline-block;font-size:12px;margin:0;padding:0}</style>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(document.getElementById("question-paper-div").innerHTML);
      mywindow.document.write('</body></html>');

      mywindow.print();
      mywindow.close();
}
$scope.downloadKeyPaper = function(){
    var mywindow = window.open('', '', '','');
    mywindow.document.write('<!doctype html> <html><head><title></title>');
    mywindow.document.write('<style>.optionSize{display:inline-block;width: auto;min-width:23%;	padding-right: 20px; vertical-align: text-top;} .optionSize>div>p,.optionSize>div,.quesPara>span>p,.quesPara>span,.quesPara>span>p{display: inline-block;font-size:12px;margin:0;padding:0}</style>');
    mywindow.document.write('</head><body >');
    mywindow.document.write(document.getElementById("questionPaperKey").innerHTML);
    mywindow.document.write('</body></html>');
    mywindow.print();
    mywindow.close();
 }

 $scope.sortSubjWisseQuestion = function(){
   var tmp = []
   for (i = 0; i < $scope.questionList.length; i++) {


    tmp[i] = $scope.questionList[i];
    var cAns = "";
    if(tmp[i].questType == 'MFQ'){

      for(var j=0; j<tmp[i].questions.length; j++){
        if(cAns == ""){
          cAns = tmp[i].questions[j].correctAnswer ;
        }else{
          cAns = cAns +","+ tmp[i].questions[j].correctAnswer ;
        }
      }
      tmp[i].correctAnswer = cAns;
    }

   }
   $scope.subjectWiseArray = quesgroupBy(tmp, function(item) {
    return [item.subjectId];
   });
   console.log($scope.subjectWiseArray);
   if($scope.testTypeTag != 'republish'){
     $scope.printTestName = $scope.testInfo.testName;
   }
   else{
     $scope.printTestName = $scope.rePublishTestName;
   }
 }

 function quesgroupBy(array, f) {
    console.log(array);
    var groups = {};
    array.forEach(function(o) {
    var group = JSON.stringify(f(o));
    groups[group] = groups[group] || [];
    groups[group].push(o);
    });
    return Object.keys(groups).map(function(group) {
    return groups[group];
    })
  }



});
