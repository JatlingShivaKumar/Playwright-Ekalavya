projectModule.controller('adminStoreStudentDashboard', function ($scope, $location) {
    $scope.$ = $;
    $scope.redirectToStoreStudentData = function (loc) {
        $location.path(loc);
    }
});