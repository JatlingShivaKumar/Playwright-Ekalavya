projectModule.controller('manageMembersController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.schemaName=localStorage.getItem("sname");
	$scope.branchId=localStorage.getItem("bnchId");
	$scope.adminRoleId = localStorage.getItem("RD");
	$scope.user_id = localStorage.getItem("userId");
	$scope.userList =  [];
	$scope.newMemMailId = "";
	$scope.getAllUsers = function(){
		httpFactory.getResult("getAllUsersDetails?branchId=" +$scope.branchId+"&schemaName="+$scope.schemaName+"&roleId="+$scope.adminRoleId+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				$scope.userList = data.UserObject;
				for(var i=0; i<$scope.userList.length; i++){
          if($scope.userList[i].profilePic == 'NA'){
            $scope.userList[i].profilePicPath = "";
          }
          else{
            $scope.userList[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/userProfileDownload?filePath="+$scope.userList[i].profilePic;
          }
        }
			}
		});
	}
	$scope.getAllUsers();
	$scope.roles =[];

	$scope.getAllRoles = function(){
		httpFactory.getResult("getAllRoles?schemaName="+$scope.schemaName+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				$scope.roles = data.roleArray;
			}
		});
	}

	$scope.profile=function(obj){
		console.log(obj);
		sessionStorage.setItem("userSession","teacher");
		$location.path("profile/"+obj.userId+"/"+obj.roleId+"/"+obj.branchId);
	}
	$scope.getAllRoles();
	$scope.subjectGroupAvail =[];
	$scope.getSubjectGroups = function(){
		$scope.subjectGroupAvail =[];
		httpFactory.getResult("getSubjectGroups?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				$scope.subjectGroupAvail = data.SubGroups;
			}
		});
	}


	$scope.selectedGroupList = [];
	$scope.updateSelectedGroupList = function(){
		$scope.selectedGroupList =[];
		for(var i=0; i<document.getElementsByName('subjGrp').length;i++){
			if(document.getElementsByName('subjGrp')[i].checked == true){
				$scope.selectedGroupList.push(JSON.parse(document.getElementsByName('subjGrp')[i].value));
			}

		}
		console.log($scope.selectedGroupList);
	}
	$scope.branchList =[];
	$scope.getAllBranches = function(){
		httpFactory.getResult("getAllBranches?instId=" +$scope.instituteId+"&schemaName="+$scope.schemaName+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId"), function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				$scope.branchList = data.collegeBranches;
				console.log($scope.branchList);
			}
			 else {
			}
		});
	}
	$scope.getAllBranches();
	$scope.newMemJDate  = new Date();
	$scope.categoryType = "";
	$scope.addMemeber = function(){
		var categoryID ;

		console.log("newMemJDate" + $scope.newMemJDate);
		for(var i=0; i<document.getElementsByName("categoryType").length; i++){
			if(document.getElementsByName("categoryType")[i].checked == true){
				categoryID = document.getElementsByName("categoryType")[i].value;
			}
		}
		var selSubjcs = "";
		for(var j=0; j<$scope.selectedGroupList.length; j++){
			if(selSubjcs == ""){
				selSubjcs = $scope.selectedGroupList[j].deptId;
			}
			else{
				selSubjcs =selSubjcs+","+$scope.selectedGroupList[j].deptId;
			}
		}
		if( $scope.newMemMailId == undefined || $scope.newMemMailId == ""){
			$scope.newMemMailId = document.getElementById("memEmail").value;
		}
		console.log($scope.newMemName);
		console.log($scope.newMemMailId);
		console.log($scope.newMemTel);
		console.log($scope.selectedRole);
		console.log($scope.selectedBranch);
		console.log($scope.categoryType);


		if($scope.newMemName == "" || $scope.newMemName == null || $scope.newMemMailId == "" || $scope.newMemMailId == null || $scope.newMemTel == "" || $scope.newMemTel == null || $scope.selectedBranch == "" || $scope.selectedBranch == null || $scope.categoryType == "" || $scope.selectedRole == "" || $scope.selectedRole == null){
			alert("Add all fields");
			return true;
		}
		if($scope.selectedRole == '1'){
					alert("You cannot add SuperAdmin user");
					return true;
				}
		if($scope.phoneValidation($scope.newMemTel) == false){
			alert("Enter valid phone number");
			return true;
		}
		if($scope.emailValidation($scope.newMemMailId) == false){
			alert("Enter valid Email Id ");
			return true;
		}

		if($scope.categoryType == '2' && selSubjcs == ""){
			alert("Please select subjects");
			return true;
		}
		var date = new Date($scope.newMemJDate);
		var genMon = date.getMonth()+1;
		if(genMon < 10){
			genMon = "0"+genMon
		}
		var genDate = date.getFullYear()+"-"+genMon+"-"+date.getDate();
		var params= {
			"schemaName":$scope.schemaName,
			"createdBy":localStorage.getItem("userId"),
			"instId":$scope.instituteId,
			"branchId":$scope.selectedBranch,
			"userInfo":
			[{
				"userName":$scope.newMemName,
				"emailId":$scope.newMemMailId,
				"contactNo":$scope.newMemTel,
				"joiningDate":genDate,
				"roleId":$scope.selectedRole,
				"categoryId":categoryID,
				"subjects":selSubjcs,
				"isActive":1
			}]
		};
		console.log(params);
//	return true;
		httpFactory.executePost("createUser", params, function(data) {
		console.log(data);
		if(data.StatusCode == "200"){
			$scope.categoryType = "";
			if (confirm('User created Successfully. Proceed with Assigning Courses & Classes now')) {
				$scope.editMember(data);
			}else{
				$scope.closeAddMemeber();
				$scope.getAllUsers();
			}
		}else{
			alert("Please enter unique mobile number and email id as either of them are already in use");
		}
	});
	}
	

	$scope.phoneValidation = function(numb){
   var stripped = numb.replace(/[\(\)\.\-\ ]/g, '');
   if (stripped == "") {
        return false;
    } else if (isNaN(parseInt(stripped))) {
        return false;
    } else if (!(stripped.length == 10)) {
        return false;
    }else{
      return true;
    }
	}
	$scope.emailValidation = function(emilId){
		var myEmailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if(emilId != "" && emilId != undefined){
			return myEmailFormat.test(emilId);
		}
	}


	$scope.openAddMemeber = function(){
		$scope.newMemName = "";
		$scope.newMemTel = "";
		$scope.newMemMailId = "";
		$scope.selectedRole = "";
		$scope.selectedBranch = "";
		$scope.selectedGroupList = [];
		$scope.getSubjectGroups();
		$("#addMembers").modal("show");
	}
	$scope.closeAddMemeber = function(){
		$("#addMembers").modal("hide");
	}

	$scope.showTimetable=function(user){
		console.log(user);
		$location.path("/teacherTT/"+user.userId+"/"+user.branchId);
	}

	$scope.propertyName = 'userName';
	$scope.reverseOrd = false;
  $scope.sortByOrd = function(propertyName) {
    $scope.reverseOrd = ($scope.propertyName === propertyName) ? !$scope.reverseOrd : false;
    $scope.propertyName = propertyName;
  }
  $scope.staffDisable = function(ust){
	  
	  httpFactory.getResult("updateStaffStatus?isActive=0&user_Id="+$scope.user_id+"&schemaName="+$scope.schemaName+"&userId="+ust.userId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				alert("Successfully Disabled");
				$scope.getAllUsers();
			}else{
				alert("Unable to Disable");
			}
	  });
  }
$scope.staffEnable = function(ust){
	  
	  httpFactory.getResult("updateStaffStatus?isActive=1&user_Id="+$scope.user_id+"&schemaName="+$scope.schemaName+"&userId="+ust.userId, function(data) {
			console.log(data);
			if(data.StatusCode == "200"){
				alert("Successfully Enabled");
				$scope.getAllUsers();
			}else{
				alert("Unable to Enabled");
			}
	  });
  }
  
$scope.deleteStaff = function(ust){
		var params={
		    "deletedBy":$scope.userId,
			"userId":ust.userId,
			"schemaName":$scope.schemaName
		}
		
		httpFactory.executePost("deleteStaff",params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$("#deleteStaff").modal("hide");
				$scope.getAllUsers();
			} else {
				alert(data.MESSAGE);
			}
		});
	}
$scope.editMember = function(ust){
	$scope.getBranchCourseClassSectionsForTeacher(ust);
    $("#editTeacherCourses").modal("show");
}

$scope.closeEditCoursesPopUp = function(){
	$("#editTeacherCourses").modal("hide");
}
 $scope.brnchSectionsSelDump = [];
 $scope.getBranchCourseClassSectionsForTeacher = function(ust){
	 $scope.staffUserId = ust.userId;
	 $scope.assignArr=[];
	 $scope.selSubArr=[];
	 $scope.delSub=[];
	 httpFactory.getResult("getBranchClassCourseSectionsForTeacher?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id")+"&roleId="+localStorage.getItem("RD")+"&userId="+ust.userId+"&branchId="+localStorage.getItem("bnchId"), function(data) {
		 console.log(data);
		 if (data.StatusCode==200) {
			 $scope.brnchSections=data.testSectionsObj;
			 console.log($scope.brnchSections);
			 for(h=0;h<$scope.brnchSections.length;h++){
				 for(i=0;i<$scope.brnchSections[h].courses.length;i++){
					 for(j=0;j<$scope.brnchSections[h].courses[i].classes.length;j++){
						 for(k=0;k<$scope.brnchSections[h].courses[i].classes[j].sections.length;k++){
							 for(l=0;l<$scope.brnchSections[h].courses[i].classes[j].sections[k].subjects.length;l++){
								 if($scope.brnchSections[h].courses[i].classes[j].sections[k].subjects[l].isSelected==true) {
									 var subObj={
												"classId":$scope.brnchSections[h].courses[i].classes[j].classId,
												"courseId":$scope.brnchSections[h].courses[i].courseId,
												"branchId":$scope.brnchSections[h].branchId,
												"sectionId":$scope.brnchSections[h].courses[i].classes[j].sections[k].sectionId,
												"subjectId":$scope.brnchSections[h].courses[i].classes[j].sections[k].subjects[l].subjectId,
												"branchName":$scope.brnchSections[h].branchName,
												"courseName":$scope.brnchSections[h].courses[i].courseName,
												"className":$scope.brnchSections[h].courses[i].classes[j].className,
												"sectionName":$scope.brnchSections[h].courses[i].classes[j].sections[k].sectionName,
												"subjectName":$scope.brnchSections[h].courses[i].classes[j].sections[k].subjects[l].subjectName,
											}
									 $scope.selSubArr.push(subObj);
								 }
							}
						 }
						 
					 }
				 }
			 }
		 }
	 });
	 $scope.assignArr=[...$scope.selSubArr];
 }
 
 $scope.selectedSections=function(branchId,branchName,courseId,courseName,classId,className,sectionId,sectionName,subjectId,subjectName){
	 $scope.found=0;
		var obj={
			"classId":classId,
			"courseId":courseId,
			"branchId":branchId,
			"sectionId":sectionId,
			"subjectId":subjectId,
			"branchName":branchName,
			"courseName":courseName,
			"className":className,
			"sectionName":sectionName,
			"subjectName":subjectName,
			"createdBy":localStorage.getItem("userId")
		}

		if ($scope.assignArr.length==0) {
		  $scope.found=2;
		  $scope.assignArr.push(obj);
		  $scope.updateBrnchSections(obj,true);
		}else{
			for(i=0;i<$scope.assignArr.length;i++){
				if($scope.assignArr[i].branchId == branchId && $scope.assignArr[i].courseId == courseId && $scope.assignArr[i].classId == classId && $scope.assignArr[i].sectionId == sectionId && $scope.assignArr[i].subjectId == subjectId){
					$scope.found=1;
					for(h=0; h<$scope.selSubArr.length; h++ ){
						if(	$scope.selSubArr[h].sectionId == obj.sectionId && $scope.selSubArr[h].subjectId == obj.subjectId){
							$scope.delSub.push(obj);
						}
					}
					$scope.assignArr.splice(i,1);
					$scope.updateBrnchSections(obj,false);
					break;
				}
			}
		}
		if ($scope.found==0) {
			$scope.assignArr.push(obj);
			for(d=0; d<$scope.delSub.length; d++ ){
				for(e=0; e<$scope.assignArr.length; e++ ){
					if($scope.delSub[d].sectionId==$scope.assignArr[e].sectionId && $scope.delSub[d].subjectId==$scope.assignArr[e].subjectId){
						$scope.delSub.splice(d,1);
					}
				}
			}
			$scope.updateBrnchSections(obj,true);
		}
		console.log($scope.assignArr);
		$scope.updateSelectedSecTreeView(obj);
	}
 $scope.updateBrnchSections = function(obj, boolValue){
		for(var i=0; i<$scope.brnchSections.length; i++ ){
			if($scope.brnchSections[i].branchId == obj.branchId){
				for(var j=0; j<$scope.brnchSections[i].courses.length; j++){
					if($scope.brnchSections[i].courses[j].courseId == obj.courseId){
						for(var k=0; k<$scope.brnchSections[i].courses[j].classes.length; k++){
							if($scope.brnchSections[i].courses[j].classes[k].classId == obj.classId){
								for(var l=0; l<$scope.brnchSections[i].courses[j].classes[k].sections.length; l++){
									if(	$scope.brnchSections[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
										for(var m=0; m<$scope.brnchSections[i].courses[j].classes[k].sections[l].subjects.length; m++){
											if(	$scope.brnchSections[i].courses[j].classes[k].sections[l].subjects[m].subjectId == obj.subjectId){
												$scope.brnchSections[i].courses[j].classes[k].sections[l].subjects[m].isSelected = boolValue;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	$scope.updateSelectedSecTreeView = function(obj){
		  console.log(obj);
		  console.log($scope.brnchSectionsSelDump);
			if($scope.brnchSectionsSelDump.length == 0){
				var brchObj = {
					'branchId':obj.branchId,
					'branchName':obj.branchName,
					'courses':[
						{
						'courseId': obj.courseId,
						'courseName': obj.courseName,
						'classes':[
							{
								'classId': obj.classId,
								'className':obj.className,
								'sections':[
									{
										'sectionId': obj.sectionId,
										'sectionName':obj.sectionName,
										'subjects':[
													{
														'subjectId': obj.subjectId,
														'subjectName':obj.subjectName
													}
												]
									}
								]
							}
						]

						}
					]
				};
				$scope.brnchSectionsSelDump.push(brchObj);
			}
			else
			{
				var subjectfound = 0;
				var sectionfound = 0;
				var branchFound =  0;
				var courseFound = 0;
				var classFound = 0
				for(var i=0; i<$scope.brnchSectionsSelDump.length; i++ ){
					if($scope.brnchSectionsSelDump[i].branchId == obj.branchId){
						branchFound =1;
						for(var j=0; j<$scope.brnchSectionsSelDump[i].courses.length; j++){
							if($scope.brnchSectionsSelDump[i].courses[j].courseId == obj.courseId){
								courseFound =1;
								for(var k=0; k<$scope.brnchSectionsSelDump[i].courses[j].classes.length; k++){
									if($scope.brnchSectionsSelDump[i].courses[j].classes[k].classId == obj.classId){
										classFound =1;
										for(var l=0; l<$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length; l++){
											if(	$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].sectionId == obj.sectionId){
												sectionfound = 1;
												for(var m=0; m<$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].subjects.length; m++){
													if(	$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].subjects[m].subjectId == obj.subjectId){
														subjectfound = 1;
														$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].subjects.splice(m,1);

													}
												}
												if(subjectfound == 1){
													if($scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].subjects.length==0){
														$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.splice(l,1);
													}
												}
												else if(subjectfound == 0){
													var subObj = {
														'subjectId': obj.subjectId,
														'subjectName':obj.subjectName
													};
													$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections[l].subjects.push(subObj);
												}
											}
										}
										if(sectionfound == 1){
											if($scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.length==0){
												$scope.brnchSectionsSelDump[i].courses[j].classes.splice(k,1);
											}
										}
										else if(sectionfound == 0){
											var secObj = {
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName,
												'subjects':[
												            {
												            	'subjectId': obj.subjectId,
																'subjectName':obj.subjectName
												            }]
											};
											$scope.brnchSectionsSelDump[i].courses[j].classes[k].sections.push(secObj);
										}
									}
								}
								if(classFound == 0){
									var clsObj = {
										'classId': obj.classId,
										'className':obj.className,
										'sections':[
											{
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName,
												'subjects':[
												            {
												            	'subjectId': obj.subjectId,
																'subjectName':obj.subjectName
												            }]
											}
										]
									};
									$scope.brnchSectionsSelDump[i].courses[j].classes.push(clsObj);
								}
								else if(classFound ==1){
									if($scope.brnchSectionsSelDump[i].courses[j].classes.length == 0){
										$scope.brnchSectionsSelDump[i].courses.splice(j,1);
									}
								}

							}
						}
						if(courseFound == 0){
							var cursObj = {
								'courseId': obj.courseId,
								'courseName': obj.courseName,
								'classes':[
									{
										'classId': obj.classId,
										'className':obj.className,
										'sections':[
											{
												'sectionId': obj.sectionId,
												'sectionName':obj.sectionName,
												'subjects':[
												            {
												            	'subjectId': obj.subjectId,
																'subjectName':obj.subjectName
												            }]
											}
										]
									}
								]

							}
							$scope.brnchSectionsSelDump[i].courses.push(cursObj);
						}else if(courseFound == 1){
							if($scope.brnchSectionsSelDump[i].courses.length == 0){
								$scope.brnchSectionsSelDump.splice(i,1);
							}
						}
					}
				}
				if(branchFound == 0){
						var brObj = {
						'branchId':obj.branchId,
						'branchName':obj.branchName,
						'courses':[
							{
							'courseId': obj.courseId,
							'courseName': obj.courseName,
							'classes':[
								{
									'classId': obj.classId,
									'className':obj.className,
									'sections':[
										{
											'sectionId': obj.sectionId,
											'sectionName':obj.sectionName,
											'subjects':[
											            {
											            	'subjectId': obj.subjectId,
															'subjectName':obj.subjectName
											            }]
											
										}
									]
								}
							]

							}
						]
					};
					$scope.brnchSectionsSelDump.push(brObj);
				}
			}
		  console.log($scope.brnchSectionsSelDump);
		}
	$scope.addTeacherSub = function(obj){
		var params={
				"createdBy":localStorage.getItem("userId"),
				"userId":$scope.staffUserId,
				"schemaName":$scope.schemaName,
				"assignSubjects":$scope.brnchSectionsSelDump,
				"delSubjects":$scope.delSub
			}
		httpFactory.executePost("assignTeacherCourseClassSections",params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$("#editTeacherCourses").modal("hide");
				$scope.assignArr=[];
				$scope.delSub=[];
				$scope.brnchSections=[];
				$scope.brnchSectionsSelDump=[];
				$scope.closeAddMemeber();
				$scope.getAllUsers();
			} else {
				alert(data.MESSAGE);
			}
		});
	}
	
	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}
	
	
});
