projectModule.controller('manualTestGenerationController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };

 $scope.manualTestName = localStorage.getItem("mgTestName");
 $scope.closePopUp=function(){
   // $scope.selectedContentOwner="";
   // $scope.selectedContentType="";
   // $scope.selectedSubjectOb="";
   // $scope.selectedTestChapter="";
   // $scope.selectedTestTopic="";
 }

 $scope.manualGenerationViewLoad = function(){
   $scope.selectedCourse=$routeParams.courseId;
   $scope.getCustomTestDetails();
   $scope.getSchemaContentOwner();
   $scope.getTestInfo();
 }

 $scope.getQuestionTypesService = function(){
   httpFactory.getResult("getQuestionTypes?schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.questionTypeList = data.questionsArray;
     } else {
       // alert('No Courses Defined. ');
     }
   });
 }
 $scope.getQuestionTypesService();

 $scope.getCustomTestDetails = function() {
   httpFactory.getResult("getCustomTestDetails?schemaName="+$scope.schemaName +"&testId="+ localStorage.getItem("mgTestId") , function(data) {
     console.log(data);
     if (data.StatusCode == 200){
       $scope.totalTestQuestions = 0;
         $scope.manualTestDetails = data.TestDetails;
         console.log($scope.manualTestDetails);
         for(i=0;i<$scope.manualTestDetails.length;i++){
           $scope.totalTestQuestions += parseInt($scope.manualTestDetails[i].TotalQuestions);
           $scope.selectedQuestionCount += parseInt($scope.manualTestDetails[i].selectedQuestionCount);

         }
         console.log($scope.totalTestQuestions);
         $scope.getTestQuestions();

     } else {
    	 console.log("Error Occured!");
     }
   });
 }

 $scope.getSchemaContentOwner = function(){
   httpFactory.getResult("getSchemaContentOwner?schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.schemaContent=[];
       $scope.schemaContent = data.schemaContent;
       console.log($scope.schemaContent);
       }
     else {
       console.log("No ContentList");
     }
   });
 }

 $scope.getTestInfo = function() {
   httpFactory.getResult("getTestInfo?schemaName="+localStorage.getItem("sname") +"&testId="+$routeParams.testId , function(data) {
     console.log(data);
     if (data.StatusCode == 200){
         $scope.testInfo = data;
         $scope.totalnumQuestions = $scope.testInfo.totalQuestions;
         $scope.courseName= $scope.testInfo.courseName;
         console.log($scope.testInfo);
         if($scope.testInfo.jeeSectionTemplate!='NA'){
        	 $scope.getJeeTestSections();
         }
     } else {
    	 console.log("Error Occured!");
     }
   });
 }
 $scope.getTestSectionQuestion=function(){
     httpFactory.getResult("getTestSectionQuestion?testId=" + $routeParams.testId + "&schemaName="+localStorage.getItem("sname"), function(data) {
       console.log(data);
       if (data.StatusCode==200) {
         $scope.testSections=data.TestSectionQuestMarks;
        // $scope.studentId=$routeParams.sid;
       } else {
          alert("Test sections unavailable");
       }
     });
   }
   // $scope.getTestSectionQuestion();
   $scope.totalTestQuesObj =[];
   $scope.getTestQuestions = function() {
     httpFactory.getResult("getTestQuestions?schemaName="+$scope.schemaName +"&testId="+ localStorage.getItem("mgTestId") , function(data) {
       console.log(data);
       if (data.StatusCode == 200) {
         $scope.totalTestQuesObj = [];
         $scope.questionList=[];
           $scope.questionList = data.testQuestions;


           for(var i=0; i<$scope.questionList.length;i++){
           if($scope.questionList[i].questType == "ITQ"){
             var itqValues = $scope.questionList[i].option1.substring(3, $scope.questionList[i].option1.length-7);
             var qoptions = itqValues.split(",");
             var stepsArray = [];
             for(var j=0; j<qoptions.length; j++){
               stepsArray.push({value:parseInt(qoptions[j])});
             }
             $scope.questionList[i].selectedValue = $scope.questionList[i].correctAnswer;
             var qoptionssteps ={
             onEnd:$scope.itqChange,
             showTicksValues: true,
             stepsArray: stepsArray
             };
             var slider = {
               value: '',
               options:qoptionssteps
             };
              $scope.questionList[i].qoptionssteps = slider;
              $scope.questionList[i].qoptionssteps.value = parseInt($scope.questionList[i].selectedValue);
           }
         }
         console.log($scope.questionList);
       $scope.generateQuestionObj();
     }
       else if (data.StatusCode == 300){
         $scope.questionList=[];
         for(i=0;i<$scope.manualTestDetails.length;i++){
           for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions); j++){
           $scope.emptyObj=[];
           var quesObj = {
             'subjectName':$scope.manualTestDetails[i].subjectName,
             'questionIndex':j+1,
             'question':''
           }
             $scope.totalTestQuesObj.push(quesObj);
         }
     }
   }
       else {
 		console.log("Error Occured!");
       }
     });
   }

   $scope.generateQuestionObj = function() {
       var quesObj;
       var count = 0;
       $scope.totalTestQuesObj=$scope.questionList.slice(0);
       console.log($scope.totalTestQuesObj);
       $scope.selQCount=0;
       for(i=0;i<$scope.manualTestDetails.length;i++){
         $scope.selQCount= $scope.selQCount+(Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount));
         console.log($scope.totalTestQuestions);
         console.log($scope.selQCount);
         console.log(Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount));
         for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount); j++){
         $scope.emptyObj=[];
          quesObj = {
           'subjectName':$scope.manualTestDetails[i].subjectName,
           'questionIndex':j+1,
           'question':''
         }
         $scope.totalTestQuesObj.push(quesObj);
       }
     }
   }

   $scope.getTestCategories = function() {
 	  $scope.selectedCategory = "";
 	  $scope.subjectList =[];
 	  if($scope.courseList != undefined){
	 	 for(var i = 0;i <  $scope.courseList.length;i++){
	 		   if($scope.courseList[i].courseId == $scope.selectedCourse){
	 			   $scope.courseName = $scope.courseList[i].courseName;
	 		   }
	 	   }
 	  }
     httpFactory.getResult("getTestCategories?instId=" + localStorage.getItem("inst_id") + "&schemaName="+$scope.schemaName +"&courseId=" + $scope.selectedCourse, function(data) {
       console.log(data);
       if (data.STATUS == 'SUCCESS') {
         $scope.categoryList = data.TestCategories;
         console.log($scope.categoryList);
       }
        else {
       }
     });
   }

   $scope.getSchemas = function() {
     $scope.selectedSchema="";
     $scope.QSchema="";
     // $scope.selectedCategoryObj="";
     $scope.contentOwnerList=[];
     $scope.selectedContentType="";
     $scope.subjectList=[];
     httpFactory.getResult("selectContentOwner?schemaName="+$scope.schemaName, function(data) {
       console.log(data);
     if (data.StatusCode == 200) {
       $scope.contentOwnerList=[];
       $scope.contentList = data.ContentOwner;
       console.log($scope.contentList);
       for (var i = 0; i < $scope.contentList.length; i++) {
         console.log($scope.contentList[i].courseId);
         console.log($scope.selectedCourse);
         if ($scope.contentList[i].courseId == $scope.selectedCourse || $scope.contentList[i].courseId==0) {
           $scope.contentOwnerList.push($scope.contentList[i]);
         }
       }
       // $scope.contentOwnerList=data.ContentOwner;
         console.log($scope.contentOwnerList);
     } else {
       // alert('No Courses Defined. ');
     }
     });
   }

   $scope.selectedSubjectMethod=function(subject) {
     console.log(subject);
     if(subject){
     $scope.selectedSubject = JSON.parse($scope.selectedSubjectOb);
     console.log($scope.selectedSubject);
     console.log($scope.selectedSubject.subjectId);
     $scope.selectedTestSubject=$scope.selectedSubject.subjectId;
     if ($scope.selQB == 'null') {
       alert("Schema not selected");
     }else{
     $scope.getSelectedChaptersBySubjectId($scope.selectedTestSubject);
     }
   }
 }

   $scope.getSelectedChaptersBySubjectId = function(subjectId){
       console.log($scope.selectedContentOwner);
       console.log($scope.selectedContentType);
       var contentType = localStorage.getItem("courseName")+","+$scope.selectedContentType;
       httpFactory.getResult("getChapterTopicsBySubId?schemaName=" + $scope.schemaName +"&subjectId="+subjectId+"&contentOwner=CEDZ,COLLEGE&contentType="+contentType+"&branchId="+localStorage.getItem("bnchId")+"&courseId="+$scope.selectedCourse+"&instId="+localStorage.getItem("inst_id"), function(data){
	       console.log(data.Chaptertopics);
	       if(data.StatusCode == 200){
	         $scope.selectedChapterDetails=data;
	       }else if(data.StatusCode == 300){
	         $scope.selectedChapterDetails=data;
	       }
	       else{
	         alert("error");
	       }
     });
   }

   $scope.selectedChapterMethod=function() {
     console.log($scope.selectedTestChapter);
     if ($scope.selectedChapter == 'null') {
       alert("Schema not selected");
     }else{
       $scope.topicList = $scope.selectedTestChapter.Topics;
       
       $scope.topicOwner = $scope.topicList[0].topicOwner;
     }
     console.log($scope.selectedTestChapter.chapterId);
   }

   $scope.selectedTopicMethod=function(topic){
	 $scope.topicId = $scope.selectedTestTopic.topicId;  
	 $scope.topicOwner = $scope.selectedTestTopic.topicOwner;
     console.log($scope.selectedTestTopic);
     $scope.questionRepo = localStorage.getItem("sname");
   }

   $scope.selectedAnswerForTOF=function(opt){
     if (opt=='1') {
       $scope.TFOption='true';
     }else{
       $scope.TFOption='false';
     }
     console.log($scope.TFOption);
   }
   
   
   $scope.testSectionSelected=function(selectedTestSection){	   
	   if(typeof selectedTestSection=='string')
		   $scope.selTestSec = JSON.parse(selectedTestSection);
	   else
		   $scope.selTestSec = selectedTestSection;
	   
   }

   $scope.addTestQuestion = function(){
     console.log($scope.question);
     console.log($scope.option1);
     console.log($scope.correctAnswer);
     console.log($scope.questionCat);
     console.log($scope.selectedTestTopic);
     console.log($scope.diffLevel);
     console.log($scope.selectedContentType);
     console.log($scope.selectedContentOwner);

       if (!$scope.explanation) {
           $scope.explanation="NA";
       }

   if (!$scope.question || !$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer  || !$scope.selectedTestTopic || !$scope.diffLevel || !$scope.selectedContentOwner) {
     alert("Enter all fields");
   }
   else{
   var quesParams = {
     "insertRecords": [{
       "testId": localStorage.getItem("mgTestId"),
       "schemaName":localStorage.getItem("sname"),
       "instId" :  $scope.instituteId,
       "repo":localStorage.getItem("sname"),
       "question": $scope.question,
       "option1": $scope.option1,
       "option2": $scope.option2,
       "option3": $scope.option3,
       "option4": $scope.option4,
       "explanation": $scope.explanation,
       "correctAnswer": $scope.correctAnswer,
       "questionType": $scope.selectedContentType,
       "topicId": $scope.selectedTestTopic,
       "chapterId": $scope.selectedTestChapter.chapterId,
       "difficultyLevel": $scope.diffLevel,
       "instQuestion": "Y",
       "createdBy": $scope.user_id,
       "contentOwner":"COLLEGE",
       "subjectId":$scope.selectedSubject.subjectId,
       "subjectName":$scope.selectedSubject.subjectName
          }]
   };

   console.log(quesParams);
   httpFactory.executePost("addTestQuestion", quesParams, function(data) {
     console.log(data);
    if (data.STATUS == 'SUCCESS') {
     alert("Success.Test question added");

     $scope.question = CKEDITOR.instances['question'].setData('');
     $scope.option1 = CKEDITOR.instances['option1'].setData('');
     $scope.option2 = CKEDITOR.instances['option2'].setData('');
     $scope.option3 = CKEDITOR.instances['option3'].setData('');
     $scope.option4 = CKEDITOR.instances['option4'].setData('');
     $scope.explanation = CKEDITOR.instances['explanation'].setData('');
     $('#correctAnswer').prop('selectedIndex', 0);
     // $('#questionCat').prop('selectedIndex',0);
     $('#diffLevel').prop('selectedIndex', 0);
     $('#testSubject').prop('selectedIndex', 0);
     $('#testChapter').prop('selectedIndex', 0);
     $('#testTopic').prop('selectedIndex', 0);

     window.scrollTo(0, 0);
     $("#addQuestion").modal("hide");
     $scope.questionList.push(quesParams.insertRecords[0]);
     $scope.getCustomTestDetails();
     $scope.generateQuestionObj();
   }
   else{
     alert("something went wrong");
   }
 });
 }
 }
 $scope.selectedTestSection = {};
 $scope.addAdvTestQuestion = function(){
   console.log($scope.selectedTestSection);
   if(typeof $scope.selectedTestSection == 'string'){
     $scope.selectedTestSection = JSON.parse($scope.selectedTestSection);
   }

   $scope.questionAdv = CKEDITOR.instances['questionAdv'].getData();
   $scope.option1 = "";
   $scope.option2 = "";
   $scope.option3 = "";
   $scope.option4 = "";
   $scope.explanation = CKEDITOR.instances['explanation'].getData();
   if ($scope.questionType=='MAQ') {
     $scope.maqCrct="";
     for (var i = 0; i < $scope.multiCorrectAnswer.length; i++) {
       if ($scope.maqCrct=="") {
           $scope.maqCrct=$scope.multiCorrectAnswer[i];
       }else{
         $scope.maqCrct +=','+$scope.multiCorrectAnswer[i];
       }
       $scope.correctAnswer=$scope.maqCrct;
     }
   }else{
     $scope.correctAnswer = $("#correctAnswer").val();
   }
   $scope.questionCat = $("#questionCat").val();
   // $scope.diffLevel = $("#diffLevel").value;
   // $scope.diffLevel =document.getElementById("diffLevel").value;

   $scope.qstnAppeared = $("#questionAppeared").val();
   $scope.selectedSchema=localStorage.getItem("addQuescontentOwner");
   if ($scope.questionType == 'MCQ' || $scope.questionType == 'MAQ') {
     $scope.option1 = CKEDITOR.instances['option1'].getData();
     $scope.option2 = CKEDITOR.instances['option2'].getData();
     $scope.option3 = CKEDITOR.instances['option3'].getData();
     $scope.option4 = CKEDITOR.instances['option4'].getData();
   }
   else if ($scope.questionType == 'TOF') {
     $scope.correctAnswer=$scope.TFOption;
     console.log($scope.correctAnswer);
   }else if($scope.questionType == 'ITQ'){
     $scope.option1 = CKEDITOR.instances['option1'].getData();
     $scope.correctAnswer=$scope.itqCorrectAns;
     if (!$scope.option1) {
       alert("Enter Values For Integer Type Question");
       return true;
     }else if(!$scope.correctAnswer){
       alert("Enter Correct Answer For Integer Type Question");
     }
   }else if($scope.questionType=='FIB'){
     $scope.correctAnswer=$scope.FIBAnswer;
   }else if($scope.questionType == 'MFQ'){
     $scope.correctAnswer="NA";
     $scope.correctAnswer="1-"+$scope.MFQ1+","+"2-"+$scope.MFQ2+","+"3-"+$scope.MFQ3;
     if($scope.MFQ4)
     $scope.correctAnswer=$scope.correctAnswer+","+"4-"+$scope.MFQ4;

     if($scope.MFQ5)
     $scope.correctAnswer=$scope.correctAnswer+","+"5-"+$scope.MFQ5;

     console.log($scope.correctAnswer);

     $scope.column1a = CKEDITOR.instances['column1a'].getData();
     $scope.column2a = CKEDITOR.instances['column2a'].getData();
     $scope.column3a = CKEDITOR.instances['column3a'].getData();
     $scope.column4a = CKEDITOR.instances['column4a'].getData();
     $scope.column5a = CKEDITOR.instances['column5a'].getData();

     console.log($scope.column4a);

     $scope.column1b = CKEDITOR.instances['column1b'].getData();
     $scope.column2b = CKEDITOR.instances['column2b'].getData();
     $scope.column3b = CKEDITOR.instances['column3b'].getData();
     $scope.column4b = CKEDITOR.instances['column4b'].getData();
     $scope.column5b = CKEDITOR.instances['column5b'].getData();

     if($scope.column1a.length<=0){
       // $scope.column1a="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column1b.length<=0){
       // $scope.column1b="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column2a.length<=0){
       // $scope.column2a="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column2b.length<=0){
       // $scope.column2b="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column3a.length<=0){
       // $scope.column3a="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column3b.length<=0){
       // $scope.column3b="NA";
       alert("Enter Mininum 3 Matches");
       return true;
     }
     if($scope.column4a.length<=0){
         $scope.column4a="NA";
     }
     if($scope.column4b.length<=0){
         $scope.column4b="NA";
     }
     if($scope.column5a.length<=0){
         $scope.column5a="NA";
     }
     if($scope.column5b.length<=0){
         $scope.column5b="NA";
     }
   }

console.log($scope.diffLevel);
   if($scope.questionAdv == undefined || $scope.questionAdv  == ""){
     alert("Please Add question");
     return true;
   }
   if($scope.correctAnswer == undefined || $scope.correctAnswer == ""){
     alert("Please select correct answer");
     return true;
   }
   if($scope.questionCat == undefined || $scope.questionCat == ""){
     alert("Please select question type");
     return true;
   }
   if($scope.diffLevel == undefined || $scope.diffLevel == ""){
     alert("Please select Difficulty Level");
     return true;
   }

   if (!$scope.qstnAppeared) {
     $scope.qstnAppeared = "";
   }

console.log($scope.diffLevel);
console.log($scope.questionCategory);
	var requestParams={};
   if (!$scope.questionAdv || !$scope.correctAnswer  || !$scope.topicId || !$scope.diffLevel || !$scope.questionCategory) {
     alert("Enter all fields");
   }else{
   if ($scope.questionType=='MFQ') {
     if (!$scope.MFQ1) {
       // $scope.MFQ1="NA";
       alert("Enter Correct Answer");
       return true;
     }
     if (!$scope.MFQ2) {
       // $scope.MFQ2="NA";
       alert("Enter Correct Answer");
       return true;
     }
     if (!$scope.MFQ3) {
       // $scope.MFQ3="NA";
       alert("Enter Correct Answer");
       return true;
     }
     if (!$scope.MFQ4) {
       $scope.MFQ4="NA";
     }
     if (!$scope.MFQ5) {
       $scope.MFQ5="NA";
     }
      requestParams = {
       "schemaName":$scope.schemaName,
       "insertRecords": [{
         "testId": localStorage.getItem("mgTestId"),
         "schemaName":localStorage.getItem("sname"),
         "instId" :  $scope.instituteId,
         "repo":$scope.questionRepo,
         "question": $scope.questionAdv,
         "explanation": $scope.explanation,
         "correctAnswer": $scope.correctAnswer,
         "questionType": $scope.questionCat,
         "topicId": $scope.topicId ,
         "subjectId": $scope.selectedTestSubject ,
         "chapterId": $scope.selectedTestChapter.chapterId,
         "difficultyLevel": $scope.diffLevel,
         "contentOwner": $scope.topicOwner,
         "questionOwner" : "COLLEGE",
         "questionAppearedIn": $scope.qstnAppeared,
         "questType": $scope.questionType,
         "branchId" : localStorage.getItem("bnchId"),
		"contentType": $scope.selectedContentType,
		"subjectId": $scope.selectedSubject.subjectId,
          // "testSectionName":$scope.selectedTestSection.testSectionName,
          //"testSectionId":$scope.selectedTestSection.testSectionId,
         "createdBy": localStorage.getItem("userId"),
         "options":[
       {
         "columnA":$scope.column1a,
         "columnB":$scope.column1b,
         "correctAnswer":$scope.MFQ1
       },
       {
         "columnA":$scope.column2a,
         "columnB":$scope.column2b,
         "correctAnswer":$scope.MFQ2
       },	{
         "columnA":$scope.column3a,
         "columnB":$scope.column3b,
         "correctAnswer":$scope.MFQ3
       },	{
           "columnA":$scope.column4a,
           "columnB":$scope.column4b,
           "correctAnswer":$scope.MFQ4
         },	{
             "columnA":$scope.column5a,
             "columnB":$scope.column5b,
             "correctAnswer":$scope.MFQ5
             }
         ]
       }]
     }
     console.log(requestParams);
   }
   else
   {
     if ($scope.questionType=='MCQ' || $scope.questionType=='MAQ') {
       if (!$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer) {
         alert("Please enter all fields");
         return true;
       }
     }
      requestParams = {
      "schemaName":$scope.schemaName,
      "insertRecords": [{
        "testId": localStorage.getItem("mgTestId"),
        "schemaName":localStorage.getItem("sname"),
        "instId": $scope.instituteId,
        "repo":$scope.questionRepo,
        "question": $scope.questionAdv,
        "option1": $scope.option1,
        "option2": $scope.option2,
        "option3": $scope.option3,
        "option4": $scope.option4,
        "explanation": $scope.explanation,
        "correctAnswer": $scope.correctAnswer,
        "questionType": $scope.questionCat,
        "topicId": $scope.topicId ,
        "subjectId": $scope.selectedTestSubject ,
        "chapterId": $scope.selectedTestChapter.chapterId,
        "difficultyLevel": $scope.diffLevel,
        "contentOwner": $scope.topicOwner,
        "questionOwner" : "COLLEGE",
        "questionAppearedIn": $scope.qstnAppeared,
        "questType": $scope.questionType,
        "branchId" : localStorage.getItem("bnchId"),
		"contentType": $scope.selectedContentType,
		"subjectId": $scope.selectedSubject.subjectId,
//        "testSectionId":$scope.selectedTestSection.testSectionId,
        "createdBy": localStorage.getItem("userId")
      }]
    }
   }
 //add testSectionName if sections available from select section Name selection
   if($scope.selectedTestSection){
       requestParams.insertRecords[0]["testSectionName"]=$scope.selectedTestSection.sectionName;
   }
   console.log(requestParams);
 httpFactory.executePost("addTestQuestion", requestParams, function(data) {
   console.log(data);
  if (data.STATUS == 'SUCCESS') {
   alert("Success.Test question added");

   $scope.questionAdv = CKEDITOR.instances['question'].setData('');
   $scope.option1 = CKEDITOR.instances['option1'].setData('');
   $scope.option2 = CKEDITOR.instances['option2'].setData('');
   $scope.option3 = CKEDITOR.instances['option3'].setData('');
   $scope.option4 = CKEDITOR.instances['option4'].setData('');
   $scope.explanation = CKEDITOR.instances['explanation'].setData('');
   $('#correctAnswer').prop('selectedIndex', 0);
   // $('#questionCat').prop('selectedIndex',0);
   $('#diffLevel').prop('selectedIndex', 0);
   $('#testSubject').prop('selectedIndex', 0);
   $('#testChapter').prop('selectedIndex', 0);
   $('#testTopic').prop('selectedIndex', 0);
   $scope.TFOption="";
   $scope.MFQ1="";
   $scope.MFQ2="";
   $scope.MFQ3="";
   $scope.MFQ4="";
   $scope.MFQ5="";
   $scope.correctAnswer="";
   $scope.itqCorrectAns="";
   $scope.diffLevel="";
   $scope.FIBAnswer="";
   $scope.selectedTestSubject="";
   $scope.topicId="";
   $scope.trueOption="";
   $scope.falseOption="";

   window.scrollTo(0, 0);


   $scope.questionList.push(requestParams.insertRecords[0]);
   $scope.getCustomTestDetails();
   $scope.generateQuestionObj();
   if($scope.selQCount<=0){
   $("#addAdvQuestion").modal("hide");
 }
 }
 else{
   alert("something went wrong");
 }
});
}
}
 
 $scope.getJeeTestSections=function(){
	    httpFactory.getResult("getJeeTestSections?schemaName="+localStorage.getItem("sname")+ "&catId="+ $scope.testInfo.testCategory, function(data) {
	      if (data.StatusCode == 200) {
	        $scope.testSections = data.TestSections[0].testSectionDetails;
	        console.log($scope.testSections);
	        }
	       else {
	    	   $scope.jeeTestSecArr=[];
	       }
	    });
	  }

$scope.selectedGroupSubj ="";
$scope.showQuesbjWise = function(sbj){
	$scope.selectedGroupSubj = sbj;
	
	console.log($scope.totalTestQuesObj);
}
 $scope.manualTestPublish=function(){
   $scope.numQuestions = parseInt(localStorage.getItem("mgNumQues"));
   if ($scope.numQuestions>$scope.questionList.length) {
     alert("add all questions");
   }else{

   $scope.testId=localStorage.getItem("mgTestId");
   $location.path("publishTest/"+$scope.testId+"/"+localStorage.getItem("bnchId")+"/publish");
 }
 }
 $scope.cancelBack=function(){
   $location.path("exams");
 }


});
