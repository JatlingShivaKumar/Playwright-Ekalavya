projectModule.controller('studentProfileController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {
$scope.$ = $;
$scope.instituteId = 1;
$scope.Math = window.Math;
var requestParams = {
  "m_inst_id": $scope.instituteId
};
$scope.schemaName=localStorage.getItem("sname");
$scope.sectionName=localStorage.getItem("stsecnme");
if ($routeParams.stuId) {
  $scope.studentId = $routeParams.stuId;
}else{
  $scope.studentId = localStorage.getItem("stuid");
}
$scope.studentProfileEdit = function(){
  $scope.studentDetailsById();
  $scope.getStudentOverallAttendance();
  $scope.getStudentOverallHWForAnalysis();
  $scope.getStudentTestCountForAnalysis();
}
$scope.goToExamLogs=function(){
  $location.path("stuExmLog");
}
$scope.goToAttendance=function(){
  sessionStorage.setItem("stuNav","att");
  $location.path("mySchool");
}
$scope.goToHomework=function(){
  sessionStorage.setItem("stuNav","hw");
  $location.path("mySchool");
}
$scope.goToReportCard=function(){
  sessionStorage.setItem("stuNav","rpt");
  $location.path("mySchool");
}
$scope.studentDetailsById = function(){
  httpFactory.getResult("studentDetailsById?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.studentProfileData = data;
		$scope.stProfilePic = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+ $scope.studentProfileData.profilePic;
    localStorage.setItem("stProfilePic",$scope.stProfilePic);
		} else {
		}
	});
}

$scope.changePwdModal=function(){
  $("#changePwdModal").modal("show");
}
$scope.changePassword=function(){
var params={
  "loginName":$scope.studentProfileData.loginName,
  "oldPassword":$scope.oldPwdVal,
  "newPassword":$scope.newPwdVal,
  "schemaName":$scope.schemaName,
  "updatedBy":localStorage.getItem("stuid")
}
  httpFactory.executePost("changeStudentPassword", params, function(data) {
		console.log(data);
	 if (data.STATUS == 'SUCCESS') {
		alert(data.MESSAGE);
		$("#changePwdModal").modal("hide");
	}
	else{
	}
});
}

$scope.getStudentOverallAttendance = function(){
  $scope.studentAttendance=[];
  httpFactory.getResult("getStudentOverallAttendance?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentAttendance = data;
        $scope.stuAtt = (($scope.studentAttendance.wokingDays - $scope.studentAttendance.studentLeaves)/$scope.studentAttendance.wokingDays)*100;
		} else {
      $scope.studentAttendance=[];
		}
	});
}

$scope.getStudentOverallHWForAnalysis = function(){
  $scope.studentHomeWorks=[];
  httpFactory.getResult("getStudentOverallHWForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentHomeWorks = data;
        console.log($scope.studentHomeWorks);
		} else {
      $scope.studentHomeWorks=[];
      var obj = {
        "completedHW": 0,
        "pendingHW": 0,
        "totalHW": 0
      }
      $scope.studentHomeWorks=obj;
		}
	});
}
$scope.getStudentTestCountForAnalysis = function(){
  httpFactory.getResult("getStudentTestCountForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentTests = data;
		} else {
      $scope.studentTests=[];
      var obj = {
        "testCompleted": 0
      }
      $scope.studentTests=obj;
		}
	});
}
$scope.uploadStudentProfile = function(){
	  var files = document.getElementById("ProfileFile").files;
	  if(files[0] == undefined){
	    return true;
	  }
	  console.log(files);
	  var fd = new FormData();

	  fd.append("studentId", $scope.studentId);
	  fd.append("admissionNo", $scope.studentProfileData.admissionNumber);
	  fd.append("schemaName",$scope.schemaName)
	  fd.append("file", files[0]);


	  httpFactory.executeFileUpload("uploadStudentProfilePic", fd, function(data) {
	    console.log(data);
	    if (data.StatusCode==200) {
//	      $route.reload();
	    	  $scope.studentDetailsById();
	    }else{
	      alert("Please upload an image");
	    }
	    document.getElementById("ProfileFile").value = "";
	  //	$scope.downLoadHw();
	  });
	}




});
