projectModule.controller('teacherRankrPlusController', function($scope, $location, httpFactory, $timeout, $window,$routeParams,$rootScope){
	$scope.$ = $;
	$scope.schemaName=localStorage.getItem("sname");
	$scope.roleId=localStorage.getItem("RD");
	$scope.branchId=localStorage.getItem("bnchId");
	$scope.Math = window.Math;
	$scope.profnav=sessionStorage.getItem("profnav");
	if($scope.profnav){
		$scope.userId=sessionStorage.getItem("profuserid");
	}else{
		$scope.userId=localStorage.getItem("TuserId");
	}
	$scope.goToMyClasses = function(){
		$location.path("myClasses");
	}

	$scope.goToGallery = function(){
		$location.path("gallery");
	}
	 $scope.goToMessages=function(){
	    $location.path("messages/yes");

  }
	$scope.goToCirculars = function(){
		$location.path("Circulars");
	}
	$scope.rankrPlusInit=function(){
		$scope.rankrPlusFlag = sessionStorage.getItem("stuNav");
		sessionStorage.removeItem("stuNav");
		if ($scope.rankrPlusFlag == "cal") {
			$scope.gotoCalenderEvents();
		}
		$scope.getEventCountByDate();
	}

	$scope.goToStudentAttendance=function(){
		sessionStorage.setItem("Tnav","attendance")
		$location.path("myClasses");
	}

	$scope.goToHomework=function(){
		sessionStorage.setItem("Tnav","homework")
		$location.path("myClasses");
	}
	$scope.goToLiveClass=function(){
		sessionStorage.setItem("Tnav","liveClass")
		$location.path("myClasses");
	}
	
	$scope.goToTimeTable=function(){
		sessionStorage.setItem("Tnav","myTmt")
		$location.path("myClasses");
	}

	$scope.goToReportCard=function(){
		sessionStorage.setItem("Tnav","reportAnalysis")
		$location.path("myClasses");
	}



	$scope.getAttendanceAndLeaves=function(){
		$scope.teacherSelfAttendance();
		$("#attendanceModal").modal("show");
	}
	$scope.leaveRequestModal=function(){
		$("#leaveRequest").modal("show");
	}

$scope.requestLeave=function(){
  $scope.startDateVal = $("#startDate").val();
  $scope.endDateVal = $("#endDate").val();
	console.log($scope.startDateVal);
	console.log($scope.endDateVal);
	console.log($scope.descText);
	console.log($scope.reasonVal);
	console.log($scope.branchId);
  var params= {
	  "schemaName":$scope.schemaName,
	  "branchId":$scope.branchId,
	  "leaveFrom":$scope.startDateVal,
	  "leaveTo":$scope.endDateVal,
	  "createdBy":$scope.userId,
	  "userId":$scope.userId,
	  "reason":$scope.reasonVal,
	  "Description":$scope.descText,
	  "isActive":1

	}
	console.log(params);
	httpFactory.executePost("addStaffLeaveRequests", params, function(data) {
	  console.log(data);
	  if (data.StatusCode == 200) {
	    alert(data.MESSAGE);
	    $scope.getStaffLeaveRequestInfo();
	    $("#leaveRequest").modal("hide");
	  }
	  else
		{
	    alert(data.MESSAGE);
	    // alert("Please try agian after some time");
	  }
	});
}

	$scope.monthLables = [];
	$scope.absentlabels = [];
	$scope.lateLabels = [];
	$scope.lineChartData = {
			labels: $scope.monthLables,
			data : [
				$scope.absentlabels,
				$scope.lateLabels
	]};

	$scope.teacherSelfAttendance=function(){
		$scope.getStaffOverallAttendance();
		$scope.getStaffAttendanceForAnalysis();
		$scope.getStaffLeaveRequestInfo();
	}
	$scope.closePopUpHW=function(){
		if($scope.profnav=="att" && $rootScope.latestCurrentPath == 'teacherRankrPlus'){
		$("#attendanceModal").modal("hide");
		$location.path("/profile/"+sessionStorage.getItem("profuserid")+"/"+sessionStorage.getItem("profroleid")+"/"+sessionStorage.getItem("profbranchid"));
		sessionStorage.removeItem("profuserid");
		sessionStorage.removeItem("profroleid");
		sessionStorage.removeItem("profbranchid");
		sessionStorage.removeItem("profnav");
		}else if($rootScope.latestCurrentPath == 'rankrPlus'){
			$("#attendanceModal").modal("hide");
			//$location.path("profile");
		}
		else{
		$("#attendanceModal").modal("hide");
	}
	}

	$scope.getStaffAttendanceForAnalysis=function(){
	  httpFactory.getResult("getStaffAttendanceForAnalysis?userId="+$scope.userId+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.staffAttAnalysis = data.staffMonthWiseAttendance;
				console.log($scope.staffAttAnalysis);
				$scope.monthLables=[];
				$scope.absentlabels=[];
				$scope.lateLabels=[];
				$scope.lateCount=0;
				$scope.absentCount=0;
				$scope.totalWorkingDays=0;
				$scope.attendanceTakenDays=0;

				$scope.monthSel = $scope.staffAttAnalysis[0];
				for (var i = 0; i < $scope.staffAttAnalysis.length; i++) {
					$scope.monthLables.push($scope.staffAttAnalysis[i].MonthName);
					$scope.absentlabels.push($scope.staffAttAnalysis[i].absentCount);
					$scope.lateLabels.push($scope.staffAttAnalysis[i].lateCount);
					$scope.lateCount += Number($scope.staffAttAnalysis[i].lateCount);
					$scope.absentCount += Number($scope.staffAttAnalysis[i].absentCount);
					$scope.totalWorkingDays+=Number($scope.staffAttAnalysis[i].workingDays);
					$scope.attendanceTakenDays+=Number($scope.staffAttAnalysis[i].attendanceTakenDays);

				}
				console.log($scope.lateCount);
				console.log($scope.absentCount);
				console.log($scope.monthLables);
				console.log($scope.absentlabels);
				console.log($scope.lateLabels);
				$scope.totalPerc = (($scope.attendanceTakenDays-$scope.absentCount)/$scope.attendanceTakenDays)*100;
				console.log($scope.attendanceTakenDays);
				console.log($scope.totalPerc);
				$scope.lineChartData = {
							labels: $scope.monthLables,
							data : [
						$scope.absentlabels,
						$scope.lateLabels
					]};
					$scope.staffAtt=$scope.staffAttAnalysis[$scope.staffAttAnalysis.length-1];
	      $scope.staffAttMonthClick($scope.staffAttAnalysis[$scope.staffAttAnalysis.length-1]);
	    }else{
	      $scope.assignList=[];
	    }
	  });
	}

	$scope.monthSel= {};
	$scope.staffAttMonthClick=function(monthAtt){
	  console.log(monthAtt);
	  $scope.staffMonthAtt=monthAtt;
	  $scope.staffPDays=parseInt($scope.staffMonthAtt.attendanceTakenDays)-parseInt($scope.staffMonthAtt.absentCount);
	  $scope.staffHolidays=parseInt($scope.staffMonthAtt.totalDays)-parseInt($scope.staffMonthAtt.workingDays);
		var ndate= new Date();
	//	var lastDay = new Date(ndate.getFullYear(), ndate.getMonth() + 1, 0).getUTCDate();
	  $scope.selDate= $scope.staffMonthAtt.MonthandYear +'-'+ndate.getDate();
	  $scope.getStaffMonthWiseAttendanceDetails();
	  // $scope.getTotalLeaveRequestsForStudent();
		//	$scope.getStaffLeaveRequestInfo();
	  console.log($scope.studentPDays);
	}
	$scope.staffMonthAttDetails=[];
	$scope.getStaffMonthWiseAttendanceDetails=function(){
	  httpFactory.getResult("getStaffMonthWiseAttendanceDetails?userId="+$scope.userId+"&schemaName="+$scope.schemaName+"&date="+$scope.selDate, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.staffMonthAttDetails = data.staffAttendance;
	    }else{
	      $scope.staffMonthAttDetails=[];
	    }
	  });
	}
	$scope.getStaffLeaveRequestInfo=function(){
		httpFactory.getResult("getTotalLeaveRequestsForStaff?staffId="+$scope.userId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.stuLeaveRequests = data.staffLeaveReqArray;
			}else{
				$scope.stuLeaveRequests=[];
			}
		});
	}

	$scope.getStaffOverallAttendance=function(){
		httpFactory.getResult("getStaffOverallAttendance?userId="+$scope.userId+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.staffOverallAtt = data;
				console.log($scope.staffOverallAtt);

				$scope.staffTotalDays=$scope.staffOverallAtt.workingDays;
			}else if(data.StatusCode == 300){
				$scope.staffOverallAtt = data;
				console.log($scope.staffOverallAtt);

				$scope.staffTotalDays=$scope.staffOverallAtt.workingDays;
			}else{
				$scope.staffOverallAtt=[];
			}
		});
		console.log($scope.staffTotalDays);
	}

		/* Calender Events Started*/

	$scope.gotoCalenderEvents = function(){
		$scope.calendarInitMethod();
	//	$scope.generateDateOfobj();
		$("#calEventsModal").modal("show");
	}

	$scope.calendarInitMethod=function(){
		var ndate = new Date();
		$scope.monthId=ndate.getMonth()+1;
		$scope.yearId=ndate.getFullYear();
		$scope.generateDateOfobj();
	}



	$scope.getEventsAndHolidaysMonth=function(){

		// get service --  getEventsAndHolidaysMonth?schemaNameschemaName=&monthId=&yearId
		var params = {
			"monthId":$scope.monthId,
			"schemaName":$scope.schemaName,
			"yearId":$scope.yearId,
			"branchId":$scope.branchId,
			"roleId":$scope.roleId,
		};

		httpFactory.executePost("getEventsAndHolidaysMonth", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.EventsHolidays = data.EventsAndHolidays;
				$scope.thisMonthGeneration();
			}
		});

	}


	$scope.weekday = new Array(7);

	$scope.weekday[0] = "Mon";
	$scope.weekday[1] = "Tue";
	$scope.weekday[2] = "Wed";
	$scope.weekday[3] = "Thu";
	$scope.weekday[4] = "Fri";
	$scope.weekday[5] = "Sat";
	$scope.weekday[6] = "Sun";

	$scope.weekDisplayDays = new Array(7);
	$scope.weekDisplayDays[0] = "Sun";
	$scope.weekDisplayDays[1] = "Mon";
	$scope.weekDisplayDays[2] = "Tue";
	$scope.weekDisplayDays[3] = "Wed";
	$scope.weekDisplayDays[4] = "Thu";
	$scope.weekDisplayDays[5] = "Fri";
	$scope.weekDisplayDays[6] = "Sat";


	$scope.cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.getViewMonth = "";
	$scope.getViewYear = "";
	$scope.getViewMonthNumber = 0;
	console.log($scope.newDate);

	$scope.monthView = [];
	$scope.monthDaysList = [];
	$scope.monthDaysListView = [];



	$scope.goToNextMonth = function(){
		if($scope.getViewMonthNumber == 12){
		 $scope.getViewMonthNumber = 1;
		 $scope.getViewYear = parseInt($scope.getViewYear)+1;
		 $scope.getViewMonth = $scope.cal_months_labels[0];
		}
		else{

		 $scope.getViewMonth = $scope.cal_months_labels[$scope.getViewMonthNumber];
		 $scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)+1;
		}
		$scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
		$scope.monthId=$scope.newDate.getMonth()+1;
		$scope.yearId=$scope.newDate.getFullYear();
		$scope.eventListArray = "";
		$scope.getEventsAndHolidaysMonth();
		//$scope.thisMonthGeneration();
	}

	$scope.goToBeforeMonth = function(){
		if($scope.getViewMonthNumber == 1){
		 $scope.getViewMonthNumber = 12;
		 $scope.getViewYear = parseInt($scope.getViewYear)-1;
		 $scope.getViewMonth = $scope.cal_months_labels[11];
		}
		else{
			$scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)-1;
			$scope.getViewMonth = $scope.cal_months_labels[parseInt($scope.getViewMonthNumber)-1];
		}
		$scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
		$scope.monthId=$scope.newDate.getMonth()+1;
		$scope.yearId=$scope.newDate.getFullYear();
		$scope.eventListArray = "";
		$scope.getEventsAndHolidaysMonth();
		//$scope.thisMonthGeneration();
	}

	$scope.generateDateOfobj = function(){
		var nDate = new Date();
		$scope.newDate = nDate;
		$scope.monthId=nDate.getMonth()+1;
		$scope.yearId=nDate.getFullYear();
		$scope.getViewMonth = $scope.cal_months_labels[nDate.getMonth()];
		$scope.getViewMonthNumber = parseInt(nDate.getMonth())+1;
		$scope.getViewYear = parseInt(nDate.getFullYear());
		$scope.getEventsAndHolidaysMonth();
		//$scope.thisMonthGeneration();
	}

	$scope.thisMonthGeneration =  function(){
		var date = new Date($scope.newDate);
		var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();

		console.log(lastDay);

			var startDay = $scope.weekday[new Date(date.getFullYear(),date.getMonth(), 0).getDay()]
			var firstWeekStart = false;
			var weekIndex = 0;
			var dayStartedIndex = 0;
			var dateIndx = 1;
			$scope.monthDaysList = [];
			do{
				$scope.monthDaysList[weekIndex] = [];
				for(var j=0;j<$scope.weekDisplayDays.length;j++){
					wdayObj = {};
					if(firstWeekStart == false){
						if(startDay != $scope.weekDisplayDays[j] && dayStartedIndex == 0 ){
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],

							};
							console.log("entered");
						}
						else{
							wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
					}
					else{
						if(dayStartedIndex < lastDay+1){
							wdayObj = wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
						else{
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],
							};
							if($scope.weekDisplayDays.length-1 == j){
								dayStartedIndex++;
							}
						}

					}
					$scope.monthDaysList[weekIndex].push(wdayObj);
				}
				firstWeekStart = true;
				weekIndex++;

			}
			while(dayStartedIndex <= lastDay)
		console.log($scope.monthDaysList);
		console.log(JSON.stringify($scope.monthDaysList));
		$scope.generateEventsWithMonth();
	}

	$scope.generateEventsWithMonth = function(){
		console.log($scope.EventsHolidays);
		for(var k=0;k<$scope.EventsHolidays.length;k++){
			for(var j=0;j<$scope.EventsHolidays[k].eventDetails.length; j++){

				if($scope.EventsHolidays[k].eventDetails[j].from == $scope.EventsHolidays[k].eventDetails[j].to){
					var ndate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
					for(var i=0; i<$scope.monthDaysList.length; i++){
						for(var l=0; l<$scope.monthDaysList[i].length; l++){
							if($scope.monthDaysList[i][l].date == ndate.getDate()){

								if($scope.monthDaysList[i][l].eventList == undefined){
									$scope.monthDaysList[i][l].eventList = [];
								}
								if($scope.monthDaysList[i][l].eventList.length == 0){
									var doopEventDet ={
										"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
										"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
										"eventDetails":[]
									};
									doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
									$scope.monthDaysList[i][l].eventList.push(doopEventDet);
								}else{
									var founIndx = 0;
									for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
										if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
											founIndx++;
											$scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										}
									}
									if(founIndx == 0){
										var doopEventDet ={
											"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
											"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
											"eventDetails":[]
										};
										doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										$scope.monthDaysList[i][l].eventList.push(doopEventDet);
									}
								}
							}
						}
					}
				}else{
					var nFromDate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
					var nToDate = new Date($scope.EventsHolidays[k].eventDetails[j].to);
					var date = new Date($scope.newDate);
					var nstartDate = 0;
					var nendDate = 0;
					if(date.getMonth() == nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
						nstartDate = nFromDate.getDate();
						nendDate = nToDate.getDate();
					}else if(date.getMonth() == nFromDate.getMonth() && date.getMonth() != nToDate.getMonth()){
						var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();
						nstartDate = nFromDate.getDate();
						nendDate = lastDay+1;
					}else if(date.getMonth() != nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
						nstartDate = 1;
						nendDate = nToDate.getDate();
					}else {
						var date1 = new Date($scope.newDate);
						var lastDay = new Date(date1.getFullYear(), date1.getMonth() + 1, 0).getUTCDate();
						nstartDate = 1;
						nendDate = lastDay+1;
					}

					for(var i=0; i<$scope.monthDaysList.length; i++){
						for(var l=0; l<$scope.monthDaysList[i].length; l++){
							if($scope.monthDaysList[i][l].date >= nstartDate && $scope.monthDaysList[i][l].date <= nendDate){
								if($scope.monthDaysList[i][l].eventList == undefined){
									$scope.monthDaysList[i][l].eventList = [];
								}
									if($scope.monthDaysList[i][l].eventList.length == 0){
										var doopEventDet ={
											"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
											"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
											"eventDetails":[]
										};
										doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										$scope.monthDaysList[i][l].eventList.push(doopEventDet);
									}else{
										var founIndx = 0;
										for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
											if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
												founIndx++;
												$scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
											}
										}
										if(founIndx == 0){
											var doopEventDet ={
												"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
												"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
												"eventDetails":[]
											};
											doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
											$scope.monthDaysList[i][l].eventList.push(doopEventDet);
										}
									}
							}
						}
					}
				}
			}
		}
		console.log($scope.monthDaysList);
	}

	$scope.updateEventListArray = function(wdev){
		$scope.eventListArray=[];
		$scope.selectedDate=wdev.date;
		$scope.eventListArray = wdev;
	}


	$scope.getEventCountByDate=function(){
		var date =new Date();
		$scope.todayDate=date.getDate();
		$scope.currDate = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+$scope.todayDate;
		console.log($scope.currDate);
		var params = {
			"date":$scope.currDate,
			"schemaName":$scope.schemaName,
			"branchId":$scope.branchId,
			"roleId":$scope.roleId,
			"userId":$scope.userId

		};
		httpFactory.executePost("getEventCountByDate", params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.eventCount=data.eventCount;
			}else{
				$scope.eventCount=0;
			}
		});
	}

	if($scope.profnav=="att"){
		$scope.getAttendanceAndLeaves();
	}


	/* Calender Events Ended*/
});
