projectModule.controller('feeSettingsController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");
	$scope.selectedDisCategory = {};
	$scope.selectedDisCategoryObj = {};
	$scope.selectedFeeCategory = {};
	$scope.discForTab = "";
	$scope.isDiscount = false;
	$scope.isDefaultIndx = false;
	$scope.allDiscountCatglist = [
		{
			"categoryId":1,
			"categoryName":"Merit",
			"min":10,
			"max":20
		},
		{
			"categoryId":2,
			"categoryName":"Sibling",
			"min":20,
			"max":30
		},
		{
			"categoryId":3,
			"categoryName":"Financial week",
			"min":10,
			"max":20
		}

	];

	$scope.allFeeCatglist =[];
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourseOb = {};
	$scope.selectedClassObj = {};
	$scope.selectedClass = "";

	$scope.getCoursesByBranch = function() {

	  $scope.courseList = [];
	  $scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
	  $scope.selectedClass = "";

	    httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.selectedBranch , function(data) {
      console.log(data);
      if (data.StatusCode == 200){
          $scope.courseList = data.Courses;
          console.log($scope.courseList);
      } else {
				$scope.courseList = [];
				console.log("No courses");
      }
    });
  }

	$scope.getClassesByCourse = function() {

    console.log($scope.selectedCourseOb);
		if($scope.selectedCourseOb == null){
			return true;
		}
    $scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
    $scope.selectedCourse=$scope.selectedCourseObj.courseId;
    $scope.selectedCourseName=$scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
				httpFactory.getResult("getClassByCoursesID?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch + "&courseId="+$scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200){
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);

			} else {
				console.log("No classes found");
			}
		});
	}


	$scope.getAllFeeCategories = function(){
		httpFactory.getResult("getAcademicFeeInformation?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.allFeeCatglist = data.data;
			}
			else{
				$scope.allFeeCatglist = [];
			}

		});
	}
	$scope.getCoursesByBranch();
	$scope.getAllFeeCategories();

	$scope.checkDiscountFor = function(dtab){
		$scope.discForTab = dtab;
	}

	$scope.changeDiscObj = function(){

			if(typeof $scope.selectedDisCategoryObj == "string"){
				$scope.selectedDisCategory = JSON.parse($scope.selectedDisCategoryObj)
			}
			else{
					$scope.selectedDisCategory = $scope.selectedDisCategoryObj
			}
	}
	$scope.checkDiscRange = function(){
		if($scope.selectedDiscPercentage < $scope.selectedDisCategory.min || $scope.selectedDiscPercentage > $scope.selectedDisCategory.max){
			alert("Please Enter discount with in "+$scope.selectedDisCategory.min+" to "+$scope.selectedDisCategory.max);
			$scope.selectedDiscPercentage = 0;
		}
	}

	$scope.saveFeeDetails = function(){

		$scope.selectedClassObjc = JSON.parse($scope.selectedClassObj);

		var isDiscIndx = 0;
		var isDefaIndx = 0;
		if($scope.isDiscount == true){
			isDiscIndx = 1;
			isDefaIndx = 0;
		}
		if($scope.isDefaultIndx == true){
			isDefaIndx = 1;
			isDiscIndx = 0;
			$scope.selectedDiscPercentage = 0;
		}
		var params = {
			"classId":$scope.selectedClassObjc.classId,
	    "courseId":$scope.selectedCourse,
	    "branchId":$scope.selectedBranch,
	    "createdBy":$scope.user_id,
	    "schemaName":$scope.schemaName,
	    "isDefault":isDefaIndx,
	    "detailsArray":[{
	        "acadFeeDetailId":$scope.selectedFeeCategory,
					"feeDiscountTypeId":$scope.selectedDisCategory.categoryId,
					"isDiscount":isDiscIndx,
	        "amount":$scope.totalAmount,
					"feeDiscountPerc":$scope.selectedDiscPercentage
	    }]
		}
		console.log(params);
	//	return true;

		httpFactory.executePost("addClassCourseFeeDetails",params,function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert("added");
			}
			else{
				alert("Got Error");
			}
		});
	}

/* Adding Discount Category */

	$scope.selDiscCategory = "";
	$scope.selDiscDesc = "";
	$scope.selDiscMin = 0;
	$scope.selDiscMax = 0;

	$scope.addDiscCategory = function(){
		$scope.selDiscMin = document.getElementById("discMin").value;
		$scope.selDiscMax = document.getElementById("discMax").value;
		var params = {
			"schemaName":$scope.schemaName,
    	"feeDiscountName":$scope.selDiscCategory,
    	"feeDiscountDesc":$scope.selDiscDesc,
    	"maxDiscount":$scope.selDiscMax,
    	"minDiscount":$scope.selDiscMin,
    	"createdBy":$scope.user_id,
		};

		console.log(params);
		//return true;
		httpFactory.executePost("addEditDiscountType", params,function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert("added");
				$scope.selDiscCategory = "";
				$scope.selDiscDesc = "";
				$scope.selDiscMin = 0;
				$scope.selDiscMax = 0;
				document.getElementById("discMin").value = 0;
				document.getElementById("discMax").value = 0;
			}
			else{
				alert("Got Error");
			}
		});
	};


	/* adding Fee Category */


	$scope.feeTypeName = "";
	$scope.feeAmount = "";
	$scope.feeLastDate = "";
	$scope.academicYearFrom ="";
	$scope.academicYearTo = "";

	$scope.termLength = 0;
	$scope.termsList = [];

	$scope.isDefaultTerm = function()	{
		if(document.getElementById('isDefaultTerm').checked == true){
				$scope.termLength = 1;
				$scope.createTermsList();
		}else{
			$scope.termLength = 0;
			$scope.termsList = [];
		}
	}

	$scope.createTermsList = function(){
		$scope.termsList = [];
		console.log($scope.termLength);

		for(var i=0; i<$scope.termLength; i++){
			var termsObject = {
					"termIndex":i,
					"acadFeeTermName":"",
					"fromDate":"",
					"toDate":"",
			};
			$scope.termsList.push(termsObject);
		}
	}


	$scope.addNewFeeType = function(){

		var selTermList = [];
		for(var i=0; i<$scope.termsList.length; i++){
			var fromDate = new Date($scope.termsList[i].fromDate);
			var toDate = new Date($scope.termsList[i].toDate);
			var termsObject = {
					"acadFeeTermName":$scope.termsList[i].acadFeeTermName,
					"fromDate":fromDate.getFullYear()+"-"+(fromDate.getMonth()+1)+"-"+fromDate.getDate(),
					"toDate": toDate.getFullYear()+"-"+(toDate.getMonth()+1)+"-"+toDate.getDate(),
					"lastDueDate":toDate.getFullYear()+"-"+(toDate.getMonth()+1)+"-"+toDate.getDate(),
			};
			selTermList.push(termsObject);
		}
		var  academicYearFrom = new Date($scope.academicYearFrom);
		var academicYearTo = new Date($scope.academicYearTo);
		var lastDueDate = new Date($scope.feeLastDate);
		var params = {
			"schemaName":$scope.schemaName,
			"acadFeeType":$scope.feeTypeName,
    	"termCount":$scope.termsList.length,
    	"isRecurring":1,
			"academicYear":academicYearFrom.getFullYear()+"-"+academicYearTo.getFullYear(),
			"lastDueDate":lastDueDate.getFullYear()+"-"+(lastDueDate.getMonth()+1)+"-"+lastDueDate.getDate(),
    	"createdBy":$scope.user_id,
			"termArray":selTermList
		}

		console.log(params);

		httpFactory.executePost("addAcademicFeeType", params,function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert("added");
			}
			else{
				alert("Got Error");
			}
		});



	}


});
