projectModule.controller('liveDashboardController', function($scope, $location, commonFactory, httpFactory, $routeParams, $sce) {
	$scope.$ = $;
	google.charts.load('current', { packages: ['corechart', 'bar'] });

	$scope.roleId = localStorage.getItem("RD");
	$scope.localDomain = localStorage.getItem("domain");
	$scope.selSubjId = sessionStorage.getItem("selsubId");
	$scope.courseId = sessionStorage.getItem("selcourseId");
	$scope.classId = sessionStorage.getItem("selclassId");
	$scope.SubjName = sessionStorage.getItem("selsubName");
	$scope.courseName = sessionStorage.getItem("selcourseName");
	$scope.className = sessionStorage.getItem("selclassName");
	$scope.schemaName = "ekalavya_store";
	$scope.selectedStudId = sessionStorage.getItem("selStudentId");
	$scope.selectedChapId = sessionStorage.getItem("selChapterId");
	$scope.selectedDomainId = sessionStorage.getItem("selDomainId");
	$scope.selectedStudName = sessionStorage.getItem("selStudentName");

	$scope.subjectList = [];
	$scope.gotoLiveDashboard = function(classId, courseId) {
		$location.path("liveDashboard/" + classId + "/" + courseId);
	}
	
	$scope.getAllClasses = function() {
		httpFactory.getResult("getClassCoursesForStudentLiveDashboard?schemaName=ekalavya_store", function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' && data.StatusCode == 200) {
				$scope.classList = data.Classes;
			} else {

			}
		});
	}
	
	$scope.getStudentListForLiveDashboard = function() {
		httpFactory.getResult("getStudentListForLiveDashboard?schemaName=ekalavya_store" + "&branchId=" + localStorage.getItem("bnchId") + "&classId=" + $routeParams.classId + "&courseId=" + $routeParams.courseId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.studentList = data.studentList;
				$scope.getSubjectListForLiveDashboardByCourseIdAndClassId();
			}
			else { }
		});
	}
	
	$scope.getSubjectsAndChaptersForInsightsByStudentId = function() {
		httpFactory.getResult("getSubjectsAndChaptersForInsightsByStudentId?schemaName=ekalavya_store" + "&studentId=" + $scope.selectedStudId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.subjectList = data.subjectList;
//				for (i = 0; i < $scope.subjectList.length; i++) {
//					$scope.chapWiseGraph($scope.subjectList[i]);
//				}
			} else {

			}
		});
	}

//	$scope.chapWiseGraph = function(subList) {
//		google.load('visualization', '1.0', { 'packages': ['corechart'] });
//		google.setOnLoadCallback(drawBasic);
//		function drawBasic() {
//			var chartdata = [];
//			var Header = ['Domains', 'Total Percentage %',];
//			chartdata.push(Header);
//			for (j = 0; j < subList.chapterArray.length; j++) {
//				var temp = [];
//				temp.push(subList.chapterArray[j].chapterName);
//				temp.push(parseFloat(subList.chapterArray[j].correctAwnsersPerct));
//				chartdata.push(temp);
//			}
//			var data = google.visualization.arrayToDataTable(chartdata);
//
//			var options = {
//				title: 'Chapter Wise Percentage',
//				chartArea: { width: '40%' },
//				hAxis: {
//					title: 'Total Percentage',
//					minValue: 0,
//					maxValue: 100
//				},
//				vAxis: {
//					title: 'City'
//				}
//			};
//
//			var chart = new google.visualization.BarChart(document.getElementById('ssubjList'));
//
//			
//            chart.draw(data, options);
//		}
//	}

	$scope.getTopicListForInsightsByChapterId = function(chapterId) {
		sessionStorage.setItem("selChapterId", chapterId);
		$scope.testList = [];
		document.getElementById("subChapList").style.display = "none";
		document.getElementById("chapTopicList").style.display = "block";
		httpFactory.getResult("getTopicListForInsightsByChapterId?schemaName=ekalavya_store" + "&chapterId=" + chapterId + "&studentId=" + $scope.selectedStudId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.topicList = data.topicList;
				$scope.getDomainListWithPercentageByChapterId(chapterId);
			} else {

			}
		});
	}



	$scope.getSubjectListForLiveDashboardByCourseIdAndClassId = function() {
		httpFactory.getResult("getSubjectListForLiveDashboardByCourseIdAndClassId?schemaName=ekalavya_store" + "&courseId=" + $routeParams.courseId + "&classId=" + $routeParams.classId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.subjectList = data.subjectList;
				$scope.showCODiv($scope.subjectList[0].subjectId,0);
			} else {

			}
		});
	}

	$scope.gotoStudentLiveDashBoard = function(studDetails) {
		sessionStorage.setItem("selStudentId", studDetails.studentId);
		sessionStorage.setItem("selStudentName", studDetails.studentName);
		$location.path("studentLiveDashboard");
	}

	$scope.latestCurrentTabTest = 'examAnalysis';

	$scope.redirectToCurrentTabTest = function(currentTab) {
		$scope.latestCurrentTabTest = currentTab;
		$scope.getStoreStudentSubjectListForLiveDashboard();
	}

	$scope.showCODiv = function(tab, indx) {
		$scope.activeCOTab = tab;
		console.log($scope.activeCOTab);
		$scope.coQues = indx;
	}

	$scope.goBackToSubjects = function() {
		document.getElementById("subChapList").style.display = "block";
		document.getElementById("chapTopicList").style.display = "none";
		document.getElementById("chapWiseInsights").style.display = "none";
		$scope.getSubjectsAndChaptersForInsightsByStudentId();

	}

	$scope.getTestData = function(topId) {
		if ($scope.tempTopicId != topId) {
			$scope.getPreviousTestsForStudentByTopicId(topId);
			$scope.tempTopicId = topId;
		} else {
			$scope.testList = [];
			$scope.tempTopicId = "";
		}
	}

	$scope.getPreviousTestsForStudentByTopicId = function(topId) {
		httpFactory.getResult("getPreviousTestsForStudentByTopicId?schemaName=ekalavya_store" + "&studentId="+$scope.selectedStudId+"&topicId=" + topId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.testList = data.quizArray;
			}
			else { }
		});
	}

	$scope.getDomainListWithPercentageByChapterId = function(chapId) {
		sessionStorage.setItem("selChapterId", chapId);
		httpFactory.getResult("getDomainListWithPercentageByChapterId?schemaName=ekalavya_store" + "&studentId=" + $scope.selectedStudId + "&chapterId=" + chapId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.chapWiseDomainList = data.domainList;
			}
			else { }
		});
		google.charts.setOnLoadCallback(drawBasic);


		function drawBasic() {
			var chartdata = [];
			var Header = ['Domains', 'Total Percentage %',];
			chartdata.push(Header);
			for (j = 0; j < $scope.chapWiseDomainList.length; j++) {
				var temp = [];
				temp.push($scope.chapWiseDomainList[j].domainName);
				temp.push(parseFloat($scope.chapWiseDomainList[j].correctAwnsersPerct));
				chartdata.push(temp);
			}
			var data = google.visualization.arrayToDataTable(chartdata);

			var options = {
				title: 'Domain Wise Percentage',
				chartArea: {width: '40%'},
				 hAxis: {
					title: 'Total Percentage',
					minValue: 0,
					maxValue: 100
				},
				vAxis: {
					title: 'City'
				}
			};

			var chart = new google.visualization.BarChart(document.getElementById('keyword_chart'));

			chart.draw(data, options);
		}
	}

	$scope.goToChapInsights = function(){
		document.getElementById("subChapList").style.display = "none";
		document.getElementById("chapTopicList").style.display = "none";
		document.getElementById("chapWiseInsights").style.display = "block";
		$scope.getChapWiseInsightByChapId();
	}
	
	$scope.getChapWiseInsightByChapId = function(){
		httpFactory.getResult("getChapterWiseInsightsByChapterId?schemaName=ekalavya_store&chapterId=" + sessionStorage.getItem("selChapterId") + "&studentId=" + sessionStorage.getItem("selStudentId"), function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.chapWiseInsightList = data.domainList;
			}else if (data.StatusCode == 300){
				console.log(data.MESSAGE);
			}else {

			}
		});
		$scope.printContent = function() {
                  var printStyle = document.createElement('style');
                  printStyle.innerHTML = `
                    @media print {
                      body * {
                        display: none !important;
                      }
                      #printContainer,
                      #printContainer * {
                        display: block !important;
                      }
                    }
                  `;
                  document.head.appendChild(printStyle);

                  var printContainer = document.createElement('div');
                  printContainer.id = 'printContainer';

                  var nameElement = document.createElement('p');
                            nameElement.style.color = 'black';
                            nameElement.style.marginRight = '80%';
                            nameElement.style.fontSize = '18px';
                            nameElement.innerHTML = 'Name: ' + $scope.selectedStudName;
                            printContainer.appendChild(nameElement);

                            var chapterNameElement = document.createElement('div');
                            chapterNameElement.style.padding = '10px';
                            chapterNameElement.style.fontSize = '25px';
                            chapterNameElement.style.color = '#702558';
                            chapterNameElement.style.textAlign = 'center';
                            chapterNameElement.style.borderStyle = 'none';
                            chapterNameElement.style.fontWeight = 'bold';
                            chapterNameElement.innerHTML = 'Chapter name: ' + $scope.topicList[0].chapterName;
                            printContainer.appendChild(chapterNameElement);

                  angular.forEach($scope.chapWiseInsightList, function(domains) {
                    var domainDiv = document.createElement('div');
                    domainDiv.style.padding = '10px';
                    domainDiv.style.fontSize = '35px';
                    domainDiv.style.color = '#702558';
                    domainDiv.style.textAlign = 'center';
                    domainDiv.style.borderStyle = 'none';
                    domainDiv.style.fontWeight = 'bold';
                    domainDiv.innerHTML = domains.domainName;

                    angular.forEach(domains.keywordArray, function(keywordList) {
                      var keywordDiv = document.createElement('div');
                      keywordDiv.style.fontSize = '25px';
                      keywordDiv.style.color = '#36454F';
                      keywordDiv.style.fontWeight = '100';
                      keywordDiv.style.margin = '1px';
                      keywordDiv.style.paddingLeft = '20%';
                      keywordDiv.style.paddingRight = '20%';

                      angular.forEach(keywordList.topicArray, function(sentList) {
                        var sentenceDiv = document.createElement('div');
                        sentenceDiv.style.fontSize = '20px';
                        sentenceDiv.style.color = '#36454F';
                        sentenceDiv.innerHTML = sentList.sentences;

                        keywordDiv.appendChild(sentenceDiv);
                      });
                      domainDiv.appendChild(keywordDiv);
                    });
                    printContainer.appendChild(domainDiv);
                  });
                  document.body.appendChild(printContainer);
                  window.print();
                  document.head.removeChild(printStyle);
                  document.body.removeChild(printContainer);
                };
	}
	
	$scope.getDomainWiseInsightsByChapterIdAndDomainId = function(domId,domainName,chapId) {
		$scope.selectedChapterId = chapId;
		$scope.selectedDomainName = domainName;
		httpFactory.getResult("getDomainWiseInsightsByChapterIdAndDomainId?schemaName=ekalavya_store" + "&studentId=" + $scope.selectedStudId + "&chapterId=" + chapId + "&domainId=" + domId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.domWiseKeywordList = data.domainList;
			}
			else { }
		});
	}

	$scope.gotoStudentReports = function(domId,domainName,chapterId) {
	    document.getElementById("subChapList").style.display = "none";
		document.getElementById("chapTopicList").style.display = "none";
		document.getElementById("keywordWiseReports").style.display = "block";
		$scope.getDomainWiseInsightsByChapterIdAndDomainId(domId,domainName,chapterId);
		/*sessionStorage.setItem("selDomainId", domId);
		$location.path("studentReport");*/
	}
    
    $scope.goBackToChapterAndTopics = function(chapterId) {
		document.getElementById("subChapList").style.display = "none";
		document.getElementById("chapTopicList").style.display = "block";
		document.getElementById("chapWiseInsights").style.display = "none";
		document.getElementById("keywordWiseReports").style.display = "none";
		$scope.getTopicListForInsightsByChapterId(chapterId);

	}
});
