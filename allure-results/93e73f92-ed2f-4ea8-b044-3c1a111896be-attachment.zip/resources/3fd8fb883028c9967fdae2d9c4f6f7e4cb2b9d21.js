projectModule.controller('reportCardPreviewController', function ($scope, $rootScope, $compile, $timeout, $location, commonFactory, httpFactory, $routeParams) {

    $scope.$ = $;
    $scope.schemaName = localStorage.getItem("sname");
    $scope.branchId = localStorage.getItem("bnchId");
    $scope.branchName = localStorage.getItem("branchName");
    $scope.change = false;
    $scope.inputBox = true;

    $scope.student = null;
    $scope.selectedStudentIndex = 0;

    $scope.getBranchDetailsForRC = function () {
        httpFactory.getResult("getBranchDetailsForHalltickets?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId, function (data) {
            if (data.StatusCode == 200) {
                $scope.branchReportCardData = data.hallticketData;
                $scope.branchName = $scope.branchReportCardData.branchName;
                $scope.branchAddress = $scope.branchReportCardData.branchAddress;
                $scope.academicYear = $scope.branchReportCardData.academicYear;
                if ($scope.branchReportCardData.logo !== '') {
                    $scope.logo = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.branchReportCardData.logo;
                } else {
                    $scope.logo = '';
                }
                if ($scope.branchReportCardData.principleSignature !== '') {
                    $scope.principleSignature = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.branchReportCardData.principleSignature;
                } else {
                    $scope.principleSignature = '';
                }
            } else {
                $scope.branchReportCardData = undefined;
                $scope.principleSignature = '';
            }
        });
    }

    $scope.getTemplateToUse = function (stf) {
        if (stf == undefined) {
            $scope.templateId = sessionStorage.getItem("templateId");
        } else {
            $scope.templateId = stf.templateId;
            $scope.selectedTemplate = stf;
        }
        $scope.testIds = [];
        $scope.updateArray = [];
        $scope.colName = '';
        if ($scope.selectedTemplate != "") {
            httpFactory.getResult("getGenericRCT?templateId=" + $scope.templateId + "&schemaName=" + $scope.schemaName, function (data) {
                if (data.StatusCode == 200) {
                    $scope.changeTemplateMode('1');
                    $scope.testsArray = data.workingDays.slice();
                    $scope.columnLength = $scope.testsArray.length;
                    $scope.colName = '';
                }


            });
        }
    }

    $scope.getGradesandGradePointsForReportCard = function () {
        httpFactory.getResult("getGradesandGradePointsForReportCard?schemaName=" + $scope.schemaName, function (data) {
            if (data.StatusCode == 200) {
                $scope.gradeArray = data.gradesArray;
            }
        });
    }

    $scope.getReportCardDetailsForStudents = async function () {
        $scope.getBranchDetailsForRC();
        $scope.getTemplateToUse();
        $scope.getGradesandGradePointsForReportCard();
        const temp = {
            "courseId": sessionStorage.getItem("courseId"),
            "classId": sessionStorage.getItem("classId")
        };
        $scope.getSubjectsByCourseClass(temp, temp);

        $scope.studentAttArray = [];

        const selectStudentList = JSON.parse(sessionStorage.getItem("selectStudentList"));

        const profilePicturePrefix = (localStorage.getItem("domain").includes('ekalavya.online') ? ((window.location.href.includes('//www.')) ? 'https://www.' : 'https://') : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath="

        // Loop through each student and fetch their report card
        selectStudentList.forEach(function (student) {
            const studentDetails = {};

            studentDetails["studentDetails"] = $scope.getStudentDetailsForReportCard(student);

            studentDetails["studentDetails"].profilePic = profilePicturePrefix + studentDetails["studentDetails"].profilePic;

            studentDetails["studentDetails"].classSection = sessionStorage.getItem("className") + '-' + studentDetails["studentDetails"].sectionName

            const response = $scope.getReportCardTestMarks(student);
            studentDetails["studentRcMarks"] = response.returnValue;
            studentDetails["totalCalculation"] = response.totalCalc;

            studentDetails["studentReportCardPresentDays"] = $scope.getRCPresentAttendance(student);
            // Calculate total working days and present days
            studentDetails["totalWorkingDays"] = $scope.sum(studentDetails["studentReportCardPresentDays"], 'totalWorkingDays');
            studentDetails["totalPresentDays"] = $scope.sum(studentDetails["studentReportCardPresentDays"], 'presentDays');

            // Add the studentDetails object to studentArray
            $scope.studentAttArray.push(studentDetails);
        });
        // Iterate through the student array
        $scope.studentAttArray.forEach(function (student) {
            // Iterate through each subject
            student.studentRcMarks.forEach(function (subject) {
                if(subject.marks !== undefined){
                    // Iterate through each mark
                    subject.marks.forEach(function (mark) {
                        // Add 'originalValue' property if not already present
                        if (typeof mark.originalValue === 'undefined') {
                            mark.originalValue = mark.mark;
                        }
                    });
                }
            });
        });

        if($scope.studentAttArray.length > 0){
            const queryParams = window.location.hash?.split('?')[1]?.split('&')
            const selectedStudentIndex = queryParams?.find((o) => o && o.split('=')[0] === 'selectedStudentIndex' && o.split('=')[1])?.split('=')[1]
            if(selectedStudentIndex && !isNaN(selectedStudentIndex)){
                $scope.selectedStudentIndex = Number(selectedStudentIndex)
            }else{
                window.location.hash =  window.location.hash.split('?')[0] + '?selectedStudentIndex=0'
            }
            $scope.student = $scope.studentAttArray[$scope.selectedStudentIndex]
            const color =  (queryParams?.find((o) => o && o.split('=')[0] === 'isBlackAndWhite' && o.split('=')[1])?.split('=')[1]) === 'true'
            if(color){
                $scope.change = true
            }else{
                $scope.change = false
            }
            $scope.isAutoDownload = (queryParams?.find((o) => o && o.split('=')[0] === 'autoDownload' && o.split('=')[1])?.split('=')[1]) === 'true'
            if($scope.isAutoDownload){
                if($scope.selectedStudentIndex >= $scope.studentAttArray.length){
                    $scope.isAutoDownload = false
                    window.location.hash =  window.location.hash.split('?')[0] + '?selectedStudentIndex=0&autoDownload=false'
                }else{
                    await delay(0)
                    await $scope.makePdfForReportCard()
                }
            }
        }
    }

    $scope.selectPreviousStudent = function() {
        if($scope.selectedStudentIndex > 0){
            $scope.selectedStudentIndex--;
            $scope.student = $scope.studentAttArray[$scope.selectedStudentIndex]
        }
    }

    $scope.selectNextStudent = function() {
        if($scope.selectedStudentIndex < $scope.studentAttArray.length - 1){
            $scope.selectedStudentIndex++;
            $scope.student = $scope.studentAttArray[$scope.selectedStudentIndex]
        }
    }

    async function delay (ms) {
        return await new Promise((resolve) => setTimeout(() => resolve(true), ms))
    }

    $scope.makePdfForReportCard = async function() {
        if(!$scope.isAutoDownload && $scope.selectedStudentIndex !== 0){
            window.location.hash =  window.location.hash.split('?')[0] + '?selectedStudentIndex=0&autoDownload=true';
            window.location.reload();
        }
        const loadingIndicator = document.getElementById("loadingOverlay");
        if($scope.selectedStudentIndex === 0){
            if (!confirm('Make sure your page resolution is 100%.')) {
                return;
            }
        }
        loadingIndicator.style.display = "block";
        const studDOB = document.getElementById("studDOB");
        const studDOBDisplay = document.getElementById("studDOBDisplay");
        studDOBDisplay.value = new Date(studDOB.value)?.toLocaleDateString();
        studDOB.style.display = "none";
        studDOBDisplay.style.display = "block";
        $scope.inputBox = false;
        const studentsDivsLength =  $scope.studentAttArray.length

        async function processDiv() {
            try {
                const div = document.getElementById(`reportCardPdfContent-${$scope.selectedStudentIndex}`)
                const pdf = new window.jspdf.jsPDF('l', 'pt', 'a4');
                const PDF_Width = pdf.internal.pageSize.width;
                const canvas = await html2canvas(div, { allowTaint: true, scale: 1 })
                const scaleFactor = PDF_Width / canvas.width;
                const HTML_Width = PDF_Width;
                const HTML_Height = canvas.height * scaleFactor;
                const blob = await new Promise(resolve => canvas.toBlob(resolve,'image/jpeg'));
                const img = new Image()
                img.src = URL.createObjectURL(blob)
                pdf.addImage(img, 'JPEG', 0, 0, HTML_Width, HTML_Height)
                await pdf.save(`reportCard_part${$scope.selectedStudentIndex}.pdf`)
                URL.revokeObjectURL(img.src)

                window.location.hash =  window.location.hash.split('?')[0] + '?selectedStudentIndex=' + ($scope.selectedStudentIndex + 1) + `&autoDownload=true&isBlackAndWhite=${$scope.change}`
                if($scope.selectedStudentIndex === $scope.studentAttArray.length - 1){
                    loadingIndicator.style.display = "none";
                    $scope.inputBox = true;
                    studDOB.style.display = "block";
                    studDOBDisplay.style.display = "none";
                    alert("All PDFs have been downloaded.");
                }
                window.location.reload()

            } catch (err){
                console.error('error while generating PDF:', err)
                throw err
            }
        }

        try {
            await processDiv()
        }
        catch (err){
            loadingIndicator.style.display = "none";
            $scope.inputBox = true;
            studDOB.style.display = "block";
            studDOBDisplay.style.display = "none";
            console.error("error while generating PDFs",err)
            alert("Failed to generate PDFs.");
        }
    };


    $scope.saveReportCardDetails = function (students) {
        const reportCardDetails = [];
        const missingMadatoryForStudents = [];
        $scope.studentAttArray.forEach(function (student) {
            // Check if student details are empty
            if (
            !student.studentDetails.fatherName ||
            !student.studentDetails.motherName ||
            !student.studentDetails.DOB
            ) {
                missingMadatoryForStudents.push(student.studentDetails.studentName)
            }

            // Check if student details have changed
            const dob = student.studentDetails.DOB.toString();

            if (dob && !dob.includes('-')) {
                const date = new Date(student.studentDetails.DOB);
                let genMon = date.getMonth() + 1;

                if (genMon < 10) {
                    genMon = "0" + genMon;
                }

                const genDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
                student.studentDetails.DOB = genDate;
            }

            const studentData = {
                "DOB": student.studentDetails.DOB,
                "fatherName": student.studentDetails.fatherName,
                "motherName": student.studentDetails.motherName,
                "studentId": student.studentDetails.studentId,
                "reportCardId": student.studentDetails.reportCardId
            };

            reportCardDetails.push(studentData);
        });

        // Check if any changes were made
        if (reportCardDetails.length === 0) {
            alert("No changes detected for any student");
            return;
        }else if(missingMadatoryForStudents.length > 0){
            alert("Please enter all details for students: " + missingMadatoryForStudents.join(', '));
            return;
        }

        const params = {
            "schemaName": $scope.schemaName,
            "branchId": $scope.branchId,
            "templateId": sessionStorage.getItem("templateId"),
            "courseId": sessionStorage.getItem("courseId"),
            "createdBy": localStorage.getItem("userId"),
            "studentDetails": reportCardDetails
        };

        //Call your API with the params object
        httpFactory.executePost("saveReportCardDetails", params, function (data) {

            if (data.StatusCode == 200) {
                alert("Changes Saved for multiple students");
                // Add any additional logic if needed
            } else {
                alert("Something went wrong");
            }
        });
    };

    $scope.avgAndSumMarks = function () {
        for (i = 0; i < $scope.rcMarks.length; i++) {
            if ($scope.rcMarks[i].subjectType === 'General') {
                for (j = 0; j < $scope.rcMarks[i].marks.length; j++) {
                    if ($scope.rcMarks[i].marks[j].colType === 'Avg' || $scope.rcMarks[i].marks[j].colType === 'Sum') {
                        $scope.rcMarks[i].marks[j].totalMarks = '';
                        $scope.rcMarks[i].marks[j].mark = '';
                        for (t = 0; t < $scope.testsArray.length; t++) {
                            if ($scope.rcMarks[i].marks[j].colType === $scope.testsArray[t].colType && $scope.rcMarks[i].marks[j].colNum === $scope.testsArray[t].colNum) {
                                if (i == 0) {
                                    $scope.testsArray[t].totalMarks = '';
                                }
                                for (k = 0; k < $scope.rcMarks[i].marks.length; k++) {
                                    if ($scope.rcMarks[i].marks[j].testId.includes($scope.rcMarks[i].marks[k].testId) && $scope.rcMarks[i].marks[k].colType === 'Test') {
                                        $scope.rcMarks[i].marks[j].mark = Number($scope.rcMarks[i].marks[j].mark) + Number($scope.rcMarks[i].marks[k].mark);
                                        $scope.rcMarks[i].marks[j].totalMarks = Number($scope.rcMarks[i].marks[j].totalMarks) + Number($scope.rcMarks[i].marks[k].totalMarks);
                                        if (i == 0) {
                                            $scope.testsArray[t].totalMarks = Number($scope.testsArray[t].totalMarks) + Number($scope.rcMarks[i].marks[k].totalMarks);
                                            $scope.totalCalculation[0].marks[j].totalMarks = $scope.rcMarks[i].marks[j].totalMarks;
                                        }
                                    }
                                }
                                if ($scope.rcMarks[i].marks[j].colType === 'Avg') {
                                    $scope.rcMarks[i].marks[j].mark = Math.round(Number($scope.rcMarks[i].marks[j].mark) / $scope.rcMarks[i].marks[j].testId.length);
                                    $scope.rcMarks[i].marks[j].totalMarks = Math.round(Number($scope.rcMarks[i].marks[j].totalMarks) / $scope.rcMarks[i].marks[j].testId.length);
                                    if (i == 0) {
                                        $scope.testsArray[t].totalMarks = Math.round(Number($scope.testsArray[t].totalMarks) / $scope.testsArray[t].testId.length);
                                        $scope.totalCalculation[0].marks[j].totalMarks = $scope.rcMarks[i].marks[j].totalMarks;
                                    }
                                }
                            }
                        }
                    }
                    if ($scope.rcMarks[i].marks[j].colType.includes('Grade')) {
                        $scope.rcMarks[i].marks[j].mark = '';
                        for (k = 0; k < $scope.rcMarks[i].marks.length; k++) {
                            if ($scope.rcMarks[i].marks[j].colNum === $scope.rcMarks[i].marks[k].colNum && $scope.rcMarks[i].marks[k].colType !== 'Total Percentage' && $scope.rcMarks[i].marks[k].colType !== 'Grade' && $scope.rcMarks[i].marks[k].colType !== 'Grade Points') {
                                for (m = 0; m < $scope.gradeArray.length; m++) {
                                    if (Math.round(($scope.rcMarks[i].marks[k].mark * 100) / ($scope.rcMarks[i].marks[k].totalMarks)) >= $scope.gradeArray[m].marksFrom && Math.round(($scope.rcMarks[i].marks[k].mark * 100) / ($scope.rcMarks[i].marks[k].totalMarks)) <= $scope.gradeArray[m].marksTo) {
                                        if ($scope.rcMarks[i].marks[j].colType === 'Grade') {
                                            $scope.rcMarks[i].marks[j].mark = $scope.gradeArray[m].grade;
                                        }
                                        if ($scope.rcMarks[i].marks[j].colType === 'Grade Points') {
                                            $scope.rcMarks[i].marks[j].mark = $scope.gradeArray[m].gradePoints;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        $scope.totalPercentage = 0;
        $scope.totalGPA = '';
        for (k = 0; k < $scope.rcMarks[0].marks.length; k++) {
            $scope.totalCalculation[0].marks[k].mark = '';
            let count = 0;
            for (l = 0; l < $scope.rcMarks.length; l++) {
                if ($scope.rcMarks[l].subjectType === 'General') {
                    $scope.totalCalculation[0].marks[k].mark = Number($scope.totalCalculation[0].marks[k].mark) + Number($scope.rcMarks[l].marks[k].mark);
                    count++;
                }
            }
            for (m = 0; m < $scope.gradeArray.length; m++) {
                if (Math.round(($scope.totalCalculation[0].marks[k].mark * 100) / ($scope.totalCalculation[0].marks[k].totalMarks * (count))) >= $scope.gradeArray[m].marksFrom && Math.round(($scope.totalCalculation[0].marks[k].mark * 100) / ($scope.totalCalculation[0].marks[k].totalMarks * (count))) <= $scope.gradeArray[m].marksTo) {
                    $scope.totalCalculation[1].marks[k].mark = $scope.gradeArray[m].grade;
                    $scope.totalCalculation[2].marks[k].mark = $scope.gradeArray[m].gradePoints;
                    break;
                }
                if ($scope.totalCalculation[0].marks[k].colType === 'Total Percentage' && m == 0) {
                    for (n = 0; n < $scope.totalCalculation[0].marks.length; n++) {
                        if ($scope.totalCalculation[0].marks[n].colNum === $scope.totalCalculation[0].marks[k].colNum && $scope.totalCalculation[0].marks[n].colType !== 'Total Percentage' && $scope.totalCalculation[0].marks[n].colType !== 'Grade' && $scope.totalCalculation[0].marks[n].colType !== 'Grade Points') {
                            $scope.totalPercentage = ($scope.totalCalculation[0].marks[n].mark * 100) / ($scope.totalCalculation[0].marks[n].totalMarks * (count));
                        }
                    }
                }
                if (Math.round($scope.totalPercentage) >= $scope.gradeArray[m].marksFrom && Math.round($scope.totalPercentage) <= $scope.gradeArray[m].marksTo) {
                    $scope.totalGPA = $scope.gradeArray[m].gradePoints;
                }
            }
        }
        return $scope.totalCalculation
    }

    $scope.practicalMarksAndGrade = function () {
        for (i = 0; i < $scope.rcMarks.length; i++) {
            if ($scope.rcMarks[i].subjectType !== 'General') {
                for (j = 0; j < $scope.rcMarks[i].marks.length; j++) {
                    for (k = 0; k < $scope.rcMarks[i].markGrade.length; k++) {
                        if ($scope.rcMarks[i].marks[j].testId == $scope.rcMarks[i].markGrade[k].testId) {
                            if ($scope.rcMarks[i].markGrade[k].hasOwnProperty('mark'))
                            $scope.rcMarks[i].marks[j].mark = $scope.rcMarks[i].markGrade[k].mark;
                            else
                            $scope.rcMarks[i].marks[j].grade = $scope.rcMarks[i].markGrade[k].grade;
                        }
                    }
                }
            }
        }
    }

    $scope.getSubjectsByCourseClass = function (selectedCrs, selectedCls) {
        let selectedCourse
        let selectedClass
        if (typeof selectedCrs == 'string' && selectedCrs != '')
        selectedCourse = JSON.parse(selectedCrs)
        else
        selectedCourse = selectedCrs;
        if (typeof selectedCls == 'string' && selectedCls != '')
        selectedClass = JSON.parse(selectedCls)
        else
        selectedClass = selectedCls;
        $scope.classSubjectsList = [];
        $scope.subjectsList = [];
        httpFactory.getResult("getSubjectsByCourseForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + selectedCourse.courseId + "&classId=" + selectedClass.classId, function (data) {
            if (data.StatusCode == 200) {
                $scope.subjectsList = data.subjectsArray;
                for (i = 0; i < $scope.subjectsList.length; i++) {
                    $scope.classSubjectsList.push($scope.subjectsList[i]);
                    if ($scope.subjectsList[i].isAssigned == 1) {
                        $scope.subjectsList[i]["selected"] = true;
                    }
                    else {
                        $scope.subjectsList[i]["selected"] = false;
                    }
                }
            } else if (data.StatusCode == 300)
            $scope.subjectsList = [];
        });
    }

    $scope.getStudentDetailsForReportCard = function (student) {
        let studentId = "";
        if (student != undefined) {
            studentId = student.studentId;
        }
        else {
            studentId = sessionStorage.getItem("studentId");
        }
        let reportCardStudentDetails
        httpFactory.getResult("getStudentDetailsForReportCard?schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&sectionId=" + sessionStorage.getItem("sectionId") + "&studentId=" + studentId + "&templateId=" + sessionStorage.getItem("templateId"), function (data) {
            if (data.StatusCode == 200) {
                reportCardStudentDetails = data.reportCardStudentDetails[0];
            }
        });
        return reportCardStudentDetails;
    }

    $scope.getReportCardTestMarks = function (student) {
        let totalCalc
        let studentId = "";
        if (student != undefined) {
            studentId = student.studentId;
        }
        else {
            studentId = sessionStorage.getItem("studentId");
        }
        $scope.rcMarks = [];
        httpFactory.getResult("getReportCardTestMarks?schemaName=" + $scope.schemaName + "&studentId=" + studentId, function (data) {
            if (data.StatusCode == 200) {
                $scope.reportCardMarksArray = data.reportCardMarks;
                totalCalc = $scope.subjectsAndMarks();
            }
        });
        const returnValue = angular.copy($scope.rcMarks)
        $scope.rcMarks = null
        $scope.reportCardMarksArray = null
        return { returnValue, totalCalc };
    }

    $scope.subjectsAndMarks = function () {
        $scope.totalCalculation = [];
        $scope.totalCalculation.push({ "header": "Total" }, { "header": "Grade" }, { "header": "GPA" });
        let inx = -1;
        let tempSubId = 0;
        $scope.practicalMarks = false;
        for (i = 0; i < $scope.classSubjectsList.length; i++) {
            if ($scope.classSubjectsList[i].isAssigned == 1) {
                const sub = {
                    "subjectId": $scope.classSubjectsList[i].subjectId,
                    "subjectName": $scope.classSubjectsList[i].subjectName,
                    "subjectType": $scope.classSubjectsList[i].subjectType
                }
                $scope.rcMarks.push(sub);
                inx++;
                let number = 0;
                for (j = 0; j < $scope.testsArray.length; j++) {
                    let marks
                    if ($scope.rcMarks[inx].subjectType === 'General' && !($scope.testsArray[j].colType === 'Co-Curricular')) {
                        if (tempSubId == 0)
                        tempSubId = $scope.classSubjectsList[i].subjectId;

                        marks = {
                            "colType": $scope.testsArray[j].colType,
                            "colNum": $scope.testsArray[j].colNum,
                            "testId": $scope.testsArray[j].testId,
                            "totalMarks": $scope.testsArray[j].totalMarks,
                            "mark": ''
                        }
                        if (tempSubId == $scope.rcMarks[inx].subjectId) {
                            const totMarks = [];
                            totMarks.push(marks);
                            if ($scope.totalCalculation[0].hasOwnProperty("marks")) {
                                $scope.totalCalculation[0].marks.push(angular.copy(totMarks[0]));
                                $scope.totalCalculation[1].marks.push(angular.copy(totMarks[0]));
                                $scope.totalCalculation[2].marks.push(angular.copy(totMarks[0]));
                            } else {
                                $scope.totalCalculation[0]["marks"] = angular.copy(totMarks);
                                $scope.totalCalculation[1]["marks"] = angular.copy(totMarks);
                                $scope.totalCalculation[2]["marks"] = angular.copy(totMarks);
                            }
                        }
                    } else {
                        if (!($scope.testsArray[j].colType === 'Co-Curricular') || $scope.rcMarks[inx].subjectType === 'General') {
                            continue;
                        }
                        marks = {
                            "colType": $scope.testsArray[j].colType,
                            "colNum": $scope.testsArray[j].colNum,
                            "colName": $scope.testsArray[j].colName,
                            "testId": $scope.testsArray[j].testId,
                            "totalMarks": $scope.testsArray[j].totalMarks,
                            "mark": '',
                            "grade": ''
                        }
                        $scope.practicalMarks = true;
                    }
                    const subMarks = [];
                    subMarks.push(marks);
                    if ($scope.rcMarks[inx].hasOwnProperty("marks")) {
                        $scope.rcMarks[inx].marks.push(subMarks[0]);
                        if ($scope.rcMarks[inx].hasOwnProperty("markGrade") && $scope.rcMarks[inx].subjectType === 'Co-Curricular') {
                            const markObj = {
                                "testId": $scope.testsArray[j].testId,
                                "mark": ''
                            }
                            $scope.rcMarks[inx].markGrade.push(markObj);
                            const gradeObj = {
                                "testId": $scope.testsArray[j].testId,
                                "grade": ''
                            }
                            $scope.rcMarks[inx].markGrade.push(gradeObj);
                        }
                    } else {
                        $scope.rcMarks[inx]["marks"] = subMarks;
                        if (!$scope.rcMarks[inx].hasOwnProperty("markGrade") && $scope.rcMarks[inx].subjectType === 'Co-Curricular') {
                            const markObj = {
                                "testId": $scope.testsArray[j].testId,
                                "mark": ''
                            }
                            $scope.rcMarks[inx]["markGrade"] = [];
                            const markGrade = [];
                            $scope.rcMarks[inx].markGrade.push(markObj);
                            const gradeObj = {
                                "testId": $scope.testsArray[j].testId,
                                "grade": ''
                            }
                            $scope.rcMarks[inx].markGrade.push(gradeObj);
                        }
                    }

                    for (k = 0; k < $scope.reportCardMarksArray.length; k++) {
                        if ($scope.reportCardMarksArray[k].subjectId === Number($scope.classSubjectsList[i].subjectId) && $scope.reportCardMarksArray[k].testId == $scope.testsArray[j].testId && $scope.testsArray[j].colType === 'Co-Curricular') {
                            $scope.rcMarks[inx].marks[number].mark = $scope.reportCardMarksArray[k].marks;
                            if ($scope.rcMarks[inx].marks[number].colType === 'Co-Curricular') {
                                $scope.rcMarks[inx].marks[number].grade = $scope.reportCardMarksArray[k].grade;

                                for (a = 0; a < $scope.rcMarks[inx].markGrade.length; a++) {
                                    if ($scope.rcMarks[inx].markGrade[a].testId == $scope.reportCardMarksArray[k].testId && a % 2 == 0) {
                                        $scope.rcMarks[inx].markGrade[a].mark = $scope.reportCardMarksArray[k].marks;
                                    } else if ($scope.rcMarks[inx].markGrade[a].testId == $scope.reportCardMarksArray[k].testId && a % 2 == 1) {
                                        $scope.rcMarks[inx].markGrade[a].grade = $scope.reportCardMarksArray[k].grade;
                                    }
                                }
                            }
                            number++;
                            break;
                        } else if ($scope.reportCardMarksArray[k].subjectId === Number($scope.classSubjectsList[i].subjectId) && $scope.reportCardMarksArray[k].testId == $scope.testsArray[j].testId && $scope.testsArray[j].colType !== 'Co-Curricular' && $scope.testsArray[j].colType !== 'Total Percentage') {
                            $scope.rcMarks[inx].marks[j].mark = $scope.reportCardMarksArray[k].marks;
                            if ($scope.rcMarks[inx].marks[j].colType === 'Co-Curricular') {
                                $scope.rcMarks[inx].marks[j].grade = $scope.reportCardMarksArray[k].grade;
                            }
                            break;
                        }
                    }
                }
            }
        }

        return $scope.avgAndSumMarks();
    }

    $scope.getRCPresentAttendance = function (student) {
        let studentId = "";
        if (student != undefined) {
            studentId = student.studentId;
        }
        else {
            studentId = sessionStorage.getItem("studentId");
        }
        let reportCardPresentDays = []
        httpFactory.getResult("getRCPresentAttendance?schemaName=" + $scope.schemaName + "&studentId=" + studentId + "&branchId=" + $scope.branchId, function (data) {
            if (data.StatusCode == 200) {
                reportCardPresentDays = data.reportCardPresentDays;
            }
        });
        return reportCardPresentDays;
    }

    $scope.sum = function (items, prop) {
        if(items)
        return items.reduce(function (a, b) {
            return Number(a) + Number(b[prop]);
        }, 0);
    };

    $scope.changeTemplateMode = function (indx) {
        $scope.templateMode = indx;
        $scope.testsArray = [];
    }

    $scope.calculatePresents = function () {
        $scope.studentArray.forEach(function (student) {
            student.totalPresentDays = $scope.sum(student.studentReportCardPresentDays, 'presentDays');
        });
    }

    $scope.changeColor = function () {
        if ($scope.change)
        $scope.change = false;
        else
        $scope.change = true;
    }

    $scope.backMethod = function () {
        $location.path("reportCardGeneration");
    }
});