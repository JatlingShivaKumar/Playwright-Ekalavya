projectModule.controller('customTestGenerationController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;

	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.selectedQuestionsResponse = {

}

$scope.selectedQuestionsResObject = [];
$scope.selectedGroupSubj ="";
$scope.showQuesbjWise = function(sbj){
	$scope.selectedGroupSubj = sbj;
}


$scope.genrateQuestionsObjects = function(){
	for(var i=0; i<$scope.testQuestionsSubjectwise.length; i++){
		for(var j=0; j<Number($scope.testQuestionsSubjectwise[i].totalQuesNo); j++){
			var quesObj = {
				'subjectGroup':$scope.testQuestionsSubjectwise[i].subjectGroup,
				'questionIndex':j+1,
				'question':''
			}
			$scope.selectedQuestionsResObject.push(quesObj);
		}
	}
}

$scope.genrateQuestionsObjects();
});
