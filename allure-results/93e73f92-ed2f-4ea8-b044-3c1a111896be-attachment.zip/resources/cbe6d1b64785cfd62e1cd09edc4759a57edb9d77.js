projectModule.controller('storeContentManagementController', function($scope, $location, commonFactory, httpFactory, $routeParams, $sce) {
    $scope.$ = $;
    
    $scope.roleId = localStorage.getItem("RD");
    $scope.localDomain = localStorage.getItem("domain");
    $scope.selSubjId = sessionStorage.getItem("selsubId");
    $scope.courseId = sessionStorage.getItem("selcourseId");
    $scope.classId = sessionStorage.getItem("selclassId");
    $scope.SubjName = sessionStorage.getItem("selsubName");
    $scope.courseName = sessionStorage.getItem("selcourseName");
    $scope.className = sessionStorage.getItem("selclassName");
    $scope.schemaName = "ekalavya_store"; 
    $scope.groupList =[];
    $scope.chapQues=false;
    
    $scope.storeContentInit = function() {
        $scope.getChapterTopicsBySubjectChangeques();
    }
    
    $scope.addGroupModal = function() {
        $("#addGroup").modal('show');
    }
    
    $scope.addGroupInEdit = function() {
        $("#addGroupInEdit").modal('show');
    }
    
    $scope.addDomainModal = function() {
        $("#addDomain").modal('show');
    }
    
    $scope.addDomainInEdit = function() {
        $("#addDomainInEdit").modal('show');
    }
    
    $scope.addDomainKeywordModal = function() {
        $("#addDomainKeyword").modal('show');
    }
    
    $scope.addDomainKeywordInEdit = function() {
        $("#addDomainKeywordInEdit").modal('show');
    }
    
    $scope.getChapterTopicsBySubjectChangeques = function(subjectId) {
        angular.element("#smallLoader").show();
        console.log("class ID "+$scope.classId);
        console.log("subject ID "+$scope.selSubjId);
        setTimeout(function() {
            if ($scope.classId > 0 && $scope.selSubjId > 0) {
                httpFactory.getResult("getStoreChapterTopicsBySubId?classId=" + $scope.classId + "&subjectId=" + $scope.selSubjId + "&schemaName=" + $scope.schemaName + "&instId="+$scope.instituteId, function(data) {
                    console.log(data);
                    if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                        $scope.chapterListByClassSubject = data.Chaptertopics;
                        $scope.chapterList = data.Chaptertopics;
                        if ($scope.chapterList.length > 0) {
                        	for(var i = 0; i<$scope.chapterList.length; i++){
                        		for(var j = 0; j<$scope.chapterList[i].Topics.length; j++){
                                   if($scope.chapterList[i].Topics[j].isChapterLevel == 1) {
                                	   $scope.chapterList[i]["chapterLevelTopicId"] = $scope.chapterList[i].Topics[j].topicId;
                                	   $scope.chapterList[i].Topics.splice(j,1);
                                   }
                        		}
                        	}
                            $scope.chapterClick($scope.chapterList[0]);
                            var topic = $scope.chapterList[0].Topics[0];
                            $scope.chapterTopicClick($scope.chapterList[0].chapterschemaName, $scope.chapterList[0].Topics[0]);
                            $scope.activeTpcTab = 'video';
                            console.log($scope.chapterListByClassSubject);
                        } else {
                            angular.element("#smallLoader").hide();
                            alert("No Chapters");
                        }
                    } else {
                        angular.element("#smallLoader").hide();
                        alert("No Chapters");
                    }
                });
            } else {
                angular.element("#smallLoader").hide();
            }
        }, 100)
    }
    
    $scope.chapterClick = function(chapter) {
        $scope.selChapterId = chapter.chapterId;
        $scope.selChpterName = chapter.chapterName;
    }
    
    $scope.chapterTopicClick = function(chapterSCN, topic) {
        if (topic == undefined) {
            angular.element("#smallLoader").hide();
            $scope.$apply();
        } else {
        	$scope.ques=[];
            $scope.selTopicId = topic.topicId;
            $scope.seltopicName = topic.topicName;
            angular.element("#smallLoader").show();
            setTimeout(function() {
                $scope.getTopicVideos();
                $scope.getChapterAnnexure();
                $scope.getQuestionsGroup();
                angular.element("#smallLoader").hide();
                $scope.$apply();
            }, 500);
        }
        $scope.chapQues=false;
    }
    
    $scope.lviewexpand = true;
    $scope.toogleSide = function() {
        $('.togglesidebar').toggleClass('is-collapsed');
        $('.togglecontent').toggleClass('is-full-width');
        $scope.lviewexpand = !$scope.lviewexpand;
    }

    $scope.lviewstate = true;
    $scope.expandToggle = function(lview) {
        $scope.lviewstate = lview;
    }

    $scope.closePopUp = function() {
        $scope.getQuestionsByTopicId();
    }
    
    $scope.getChapterAnnexure = function() {
        httpFactory.getResult("getChapterSummaryForStore?chapterId=" + $scope.selChapterId + "&subjectId=" + $scope.selSubjId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = data.chapterAnnexure[0];
                console.log($scope.annexureOb);
                $scope.annexureObEdit = data.chapterAnnexure[0];

                $scope.annexContent = $scope.annexureOb.annexureContent;
            } else {
                $scope.annexureOb = {};
                $scope.annexureObEdit = {};
                $scope.annexContent = '';
            }
        });
    }
    
    $scope.annexureOb = {};
    $scope.openAnnextureEdit = function() {
        $("#openAnnextureEdit").modal("show");
    }
    
    $scope.openAnnextureAdd = function() {
        $scope.annexureOb = {
            "annexureContent": ''
        };
        $("#openAnnextureAdd").modal("show");
    }
    
    $scope.annextureAdd = function() {
        var quesParams = {
            "schemaName": $scope.schemaName,
            "insertRecords": [{
                "chapterId": $scope.selChapterId,
                "topicId": $scope.selTopicId,
                "subjectId": $scope.selSubjId,
                "annexureContent": $scope.annexureOb.annexureContent,
                "createdBy": localStorage.getItem("userId"),
            }]
        };
        httpFactory.executePost("addChapterSummaryForStore", quesParams, function(data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = $scope.annexureObEdit;
                $scope.annexContent = $scope.annexureObEdit.annexureContent
                alert("added Successfully");
                $("#openAnnextureAdd").modal("hide");
                $scope.getChapterAnnexure();
            } else {
                alert("Please Try Again");
            }
        });
    }
    
    $scope.annextureEdit = function() {
        var quesParams = {
        	"schemaName": $scope.schemaName,
            "updateRecords": [{
                "annexureId": $scope.annexureObEdit.annexureId,
                "annexureContent": $scope.annexureObEdit.annexureContent,
                "updatedBy": localStorage.getItem("userId")           
                }]
        }
        httpFactory.executePost("updateChapterAnnexureForStore", quesParams, function(data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = $scope.annexureObEdit;
                $scope.annexContent = $scope.annexureObEdit.annexureContent
                alert("Updated Successfully");
                $("#openAnnextureEdit").modal("hide");
            } else {
                alert("Please Try Again");
            }
        });
    }
    
    $scope.deleteChapterAnnexureModal = function(){
    	$("#deleteChapterAnnexureModal").modal("show");
    }
    
    $scope.deleteChapterAnnexure = function() {
		httpFactory.getResult("deleteChapterAnnexureForStore?annexureId="+ $scope.annexureObEdit.annexureId +"&schemaName=" + $scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				 $scope.getChapterAnnexure($scope.annexureOb);
				alert(data.MESSAGE);
				 $("#deleteChapterAnnexureModal").modal("hide");
			} else{
				alert(data.MESSAGE);
			}
		});
	}
    
    $scope.getTopicVideos = function() {
        $scope.videoContent = [];
        $scope.activeVideosCOTab = "PRIMARY";
        httpFactory.getResult("getTopicVideosForStore?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId+"&chapterId=" + $scope.selChapterId+"&courseName="+$scope.courseName+"&instId="+$scope.instituteId+"&subjectId="+$scope.selSubjId, function(data) {
            console.log(data);
            if (data.StatusCode == 200 && data.TopicVideos.length > 0 ) {
					$scope.videoContent = data.TopicVideos;
                if ($scope.videoContent[0] != undefined && $scope.videoContent[0].videoLink != 'NA') {
                    $scope.getVideoPlay($scope.videoContent[0]);
                }
                console.log($scope.videoContent);
            } else {
                $scope.videoContent = [];
                console.log("No Videos");
            }
        });
    }
    
    $scope.getVideoPlay = function(video) {
        console.log(video);
        $scope.videoLinkToPlay = video.videoLink;
        if($scope.videoLinkToPlay.indexOf('youtu') >= 0) {
//        	$scope.videoLinkToPlay = "https://youtube.com/embed/" + $scope.videoLinkToPlay.substr($scope.videoLinkToPlay.lastIndexOf('/') + 1);
        	$scope.videoLinkToPlay = "https://www.youtube-nocookie.com/embed/" + $scope.videoLinkToPlay.substr($scope.videoLinkToPlay.lastIndexOf('/') + 1) + "?rel=0&amp;controls=1&amp&amp;showinfo=0&amp;modestbranding=1";
        }
        console.log($scope.videoLinkToPlay);
    }
    
    $scope.trustSrc = function(src) {
        return $sce.trustAsResourceUrl(src);
    }

    $scope.showOnlineDiv = function(tab) {
        $scope.activeTpcTab = tab;
    }
    
    $scope.questionsArray = [];
    $scope.getQuestionsByTopicId = function(groupId) {
        console.log($scope.contentOwner);
        httpFactory.getResult("getQuestionsForStore?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName + "&groupId=" + groupId, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
            	$scope.ques = data.Questions;
            	$scope.activeCOTab = groupId; 
              $scope.coQues = 0;
            } else {}
        });
    }
    
    $scope.viewAnswerForQues = function(quesId) {
        $scope.viewAnswerForQuesId = quesId;
    }

    $scope.showCODiv = function(tab, indx) {
        $scope.activeCOTab = tab;
        console.log($scope.activeCOTab);
        $scope.coQues = indx;
        	$scope.getQuestionsByTopicId(tab);
    }

    $scope.getQuestionsGroup = function() {
        $scope.groupList = [];
        if( $scope.groupList.length == 0){
	        httpFactory.getResult("getQuestionGroupForStore?schemaName=" + $scope.schemaName + "&topicId=" + $scope.selTopicId, function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.QuestionGroups != undefined) {
	            	$scope.groupList = data.QuestionGroups;
	            	if(Object.keys($scope.groupList[0]).length > 0){
	                $scope.getQuestionsByTopicId($scope.groupList[0].groupId);
	            	}
	            }
	        });
        }
    }

    $scope.addNewQuestionGroup = function() {
        var params = {
            "groupName": $scope.groupNameText,
            "createdBy": localStorage.getItem("userId"),
            "schemaName": "ekalavya_store",
             "topicId"  : $scope.selTopicId,
             "chapterId"  : $scope.selChapterId
        }
        console.log(params);
        	httpFactory.executePost("addQuestionGroupForStore", params, function(data) {
        		console.log(data);
        		if (data.StatusCode == 200) {
        			alert("New Group added");
        			$("#addGroup").modal("hide");
        			$scope.getQuestionsGroup();
        			$scope.clearNgModels();
        		} else if (data.StatusCode == 300) {
        			alert("Please Check Group Name ");
        		} else {
        			alert("Please Try again Later");
        		}
        	});
    }

    $scope.getQuestionTypesService = function() {
        httpFactory.getResult("getQuestionTypes?schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.questionTypeList = data.questionsArray;
            } else {
            }
        });
    }
    $scope.getQuestionTypesService();

    $scope.addAdvnceQuestion = function() {
        $scope.questionType = "";
        $("#addAdvanceQuestionModal").modal("show");
        $scope.getQuestionDomainForStore();
    }
    
    $scope.selectedAnswerForTOF = function(opt) {
        if (opt == '1') {
            $scope.TFOption = 'true';
        } else {
            $scope.TFOption = 'false';
        }
        console.log($scope.TFOption);
    }
    
    $scope.insertFoundationQuestion = function() {
        $scope.questionAdv = CKEDITOR.instances['questionAdv'].getData();
//        $scope.option1 = "";
//        $scope.option2 = "";
//        $scope.option3 = "";
//        $scope.option4 = "";
//        $scope.explanation = CKEDITOR.instances['explanation'].getData();
        if ($scope.questionType == 'MAQ') {
            $scope.maqCrct = "";
            for (var i = 0; i < $scope.multiCorrectAnswer.length; i++) {
                if ($scope.maqCrct == "") {
                    $scope.maqCrct = $scope.multiCorrectAnswer[i];
                } else {
                    $scope.maqCrct += ',' + $scope.multiCorrectAnswer[i];
                }
                $scope.correctAnswer = $scope.maqCrct;
            }
        } else {
            $scope.correctAnswer = $("#correctAnswer").val();
        }
        $scope.questionGroup = $("#questionGroupId").val();
        $scope.diffLevel = $("#diffLevel1").val();
        if ($scope.questionType == 'MCQ' || $scope.questionType == 'MAQ') {
//            $scope.option1 = CKEDITOR.instances['option1'].getData();
//            $scope.option2 = CKEDITOR.instances['option2'].getData();
//            $scope.option3 = CKEDITOR.instances['option3'].getData();
//            $scope.option4 = CKEDITOR.instances['option4'].getData();
        } else if ($scope.questionType == 'TOF') {
            $scope.correctAnswer = $scope.TFOption;
            console.log($scope.correctAnswer);
        } else if ($scope.questionType == 'ITQ') {
//            $scope.option1 = CKEDITOR.instances['option1'].getData();
            $scope.correctAnswer = $scope.itqCorrectAns;
        } else if ($scope.questionType == 'FIB') {
            $scope.correctAnswer = $scope.FIBAnswer;
        } else if ($scope.questionType == 'MFQ') {
            $scope.correctAnswer = "NA";
            $scope.column1a = CKEDITOR.instances['column1a'].getData();
            $scope.column2a = CKEDITOR.instances['column2a'].getData();
            $scope.column3a = CKEDITOR.instances['column3a'].getData();
            $scope.column4a = CKEDITOR.instances['column4a'].getData();
            $scope.column5a = CKEDITOR.instances['column5a'].getData();
            console.log($scope.column4a);
            $scope.column1b = CKEDITOR.instances['column1b'].getData();
            $scope.column2b = CKEDITOR.instances['column2b'].getData();
            $scope.column3b = CKEDITOR.instances['column3b'].getData();
            $scope.column4b = CKEDITOR.instances['column4b'].getData();
            $scope.column5b = CKEDITOR.instances['column5b'].getData();

            if ($scope.column4a.length <= 0) {
                $scope.column4b = "NA";
                $scope.column4a = "NA";
            }
            if ($scope.column5a.length <= 0) {
                $scope.column5b = "NA";
                $scope.column5a = "NA";
            }
        }

        if ($scope.questionAdv == undefined || $scope.questionAdv == "") {
            alert("Please Add question");
            return true;
        }
        if ($scope.correctAnswer == undefined || $scope.correctAnswer == "") {
            alert("Please select correct answer");
            return true;
        }
        if ($scope.questionGroup == undefined || $scope.questionGroup == "") {
            alert("Please select a Group ");
            return true;
        }
        if ($scope.diffLevel == undefined || $scope.diffLevel == "" || $scope.diffLevel.includes('?')) {
            alert("Please select Difficulty Level");
            return true;
        }

        if ($scope.questionType == 'MFQ') {
            if (!$scope.MFQ4) {
                $scope.MFQ4 = "NA";
            }
            if (!$scope.MFQ5) {
                $scope.MFQ5 = "NA";
            }
            var requestParams = {
                "schemaName": $scope.schemaName,
                "insertRecords": [{
                    "question": $scope.questionAdv,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "groupId": $scope.questionGroup,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "questType": $scope.questionType,
                    "createdBy": localStorage.getItem("userId"),
					"domainId": $scope.domainId,
					"keywordId": document.getElementById("domainKeywordId").value,
                    "options": [{
                            "columnA": $scope.column1a,
                            "columnB": $scope.column1b,
                            "correctAnswer": $scope.MFQ1
                        },
                        {
                            "columnA": $scope.column2a,
                            "columnB": $scope.column2b,
                            "correctAnswer": $scope.MFQ2
                        }, {
                            "columnA": $scope.column3a,
                            "columnB": $scope.column3b,
                            "correctAnswer": $scope.MFQ3
                        }, {
                            "columnA": $scope.column4a,
                            "columnB": $scope.column4b,
                            "correctAnswer": $scope.MFQ4
                        }, {
                            "columnA": $scope.column5a,
                            "columnB": $scope.column5b,
                            "correctAnswer": $scope.MFQ5
                        }
                    ]
                }]
            }
            console.log(requestParams);
        } else {
            var requestParams = {
                "schemaName": $scope.schemaName,
                "insertRecords": [{
                    "question": $scope.questionAdv,
                    "option1": $scope.option1,
                    "option2": $scope.option2,
                    "option3": $scope.option3,
                    "option4": $scope.option4,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "groupId": $scope.questionGroup,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "questType": $scope.questionType,
                    "createdBy": localStorage.getItem("userId"),
					"domainId": $scope.domainId,
					//"keywordId": $scope.keywordId,
					"keywordId": document.getElementById("domainKeywordId").value,
                }]
            }
        }
        console.log(requestParams);
        httpFactory.executePost("addTopicQuestionsForStore", requestParams, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("inserted successfully")
//                $scope.option1 = CKEDITOR.instances['option1'].setData('');
//                $scope.option2 = CKEDITOR.instances['option2'].setData('');
//                $scope.option3 = CKEDITOR.instances['option3'].setData('');
//                $scope.option4 = CKEDITOR.instances['option4'].setData('');
//                $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                $scope.option1 = "";
                $scope.option2 = "";
                $scope.option3 = "";
                $scope.option4 = "";
                $scope.explanation = "";
                $scope.questionAdv = "";
                $scope.clearNgModels();
                if ($scope.questionType == "MFQ") {
                    $scope.column1a = CKEDITOR.instances['column1a'].setData('');
                    $scope.column2a = CKEDITOR.instances['column2a'].setData('');
                    $scope.column3a = CKEDITOR.instances['column3a'].setData('');
                    $scope.column4a = CKEDITOR.instances['column4a'].setData('');
                    $scope.column5a = CKEDITOR.instances['column5a'].setData('');

                    $scope.column1b = CKEDITOR.instances['column1b'].setData('');
                    $scope.column2b = CKEDITOR.instances['column2b'].setData('');
                    $scope.column3b = CKEDITOR.instances['column3b'].setData('');
                    $scope.column4b = CKEDITOR.instances['column4b'].setData('');
                    $scope.column5b = CKEDITOR.instances['column5b'].setData('');
                }
                $scope.correctAnswer = 0;
                document.getElementById("correctAnswer").value = 0;
                $('#diffLevel').prop('selectedIndex', 0);
                window.scrollTo(0, 0);
                $scope.optionsArr = [];
                $("#addAdvanceQuestionModal").modal("hide");
                $scope.getQuestionsByTopicId($scope.groupList[0].groupId);
            } else {}
        });
    }

    $scope.addChapter = function() {
        $("#addChapterModal").modal("show");
    }

    $scope.addNewChapter = function() {
        var chapParams = {
            "schemaName": "ekalavya_store",
            "insertRecords": [{
                "classId": $scope.classId,
                "subjectId": $scope.selSubjId,
                "chapterName": $scope.chapterName,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId"),
            }]
        };

        console.log(chapParams);
        httpFactory.executePost("addChaptersForStore", chapParams, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $scope.clearNgModels();
                $("#addChapterModal").modal("hide");
                alert("Successfully Chapter added");
                $scope.getChapterTopicsBySubjectChangeques();
            } else {
                alert("something went wrong, Please Try again Later");
            }
        });
    }

    $scope.addTopic = function(chapterId) {
        $scope.chapId = chapterId;
        $("#addTopicModal").modal("show");
    }
    $scope.addNewTopic = function() {
        var chapParams = {
            "schemaName": $scope.schemaName,
            "insertRecords": [{
                "classId": $scope.classId,
                "chapterId": $scope.selChapterId,
                "topicName": $scope.topicName,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId"),
                "courseId": $scope.courseId
            }]
        };

        console.log(chapParams);
        httpFactory.executePost("addTopicForStore", chapParams, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $("#addTopicModal").modal("hide");
                alert("Successfully Topic added");
                $scope.clearNgModels();
                $scope.getChapterTopicsBySubjectChangeques();
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.addNewVideoLink = function(chapterid, topicId) {
        $("#addNewVideo").modal("show");
    }
    $scope.saveNewVideoLink = function() {
        var vidParams = {
            "schemaName": $scope.schemaName,
            "insertRecords": [{
                "topicId": $scope.selTopicId,
                "chapterId": $scope.selChapterId,
                "videoName": $scope.videoName,
                "videoLink": $scope.videoLink,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId")
            }]
        };
        console.log(vidParams);
        httpFactory.executePost("addTopicVideoForStore", vidParams, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success.Video Added");
                $scope.clearNgModels();
                $("#addNewVideo").modal("hide");
                $scope.getTopicVideos();
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.clearNgModels = function() {
        $scope.videoName = "";
        $scope.videoLink = "";
        $scope.topicId = "";
        $scope.topicName = "";
        $scope.chapterId = "";
        $scope.chapterName = "";
        $scope.groupNameText = "";
        $scope.questionGroup = "";
        $scope.keywordNameText = "";
        $scope.keywordId="";
        $scope.domainNameText = "";
        $scope.domainId="";
        $scope.diffLevel = "";
        $scope.selAdvQuestion = {};
    }
    
    $scope.getQuestionDomainForStore = function() {
        $scope.domainList = [];
        if( $scope.domainList.length == 0){
	        httpFactory.getResult("getQuestionDomainForStore?schemaName=" + $scope.schemaName, function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.QuestionDomains != undefined) {
	            	$scope.domainList = data.QuestionDomains;
//	            	if(Object.keys($scope.domainList[0]).length > 0){
//	                $scope.getQuestionsByTopicId($scope.domainList[0].groupId);
//	            	}
	            }
	        });
        }
    }
    
    $scope.getQuestionDomainKeywords= function(domain) {
        $scope.keywordList = [];
        if( $scope.keywordList.length == 0){
	        httpFactory.getResult("getQuestionDomainKeywords?schemaName=" + $scope.schemaName + "&domainId=" + domain + "&subjectId=" + $scope.selSubjId , function(data) {
	            console.log(data);
	            if (data.STATUS == 'SUCCESS' && data.DomainKeywords != undefined) {
	            	$scope.keywordList = data.DomainKeywords;
//	            	if(Object.keys($scope.keywordList[0]).length > 0){
//	                $scope.getQuestionsByTopicId($scope.keywordList[0].groupId);
//	            	}
	            }
	        });
        }
    }
    
    $scope.addQuestionDomain = function() {
        var params = {
            "domainName": $scope.domainNameText,
            "createdBy": localStorage.getItem("userId"),
            "schemaName": "ekalavya_store"
        }
        console.log(params);
        httpFactory.executePost("addQuestionDomain", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("New Domain added");
                $("#addDomain").modal("hide");
                $scope.getQuestionDomainForStore();
                $scope.domainNameText = "";
        		$scope.domainId="";
            } else if (data.StatusCode == 300) {
                alert("Please Check Domain Name ");
            } else {
                alert("Please Try again Later");
            }
        });
    }
    
    $scope.addDomainKeyword = function() {
    	if($scope.domainId=="" || $scope.domainId==null){
    		$scope.domainId=document.getElementById("quesDomainId").value;
    	}
        var params = {
            "keywordName": $scope.keywordNameText,
            "createdBy": localStorage.getItem("userId"),
            "schemaName": "ekalavya_store",
            "domainId": $scope.domainId,
            "subjectId": $scope.selSubjId
        }
        console.log(params);
        httpFactory.executePost("addDomainKeyword", params, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("New Domain Keyword added");
                $("#addDomainKeyword").modal("hide");
                $scope.getQuestionDomainKeywords($scope.domainId);
        		$scope.keywordNameText = "";
        		$scope.keywordId="";
            } else if (data.StatusCode == 300) {
                alert("Please Check Domain Keyword Name ");
            } else {
                alert("Please Try again Later");
            }
        });
    }
    
    $scope.selAdvQuestion = {};
    $scope.editAdvanceQuestion = function(question) {
        console.log(question);
        $scope.getQuestionDomainForStore();
        $scope.getQuestionDomainKeywords(question.domainId);
        $scope.selAdvQuestion = question;
//        if ($scope.selAdvQuestion.questType == 'TOF') {
//            if ($scope.selAdvQuestion.correctAnswer == 'true') {
//                $scope.selAdvQuestion.correctAnswer = true;
//            } else if ($scope.selAdvQuestion.correctAnswer == 'false') {
//                $scope.selAdvQuestion.correctAnswer = false;
//            }

//            if ($scope.selAdvQuestion.correctAnswer == 'true') {
//                $scope.trueOptionedit = true;
//                $scope.falseOptionedit = false;
//            } else {
//                $scope.trueOptionedit = false;
//                $scope.falseOptionedit = true;
//            }
//        }
        console.log($scope.selAdvQuestion);
        $("#editAdvanceQuestionModal").modal("show");
    }
    
    $scope.insertFoundationQuestionContent = function() {
        console.log($scope.selAdvQuestion);
        console.log($scope.selAdvQuestion.question);
        var requestParams = {};
        if ($scope.selAdvQuestion.questType == 'MFQ') {
            requestParams = {
                "schemaName": $scope.schemaName,
                "insertRecords": [{
                    "questionId": $scope.selAdvQuestion.questionId,
                    "question": "Match the following",
                    "explanation": $scope.selAdvQuestion.explanation,
                    "correctAnswer": $scope.selAdvQuestion.correctAnswer,
                    "questionType": $scope.selAdvQuestion.questionType,
                    "groupId": $scope.selAdvQuestion.groupId,
                    "domainId": $scope.selAdvQuestion.domainId,
                    "domainKeywordId": $scope.selAdvQuestion.domainKeywordId,
                    "difficultyLevel": $scope.selAdvQuestion.difficultyLevel,
                    "questType": $scope.selAdvQuestion.questType,
                    "updatedBy": localStorage.getItem("userId"),
                    "options": $scope.selAdvQuestion.questions
                }]
            }
            console.log(requestParams);
        } else {
            console.log($scope.selAdvQuestion);
            console.log($scope.selAdvQuestion.question);
            requestParams = {
                "schemaName": $scope.schemaName,
                "insertRecords": [{
                    "questionId": $scope.selAdvQuestion.questionId,
                    "question": $scope.selAdvQuestion.question,
                    "option1": $scope.selAdvQuestion.option1,
                    "option2": $scope.selAdvQuestion.option2,
                    "option3": $scope.selAdvQuestion.option3,
                    "option4": $scope.selAdvQuestion.option4,
                    "explanation": $scope.selAdvQuestion.explanation,
                    "correctAnswer": $scope.selAdvQuestion.correctAnswer,
                    "questionType": $scope.selAdvQuestion.questionType,
                    "groupId": $scope.selAdvQuestion.groupId,
                    "domainId": $scope.selAdvQuestion.domainId,
                    "domainKeywordId": $scope.selAdvQuestion.domainKeywordId,
                    "difficultyLevel": $scope.selAdvQuestion.difficultyLevel,
                    "questType": $scope.selAdvQuestion.questType,
                    "updatedBy": localStorage.getItem("userId")
                }]
            }
        }
        console.log(requestParams);
        httpFactory.executePost("updateTopicQuestionsForStore", requestParams, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Success.Question Updated");
                $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                $('#correctAnswer').prop('selectedIndex', 0);
                $('#diffLevell').prop('selectedIndex', 0);
                window.scrollTo(0, 0);
                $("#editAdvanceQuestionModal").modal("hide");
                $scope.selAdvQuestion = {};
                $scope.getQuestionsByTopicId($scope.groupList[0].groupId);
            } else {
                alert("something went wrong");
            }
        });
    }
    
    $scope.updateStoreChapter = function(chapterId, chapterName, chapIndex) {
    	$("#updateStoreChapterModal").modal("show");
    	$scope.chapterName = chapterName.substr((chapterName.indexOf(' ') + 1));
    	$scope.chapId = chapterId;
    	$scope.updateChapIndex = chapIndex;
    }
    $scope.updateStoreChapterName = function() {
    	var chapParams = {
    			"schemaName": $scope.schemaName,
    			"updatedRecords": [{
    				"chapterId": $scope.chapId,
    				"chapterName": $scope.chapterName,
    				"updatedBy": localStorage.getItem("userId")

    			}]
    	};

    	console.log(chapParams);
    	httpFactory.executePost("updateStoreChapters", chapParams, function(data) {
    		console.log(data);
    		if (data.STATUS == 'SUCCESS') {
    			$("#updateStoreChapterModal").modal("hide");
    			alert("Chapter Updated Succesfully");
    			console.log($scope.chapterList[$scope.updateChapIndex]["chapterName"]);
    			$scope.chapterList[$scope.updateChapIndex]["chapterName"] = $scope.chapterName;
    			$scope.clearNgModels();
    		} else {
    			alert("Something went wrong");
    		}
    	});
    }

    $scope.updateStoreTopic = function(topicId, topicName, chapIndex, topicIndex) {
    	$scope.topcId = topicId;
    	$scope.topicName = topicName;
    	$scope.updateChapIndex = chapIndex;
    	$scope.updateTopicIndex = topicIndex;
    	$("#updateStoreTopicModal").modal("show");

    }

    $scope.updateStoreTopicName = function() {
    	var chapParams = {
    			"schemaName": $scope.schemaName,
    			"updatedRecords": [{
    				"topicId": $scope.topcId,
    				"topicName": $scope.topicName,
    				"updatedBy": localStorage.getItem("userId")
    			}]
    	};
    	console.log(chapParams);
    	httpFactory.executePost("updateStoreTopics", chapParams, function(data) {
    		console.log(data);
    		if (data.STATUS == 'SUCCESS') {
    			$("#updateStoreTopicModal").modal("hide");
    			alert("Success. Topic Updated");
    			console.log($scope.chapterList[$scope.updateChapIndex]["Topics"][$scope.updateTopicIndex]["topicName"]);
    			console.log($scope.topicName);
    			$scope.chapterList[$scope.updateChapIndex]["Topics"][$scope.updateTopicIndex]["topicName"] = $scope.topicName;
    			$scope.clearNgModels();

    		} else {
    			alert("something went wrong");
    		}
    	});
    }

    $scope.updateStoreVideoLinkModal = function(video) {
    	$scope.videoName = video.videoName;
    	$scope.videoLink = video.videoLink;
    	$scope.delTpcVidId = video.videoLinkId;
    	$("#updateStoreTopicVideo").modal("show");
    }

    $scope.updateStoreVideoLink = function() {
    	var vidParams = {
    			"schemaName": $scope.schemaName,
    			"videoId": $scope.delTpcVidId,
    			"videoName": $scope.videoName,
    			"videoLink": $scope.videoLink,
    			"updatedBy": localStorage.getItem("userId")
    	};
    	console.log(vidParams);
    	httpFactory.executePost("updateStoreTopicVideo", vidParams, function(data) {
    		console.log(data);
    		if (data.STATUS == 'SUCCESS') {
    			alert("Success.Video Updated");
    			$scope.clearNgModels();
    			$("#updateStoreTopicVideo").modal("hide");
    			$scope.getTopicVideos();
    		} else {
    			alert("something went wrong");
    		}
    	});
    }

    $scope.deleteStoreTopicVideoModal = function(video) {
    	console.log(video);
    	$scope.videoName = video.videoName;
    	$scope.videoLink = video.videoLink;
    	$scope.delTpcVidId = video.videoLinkId;
    	$scope.topicId = video.topicId;
    	$("#deleteStoreTopicVideo").modal("show");
    }

    $scope.deleteStoreTopicVideo = function() {
    	var videoParms = {
    			"videoId" : $scope.delTpcVidId,
    			"schemaName" : $scope.schemaName,
    			"updatedBy" : localStorage.getItem("userId")
    	}

    	httpFactory.executePost("deleteStoreTopicVideo", videoParms, function(data) {
    		console.log(data);
    		if(data.StatusCode == 200) {
    			$("#deleteStoreTopicVideo").modal("hide");
    			alert(data.MESSAGE);
    			$scope.clearNgModels();
    			$scope.getTopicVideos();
    		} else {
    			alert(data.MESSAGE);
    		}
    	});
    }

    $scope.deleteStoreQuestion = function(question, index) {
    	if (confirm('Are you sure, you want to delete this question?')) {
    		$scope.deleteStoreQuestionApi(question, index);
    	}
    }

    $scope.deleteStoreQuestionApi = function(question, index) {
    	var quesParms = {
    			"questionId" : question.questionId,
    			"questType" : question.questType,
    			"schemaName" : $scope.schemaName,
    			"updatedBy" : localStorage.getItem("userId")
    	}

    	httpFactory.executePost("deleteStoreQuestion", quesParms, function(data) {
    		console.log(data);
    		if (data.StatusCode == 200) {
    			$scope.ques[0].questionArray.splice(index, 1);
    			alert("Successfully deleted");
    		} else {
    			console.log(data.MESSAGE);
    			alert(data.MESSAGE);

    		}
    	});
    }

    $scope.deleteStoreTopicModal = function(topic) {
    	console.log(topic);
    	$scope.delTpcId = topic.topicId;
    	$scope.delTpcName = topic.topicName;
    	$("#deleteStoreTopicModal").modal("show");
    }

    $scope.deleteStoreTopic = function() {
    	var topicParms = {
    			"topicId" : $scope.delTpcId,
    			"schemaName" : $scope.schemaName,
    			"updatedBy" : localStorage.getItem("userId")
    	}

    	httpFactory.executePost("deleteStoreTopic", topicParms, function(data) {
    		console.log(data);
    		if(data.StatusCode == 200) {
    			alert(data.MESSAGE);
    		}else if(data.StatusCode == 300) {
    			alert(data.MESSAGE);
    		}else if(data.StatusCode == 302){
    			alert(data.MESSAGE);
    		}else{
    			alert("Something went wrong.Please try again!");
    		}
    		$("#deleteStoreTopicModal").modal("hide");
    		$scope.clearNgModels();
    		$scope.getChapterTopicsBySubjectChangeques();
    	});
    }

    $scope.deleteStoreChapterModal = function(chapter) {
    	console.log(chapter);
    	$scope.delChapId = chapter.chapterId;
    	$scope.delChapName = chapter.chapterName;
    	$("#deleteStoreChapterModal").modal("show");
    }

    $scope.deleteStoreChapter = function() {
    	var chaptParms = {
    			"chapterId" : $scope.delChapId,
    			"schemaName" : $scope.schemaName,
    			"updatedBy" : localStorage.getItem("userId")
    	}

    	httpFactory.executePost("deleteStoreChapters", chaptParms, function(data) {
    		console.log(data);
    		if (data.StatusCode == 200) {
    			$("#deleteStoreChapterModal").modal("hide");
    			alert(data.MESSAGE);
    		}else if(data.StatusCode == 302) {
    			$("#deleteStoreChapterModal").modal("hide");
    			alert(data.MESSAGE);
    		}else {
    			$("#deleteStoreChapterModal").modal("hide");
    			alert(data.MESSAGE);
    		}
    		$scope.clearNgModels();
    		$scope.getChapterTopicsBySubjectChangeques();
    	});
    }
    $scope.chapterQuesClick = function(chapter) {
    	$scope.selTopicId = "";
    	$scope.chapQues = true;
    	/*$scope.annexureOb = {};
        $scope.annexureObEdit = {};
        $scope.annexContent = '';
    	$scope.videoContent = [];*/
    	if(chapter.chapterLevelTopicId != undefined)
    		$scope.selTopicId = chapter.chapterLevelTopicId;
    	$scope.ques=[];
        $scope.seltopicName = chapter.chapterName;
        angular.element("#smallLoader").show();
        setTimeout(function() {
            $scope.getQuestionsGroup();
            $scope.showOnlineDiv('topic');
            angular.element("#smallLoader").hide();
            $scope.$apply();
        }, 500);
    	
    
    }

});
