projectModule.controller('uploadNewQuesPaperController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };
 $scope.courseId="";
 $scope.schemaName = localStorage.getItem("sname");
 $scope.subjectList =[];
 
 $scope.init = function(){
	 $scope.getInstituteTypes();
	 $scope.getAllBranches();
 }

 $scope.selectedContentOwner=localStorage.getItem("cgTestSelQB");
 $scope.selContentType =localStorage.getItem("cgTestContentType");

 $scope.back=function(){
   $location.path("/examType");
 }
 $scope.cancel=function(){
   $location.path("/examType");
 }
 
/* $scope.getInstituteTypes = function(){
	 	httpFactory.getResult("getCollegeInstituteTypes?schemaName="+localStorage.getItem("sname") + "&instId="+localStorage.getItem("inst_id"), function(data){
	 		if(data.statusCode == '200'){
	 			$scope.instituteTypes = data.data;
	 			console.log($scope.instituteTypes);
	 		}
	 	});
	 }*/
 $scope.getInstituteTypes = function(){
	 debugger;
	 httpFactory.getResult("getBranchInstituteTypes?schemaName=" + localStorage.getItem("sname") +"&branchId=" + localStorage.getItem("bnchId"), function(data) {
	 		if(data.statusCode == '200'){
	 			$scope.instituteTypes = data.data;
	 			console.log($scope.instituteTypes);
	 		}
	 	});
	 }

  $scope.getAllBranches = function() {
    httpFactory.getResult("getAllBranches?instId=" + $scope.instituteId + "&schemaName="+$scope.schemaName, function(data) {
      console.log(data.collegeBranches);
      if (data.StatusCode == 200) {
          $scope.branchList = data.collegeBranches;
          console.log($scope.branchList);
      } else {
        console.log("No courses");
      }
    });
  }
  $scope.getCoursesByBranch = function() {
	  $scope.selectedCourse = "";
	  $scope.selectedCategory = "";
	  $scope.selectedSchema = "";
	  $scope.subjectList =[];
    httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.selectedBranch , function(data) {
      console.log(data);
      if (data.StatusCode == 200){
          $scope.courseList = data.Courses;
          console.log($scope.courseList);
      } else {
		console.log("No courses");
      }
    });
  }


  // //getdynamic schemas
  // $scope.getSchemas = function() {
	//   $scope.selectedSchema = "";
	// // $scope.selectedCategory = "";
	// $scope.subjectList =[];
  //   httpFactory.getResult("selectContentOwner?schemaName="+$scope.schemaName, function(data) {
	// 	if (data.StatusCode == 200) {
	// 		$scope.schemaObject = data.ContentOwner;
  //
  //     if ($scope.selectedCategory ==6 || $scope.selectedCategory == 7 ) {
  //       $scope.schemaObject.splice(0,1);
  //     }else if($scope.selectedCategory == 5){
  //       $scope.schemaObject.splice(1,1);
  //     }
  //     else {
  //     // alert('No Courses Defined. ');
  //   }
	// 	} else {
	// 		// alert('No Courses Defined. ');
	// 	}
  //   });
  // }

  $scope.categoryChange = function(category) {
    $scope.selectedQType="";
    $scope.categoryObj = JSON.parse($scope.selectedCategoryObj);
    $scope.categoryName=$scope.categoryObj.categoryName;

    $scope.duration = $scope.categoryObj.duration;
    $scope.correctMarks = $scope.categoryObj.correctMarks;
    $scope.wrongMarks = $scope.categoryObj.wrongMarks;
    $scope.numQuestions = $scope.categoryObj.totalQuestions;

    $scope.totalMarks = parseInt($scope.numQuestions)*parseInt($scope.correctMarks);
    $scope.selectedCategory = $scope.categoryObj.categoryId;
    

    
    $scope.getSchemas();
  }

  $scope.getTestCategories = function() {
	  $scope.selectedCategory = "";
	  $scope.selectedQType="";
	  $scope.selectedSchemaOb="";
	  $scope.getSchemas();
	  $scope.subjectList =[];
	  if($scope.courseList != undefined){
		  for(var i = 0;i <  $scope.courseList.length;i++){
			   if($scope.courseList[i].courseId == $scope.selectedCourse){
				   $scope.courseName = $scope.courseList[i].courseName;
				   $scope.courseId = $scope.courseList[i].courseId;
			   }
		   }
	  }
	  httpFactory.getResult("getTestCategories?instId=" + localStorage.getItem("inst_id") + "&schemaName="+$scope.schemaName +"&courseId=" + $scope.selectedCourse, function(data) {
      console.log(data);
      if (data.STATUS == 'SUCCESS') {
        $scope.categoryList = data.TestCategories;
        console.log($scope.categoryList);
      }
       else {
      }
    });
  }

  //$scope.subjectList =[];
  $scope.getSubjectsByCourse = function(schemaObj) {
    console.log(schemaObj);
    if (typeof schemaObj=='string') {
      $scope.selectedRepoObj=JSON.parse(schemaObj);
    }else{
      $scope.selectedRepoObj=schemaObj;
    }
    console.log($scope.selectedRepoObj);
    if (schemaObj) {
      $scope.selQB=$scope.selectedRepoObj.contentType;
      $scope.selRepo = $scope.selectedRepoObj.contentSchema;
      console.log(schemaObj);
      console.log($scope.selQB);
      console.log($scope.selRepo);
    }
    //$scope.categoryChange();
    $scope.selectedCategory = $scope.categoryObj.categoryId;
  $scope.subjectList = [];
    httpFactory.getResult("getSubjectsByCourse?schemaName=" + $scope.schemaName + "&courseId="+ $scope.selectedCourse +"&branchId="+ $scope.selectedBranch, function(data) {
      console.log(JSON.stringify(data));
      if (data.StatusCode == 200) {
		var tmp = []
        for (i = 0; i < data.classeSubjects.length; i++) {
          tmp[i] = data.classeSubjects[i];
        }
        $scope.yearWiseArray = groupBy(tmp, function(item) {
          return [item.classId];
        });
        console.log($scope.yearWiseArray);
		for(var j=0; j<$scope.yearWiseArray.length; j++){
			var tempObj = {
				'classId':$scope.yearWiseArray[j][0].classId,
				'className':$scope.yearWiseArray[j][0].className,
				'clsSubjects':$scope.yearWiseArray[j]
			};
			$scope.subjectList.push(tempObj);
		}
		console.log($scope.subjectList);
      } else {}
    });
  }
	function groupBy(array, f) {
    console.log(array);
    var groups = {};
    array.forEach(function(o) {
      var group = JSON.stringify(f(o));
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });
    return Object.keys(groups).map(function(group) {
      return groups[group];
    })
  }
$scope.calMarks = function(){
	$scope.totalMarks = $scope.numQuestions * $scope.correctMarks;
}

  $scope.createTest = function(){
    $scope.selectedBranch = localStorage.getItem("bnchId");
	  if($scope.testName =="" || $scope.testName == undefined){
		  alert("Fill Test Name");
		  return;
	  }
	  if( $scope.selectedCategory == "" || $scope.selectedCategory == undefined || $scope.numQuestions < 1 || $scope.correctMarks < 1 || $scope.duration =="" || $scope.duration == undefined){
		  alert("Fill all the fields");
		  return ;
	  }
	  var selectedSubjDetails = [];
	  var chckNumQues = 0;
	  for(var i=0; i<$scope.subjectList.length; i++){
		 for(var j=0; j<$scope.subjectList[i].clsSubjects.length; j++){
			 if($scope.subjectList[i].clsSubjects[j].numQuestions > 0){
				chckNumQues = Number(chckNumQues)+Number($scope.subjectList[i].clsSubjects[j].numQuestions);
				selectedSubjDetails.push($scope.subjectList[i].clsSubjects[j]);
			 }
		 }
	  }
	  if(chckNumQues != $scope.numQuestions){
		  alert("Verify Subjects allocation");
		  return;
	  }
	  if($scope.wrongMarks == undefined){
		  $scope.wrongMarks = 0;
	  }

	  console.log(selectedSubjDetails);
	  var testParams = {
        "testName": $scope.testName,
        "testCreationType": "CGT",
        "testCategory": $scope.selectedCategory,
        "testType": $scope.selectedSchema,
        "numQuestions": $scope.numQuestions,
        "diffLevel":'1',
        "duration":$scope.duration,
        "courseId":$scope.selectedCourse,
        "correctMarks": $scope.correctMarks,
        "wrongMarks": $scope.wrongMarks,
        "createdBy": $scope.user_id,
        "schemaName":localStorage.getItem("sname"),
		      "branchId":$scope.selectedBranch,
          "testContentType":$scope.selectedContentType,
		        "isActive": 1,
        "testDetails": selectedSubjDetails,
        "totalMarks":$scope.totalMarks,
        "sectionAvailable":0
	};
	console.log(testParams);
	
    httpFactory.executePost("createTest", testParams, function(data) {
      console.log(data);
		 if (data.STATUS == 'SUCCESS') {
			alert("Success Test Created");
			localStorage.setItem("cgTestId",data.testId );
			localStorage.setItem("cgTestSelQB",$scope.selectedContentOwner);
			localStorage.setItem("cgTestSelRepo",$scope.selectedContentSchema);
			localStorage.setItem("cgTestName",$scope.testName );
			localStorage.setItem("cgTestContentType",$scope.selectedContentType);
			localStorage.setItem("soqMark",$scope.correctMarks);
			localStorage.setItem("courseName",$scope.courseName);
			localStorage.setItem("courseId",$scope.courseId);
			$location.path("customSelect");
		}
		 else{
			 alert("Error while creating test");
		 }
		
	});
  }

  $scope.getTestInfo = function() {
    httpFactory.getResult("getTestInfo?schemaName="+localStorage.getItem("sname") +"&testId="+$routeParams.testId , function(data) {
      console.log(data);
      if (data.StatusCode == 200){
          $scope.testInfo = data;
          $scope.totalnumQuestions = $scope.testInfo.totalQuestions;
          $scope.courseName = $scope.testInfo.courseName;
      } else {
    	  console.log("Error Occured!");
      }
    });
  }

//suresh method for manual adding questions by typing
  $scope.createTestManual = function(){
    $scope.categoryObj = JSON.parse($scope.selectedCategoryObj);
    $scope.selectedCategory = $scope.categoryObj.categoryId;

    $scope.selectedBranch = localStorage.getItem("bnchId");
    console.log($scope.selectedBranch );
    console.log($scope.selectedCourse );
    console.log($scope.selectedContentSchema );
    console.log($scope.selectedCategory );
    console.log($scope.numQuestions );

    if(!$scope.testName ||  !$scope.selectedBranch|| !$scope.selectedCourse || !$scope.selectedContentSchema || !$scope.selectedCategory){
          alert("Please enter all fields");
        }else{
    if(!$scope.numQuestions || !$scope.correctMarks || !$scope.totalMarks || !$scope.duration){
          alert("Please enter all fields");
        }else{
          if($scope.wrongMarks == undefined){
           $scope.wrongMarks = 0;
         }
	  var selectedSubjDetails = [];
    var chckNumQues = 0;

    for(var i=0; i<$scope.subjectList.length; i++){
    for(var j=0; j<$scope.subjectList[i].clsSubjects.length; j++){
      if($scope.subjectList[i].clsSubjects[j].numQuestions > 0){
       chckNumQues = Number(chckNumQues)+Number($scope.subjectList[i].clsSubjects[j].numQuestions);
       selectedSubjDetails.push($scope.subjectList[i].clsSubjects[j]);
      }
    }
   }
 }
    if(chckNumQues != $scope.numQuestions){
     alert("Verify Subjects allocation");
     return;
   }

	  console.log(selectedSubjDetails);
	  var testParams = {
        "testName": $scope.testName,
        "testCreationType": "MGT",
        "testCategory": $scope.selectedCategory,
        "testType": $scope.selectedSchema,
        "numQuestions": $scope.numQuestions,
        "diffLevel":'1',
        "duration":$scope.duration,
        "courseId":$scope.selectedCourse,
        "correctMarks": $scope.correctMarks,
        "wrongMarks": $scope.wrongMarks,
        "createdBy": $scope.user_id,
        "schemaName":localStorage.getItem("sname"),
         "branchId":$scope.selectedBranch,
		"isActive": 1,
        "testContentType":$scope.selectedContentType,
        "testDetails": selectedSubjDetails,
        "totalMarks":$scope.totalMarks
	};
	  
	  if($scope.isSectionAvailable==1){
		  console.log($scope.selectedJeeTemplate);
	        testParams["sectionAvailable"]=$scope.isSectionAvailable;
	    	testParams["jeeSectionTemplateName"]=$scope.selJeeTemplate.templateName;
	  }
	console.log(testParams);
    httpFactory.executePost("createTest", testParams, function(data) {
      console.log(data);
		 if (data.STATUS == 'SUCCESS') {
			alert("Success Test Created");
		      localStorage.setItem("mgTestId",data.testId );
		      localStorage.setItem("mgTestSelQB",$scope.selectedSchema );
		      localStorage.setItem("testSchema", localStorage.getItem("sname"));
		      localStorage.setItem("mgTestName",$scope.testName );
		      localStorage.setItem("mgNumQues",$scope.numQuestions);
		      localStorage.setItem("courseName",$scope.courseName);
		      localStorage.setItem("courseId",$scope.courseId);
		      $location.path("customTest/"+ $scope.selectedCourse + "/" +data.testId );
		 }

	});
  }
}

$scope.manualGenerationViewLoad = function(){
  $scope.selectedCourse=$routeParams.courseId;
  $scope.getCustomTestDetails();
  $scope.getSchemaContentOwner();
  $scope.getTestInfo();
}
$scope.totalTestQuesObj =[];
  $scope.getTestQuestions = function() {
    httpFactory.getResult("getTestQuestions?schemaName="+$scope.schemaName +"&testId="+ localStorage.getItem("mgTestId") , function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.totalTestQuesObj = [];
        $scope.questionList=[];
          $scope.questionList = data.testQuestions;
      $scope.generateQuestionObj();
    }
      else if (data.StatusCode == 300){
        $scope.questionList=[];
        for(i=0;i<$scope.manualTestDetails.length;i++){
          for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions); j++){
          $scope.emptyObj=[];
          var quesObj = {
            'subjectName':$scope.manualTestDetails[i].subjectName,
            'questionIndex':j+1,
            'question':''
          }
            $scope.totalTestQuesObj.push(quesObj);
        }
    }
  }
      else {
		console.log("Error Occured!");
      }
    });
  }

  $scope.generateQuestionObj = function() {
      var quesObj;
      var count = 0;
      $scope.totalTestQuesObj=$scope.questionList.slice(0);
      console.log($scope.totalTestQuesObj);

      for(i=0;i<$scope.manualTestDetails.length;i++){
        for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount); j++){
        $scope.emptyObj=[];
         quesObj = {
          'subjectName':$scope.manualTestDetails[i].subjectName,
          'questionIndex':j+1,
          'question':''
        }
        $scope.totalTestQuesObj.push(quesObj);
      }
    }
  console.log($scope.totalTestQuesObj);
  }

  $scope.getCustomTestDetails = function() {
    httpFactory.getResult("getCustomTestDetails?schemaName="+$scope.schemaName +"&testId="+ localStorage.getItem("mgTestId") , function(data) {
      console.log(data);
      if (data.StatusCode == 200){
        $scope.totalTestQuestions = 0;
          $scope.manualTestDetails = data.TestDetails;
          console.log($scope.manualTestDetails);
          for(i=0;i<$scope.manualTestDetails.length;i++){
            $scope.totalTestQuestions += parseInt($scope.manualTestDetails[i].TotalQuestions);
          }
          console.log($scope.totalTestQuestions);
          $scope.getTestQuestions();

      } else {
    console.log("Error Occured!");
      }
    });
  }

  $scope.selectedGroupSubj ="";
  $scope.showQuesbjWise = function(sbj){
  	$scope.selectedGroupSubj = sbj;
  }

  $scope.selectedSubjectMethod=function(subject) {
    console.log(subject);
    $scope.selectedSubject = JSON.parse($scope.selectedSubjectOb);
    console.log($scope.selectedSubject);
    console.log($scope.selectedSubject.subjectId);
    $scope.selectedTestSubject=$scope.selectedSubject.subjectId;
    if ($scope.selQB == 'null') {
      alert("Schema not selected");
    }else{
    $scope.getSelectedChaptersBySubjectId($scope.selectedTestSubject);
    }
  }

    $scope.selectedChapterMethod=function() {
      console.log($scope.selectedTestChapter);
      if ($scope.selectedChapter == 'null') {
        alert("Schema not selected");
      }else{
        $scope.topicList = $scope.selectedTestChapter.Topics;
      }
      console.log($scope.selectedTestChapter.chapterId);
    }

    $scope.selectedTopicMethod=function(){
      console.log($scope.selectedTestTopic);
    }

    $scope.selectedCat = function()
    {
      console.log($scope.questionCategory);
    }

$scope.getSelectedChaptersBySubjectId = function(subjectId){

  $scope.selectedContentOwner=localStorage.getItem("cgTestSelQB");
  $scope.selContentType =localStorage.getItem("cgTestContentType");
  var contentType = localStorage.getItem("courseName")+","+$scope.selContentType;
  httpFactory.getResult("getChapterTopicsBySubId?schemaName=" + $scope.schemaName +"&subjectId="+subjectId+"&contentOwner="+$scope.selectedContentOwner+"&contentType="+contentType+"&branchId="+localStorage.getItem("bnchId")+"&courseId="+$scope.selectedCourse+"instId="+ $scope.instituteId, function(data){
    console.log(data.Chaptertopics);
    console.log(data);
    if(data.StatusCode == 200){
      $scope.selectedChapterDetails=data;
    }else if(data.StatusCode == 300){
      $scope.selectedChapterDetails=data;
    }
    else{
      alert("error");
    }
  });
}

$scope.manualTestPublish=function(){
  $scope.numQuestions = parseInt(localStorage.getItem("mgNumQues"));
  if ($scope.numQuestions>$scope.questionList.length) {
    alert("add all questions");
  }else{
  $scope.testId=localStorage.getItem("mgTestId");
  $location.path("publishTest/"+$scope.testId+"/"+localStorage.getItem("bnchId")+"/publish");
}
}



  // manual genearation test methods end

	$scope.testId= "";
	$scope.allSelectedQuestions = new Array();
	$scope.savedQuesinDB = new Array();
	$scope.selectedSubjectsQuestionTotalDetails = [];
	$scope.questionCustomList = [];
	$scope.selTopic = "";
	$scope.selChapter = "";
	$scope.selectedChapterDetails = {};
	$scope.selectedQuestionsForChapter  = [];
	$scope.selSbjId ="";
	$scope.curSubjLimit = false;
	$scope.soqMark = localStorage.getItem("soqMark");


	$scope.getCustomTestQuestionIds = function(){
		httpFactory.getResult("getCustomTestQuestionIds?schemaName=" + $scope.schemaName + "&testId="+ $scope.testId , function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.savedQuesinDB = [];
				$scope.savedQuesinDB = data.TestQuestionId.slice(0);
				$scope.allSelectedQuestions = new Array();
				$scope.allSelectedQuestions = data.TestQuestionId.slice(0);

			}else if(data.StatusCode == 300){
				$scope.allSelectedQuestions = [];
			}
		});
	}

	$scope.getAllSelectedChapterDetails = function(sbjId, selCnt, totCnt){
		if(selCnt == totCnt){
			$scope.curSubjLimit = true;
		}
		else{
			$scope.curSubjLimit = false;
		}

		$scope.selSbjId = sbjId;
		$scope.questionCustomList = [];
		var contentType = localStorage.getItem("courseName")+","+$scope.selContentType;
		var courseId = $scope.courseId;
		if(courseId != undefined){
			courseId = localStorage.getItem("courseId");
		}
		httpFactory.getResult("getChapterTopicsBySubId?schemaName="+$scope.schemaName +"&subjectId="+sbjId+"&contentOwner="+$scope.selectedContentOwner+"&contentType="+contentType+"&branchId="+localStorage.getItem("bnchId")+"&courseId="+courseId+"&instId="+$scope.instituteId , function(data){
			console.log(data.Chaptertopics);
			$scope.selectedChapterDetails = data;
			for(var j=0; j<$scope.allSelectedQuestions.length; j++){
			  if($scope.allSelectedQuestions[j].subjectId == $scope.selSbjId){
				for(var i=0; i<$scope.selectedChapterDetails.Chaptertopics.length; i++){
				  if($scope.allSelectedQuestions[j].chapterId == $scope.selectedChapterDetails.Chaptertopics[i].chapterId){
					  $scope.selectedChapterDetails.Chaptertopics[i].selected =true;
					 // $scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount =0;
					for(var k=0; k<$scope.selectedChapterDetails.Chaptertopics[i].Topics.length; k++ ){
						if($scope.allSelectedQuestions[j].topicId == $scope.selectedChapterDetails.Chaptertopics[i].Topics[k].topicId){
							if($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount == undefined || $scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount == NaN){
								$scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount = 0;
							}
							if($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount == undefined || $scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount == NaN){
								$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount = 0;
							}
							$scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount)+1;
							$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].selected = true;
							$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount) + 1;
						}
					}
				  }
				}
			  }
			}
		});
	}

	$scope.updateChapterDetailsSection = function(){
		for(var j=0; j<$scope.allSelectedQuestions.length; j++){
		  if($scope.allSelectedQuestions[j].subjectId == $scope.selSbjId){
			for(var i=0; i<$scope.selectedChapterDetails.Chaptertopics.length; i++){
			  if($scope.allSelectedQuestions[j].chapterId == $scope.selectedChapterDetails.Chaptertopics[i].chapterId){
				  $scope.selectedChapterDetails.Chaptertopics[i].selected =true;
				for(var k=0; k<$scope.selectedChapterDetails.Chaptertopics[i].Topics.length; k++ ){
					if($scope.allSelectedQuestions[j].topicId == $scope.selectedChapterDetails.Chaptertopics[i].Topics[k].topicId){
						$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].selected = true;
					}
				}
			  }
			}
		  }
		}
	}


	$scope.getChapterTopicQuestions = function(tpcId,chpId,tpcName){
		$scope.selChapter = chpId;
		$scope.selTopic = tpcId;
    $scope.selTopicName = tpcName;
    var branchId = localStorage.getItem("bnchId") + "," + "0";
    if (localStorage.getItem("sname")!=localStorage.getItem("cgTestSelRepo")) {
      $scope.qRepositoryName= "CEDZ" + ',' + localStorage.getItem("sname");
    }else{
      $scope.qRepositoryName=localStorage.getItem("sname");
    }
    console.log($scope.qRepositoryName);
		httpFactory.getResult("getQuestionsByTopicId?schemaName="+localStorage.getItem("sname") +"&topicId="+tpcId+"&contentOwner="+$scope.qRepositoryName +"&branchId=" + branchId, function(data){
			console.log(data.Questions);
      $scope.questionCustomList=data.Questions;
			// $scope.questionCustomList = $scope.repoQuesObj[0].questionArray;
			for(var i=0; i<$scope.allSelectedQuestions.length; i++){
				if($scope.allSelectedQuestions[i].topicId == tpcId){
					for(var j=0; j<$scope.questionCustomList.length; j++){
            for(var k=0; k<$scope.questionCustomList[j].questionArray.length; k++){
  						if($scope.allSelectedQuestions[i].questionId == $scope.questionCustomList[j].questionArray[k].questionId){
  							$scope.questionCustomList[j].questionArray[k].selected = true;
  						}
            }
					}
				}
			}
		});
	}

$scope.Publishable = true;
$scope.selProgress = "0%";
$scope.selProgresObj = {};
$scope.publishCheck = function(){
	var tempselectedQuestionCount = 0;
		var tempTotalQuestions = 0;
	for(var k=0; k<$scope.selectedSubjectsQuestionTotalDetails.length; k++){
		tempselectedQuestionCount = Number(tempselectedQuestionCount) + Number($scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount);
		tempTotalQuestions = Number(tempTotalQuestions) + Number($scope.selectedSubjectsQuestionTotalDetails[k].TotalQuestions);
	}
	if(tempselectedQuestionCount == tempTotalQuestions){
			$scope.Publishable = false;
		}
		else{
			$scope.Publishable = true;
		}
	$scope.selProgress = ((tempselectedQuestionCount/tempTotalQuestions)*100).toFixed(0) +"%";
		$scope.selProgresObj = {
			"width":$scope.selProgress
		};

}
	$scope.updateSelectedTopicStatus = function(qId, ques, chckStatus,index){
		//$scope.selectedQuestionsForChapter.push(qId);
		console.log(chckStatus);
    console.log(qId);
    console.log(ques);
    console.log(ques.questionOwner);
    
    if(ques.questionOwner=='CEDZ'){
    	//$scope.cgTestSelRepo = "rankr";
		$scope.cgTestSelRepo=$scope.schemaName;
    }else{
    	$scope.cgTestSelRepo=$scope.schemaName;
    }

		if(chckStatus != true && $scope.curSubjLimit == true){
			alert("Already reached the Limit, Please deselect added question and then select new one");

			for(var j=0; j<$scope.questionCustomList[index].questionArray.length; j++){
				if(qId == $scope.questionCustomList[index].questionArray[j].questionId){
					$scope.questionCustomList[index].questionArray[j].selected = false;
					return true;
				}
			}
		}
		else{
			var found =0;
			for(var i=0; i<$scope.allSelectedQuestions.length;i++){
				if($scope.allSelectedQuestions[i].questionId == qId ){
					for(var j=0; j<$scope.questionCustomList[index].questionArray.length; j++){
						if($scope.allSelectedQuestions[i].questionId == $scope.questionCustomList[index].questionArray[j].questionId){
							$scope.questionCustomList[index].questionArray[j].selected = false;
							$scope.allSelectedQuestions.splice(i,1);
							i--;
							$scope.selectedQuestionCount--;
							found  = 1;
							break;
						}
					}
				}
			}
      console.log(found);
      console.log(ques.questionOwner);
			if(found ==0){
        console.log(ques.questionOwner);
      				var qObj = {
					"questionId":qId,
					"subjectId":$scope.selSbjId,
					"chapterId":$scope.selChapter,
					"topicId":$scope.selTopic,
          "repo":$scope.cgTestSelRepo,
          "correctAnswer":ques.correctAnswer

				};
				$scope.allSelectedQuestions.push(qObj);
			}
			for(var k=0; k<$scope.selectedSubjectsQuestionTotalDetails.length; k++){
				if($scope.selSbjId == $scope.selectedSubjectsQuestionTotalDetails[k].subjectId){
					if(found == 0){
						$scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount = Number($scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount) + 1;
					}
					else if(found == 1){
						$scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount = Number($scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount) - 1;
					}
					if($scope.selectedSubjectsQuestionTotalDetails[k].selectedQuestionCount == $scope.selectedSubjectsQuestionTotalDetails[k].TotalQuestions){
						$scope.curSubjLimit = true;
					}
					else{
						$scope.curSubjLimit = false;
					}
				}
			}
			for(var i=0; i<$scope.selectedChapterDetails.Chaptertopics.length; i++){
			  if($scope.selChapter == $scope.selectedChapterDetails.Chaptertopics[i].chapterId){
				  if($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount == undefined || $scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount == NaN){
					$scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount = 0;
				}
				  if(found == 0){
						$scope.selectedChapterDetails.Chaptertopics[i].selected =true;
						$scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount) + 1;
					}
					else if(found == 1){
						$scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount) - 1;
						if(Number($scope.selectedChapterDetails.Chaptertopics[i].Topics.isaciveCount) == 0){
							 $scope.selectedChapterDetails.Chaptertopics[i].selected =false;
						 }
					}



					for(var k=0; k<$scope.selectedChapterDetails.Chaptertopics[i].Topics.length; k++ ){
						if($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount == undefined || $scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount == NaN){
							$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount = 0;
						}
						if($scope.selTopic == $scope.selectedChapterDetails.Chaptertopics[i].Topics[k].topicId){
							if(found == 0){
								$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount) + 1;

								$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].selected = true;
							}
							else if(found == 1){
								$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount = Number($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount) - 1;
								if($scope.selectedChapterDetails.Chaptertopics[i].Topics[k].isaciveCount == 0){
									$scope.selectedChapterDetails.Chaptertopics[i].Topics[k].selected = false;
								}
							}
						}
					}

			  }
			}
			$scope.publishCheck();
		}
	}



	$scope.getTestAllDetails = function(){
    // var obj = {"TestDetails":[{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"1","subjectName":"Maths1A"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"2","subjectName":"Maths1B"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"5","subjectName":"Physics1"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"7","subjectName":"Chemistry1"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"3","subjectName":"Maths2A"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"4","subjectName":"Maths2B"},{"TotalQuestions":"1","selectedQuestionCount":"0","subjectId":"6","subjectName":"Physics2"}]};
    // $scope.selectedSubjectsQuestionTotalDetails =data.TestDetails;
		$scope.testId =  localStorage.getItem("cgTestId");
		$scope.selQB =  localStorage.getItem("cgTestSelQB");
		$scope.testName =  localStorage.getItem("cgTestName");
		httpFactory.getResult("getCustomTestDetails?schemaName=" + $scope.schemaName + "&testId="+ $scope.testId , function(data) {
			console.log(data);
      if (data.StatusCode==200) {
        $scope.selectedSubjectsQuestionTotalDetails = data.TestDetails;
      }else{
        alert("Something Went wrong");
      }
			//$scope.geAllSelectedChapterDetails();
		});
		$scope.getCustomTestQuestionIds();
		$scope.getAllSelectedChapterDetails($scope.selectedSubjectsQuestionTotalDetails[0].subjectId, $scope.selectedSubjectsQuestionTotalDetails[0].selectedQuestionCount, $scope.selectedSubjectsQuestionTotalDetails[0].TotalQuestions);
	//	$scope.getChapterTopicQuestions($scope.selectedChapterDetails.Chaptertopics[0].Topics[0].topicId, $scope.selectedChapterDetails.Chaptertopics[0].chapterId);
		$scope.publishCheck();
	}

	$scope.saveCustomTestQuestions = function(){
		var addSelectedQuestions = [];
		var deleteSelectedQuestions = [];
		var updatedTestDetailsSubjects = [];
		for(var j=0; j<$scope.savedQuesinDB.length;j++){
			var deleteFound = 0;
			for(var i=0; i<$scope.allSelectedQuestions.length; i++){
				if($scope.allSelectedQuestions[i].questionId == $scope.savedQuesinDB[j].questionId){
					deleteFound = 1;
				}
			}
			if(deleteFound == 0){
				deleteSelectedQuestions.push($scope.savedQuesinDB[j]);
			}
		}
		for(var k=0; k<$scope.allSelectedQuestions.length; k++){
			var addFound = 0;
			for(var l=0; l<$scope.savedQuesinDB.length;l++){
				if($scope.allSelectedQuestions[k].questionId == $scope.savedQuesinDB[l].questionId){
					addFound = 1;
				}
			}
			if(addFound == 0){
				addSelectedQuestions.push($scope.allSelectedQuestions[k]);
			}
		}
		var requestParams = {
			"createdBy":$scope.user_id,
			"testId":$scope.testId,
			"schemaName":$scope.schemaName,
			"AddQuestions":addSelectedQuestions,
			"DeleteQuestions":deleteSelectedQuestions,
			"TestDetails":$scope.selectedSubjectsQuestionTotalDetails
		};
		console.log(requestParams);
		httpFactory.executePost("saveCustomTestQuestions", requestParams, function(data) {
			console.log(data);
			if(data.StatusCode =="200"){
				$scope.savedQuesinDB = $scope.allSelectedQuestions.slice(0);
				$scope.getCustomTestQuestionIds();
				alert("Added Successfully");
			}
			$location.path("publishTest/"+$scope.testId+"/"+localStorage.getItem("bnchId")+"/publish");
		});
	}

	$scope.saveTestAndContinue = function(){
		$scope.saveCustomTestQuestions();
	}

  $scope.getCourses = function(instType) {
    $scope.selectedCategoryObj=[];
    $scope.instTypeOb=instType;
    $scope.selectedQType="";

$scope.selectedBranch=localStorage.getItem("bnchId");
    httpFactory.getResult("getClassCoursesByBId?branchId=" + $scope.selectedBranch + "&instType="  +$scope.selectedInst+ "&schemaName="+localStorage.getItem("sname")+"&instId="+$scope.instituteId, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
          $scope.courseList = data.ClassCourses;
          console.log($scope.courseList);
      } else {
        console.log("No courses");
      }
    });
  }

// methods for manual and select test setup screen

$scope.showCourseByInstType=function(instType){
    $scope.instTypeOb=instType;

  httpFactory.getResult("getAllCoursesByInstType?instType=" + $scope.selectedInst + "&schemaName="+localStorage.getItem("sname"), function(data) {
    console.log(data);
    $scope.courseList=[];

    if (data.StatusCode == 200) {
      $scope.courseList=data.Courses;
    } else {
      console.log("No Courses");
    }
  });
}


$scope.categoryChange = function(category) {
  $scope.showClass = false;
  $scope.showSubject = false;
  $scope.showChapter = false;
  $scope.showTopic = false;

  $scope.categoryObj = JSON.parse($scope.selectedCategoryObj);
  $scope.categoryName=$scope.categoryObj.categoryName;
  $scope.isMultipleSub = $scope.categoryObj.multipleSubjects;
  console.log($scope.isMultipleSub);

  $scope.duration = $scope.categoryObj.duration;
  $scope.correctMarks = $scope.categoryObj.correctMarks;
  $scope.wrongMarks = $scope.categoryObj.wrongMarks;
  $scope.numQuestions = $scope.categoryObj.totalQuestions;
  $scope.totalMarks = parseInt($scope.numQuestions)*parseInt($scope.correctMarks);
  $scope.selectedCategoryId = $scope.categoryObj.categoryId;
  if ($scope.categoryName== 'CLASS-WISE') {
    $scope.testType='Y';
  }else{
    $scope.testType=$scope.categoryName[0];
  }  
  
  console.log($scope.categoryObj.sectionAvailable);

  if($scope.categoryObj.sectionAvailable==1){
  	$scope.isSectionAvailable=1;
  	$scope.getJeeTestSections();
  
  }
  $scope.getSchemas();
}

$scope.getJeeTestSections=function(){
    httpFactory.getResult("getJeeTestSections?schemaName="+localStorage.getItem("sname")+ "&catId="+ $scope.selectedCategoryId, function(data) {
      if (data.StatusCode == 200) {
        $scope.jeeTestSecArr = data.TestSections;
        console.log($scope.jeeTestSecArr);
        }
       else {
    	   $scope.jeeTestSecArr=[];
       }
    });
  }

$scope.JEETemplateSelect=function(selectedJeeTemplate){
  	console.log(selectedJeeTemplate);
  	
  	$scope.numQuestions=0;
  	$scope.totalMarks=0;
  	
  	if(typeof selectedJeeTemplate=='string')
  		$scope.selJeeTemplate = JSON.parse(selectedJeeTemplate);
  	else
  		$scope.selJeeTemplate = selectedJeeTemplate;
  	
  
  	console.log($scope.selJeeTemplate);
  	
  	for(var i = 0;i<$scope.selJeeTemplate.testSectionDetails.length;i++){
  		
  		$scope.numQuestions+=parseInt($scope.selJeeTemplate.testSectionDetails[i].numQuestions);
  		
  		$scope.totalMarks += (parseInt($scope.selJeeTemplate.testSectionDetails[i].numQuestions) * parseInt($scope.selJeeTemplate.testSectionDetails[i].correctAnswerMarks));
  		
  		console.log($scope.totalMarks);
  	}
	}

$scope.jeeInfoTemplateSelect=function(jee){
  
  console.log(jee);
  
  $scope.jeeTemplateDetail = jee.testSectionDetails;
}

$scope.jeeTemplateInfo=function(){
  console.log($scope.selJeeTemplate);
  $("#jeeTemplateInfo").modal("show");
}



$scope.getCourseQuestionType=function(){
  httpFactory.getResult("getCourseQuestionType?schemaName="+localStorage.getItem("sname")+ "&courseId="+ $scope.selectedCourse, function(data) {
    if (data.StatusCode == 200) {
      $scope.qTypeList = data.courseQuestionTypes;
      console.log($scope.qTypeList);
      }
     else {

     }
  });
}
$scope.getSchemas = function() {
  $scope.selectedQType="";
  $scope.selectedSchema="";
  $scope.QSchema="";
  // $scope.selectedCategoryObj="";
  $scope.subjectList=[];
  httpFactory.getResult("selectContentOwner?schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    $scope.contentOwnerList=[];

  if (data.StatusCode == 200) {
    $scope.contentList = data.ContentOwner;
    console.log($scope.contentList);
    for (var i = 0; i < $scope.contentList.length; i++) {
      console.log($scope.contentList[i].courseId);
      console.log($scope.selectedCourse);
      if ($scope.contentList[i].courseId == $scope.selectedCourse || $scope.contentList[i].courseId==0) {
        $scope.contentOwnerList.push($scope.contentList[i]);
      }
    }
      console.log($scope.contentOwnerList);
  } else {
  }
  });
}

$scope.questionTypeChange=function(qType){
  $scope.qTypeobj=JSON.parse(qType);
  $scope.selectedContentOwner = $scope.qTypeobj.contentOwnerName;
  $scope.getSubjectsByCourse();
}

$scope.schemaChange = function(){
  $scope.selectedYear = "";
  $scope.selectedSubject = "";
  $scope.selectedChapter = "";
  $scope.selectedTopic = "";
  $scope.selectedQType="";
  $scope.getSchemaContentOwner();
  console.log($scope.selectedSVal);
  if (typeof $scope.selectedSchemaOb == 'string') {
    $scope.selectedSVal = JSON.parse($scope.selectedSchemaOb);
  }else{
    $scope.selectedSVal = $scope.selectedSchemaOb;
  }
  console.log($scope.selectedSVal);
  if ($scope.selectedSVal.courseId == 0) {
    $scope.selectedSchema = "COLLEGE";
    $scope.selectedContentSchema = localStorage.getItem("sname");
  }else {
  $scope.selectedContentType=$scope.selectedSVal.contentType;
  $scope.selectedContentSchema = $scope.selectedSVal.contentSchema;
  console.log($scope.selectedContentType);
}
  $scope.getSchemaContentOwner();
}

$scope.getSchemaContentOwner = function(){
  httpFactory.getResult("getSchemaContentOwner?schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    $scope.schemaContent=[];
    if (data.StatusCode == 200) {
      $scope.schemaContent = data.schemaContent;
      console.log($scope.schemaContent);
      }
    else {
      console.log("No ContentList");
    }
  });
}

});
