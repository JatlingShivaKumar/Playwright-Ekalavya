projectModule.controller('reportController', function($scope, $location, $timeout, $routeParams, httpFactory,Excel, $rootScope) {
  $scope.$ = $;
  $scope.labels = ["Correct Answers", "Wrong Answers", "Not Answered"];
  $scope.data = [450, 280, 220];
  $scope.colors = ['#16a085', '#e74b3b', '#f1c30f'];
  $scope.options = {
    legend: {
      display: true,
      position: 'left'
    }
  };
  $scope.testId = $routeParams.id;
  $scope.testId = $routeParams.testId;
  $scope.testStatusFlag = $routeParams.status;
  $scope.qusbSelTab = "";
  $scope.schemaName=localStorage.getItem("sname");
  $scope.questionAnalysisFlag=false;

  $scope.redirectToReport = function() {
    $location.path("/report/" + $scope.testId + "/0");
  }
  $scope.redirectToExamReport = function() {
    $location.path("/examReport/" + $scope.testId + "/0");
  }
  $scope.redirectToExams = function() {
    $location.path("/exams");
  }
  $scope.getStudentAnswerChartData = [];
  $scope.getStudentRankData = [];
  $scope.getAllAnswersChartData = [];
  $scope.getStudentsAnswerSubjectData = [];
  $scope.studentId = localStorage.getItem("stuid");
  $scope.studentName = localStorage.getItem("name");
  $scope.testDetailObject = [];
  $scope.allStudents = [];
  $scope.selectedquesAnalysis = {};

  $scope.subjectGroup1=0;

  $scope.subjectWrngGroup1=0;

  $scope.subjectSkipGroup1=0;

  $scope.subjectNotVisitedGroup1=0

  $scope.subjectGroupTT1=0;

  $scope.subjectWrngGroupTT1=0;

  $scope.subjectSkipGroupTT1=0;

  $scope.subjectNotVisitedGroupTT1=0;


	$scope.assignselectedquesAnalysis = function(ques){
		$scope.selectedquesAnalysis = ques;
    $scope.selectedQuestOb=ques;
    console.log($scope.selectedQuestOb);

    for(i=0;i<$scope.questionOrder.length;i++){
      if ($scope.questionOrder[i].questionId == ques.questionId) {
        $scope.selectedQuestOb = $scope.questionOrder[i];
        break;
      }
    }
		$scope.prgBarItemsCorrect = {
			'width':(ques.correctAnswerpercentage)+'%'
		};
		$scope.prgBarItemsUnat = {
			'width':(ques.unattemptedAnswerPercentage)+'%'
		};
		$scope.prgBarItemsWrng = {
			'width':(ques.wrongAnswerpercentage)+'%'
		};
    $scope.getQuestionWiseTimeAnalysis(ques);
	}
  $scope.afterExamResult = function(){
    if ($routeParams.status == 0) {
      $('#mainheader').hide();
      $('#tabsDiv').hide();
      $('#reviewP').hide();
      $('#reviewPalette').hide();
      $('#reviewQuestionDiv').hide();
      $('#whereDiv').hide();
    }
  }

  $scope.getStudentExamReport = function(){
    console.log('getStudentExamReport');
    if ($routeParams.status==0) {
      $scope.testId=$routeParams.id;
      $scope.testId=$routeParams.id;
      console.log($routeParams.id);
      $scope.studentId = $routeParams.sid;
      console.log($scope.studentId);
      // $scope.getExamResults();
      $scope.getStudentTestAnalysis();
    }else{
      $scope.studentName = localStorage.getItem("name");
      console.log($scope.studentName);
      $scope.testId=$routeParams.id;
      $scope.testId=$routeParams.id;
      console.log($routeParams.id);
      $scope.studentId = localStorage.getItem("stuid");
      console.log($scope.studentId);
      // $scope.getExamResults();
      $scope.getStudentTestAnalysis();
    }
}

$scope.getStudentTestAnalysis = function(){
  console.log("getStudentTestAnalysis");
  httpFactory.getResult("getStudentTestAnalysis?testId=" + $scope.testId + "&studentId=" + $scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    console.log(data.StatusCode);
    if (data.StatusCode == 200) {
      $scope.getStudentExamDetails = data;
      $scope.getStudentAnswerChartData = [$scope.getStudentExamDetails.correctAnswersCount, $scope.getStudentExamDetails.wrongAnswersCount, $scope.getStudentExamDetails.notAnsweredCount];
      console.log($scope.getStudentAnswerChartData);
      $scope.overallScore=$scope.getStudentExamDetails.result;
      console.log($scope.overallScore);
    }
  });
}

$scope.getTestInfo = function(){
  httpFactory.getResult("getTestInfo?testId=" + $scope.testId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    console.log(data.StatusCode);
    if (data.StatusCode == 200) {
    $scope.testInfo = data;
    $scope.correctMarksValue=data.correctAnswerMarks;
    $scope.wrongMarksValue=data.WrongAnswerMarks;

    }
  });
}

$scope.getStudentAttendence = function(){
  console.log("getStudentAttendence");
  httpFactory.getResult("getStudentAttendence?testId=" +  $routeParams.testId + "&branchId=" + $routeParams.brchId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    console.log(data.StatusCode);
    if (data.StatusCode == 200) {
      $scope.testAttendanceData = data;
      if ($scope.testAttendanceData.AttendedCount!=0) {

      $scope.aLabels = ["Attended", "Absent"];
      $scope.attendance = [$scope.testAttendanceData.AttendedCount, $scope.testAttendanceData.AbsentCount];
      console.log($scope.attendance);
      $scope.colors = ['#16a085', '#e74b3b'];
      $scope.options = {
        legend: {
          display: false,
          position: 'left'
        }
      };
      console.log($scope.attendance);
      $scope.getTestInfo();
      $scope.getStudentRankForAdmin();
    }else{
      alert("No students attended this exam");
      window.history.back();
    }

    }
  });
}

$scope.getStudentsTestResultByTestId = function(){
  httpFactory.getResult("getStudentsTestResultByTestId?testId=" + $routeParams.testId + "&branchId=" + $routeParams.brchId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.studentResult = data.testStudentReport;
      if ($scope.studentResult.length>0) {
        console.log($scope.studentResult);
        for(j=0;j<$scope.studentResult.length;j++){
          for(k=0;k<$scope.studentResult[j].studentMarks.length;k++){
            $scope.studentResult[j][$scope.studentResult[j].studentMarks[k].subjectGroup] = $scope.studentResult[j].studentMarks[k].Marks;
          }
        }
        $scope.subjectArrayMarks = $scope.studentResult[0].studentMarks;
        console.log($scope.subjectArrayMarks);

        var dataObject = {
          "studentName":'Student Name',
          "studenRollnumber":'Roll Number',
          "sectionName":'Section Name',
          "totalMarks":'Total Marks',
          "percentage":'Percentage'
        }
        for(i=0;i<$scope.subjectArrayMarks.length;i++){
            dataObject[$scope.subjectArrayMarks[i].subjectGroup]=$scope.subjectArrayMarks[i].subjectGroup;
        }
        console.log(dataObject);
        $scope.excelDataObj = dataObject;
        console.log($scope.excelDataObj);
      }else{
        $scope.excelDataObj = {};
        $scope.subjectArrayMarks = [];
      }
      $scope.dataForExamAnalysisTab();
    }
  });
}
$scope.getStudentTestQuestionAnalysis = function(){
  httpFactory.getResult("getStudentTestQuestionAnalysis?testId=" + $routeParams.testId + "&branchId=" + $routeParams.brchId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.studentResult = data.testStudentReport;
      console.log($scope.studentResult);
      $scope.subjectArrayMarks = $scope.studentResult[0].studentMarks;
      console.log($scope.subjectArrayMarks);
      $scope.dataForExamAnalysisTab();
    }
  });
}



// Method for data chart for exam analysis tab in testResult.html from getStudentsTestResultByTestId api
$scope.dataForExamAnalysisTab=function(){
  var tmp = []
  for (i = 0; i < $scope.studentResult.length; i++) {
    tmp[i] = $scope.studentResult[i];
  }
  console.log(tmp);
  $scope.sectionArray = groupBy(tmp, function(item) {
    return [item.sectionName];
  });
  console.log($scope.sectionArray.length);

  $scope.sectionChartData = [];
  $scope.sLabels = [];
  $scope.sOptions = {
    legend: {
      display: true,
      position: 'left'
    }
  };
  for (i = 0; i < $scope.sectionArray.length; i++) {
    $scope.sectionArray[i].sort(function(a, b) {
      return b.totalMarks - a.totalMarks
    });
    var avg = 0;
    var count = 0;
    for (j = 0; j < $scope.sectionArray[i].length; j++) {
      avg += eval($scope.sectionArray[i][j].percentage);
      count++;
    }
    console.log($scope.sectionArray);
    $scope.sectionChartData[i] = Math.round(avg / count);
    $scope.sLabels[i] = $scope.sectionArray[i][0].sectionName;
  }


  $scope.sectionChartData[$scope.sectionChartData.length + 1] = 0;
  $scope.passCounter = 0;
  $scope.failCounter = 0;
  $scope.highScore = 0;
  $scope.lowScore = 0;
  $scope.examAverage = 0;
  var counter = 0;
  console.log($scope.studentResult);
  for (i = 0; i < $scope.studentResult.length; i++) {
    $scope.examAverage = eval($scope.examAverage) + eval($scope.studentResult[i].percentage);
    counter++;
    if ($scope.studentResult[i].percentage > 35) {
      $scope.passCounter++;
    } else {
      $scope.failCounter++;
    }
    if (i == 0) {
      $scope.highScore = $scope.studentResult[i].totalMarks;
      $scope.lowScore = $scope.studentResult[i].totalMarks;
    } else {
      if (eval($scope.studentResult[i].totalMarks) > eval($scope.highScore)) {
        $scope.highScore = eval($scope.studentResult[i].totalMarks);
      }
      if (eval($scope.studentResult[i].totalMarks) < eval($scope.lowScore)) {
        $scope.lowScore = eval($scope.studentResult[i].totalMarks);
      }
    }
  }
  $scope.examAverage = $scope.examAverage / counter;
  $scope.examAverage = Math.round($scope.examAverage, 2);
  $scope.allStudents = [$scope.passCounter, $scope.failCounter, 0]
  $scope.labels = ["Passed", "Failed", "Absent"];

}

function groupBy(array, f) {
  var groups = {};
  array.forEach(function(o) {
    var group = JSON.stringify(f(o));
    groups[group] = groups[group] || [];
    groups[group].push(o);
  });
  return Object.keys(groups).map(function(group) {
    return groups[group];
  })
}

$scope.getStudentRankForAdmin = function(){
  httpFactory.getResult("getStudentRankForAdmin?testId=" + $routeParams.testId + "&branchId=" + $routeParams.brchId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.studentRankObj = data.studentRankObj;
      console.log($scope.studentRankObj);
      $scope.getAdminChapterWiseAnalysis();
    }
  });
}

$scope.getAdminChapterWiseAnalysis = function(){
  $scope.topicWiseAnalyseData=[];
  httpFactory.getResult("getAdminTopicWiseAnalysis?testId=" + $routeParams.testId + "&branchId=" + $routeParams.brchId +"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.topicChartData=[];
      $scope.tLabels=[];
      $scope.topicWiseAnalyseData=data.topicAnalysisObj;
      console.log($scope.topicWiseAnalyseData);
      console.log($scope.topicWiseAnalyseData.length);
       var totalTopics = Object.keys($scope.topicWiseAnalyseData).length;
       console.log(totalTopics);
      for (var i=0;i<totalTopics;i++) {
        console.log(parseInt($scope.topicWiseAnalyseData[i].correctAnswerpercentage));
      $scope.topicChartData[i] =  parseInt($scope.topicWiseAnalyseData[i].correctAnswerpercentage);

      // $scope.topicChartData=[11, 18, 20, 21, 22, 23, 22, 11, 7, 0, 24, 0, 0, 50, 10, 11, 0, 0];
     $scope.tLabels[i] = $scope.topicWiseAnalyseData[i].chapterName;
      // $scope.topicChartData[$scope.topicChartData.length + 1] = 0;
    }
    console.log($scope.topicChartData);

    }
  });
}

// for student
    $scope.getAdminStudentExamReport = function(){
      $scope.reviewObjStudent = JSON.parse(localStorage.getItem('studentReviewObj'));
      console.log($scope.reviewObjStudent);
      // localStorage.removeItem('studentReviewObj');
      $scope.studentName = $scope.reviewObjStudent.studentName;
      $scope.testId=$scope.reviewObjStudent.testId;
      $scope.studentId = $scope.reviewObjStudent.studentId;
      $scope.studentPercentage = $scope.reviewObjStudent.percentage;
      $scope.getTestInfo();
      $scope.getStudentTestAnalysis();
      $scope.getTestQuestions();
      // $scope.getExamResults();
    }

  Number.prototype.round = function(decimals) {
    return Number((Math.round(this + "e" + decimals) + "e-" + decimals));
  }

  function groupBy(array, f) {
    var groups = {};
    array.forEach(function(o) {
      var group = JSON.stringify(f(o));
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });
    return Object.keys(groups).map(function(group) {
      return groups[group];
    })
  }

  // $scope.getExamResults();

  $scope.getTestDetailInformation = function() {
    $scope.getStudentAttendence();
  }

  $scope.reviewQuestions = function() {
    $scope.getReviewTestQuestions();
    $("#reviewModalStudent").modal("show");
  }
  $scope.reviewQuestionsHide = function() {
    alert("Cannot review questions as test is not yet completed for all.");
  }
  $scope.latestCurrentTab = 'reportsBox';
  $scope.redirectToCurrentTab = function(currentTab) {
    $scope.latestCurrentTab = currentTab;
  }
  $scope.latestCurrentTabTest = 'examAnalysis';
	$scope.redirectToCurrentTabTest = function(currentTab) {
    // $scope.getQuestionsForAnalysis();
    $scope.latestCurrentTabTest = currentTab;
    console.log($scope.latestCurrentTabTest);
    if (currentTab == "questionAnalysis" &&$scope. questionAnalysisFlag!=true) {
      $scope.getQuestionsForAnalysis();
      $scope.questionAnalysisFlag=true;
    }else{
      // alert("already loaded");
    }
  }

  $scope.getQuestionsForAnalysis = function(){
    // alert("getQuestionsForAnalysis");
    httpFactory.getResult("getAdminTestQuestionsAnalysis?testId=" + $scope.testId+"&branchId="+$routeParams.brchId+"&schemaName="+$scope.schemaName , function(data) {
      console.log(data);
      if (data.StatusCode== 200) {
        $scope.quesAnalysisObj = data.testQuestionAnalysis;
        console.log($scope.quesAnalysisObj);
        $scope.getQuestionOrderForTest();
      }

    });
  }

  $scope.getQuestionOrderForTest = function(){
    // alert("getQuestionOrderForTest");
    httpFactory.getResult("getTestQuestions?testId=" + $scope.testId+"&schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      if (data.StatusCode==200) {
        $scope.questionOrder = data.testQuestions;
        console.log($scope.questionOrder);
        $scope.sortingDisplayOrderForQuestionArray($scope.quesAnalysisObj,$scope.questionOrder);
      }
    });
  }
  $scope.getTestQuestions = function(){
    // alert("getQuestionOrderForTest");
    httpFactory.getResult("getStudentTestQuestionAnalysis?testId=" + $scope.testId+"&studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      if (data.StatusCode==200) {
        $scope.questionList = data.TestQuestions;
        console.log($scope.questionList);
        $scope.totalQuestions = $scope.questionList.length;
        recordsFound = true;

        $scope.subjectWiseList = [];
        $scope.subjectArr = {}
        counter = 0;
        //create subject-wise arrays
        for (i = 0; i < $scope.questionList.length; i++) {

          if (i == 0) {
            $scope.subjectArr.subjectName = $scope.questionList[i].subjectGroup;
            $scope.subjectArr.questionStart = i;
            $scope.subjectArr.active = true;
            $scope.subjectWiseList[counter] = $scope.subjectArr;
            $scope.subjectArr = {};
            counter++;
          } else {
            if ($scope.questionList[i].subjectGroup != $scope.questionList[i - 1].subjectGroup) {
              $scope.subjectArr.subjectName = $scope.questionList[i].subjectGroup;
              $scope.subjectArr.questionStart = i;
              $scope.subjectArr.active = false;
              $scope.subjectWiseList[counter] = $scope.subjectArr;
              $scope.subjectArr = {};
              counter++;
            }
          }
          if ($scope.questionList[i].timeTaken == 0 && $scope.questionList[i].style == 'not_visited_div') {
            $scope.questionList[i].style = 'not_visited_div';
            $scope.notVisited++;
          }
          if ($scope.questionList[i].style == 'answered_div'){
            $scope.answered++;
          }
          if ($scope.questionList[i].style == 'not_answered_div')
            $scope.not_answered++;
          if ($scope.questionList[i].style == 'markedrview_div')
            $scope.markedForReview++;
          if ($scope.questionList[i].style == 'answered_marked_div')
            $scope.answeredAndMarked++;
            //
          $scope.questionList[i].selectedAnswer = $scope.questionList[i].selectedAnswer.toUpperCase()
          $scope.questionList[i].correctAnswer =  $scope.questionList[i].correctAnswer.toUpperCase()
            if ($scope.questionList[i].selectedAnswer == $scope.questionList[i].correctAnswer) {
              $scope.studentCorrectAnswers++;
            } else if($scope.questionList[i].selectedAnswer.length==0 ){
              $scope.studentSkippedAnswers++;
            }else{
              $scope.studentWrongAnswers++;
            }
        }

      }
    });

    // $scope.questionList = JSON.parse($scope.questionList);
    // $scope.getStudentAnswerChartData = [];
    $scope.correctAns = 0;
    $scope.wrongAns = 0;
    $scope.totalTime = 0;
    $scope.labels = ["Correct Answers", "Wrong Answers", "Not Answered"];
    // $scope.data = [450, 280, 220];
    $scope.colors = ['#16a085', '#e74b3b', '#f1c30f'];
    $scope.options = {
      legend: {
        display: true,
        position: 'right'
      }
    };
    for (i = 0; i < $scope.questionList.length; i++) {
      sendList = {};
      if ($scope.questionList[i].selectedAnswer == $scope.questionList[i].correctAnswer) {
        $scope.correctAns++;
      } else if ($scope.questionList[i].selectedAnswer.length < 1) {
        $scope.notAnsweredCount++;
      } else {
        $scope.wrongAns++;
      }
      $scope.totalTime += $scope.questionList[i].timeTaken;
    }
    $scope.displayTime = $scope.totalTime;
    if ($scope.displayTime > 59) {
      $scope.displayTime = $scope.displayTime / 60;
      $scope.displayTime = $scope.displayTime.round(2);
      $scope.timeStr = "(Min)";
    } else {
      $scope.timeStr = "(Sec)";
    }

    var qLength = $scope.questionList.length;
    var diff = $scope.correctAns + $scope.wrongAns;

    var notAnswered = qLength - diff;
    // $scope.getStudentAnswerChartData = [$scope.studentCorrectAnswers, $scope.studentWrongAnswers, $scope.studentSkippedAnswers];
    $scope.average = ((($scope.correctAns*$scope.correctMarksValue)-$scope.wrongMarksValue) / $scope.questionList.length) * 100;
    $scope.average = $scope.average.round(2);
  for(var sb=0; sb<$scope.questionList.length;sb++){
    if($scope.subjectGroupArray.indexOf($scope.questionList[sb].subjectGroup) == -1){
      $scope.subjectGroupArray.push($scope.questionList[sb].subjectGroup);
    }
  }
  $scope.qusbSelTab = $scope.subjectGroupArray[0];
    var tmp = [];
    for (i = 0; i < $scope.questionList.length; i++) {
      tmp[i] = $scope.questionList[i];
    }

    $scope.subjectWiseArray = groupBy(tmp, function(item) {
      return [item.subjectGroup];
    });


  console.log($scope.subjectWiseArray);
    $scope.changeSubjectBoxStudList = $scope.subjectWiseArray[0];
    $scope.getseQuesDataDetails = $scope.changeSubjectBoxStudList[0];
    console.log($scope.subjectWiseArray[0]);
    $scope.calculateSubjectWiseAnalysis();

  }
$scope.selectedsubjectGroupValidated = {};
$scope.calculateSubjectWiseAnalysis =  function(){

  $scope.subjectGroupValidatedArr=[];
  $scope.highestCTimeTaken=0;
  $scope.highestWTimeTaken=0;
  $scope.highestSTimeTaken=0;
  $scope.lowestCTimeTaken='';
$scope.lowestWTimeTaken ='';
$scope.lowestSTimeTaken ='';
$scope.highestCQNo =0;
$scope.highestWQNo =0;
$scope.highestSQNo =0;
$scope.lowestSQNo = 0;
$scope.lowestWQNo = 0;
$scope.lowestCQNo = 0;

$scope.studentCorrectAnswers=0;

$scope.totalmarksScoredForSubject = 0;
  for (i = 0; i < $scope.subjectGroupArray.length; i++) {
      for(j=0;j<$scope.subjectWiseArray[i].length;j++){
        if ($scope.subjectWiseArray[i][j].correctAnswer == $scope.subjectWiseArray[i][j].selectedAnswer) {
          $scope.studentCorrectAnswers++;
            $scope.subjectGroup1++;
            $scope.subjectGroupTT1 += parseInt($scope.subjectWiseArray[i][j].timeTaken);
            if ($scope.highestCTimeTaken < parseInt($scope.subjectWiseArray[i][j].timeTaken) ){
              $scope.highestCTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
                $scope.highestCQNo = j+1;
            }
            if (parseInt($scope.subjectWiseArray[i][j].timeTaken)!='' && $scope.lowestCTimeTaken=='') {
              $scope.lowestCTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
              $scope.lowestCQNo = j+1;
            }else{
              if ($scope.lowestCTimeTaken>parseInt($scope.subjectWiseArray[i][j].timeTaken) ){
                $scope.lowestCTimeTaken=parseInt($scope.subjectWiseArray[i][j].timeTaken);
                $scope.lowestCQNo = j+1;
              }
            }
          }

         else if (($scope.subjectWiseArray[i][j].correctAnswer != $scope.subjectWiseArray[i][j].selectedAnswer) && $scope.subjectWiseArray[i][j].selectedAnswer.length > 0) {
          $scope.studentWrongAnswers++;
            $scope.subjectWrngGroup1++;
            $scope.subjectWrngGroupTT1 += parseInt($scope.subjectWiseArray[i][j].timeTaken);
            if ($scope.highestWTimeTaken < parseInt($scope.subjectWiseArray[i][j].timeTaken)) {
              $scope.highestWTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
                $scope.highestWQNo = j+1;
            }
            if (parseInt($scope.subjectWiseArray[i][j].timeTaken)!='' && $scope.lowestWTimeTaken=='') {
              $scope.lowestWTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
              $scope.lowestWQNo = j+1;
            }else{

              if ($scope.lowestWTimeTaken>parseInt($scope.subjectWiseArray[i][j].timeTaken)) {
                $scope.lowestWTimeTaken=parseInt($scope.subjectWiseArray[i][j].timeTaken);
                $scope.lowestWQNo = j+1;
              }
            }
      } else if ($scope.subjectWiseArray[i][j].style == "not_answered_div") {
          $scope.studentSkippedAnswers++;
            $scope.subjectSkipGroup1++;
            $scope.subjectSkipGroupTT1 += parseInt($scope.subjectWiseArray[i][j].timeTaken);
            if ($scope.highestSTimeTaken < parseInt($scope.subjectWiseArray[i][j].timeTaken)) {
              $scope.highestSTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
                $scope.highestSQNo = j+1;
            }

        if (parseInt($scope.subjectWiseArray[i][j].timeTaken)!='' && $scope.lowestSTimeTaken=='') {
          $scope.lowestSTimeTaken = parseInt($scope.subjectWiseArray[i][j].timeTaken);
          $scope.lowestSQNo = j+1;
        }else{
          if ($scope.lowestSTimeTaken>parseInt($scope.subjectWiseArray[i][j].timeTaken)) {
            $scope.lowestSTimeTaken=parseInt($scope.subjectWiseArray[i][j].timeTaken);
            $scope.lowestSQNo = j+1;
          }
        }
      }
      else if ($scope.subjectWiseArray[i][j].style == "not_visited_div") {
        // $scope.studentSkippedAnswers++;
          $scope.subjectNotVisitedGroup1++;
          $scope.subjectNotVisitedGroupTT1 += parseInt($scope.subjectWiseArray[i][j].timeTaken);
    }
  }
  console.log(parseInt($scope.subjectGroup1));
  console.log($scope.correctMarksValue);
      var groupValuesArr = {
        "subject":$scope.subjectGroupArray[i],
        "correctCount":[$scope.subjectGroup1,$scope.subjectGroupTT1,$scope.highestCTimeTaken,$scope.highestCQNo,$scope.lowestCTimeTaken,$scope.lowestCQNo],
        "wrongCount":[$scope.subjectWrngGroup1,$scope.subjectWrngGroupTT1,$scope.highestWTimeTaken,$scope.highestWQNo,$scope.lowestWTimeTaken,$scope.lowestWQNo],
        "skippedCount":[$scope.subjectSkipGroup1,$scope.subjectSkipGroupTT1,$scope.highestSTimeTaken,$scope.highestSQNo,$scope.lowestSTimeTaken,$scope.lowestSQNo],
        "notVisited":[$scope.subjectNotVisitedGroup1,$scope.subjectNotVisitedGroupTT1,0,0,0,0],
        "totalMarks":parseInt($scope.subjectGroup1)*parseInt($scope.correctMarksValue)-parseInt($scope.subjectWrngGroup1)*parseInt($scope.wrongMarksValue)
      }
      console.log(groupValuesArr);
      $scope.subjectGroupValidatedArr.push(groupValuesArr);

      $scope.subjectGroup1=0;
      $scope.subjectWrngGroup1=0;
      $scope.subjectSkipGroup1=0;
      $scope.subjectNotVisitedGroup1=0;
      $scope.studentCorrectAnswers=0;
      $scope.studentWrongAnswers=0;
      $scope.highestCTimeTaken=0;
      $scope.highestWTimeTaken=0;
      $scope.highestSTimeTaken=0;
      $scope.subjectGroupTT1=0;
      $scope.highestCQNo=0;
      $scope.lowestCTimeTaken=0;
      $scope.lowestCQNo=0;
      $scope.subjectWrngGroupTT1=0;
      $scope.highestWQNo=0;
      $scope.lowestWTimeTaken=0;
      $scope.lowestWQNo=0;
      $scope.subjectSkipGroupTT1=0;
      $scope.highestSTimeTaken=0;
      $scope.highestSQNo=0;
      $scope.lowestSTimeTaken=0;
      $scope.lowestSQNo=0;
      $scope.subjectNotVisitedGroupTT1=0;
      }
      console.log($scope.subjectGroupValidatedArr);
      $scope.selectedsubjectGroupValidated = $scope.subjectGroupValidatedArr[0];
      $scope.changeSubjectBoxStud($scope.selectedsubjectGroupValidated);
}

  $scope.subjectGroupArray = [];
    $scope.sortingDisplayOrderForQuestionArray = function(totalObj,orderObj){
  	  $scope.psColor = {
  		  'background-color': '#28C423',
  	  };
  	  $scope.medimColor = {
  		  'background-color': '#F99AA5',
  	  };
  	  $scope.dangColor = {
  		  'background-color': '#B5FFB3',
  	  };

      console.log(totalObj);
      console.log(orderObj);
      for(i=0;i<totalObj.length;i++) {
        for(j=0;j<orderObj.length;j++){
            if (totalObj[i].questionId == orderObj[j].questionId) {
              totalObj[i]["displayOrder"] = j+1;
              totalObj[i]["question"] = orderObj[j].question;
              totalObj[i]["option1"] = orderObj[j].option1;
              totalObj[i]["option2"] = orderObj[j].option2;
              totalObj[i]["option3"] = orderObj[j].option3;
              totalObj[i]["option4"] = orderObj[j].option4;
  			totalObj[i]["correctAnswer"] = orderObj[j].correctAnswer;
        totalObj[i]["questType"] = orderObj[j].questType;

        if(Math.round(totalObj[i].correctAnswerpercentage) == 100)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#059700'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 100 && Math.round(totalObj[i].correctAnswerpercentage) >= 90)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#0FAB09'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 90 && Math.round(totalObj[i].correctAnswerpercentage) >=80)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#0AAF04'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 80 && Math.round(totalObj[i].correctAnswerpercentage) >=70 )
        			{
        				totalObj[i]["selColor"] = {'background-color': '#28C423'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 70 && Math.round(totalObj[i].correctAnswerpercentage) >=60)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#55DF51'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 60 && Math.round(totalObj[i].correctAnswerpercentage) >=50)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#6FE66B'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 50 && Math.round(totalObj[i].correctAnswerpercentage) >=40)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#B5FFB3'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 40 && Math.round(totalObj[i].correctAnswerpercentage) >=30)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#F8CCD1'};
        			}
        			else if(Math.round(totalObj[i].correctAnswerpercentage) < 30 && Math.round(totalObj[i].correctAnswerpercentage) >=20)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#F8A8B1'};
        			}else if(Math.round(totalObj[i].correctAnswerpercentage) < 20 && Math.round(totalObj[i].correctAnswerpercentage) >=10)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#FA8F9B'};
        			}else if(Math.round(totalObj[i].correctAnswerpercentage) < 10 && Math.round(totalObj[i].correctAnswerpercentage) >= 0)
        			{
        				totalObj[i]["selColor"] = {'background-color': '#FA8F9B'};
        			}
      }
        }
        var status = $scope.subjectGroupArray.includes(totalObj[i].subjectGroup);
        if (status==false) {
            $scope.subjectGroupArray.push(totalObj[i].subjectGroup);
        }
      }

  	$scope.qusbSelTab = $scope.subjectGroupArray[0];
      $scope.questionList = totalObj;
      console.log(totalObj);
      $scope.assignselectedquesAnalysis(totalObj[0]);
      // $scope.getQuestionWiseTimeAnalysis(totalObj[0]);
      console.log($scope.questionList);
    }
    $scope.getseQuesDataDetails = {};
  	$scope.getseQuesData = function(ques){
  		$scope.getseQuesDataDetails = ques;
  		console.log($scope.getseQuesDataDetails);
  	}

  $scope.getQuestionWiseTimeAnalysis = function(question){
    console.log(question);
    httpFactory.getResult("getAdminQuestionTimeAnalysis?testId="+ $scope.testId + "&questionId="+question.questionId+ "&branchId="+$routeParams.brchId+"&schemaName="+$scope.schemaName, function(data) {
      console.log(data);
    if (data.StatusCode == 200) {
        $scope.quesDetailAnalysisObj = data;

        $scope.option1Count=0;
        $scope.option2Count=0;
        $scope.option3Count=0;
        $scope.option4Count=0;

      for(i=0;i<$scope.quesDetailAnalysisObj.optionPercentage.length;i++){
        if ($scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswer=="option1") {
          $scope.option1Count = $scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswercount;
        }
      else if ($scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswer=="option2") {

          $scope.option2Count = $scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswercount;
        }
        else if ($scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswer=="option3") {

            $scope.option3Count = $scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswercount;
          }
          else if ($scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswer=="option4") {
              $scope.option4Count = $scope.quesDetailAnalysisObj.optionPercentage[i].selectedAnswercount;
          }
        }
      }
    });
  }

    $scope.getSubjectChapterWiseTestAnalysis = function(){
      httpFactory.getResult("getSubjectChapterWiseTestAnalysis?testId="+ $scope.testId+"&schemaName="+$scope.schemaName, function(data) {
        console.log(data);
      if (data.length > 0) {
          $scope.topicWiseAnalyseData = data;
          console.log(data);
        }
      });
      $scope.topicChartData = [];
      $scope.tLabels = [];
      $scope.sOptions = {
        legend: {
          display: true,
          position: 'left'
        },

      };
      var avg = 0;
      var count = 0;
      for (i = 0; i < $scope.topicWiseAnalyseData.length; i++) {
        $scope.topicWiseAnalyseData.sort(function(a, b) {
          return b.correctAnswerpercentage - a.correctAnswerpercentage
        });
          avg += eval($scope.topicWiseAnalyseData[i].correctAnswerpercentage);
          count++;
        $scope.topicChartData[i] = Math.round(avg / count);
        $scope.tLabels[i] = $scope.topicWiseAnalyseData[i].topicName;
        $scope.topicChartData[$scope.topicChartData.length + 1] = 0;
      }
      $scope.tLabels = $scope.tLabels.filter( onlyUnique );
    }
    function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  $scope.redirectToResult = function(examData) {
    $location.path("/report/" + examData.testId + "/1");
  }
  var checkPDFCounter = 1;
  $scope.clearPDFCanvas = function() {
    var canvasElements = document.body.getElementsByTagName("canvas");

    for (var i = 0; i < canvasElements.length; i++) {
      if (canvasElements[i].childNodes.length == 0) {
        var parenCanvasNode = canvasElements[i].parentNode;
        parenCanvasNode.removeChild(canvasElements[i]);
        i--;
      } else {
        console.log(canvasElements[i]);
      }
    }
  }

  $scope.changeSubjectBox = function(sbj){
	$scope.qusbSelTab = sbj;
  console.log($scope.qusbSelTab);
  }

  $scope.changeSubjectBoxStudList = [];
  $scope.changeSubjectBoxStud = function(sbj){
  $scope.qusbSelTab = sbj;
  console.log($scope.qusbSelTab);
  for(var i=0; i<$scope.subjectWiseArray.length; i++){
    if(sbj == $scope.subjectWiseArray[i][0].subjectGroup){
      $scope.changeSubjectBoxStudList = $scope.subjectWiseArray[i];
      $scope.getseQuesDataDetails = $scope.changeSubjectBoxStudList[0];
      $scope.selectedsubjectGroupValidated = $scope.subjectGroupValidatedArr[i];
      console.log($scope.changeSubjectBoxStudList);
    }
  }
  $scope.subjMrks=0;
  for(var i=0;i<$scope.changeSubjectBoxStudList.length;i++){
    if($scope.changeSubjectBoxStudList[i].result){
    $scope.subjMrks+=Number($scope.changeSubjectBoxStudList[i].result);
  }
  }
  console.log($scope.subjMrks);
  }


  	$scope.makePDF = function(previewID, previewFilename)  {

      console.log(previewID);
      console.log(previewFilename);
		$("#divLoading").removeClass('hide').addClass('show');

    var pdf , PDF_Width, PDF_Height, HTML_Width, HTML_Height;
	  PDF_Width = $('#' + previewID + '').width();

      html2canvas($('#' + previewID + '')[0], { allowTaint: true }).then(function(canvas) {

  			HTML_Width = PDF_Width;
  			HTML_Height = $('#' + previewID + '').height();
  			var imgData = canvas.toDataURL("image/png", 1.0);
  			pdf = new jsPDF('p', 'pt', [PDF_Width, HTML_Height],true);
  			pdf.setPage(1);
  			pdf.addImage(imgData, 'JPG', 10, 10, HTML_Width, HTML_Height,'image1','FAST');
  				setTimeout(function() {

  					pdf.output('save',previewFilename+" results .pdf");
            $scope.clearPDFCanvas();
      			$("#divLoading").removeClass('show').addClass('hide');
  				},500);

        });
  		// document.getElementById("canvasDivID").removeChild(canvas);
       }

  $scope.makeAnalysisPDF = function(previewID, previewFilename) {

    $("#divLoading").removeClass('hide').addClass('show');
    var pdf , PDF_Width, PDF_Height, HTML_Width, HTML_Height;
	  PDF_Width = $('#' + previewID + '').width();

      html2canvas($('#' + previewID + '')[0], { allowTaint: true }).then(function(canvas) {

  			HTML_Width = PDF_Width;
  			HTML_Height = $('#' + previewID + '').height();
  			var imgData = canvas.toDataURL("image/png", 1.0);
  			pdf = new jsPDF('p', 'pt', [PDF_Width, HTML_Height],true);
  			pdf.setPage(1);
  			pdf.addImage(imgData, 'JPG', 10, 10, HTML_Width, HTML_Height,'image1','FAST');
  				setTimeout(function() {

  					pdf.output('save',previewFilename+" Analysis.pdf");

            $scope.clearPDFCanvas();
      			$("#divLoading").removeClass('show').addClass('hide');
  				},500);

        });

    // document.getElementById("canvasDivID").removeChild(canvas);
  }
  $scope.showStudentReview = function(studentObj, testId) {
    console.log(studentObj);
    console.log($scope.studentResult);

    var studentReviewObj = {
      "studentName":studentObj.studentName,
      "studentId":studentObj.studentId,
      "studentSection":studentObj.sectionName,
      "testId": $routeParams.testId,
      "percentage":studentObj.percentage
    }
    console.log(studentReviewObj);
    localStorage.setItem('studentReviewObj', JSON.stringify(studentReviewObj));
    $scope.urlString = window.location.href;
    console.log($scope.urlString);

    if($scope.urlString.includes("http") && $scope.urlString.includes("www")){
    	console.log("both");
    	$scope.protocolStr = "http://www."
    }else if($scope.urlString.includes("http")){
    	console.log("http");
    	$scope.protocolStr = "http://"

    }else if($scope.urlString.includes("www")){
    	console.log("www");
    	$scope.protocolStr = "www."

    }else{
    	console.log("nothing");
    	$scope.protocolStr = "http://"

    }
    window.open($scope.protocolStr+""+localStorage.getItem("domain")+"/module/html/learnHome.html#!/adminReport/", '_blank');
    // $("#reviewModalStudent").modal("show");
  }

  $scope.showExplanation = function(exp) {
    $("#reviewModal1").modal("hide");

    $scope.qExplanation = exp;
    console.log(exp);
    if (exp == "") {
      $scope.qExplanation = "<p>No Explanation Provided for this Question</p>";
    }
    $("#reviewModal1").modal("show");
  }

  $scope.propertyName = 'studenRollnumber';
	$scope.reverseOrd = false;
  $scope.sortByOrd = function(propertyName) {
    $scope.reverseOrd = ($scope.propertyName === propertyName) ? !$scope.reverseOrd : false;
    $scope.propertyName = propertyName;
  };

	$(function () {

    $('#studentsresultsTotal').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  });


  $scope.makePdfForExamAnalysis = function(tname){
    var previewFilename = tname;
    var pdf , PDF_Width, PDF_Height, HTML_Width, HTML_Height;
    PDF_Width = $("#analysisPdfContent").width();

    html2canvas($("#analysisPdfContent")[0], { allowTaint: true }).then(function(canvas) {

      HTML_Width = PDF_Width;
      HTML_Height = $("#analysisPdfContent").height();
      var imgData = canvas.toDataURL("image/png", 1.0);
      pdf = new jsPDF('p', 'pt', [PDF_Width, HTML_Height],true);
      pdf.setPage(1);
      pdf.addImage(imgData, 'JPG', 10, 10, HTML_Width, HTML_Height,'image1','FAST');


      setTimeout(function() {

          pdf.output('save',previewFilename+".pdf");

        },500);

   });
  }

});
