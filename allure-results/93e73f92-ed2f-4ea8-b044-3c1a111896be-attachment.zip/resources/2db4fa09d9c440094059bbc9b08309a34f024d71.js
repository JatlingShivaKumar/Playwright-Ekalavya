	'use strict';
	angular.module('commonFactory', []).factory(
	'commonFactory',
	function($http, $rootScope) {

	return {
		setDetails : setDetails,
        getBranchId : getBranchId,
        getCourseId : getCourseId,
        getClassId : getClassId,
		commonSuccessModal : commonSuccessModal,
	};

	// Func desc : Calls modal
	// Written by : Ak
	// Last updated by :
	function commonSuccessModal() {
		var htmlStr = "";
		htmlStr = '<div class="modal fade" id="courseClassSubAddModal"> ';
		htmlStr += '<div class="modal-dialog"> ';
		htmlStr += '<div class="modal-content"> ';
		htmlStr += '<div class="modal-header"> ';
		htmlStr += '<button type="button" class="close" data-dismiss="modal" aria-label="Close"> ';
		htmlStr += '<span aria-hidden="true">&times;</span></button> ';
		htmlStr += '<h4 class="modal-title">Title</h4> ';
		htmlStr += '</div> ';
		htmlStr += '<form role="form"> ';
		htmlStr += '<div class="modal-body"> ';
		htmlStr += '<div class="form-group"> ';
		htmlStr += '<p>Message</p> ';
		htmlStr += '</div> ';
		htmlStr += '</div> ';
		htmlStr += '<div class="modal-footer"> ';
		htmlStr += '<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button> ';
		htmlStr += '<button type="button" class="btn btn-primary">Save changes</button> ';
		htmlStr += '</div> ';
		htmlStr += '</form> ';
		htmlStr += '</div> ';
		htmlStr += '</div> ';
		htmlStr += '</div> ';

		$(".homeClass").modal("show");
	}

	var branchId = "";
	var courseId = "";
	var classId = "";
	function setDetails(branchId,courseId,classId){
		branchId = branchId;
		courseId = courseId;
		classId = classId;
	}
function getBranchId(){
		return branchId;
	}
	function getCourseId(){
		return courseId;
	}
	function getClassId(){
		return classId;
	}

	});
