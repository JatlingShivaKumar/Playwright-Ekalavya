projectModule.controller('boardSettingsController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;

	
	
	
//	board related services
	
	$scope.addBoard=function(){		
		if($scope.boardName){
			if($scope.boardName.trim().length>0){
		  var params = {
				    "boardName":$scope.boardName.trim(),
				    "boardDesc":"kdlfkdflk",
				    "schemaName":$scope.schemaName,
				    "isActive":0,
					"createdBy":$scope.userId
				  }
				  httpFactory.executePost("addBoardType", params, function(data) {
				    console.log(data);
				    if (data.StatusCode == "200") {
				    	$scope.boardName=undefined;
				    	$scope.getBoardTypes();
				    	alert("successfully added");
				      }
				  });
			}
			else{
				alert("Name cannot be spaces or blank");
			}	
		}
			else{
				
		alert("Enter all fields");
	}
	}
	
	$scope.addMedium=function(){		
		if($scope.mediumName){
			if($scope.mediumName.trim().length>0){
		  var params = {
				    "mediumName":$scope.mediumName.trim(),
				    "schemaName":$scope.schemaName,
				    "isActive":0,
					"createdBy":$scope.userId
				  }
				  httpFactory.executePost("addMedium", params, function(data) {
				    console.log(data);
				    if (data.StatusCode == "200") {
				    	$scope.mediumName=undefined;
				    	$scope.getMedium();
				    	alert("successfully added");
				      }
				  });
			}
			else{
				alert("Name cannot be spaces or blank");
			}	
		}
			else{
				
		alert("Enter all fields");
	}
	}
	
	
	$scope.addCourse=function(){	
		
		console.log($scope.courseName);
		
		if($scope.domainUrl=='localhost:9000'){
			$scope.courseOwner="rankr";
		}else{
			$scope.courseOwner=$scope.schemaName;
		}
		
		if($scope.courseName){
			if($scope.courseName.trim().length>0){
		  var params = {
				    "courseName":$scope.courseName.trim(),
				    "schemaName":$scope.schemaName,
				    "courseDesc":"MPC",
				    "courseOwner":$scope.courseOwner,
				    "isActive":0,
				    "isDefault":1,
					"createdBy":$scope.userId
				  }
				  httpFactory.executePost("addCourse", params, function(data) {
				    console.log(data);
				    if (data.StatusCode == "200") {
				    	$scope.courseName=undefined;
				    	$scope.getCourses();
				    	alert("successfully added");
				      }
				  });
			}
			else{
				alert("Name cannot be spaces or blank");
			}	
		}
			else{
				
		alert("Enter all fields");
	}
	}
	
	$scope.addClass=function(){		
		
		if($scope.domainUrl=='localhost:9000'){
			$scope.classOwner="rankr";
		}else{
			$scope.classOwner=$scope.schemaName;
		}
		
		if($scope.className){
			if($scope.className.trim().length>0){
		  var params = {
				    "className":$scope.className.trim(),
				    "schemaName":$scope.schemaName,
				    "classDesc":"X class",
				    "classOwner":$scope.classOwner,
				    "isActive":0,
					"createdBy":$scope.userId
				  }
				  httpFactory.executePost("addClass", params, function(data) {
				    console.log(data);
				    if (data.StatusCode == "200") {
				    	$scope.className=undefined;
				    	$scope.getClasses();
				    	alert("successfully added");
				      }
				  });
			}
			else{
				alert("Name cannot be spaces or blank");
			}	
		}
			else{
				
		alert("Enter all fields");
	}
	}
	
$scope.addSubjectDept=function(){			
		if($scope.subjectDeptName){
			if($scope.subjectDeptName.trim().length>0){
		  var params = {
				    "subjectDeptName":$scope.subjectDeptName.trim(),
				    "schemaName":$scope.schemaName,
				    "isActive":0,
					"createdBy":$scope.userId
				  }
				  httpFactory.executePost("addSubjectDept", params, function(data) {
				    console.log(data);
				    if (data.StatusCode == "200") {
				    	$scope.subjectDeptName=undefined;
				    	$scope.getSubjectDepartments();
				    	alert("successfully added");
				      }
				  });
			}
			else{
				alert("Name cannot be spaces or blank");
			}	
		}
			else{
		alert("Enter all fields");
	}
	}

$scope.addSubjects=function(){
	$scope.selDeptId=1;
	if($scope.subjectName){
		if($scope.subjectName.trim().length>0){
	  var params = {
			    "subjectName":$scope.subjectName.trim(),
			    "schemaName":$scope.schemaName,
			    "isActive":0,
				"createdBy":$scope.userId,
				"deptId":$scope.selDeptId,
				"subjectDesc":"Desc"
			  }
			  httpFactory.executePost("addSubjects", params, function(data) {
			    console.log(data);
			    if (data.StatusCode == "200") {
			    	$scope.subjectName=undefined;
			    	$scope.getSubjects();
			    	alert("successfully added");
			      }
			  });
		}
		else{
			alert("Name cannot be spaces or blank");
		}	
	}
		else{
	alert("Enter all fields");
}
}
	
	$scope.getBoardTypes=function(){
		httpFactory.getResult("getBoardTypes?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.boardList = data.boardTypes;
				console.log($scope.boardList);
				
			}
		});
	}
	
	$scope.getMedium=function(){
		httpFactory.getResult("getMedium?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.mediumList = data.mediumDetails;
				console.log($scope.boardList);
				
			}
		});	
	}
	
	$scope.getCourses=function(){
		httpFactory.getResult("getCourse?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.coursesList = data.courseDetails;
				console.log($scope.coursesList);
				
			}
		});	
	}
	
	$scope.getClasses=function(){
		httpFactory.getResult("getClasses?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.classesList = data.classDetails;
				console.log($scope.classesList);
				
			}
		});	
	}
	
	$scope.getSubjectDepartments=function(){
		httpFactory.getResult("getSubjectDept?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.subjectDeptList = data.subjectDepartments;
				console.log($scope.subjectDeptList);
			}
		});
	}
	
	$scope.getSubjects=function(){
		httpFactory.getResult("getSubjects?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.subjectList = data.subjects;
				console.log($scope.subjectList);	
			}
		});
	}
	
	$scope.getBoardCourses=function(){
		httpFactory.getResult("getBoardCourses?schemaName="+$scope.schemaName, function(data){
			if(data.StatusCode == "200"){
				$scope.boardDetailList = data.boardDetails;
				console.log($scope.boardDetailList);
				
			}
		});
	}
	
	$scope.getSelectedBoardDetails=function(board){
		console.log(board);
		
		$scope.selBoardDetail=board.mediumArray;
		console.log($scope.selBoardDetail);
	}
	
	$scope.selectMedium=function(medium){
		$scope.coursesOb=medium.mediumCourses;
		
		for(var i=0;i<$scope.coursesOb.length;i++){
			if($scope.coursesOb.boardCourseId==0){
				$scope.coursesOb["selected"]=false;
			}else{
				$scope.coursesOb["selected"]=true;
			}
		}
		
		
		$scope.selMediumId=medium.mediumId;
		console.log($scope.coursesOb);
	}
	
	$scope.selectCourseAssignment = function(courseId,classId,classCourseId,crsyr){
		console.log($scope.classCourseList);
		console.log(crsyr.checked);
		console.log(crsyr.checked);
		var isActStatus = 0;
		if(crsyr.selected == true){
			isActStatus = 1;
		}
		console.log(isActStatus);
		var obj = {
			"classId":classId,
	 		"courseId":courseId,
	 		"branchId":$scope.selectedBranchForMap.branchId,
	 		"isActive":isActStatus,
	 		"userId":localStorage.getItem("userId"),
	 		"classCourseId":classCourseId
		}
		console.log(obj);
		if ($scope.classCourseArr.length==0) {
			$scope.classCourseArr.push(obj);
		}else{
			// int k=1;
			for (i=0;i<$scope.classCourseArr.length;i++) {

	    if ($scope.classCourseArr[i].classId === classId && $scope.classCourseArr[i].courseId == courseId) {
				$scope.checkStatus=1;
				break;
	    }else{
			}
		}
		if ($scope.checkStatus == 1) {
			$scope.classCourseArr.splice(i,2);
		}else{
			$scope.classCourseArr.push(obj);
		}
	}
	}
	$scope.boardPopupMethod=function(){
		$scope.getBoardTypes();
	}
	$scope.mediumPopupMethod=function(){
		$scope.getMedium();
	}
	$scope.coursePopupMethod=function(){
		$scope.getCourses();
	}
	
	$scope.classPopupMethod=function(){
		$scope.getClasses();
	}
	
	$scope.subjectDepartmentsPopUpMethod=function(){		
	$scope.getSubjectDepartments();
	}
	
	$scope.addSubjectsPopUpMethod=function(){
		$scope.getSubjects();
	}

	$scope.redirectToBoardMeduimCourse=function(){
		$location.path("/boardbcmmap");
//		$scope.getBoardCourses();
	}
	
	
});