projectModule.controller('globalWhatsAppController', function ($scope, $location, commonFactory, httpFactory, $routeParams, $route, $sce, $compile) {
	$scope.$ = $;
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.roleId = localStorage.getItem("RD");

	$scope.goToMessaging = function () {
		$location.path("messaging");
	}

	$scope.getWhatsAppTemplates = function () {
		$scope.allWHTemplates = [];
		httpFactory.getResult("getWhatsAppTemplates?schemaName=" + $scope.schemaName + "&roleId=1", function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.allWHTemplates = data.whatsappTemplatesArray;
			} else {
				 alert(data.MESSAGE);
			}
		});
	}

	$scope.updateWhatsAppUserReqTemplateStatus = function (statusCode, whTemplateId, position) {
		if(statusCode != '' && statusCode != undefined && statusCode != null){
			var tempParams = {
				"schemaName": localStorage.getItem("sname"),
				"updatedBy": $scope.userId,
				"approveStatus": statusCode,
				"whTemplateId": whTemplateId
			};
	
			httpFactory.executePost("updateWhatsAppTemplateStatus", tempParams, function (data) {
				//console.log(data);
				if (data.StatusCode == 200) {
					alert(data.MESSAGE);
					if(statusCode == '1'){
						$scope.allWHTemplates[position].isApproved = 1;
					}else if(statusCode == '2'){
						$scope.allWHTemplates[position].isApproved = 2;
					}else{
						$scope.allWHTemplates[position].isApproved = 0;
					}
					// $scope.getAllWhatappTemplateDetails();
				} else {
					alert(data.MESSAGE);
				}
			});
		}

	}

});