projectModule.controller('hallTicketCreationController', function($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");

	$scope.allFeeCatglist =[];
	$scope.courseList = [];
	$scope.courseClasses = [];
	$scope.selectedCourseOb = {};
	$scope.selectedClassObj = {};
	$scope.selectedClass = "";

	$scope.getBranchDetails = function(){
		httpFactory.getResult("getBranchDetails?schemaName="+$scope.schemaName+"&branchId="+$scope.selectedBranch, function(data) {
			console.log(data);
			if (data.statusCode == 200) {
				$scope.branchData = data.data;
				$scope.branchDescription = "";
				$scope.branchAddress = $scope.branchData.branchAddress;
				$scope.branchContactNumber = $scope.branchData.branchContactNumber;
				$scope.branchName = $scope.branchData.branchName;
			}else{
				alert("Something Went Wrong");
			}
		});
	}
	
	$scope.getCoursesByBranch = function() {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedClassObj = {};
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName="+$scope.schemaName +"&branchId="+ $scope.selectedBranch , function(data) {
			console.log(data);
			if (data.StatusCode == 200){
				$scope.courseList = data.Courses;
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function() {
    	console.log($scope.selectedCourseOb);
		if($scope.selectedCourseOb == null){
			return true;
		}
    	$scope.selectedCourseOb = JSON.parse($scope.selectedCourseOb);
    	$scope.selectedCourse=$scope.selectedCourseOb.courseId;
    	$scope.selectedCourseName=$scope.selectedCourseOb.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName="+$scope.schemaName+"&branchId=" + $scope.selectedBranch + "&courseId="+$scope.selectedCourse, function(data) {
			console.log(data);
			if (data.StatusCode == 200){
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}
	
	$scope.getCoursesByBranch();
	
	$scope.getSectionByClass = function(selectedClassObj){
		if(typeof selectedClassObj === "string"){
			$scope.classObj = JSON.parse(selectedClassObj);
		}else{
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName="+$scope.schemaName+"&classCourseId="+$scope.classObj.classCourseId+"&branchId="+$scope.selectedBranch, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.sectionList = data.Sections;
			}
			else{
				alert("Got Error");
			}
		});
	}
	
	$scope.updateCrsClsSec = function(selectedSectionObj){
		if(typeof selectedSectionObj === "string"){
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		}else{
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}
	
	$scope.getStudentsBySection = function(){
    	httpFactory.getResult("selectStudentsBySection?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&sectionId=" + $scope.sectionId, function(data) {
            console.log(data);
            if (data.StatusCode == 200) {
            	$scope.showStudents = true;
                $scope.sectionStudents = data.sectionStudents;
            } else {

            }
        });
    }
	
	$scope.goToDashbord = function(){
		$location.path("hallticket");
	}

	$scope.addExaminationForHallticket = function(){
		$("#addNewFeeCategory").modal("show");
	}
	
	$scope.addColumnForSub = function(hallTicketId){
		var tempSub = {
				"subjectName" : "",
				"startTime" : "",
				"endTime" : "",
				"subjectDate" : ""
		}
		$scope.tempObj.push(tempSub);
	}
	
	$scope.addExamintionNameForHallTicket = function(){
		$scope.selectedCourseOb=JSON.parse($scope.selectedCourseOb);
		var params = {
				"schemaName":$scope.schemaName,
				"hallticketName":document.getElementById("examinationName").value,
				"courseId":$scope.selectedCourseOb.courseId,
				"createdBy":$scope.user_id,
				"branchId" : $scope.selectedBranch
		}
		console.log(params);
		httpFactory.executePost("addExamintionNameForHallTicket", params,function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert("added");
				$scope.getHallTicketName($scope.selectedCourseOb);
				$scope.hallTicketName='';
				$("#addNewFeeCategory").modal("hide");
			}else{
				alert("Got Error");
			}
		});
	}
	
	$scope.getHallTicketName = function(selectedCourseOb){
		$scope.selectedCourseObj= {};
		if(typeof selectedCourseOb === "string"){
			$scope.selectedCourseObj = JSON.parse(selectedCourseOb);
		}else{
			$scope.selectedCourseObj = selectedCourseOb;
		}
		httpFactory.getResult("getHallTicketName?schemaName=" + $scope.schemaName + "&courseId=" + $scope.selectedCourseObj.courseId + "&branchId= "+$scope.selectedBranch, function(data) { 
			console.log(data);
			delete $scope.selectedCourseObj.$$hashKey;
			$scope.selectedCourseObj = JSON.stringify($scope.selectedCourseObj);
			if (data.StatusCode == 200) {
				$scope.hallTicketList = data.hallTicketList;
				if($scope.hallTicketList.length == 0) {
					alert("Add Examination Name");
					return;
				}
				$scope.getSubjectsForHallTicket($scope.hallTicketList[0]);
			
			}else{
				$scope.hallTicketList=[];
			}
		});
	}

	$scope.deleteSubjectsForHallTicket = function(hallTicketSubId){
		$scope.hallTicketSubId = hallTicketSubId;
		var params = {
				"schemaName":$scope.schemaName,
				"hallTicketSubId":$scope.hallTicketSubId,
				"deletedBy":$scope.user_id
		}
		httpFactory.executePost("deleteSubjectsForHallTicket", params, function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert(data.MESSAGE);
				$scope.getSubjectsForHallTicket($scope.selectedHallTicket);
			}else if(data.StatusCode == 400){
				alert(data.MESSAGE);
			}
		});
	}
	
	$scope.addSubjectsForHallTicket = function(){
		if($scope.tempSubList.length > 0) {
			if($scope.tempObj.length == 0) {
				$scope.update = true;
				for(i=0;i<$scope.hallTicketSubjectList.length;i++) {
					if($scope.hallTicketSubjectList[i].subjectName != $scope.tempSubList[i].subjectName || ($scope.hallTicketSubjectList[i].startTime != $scope.tempSubList[i].startTime && $scope.hallTicketSubjectList[i].endTime != $scope.tempSubList[i].endTime) || $scope.hallTicketSubjectList[i].subjectDate != $scope.tempSubList[i].subjectDate) {
						$scope.tempObj.push($scope.hallTicketSubjectList[i]);
					}
					for(j=0;j<$scope.tempObj.length;j++) {
						if(($scope.tempObj[j].subjectName == "" || $scope.tempObj[j].subjectName == undefined) && ($scope.tempObj[j].startTime == "" || $scope.tempObj[j].startTime == undefined) && ($scope.tempObj[j].endTime == "" || $scope.tempObj[j].endTime == undefined)  && ($scope.tempObj[j].subjectDate != "" || $scope.tempObj[j].subjectDate != undefined))
						{
							alert("Enter the SubjectList");
							return true;
						}
						if($scope.tempObj[j].subjectName == "" || $scope.tempObj[j].subjectName == undefined) {
							alert("Enter the Subject");
							return true;
						}
						if($scope.tempObj[j].startTime == "" && $scope.tempObj[j].endTime == "") {	
							alert("Enter the Timing");
							return true;
						}
						if($scope.tempObj[j].subjectDate == "" || $scope.tempObj[j].subjectDate == undefined) {
							alert("Enter the SubjectDate");
							return true;
						}
						if(($scope.tempObj[j].startTime != "" && $scope.tempObj[j].startTime == $scope.hallTicketSubjectList[i].startTime) && ($scope.tempObj[j].endTime != "" && $scope.tempObj[j].endTime == $scope.hallTicketSubjectList[i].endTime)) {
							if(($scope.tempObj[j].startTime != "" && $scope.tempObj[j].startTime != $scope.tempSubList[i].startTime) && ($scope.tempObj[j].endTime != "" && $scope.tempObj[j].endTime != $scope.tempSubList[i].endTime)) {
								$scope.tempObj[j].startTime=$scope.tempObj[j].startTime.getHours() +":"+ $scope.tempObj[j].startTime.getMinutes();
								$scope.tempObj[j].endTime=$scope.tempObj[j].endTime.getHours() +":"+ $scope.tempObj[j].endTime.getMinutes();
							}
						}
						if(($scope.tempObj[j].subjectDate != "" || $scope.tempObj[j].subjectDate != undefined) && ($scope.hallTicketSubjectList[i].subjectDate == $scope.tempObj[j].subjectDate)) {
							if(($scope.tempObj[j].subjectDate != "" || $scope.tempObj[j].subjectDate != undefined) && ($scope.tempSubList[i].subjectDate != $scope.tempObj[j].subjectDate)){
								var date = new Date($scope.tempObj[j].subjectDate);
								var genMon = date.getMonth() + 1;
								if (genMon < 10) {
									genMon = "0" + genMon
								}
								$scope.tempObj[j].subjectDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
							}
						}
					}
				}if($scope.tempObj.length == 0) {
					alert("No new Subject Updated");
					return true;
				}
			}else if($scope.tempObj.length > 0) {
				$scope.update = false;
				for(i=0;i<$scope.tempObj.length;i++) {
					if(($scope.tempObj[i].subjectName == "" || $scope.tempObj[i].subjectName == undefined) && ($scope.tempObj[i].startTime == "" || $scope.tempObj[i].startTime == undefined) && ($scope.tempObj[i].endTime == "" || $scope.tempObj[i].endTime == undefined)  && ($scope.tempObj[i].subjectDate != "" || $scope.tempObj[i].subjectDate != undefined))
					{
						alert("Enter the SubjectList");
						return true;
					}
					if($scope.tempObj[i].subjectName == "" || $scope.tempObj[i].subjectName == undefined) {
						alert("Enter the Subject");
						return true;
					}
					if($scope.tempObj[i].startTime == "" && $scope.tempObj[i].endTime == "") {	
						alert("Enter the Timing");
						return true;
					}
					if($scope.tempObj[i].subjectDate == "" || $scope.tempObj[i].subjectDate == undefined) {
						alert("Enter the SubjectDate");
						return true;
					}
					if($scope.tempObj[i].startTime != ""  && $scope.tempObj[i].endTime != "" ) {
						$scope.tempObj[i].startTime=$scope.tempObj[i].startTime.getHours() +":"+ $scope.tempObj[i].startTime.getMinutes();
						$scope.tempObj[i].endTime=$scope.tempObj[i].endTime.getHours() +":"+ $scope.tempObj[i].endTime.getMinutes();
					}
					if($scope.tempObj[i].subjectDate != "" || $scope.tempObj[i].subjectDate != undefined){
						var date = new Date($scope.tempObj[i].subjectDate);
						var genMon = date.getMonth() + 1;
						if (genMon < 10) {
							genMon = "0" + genMon
						}
						$scope.tempObj[i].subjectDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
					}
				}
			}
		}else if($scope.tempObj.length > 0 && $scope.tempSubList.length == 0) {
			$scope.update = false;
			for(i=0;i<$scope.tempObj.length;i++) {
				if(($scope.tempObj[i].subjectName == "" || $scope.tempObj[i].subjectName == undefined) && ($scope.tempObj[i].startTime == "" || $scope.tempObj[i].startTime == undefined) && ($scope.tempObj[i].endTime == "" || $scope.tempObj[i].endTime == undefined)  && ($scope.tempObj[i].subjectDate != "" || $scope.tempObj[i].subjectDate != undefined))
				{
					alert("Enter the SubjectList");
					return true;
				}
				if($scope.tempObj[i].subjectName == "" || $scope.tempObj[i].subjectName == undefined) {
					alert("Enter the Subject");
					return true;
				}
				if($scope.tempObj[i].startTime == "" && $scope.tempObj[i].endTime == "") {	
					alert("Enter the Timing");
					return true;
				}
				if($scope.tempObj[i].subjectDate == "" || $scope.tempObj[i].subjectDate == undefined) {
					alert("Enter the SubjectDate");
					return true;
				}
				if($scope.tempObj[i].startTime != ""  && $scope.tempObj[i].endTime != "" ) {
					$scope.tempObj[i].startTime=$scope.tempObj[i].startTime.getHours() +":"+ $scope.tempObj[i].startTime.getMinutes();
					$scope.tempObj[i].endTime=$scope.tempObj[i].endTime.getHours() +":"+ $scope.tempObj[i].endTime.getMinutes();
				}
				if($scope.tempObj[i].subjectDate != "" || $scope.tempObj[i].subjectDate != undefined){
					var date = new Date($scope.tempObj[i].subjectDate);
					var genMon = date.getMonth() + 1;
					if (genMon < 10) {
						genMon = "0" + genMon
					}
					$scope.tempObj[i].subjectDate = date.getFullYear() + "-" + genMon + "-" + date.getDate();
				}
			}
		}else {
			alert("No new Subject Updated");
			return true;
		}
		var params = {
				"schemaName":$scope.schemaName,
				"hallTicketId":$scope.selectedHallTicket.hallTicketId,
				"subjectDetails"  : $scope.tempObj,
				"userId":$scope.user_id 
		}
		console.log(params);
		if($scope.update == true) {	
			$scope.tempObj = [];
		}
		httpFactory.executePost("addSubjectsForHallTicket", params,function(data){
			console.log(data);
			if(data.StatusCode == 200){
				alert("Successfully Added");
				$scope.tempSubList = [];
				$scope.getSubjectsForHallTicket($scope.selectedHallTicket);
				if($scope.update == false) {	
					$scope.getSubjectsForHallTicket($scope.selectedHallTicket);
				}
			}else if(data.StatusCode == 202) {
				alert(data.MESSAGE);
			}
			else{
				alert("Got Error");
			}
		});
	}
	
	$scope.hallTicketSubjectList=[];
	$scope.getSubjectsForHallTicket  = function(htList){
		$scope.selectedHallTicket = htList;
		httpFactory.getResult("getSubjectsForHallTicket?schemaName=" + $scope.schemaName + "&hallTicketId=" + $scope.selectedHallTicket.hallTicketId, function(data) { 
			console.log(data);
			$scope.tempObj = [];
			$scope.tempSubList = [];
			if(data.StatusCode == 200) {
				$scope.hallTicketSubjectList = data.hallTicketSubjectList;
				$scope.tempSubList = (angular.copy($scope.hallTicketSubjectList));
			   }else{
				$scope.hallTicketSubjectList=[];
			}
		});
	}
	
	$scope.getBranchDetailsForHalltickets = function(){
		httpFactory.getResult("getBranchDetailsForHalltickets?schemaName="+$scope.schemaName + "&branchId=" + $scope.selectedBranch, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.branchHallticketData = data.hallticketData;
				$scope.branchName= $scope.branchHallticketData.branchName;
				$scope.branchAddress= $scope.branchHallticketData.branchAddress;
				$scope.academicYear= $scope.branchHallticketData.academicYear;
				if($scope.branchHallticketData.principleSignature !== '') {
					$scope.principleSignature= (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+$scope.branchHallticketData.principleSignature;
				}else {
					$scope.principleSignature='';
				}
			}else {
				$scope.branchHallticketData = undefined;
				$scope.principleSignature='';
			}
		});
	}
	
	$scope.saveBranchDetailsForHallTicket = function(){
		var fd = new FormData();
		if(document.getElementById("branchName").value != undefined){
			fd.append("branchName", document.getElementById("branchName").value);
		}
		else{
			alert("Enter Branch Name")
			return true
		}
		if(document.getElementById("branchAddress").value != undefined){
			fd.append("branchAddress", document.getElementById("branchAddress").value);
		}
		else{
			alert("Enter Branch Address")
			return true
		}
		if(document.getElementById("academicYear").value != undefined){
			fd.append("academicYear", document.getElementById("academicYear").value);
		}
		else{
			alert("Enter acedamicYear")
			return true
		}
		if(document.getElementById("principleSignature").files.length != 0 || $scope.principleSignature !==''){
			var logo = document.getElementById("principleSignature").files;
			fd.append("principleSignature", logo[0]);
		}
		else if(document.getElementById("principleSignature").files.length == 0 || $scope.principleSignature ===''){
			alert("Upload Principle Signature");
			return true
		}
		if(document.getElementById("phoneNumber").value != undefined){
			fd.append("phoneNumber", document.getElementById("phoneNumber").value);
		}
		else{
			alert("Enter Phone Number")
			return true
		}
		if(document.getElementById("emailId").value != undefined){
			fd.append("emailId",  document.getElementById("emailId").value);
		}
		else{
			alert("Enter email id")
			return true
		}
		fd.append("branchId",$scope.selectedBranch);
		fd.append("createdBy",$scope.user_id);
		fd.append("schemaName",$scope.schemaName);
		httpFactory.executeFileUpload("saveBranchDetailsForHallTicket", fd, function(data) {
			console.log(data);
			if (data.StatusCode== '200') {
				alert("Details Updated Successfully");
				$("#addBranchDetails").modal("hide");
			}else{
				alert("Error while updating");
			}
		});
	}
	
	$scope.addBranchDetailsForHallTicket = function(){
		if($scope.branchHallticketData == undefined) {
			$("#addBranchDetails").modal("show");
			
		}else {
			if($scope.branchHallticketData != undefined) {
				$("#addBranchDetails").modal("show");
			}
		}
		$scope.getBranchDetailsForHalltickets();
	}

});
