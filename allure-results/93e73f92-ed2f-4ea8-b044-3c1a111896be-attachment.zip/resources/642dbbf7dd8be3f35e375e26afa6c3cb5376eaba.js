var projectModule = angular.module('rankrLoginModule', [ 'httpFactory' ]);

projectModule
		.controller(
				'loginController',
				function($scope, httpFactory, $location) {

					$scope.loginUser = loginUser;
					$scope.invalidLogin = false;
					$scope.staffIsActive = true;
					$scope.showDiv = true;
					$scope.loginStudent = loginStudent;
					$scope.showLogin = showLogin;
					$scope.showForgotPwd = showForgotPwd;
					$scope.requestForgotPwdAdmin = requestForgotPwdAdmin;
					$scope.requestForgotPwdStudent = requestForgotPwdStudent;

					$scope.alertFunction = alertFunction;
					alertFunction();
					function alertFunction() {
						var absUrl = $location.absUrl();
						var domain1;
						var res;

						if (absUrl.includes("www")) {
							domain1 = absUrl.split("www.", 2);

						} else {
							domain1 = absUrl.split("//", 2);
						}
						res = domain1[1].split("/", 2);
						var mainDomainName = res[0];
						var strImg = res[1];
						var domain = $location.host();
						var domainHost = location.host;
						localStorage.setItem("domain", mainDomainName);
						$scope.pathname = $location.url();
						var requestParams = {
							"domainName" : mainDomainName
						};

						console.log(requestParams);
						console.log(mainDomainName);
						httpFactory.getResult("getCollegeCode?domainName="
								+ mainDomainName, function(data) {
							console.log(data);
							var imageUrl = "/rankr/assets/bgImgs/logo.jpg";
							$(".logo-image").css("background-image", "url(" + imageUrl + ")");
                            localStorage.setItem("sname", data.schemaName);
							localStorage.setItem("collegeName",
									data.collegeName);
							localStorage.setItem("logo", data.logoImage);
							localStorage.setItem("bg", data.backgroundImage);
							localStorage.setItem("clr", data.color);
							$scope.backgroundColor = {	
								'background' : data.color
							};
							$scope.backgroundImage = "../assets/bgImgs/" + data.backgroundImage;
							$scope.beforeLogoImage = "../assets/bgImgs/" + data.beforeLogoImage;
							$scope.collegeNameForLogo = data.collegeName;
							
						});
						// }else{
						// $scope.logoImage = "../../assets/img/kjclogo.png";
						// }
					}

					$scope.admincall = function() {
						$scope.loginRole = "admin";
					}
					$scope.getLoginRole = function(role) {
						$scope.loginRole = role;
					}
					$scope.getLoginRole("student");

					$scope.genericLogin = function() {

						if ($scope.loginRole == 'student') {
							$scope.loginStudent();
						} else if ($scope.loginRole == 'staff') {
							$scope.loginUser();
						} else if ($scope.loginRole == 'parent') {
							$scope.loginUser();
						}
					}
					
					// Func Desc : Logins the user
					// Written by :
					// Last Modified by :
					function loginUser() {

						$scope.invalidLogin = false;
						var requestParams = {};
						requestParams["loginId"] = $scope.userName;
						requestParams["password"] = $scope.password;
						requestParams["schemaName"] = localStorage
								.getItem("sname");
						requestParams["source"] = "web login";
						
						httpFactory
								.executePost(
										"loginUser",
										requestParams,
										function(data) {
											if (data.StatusCode == 200) {
												$scope.userDetails = data;
												console.log($scope.userDetails);
												if (($scope.loginRole == 'staff' && $scope.userDetails.roleId == 3)
														|| ($scope.loginRole == 'parent' && $scope.userDetails.roleId == 4)
														|| ($scope.loginRole == 'admin' && $scope.userDetails.roleId == 1)
														|| ($scope.loginRole == 'admin' && $scope.userDetails.roleId == 2)) {
													// TODO : Redirect
													localStorage
															.setItem(
																	"userId",
																	$scope.userDetails.userId);
													localStorage
															.setItem(
																	"inst_id",
																	$scope.userDetails.instId);
													localStorage
															.setItem(
																	"RD",
																	$scope.userDetails.roleId);
													localStorage
															.setItem(
																	"bnchId",
																	$scope.userDetails.branch_id);
													localStorage
															.setItem(
																	"instName",
																	$scope.userDetails.instName);

													sessionStorage
															.setItem(
																	"userId",
																	$scope.userDetails.userId);
													sessionStorage
															.setItem(
																	"inst_id",
																	$scope.userDetails.instId);

													sessionStorage
															.setItem(
																	"RD",
																	$scope.userDetails.roleId);
													sessionStorage
															.setItem(
																	"bnchId",
																	$scope.userDetails.branch_id);
													localStorage
															.setItem(
																	"userName",
																	$scope.userDetails.userName);
													localStorage
															.setItem(
																	"branchName",
																	$scope.userDetails.branch_name);

													if ($scope.userDetails.roleId == 3) {
														localStorage
																.setItem(
																		"userName",
																		$scope.userDetails.userName);
														localStorage
																.setItem(
																		"TuserId",
																		$scope.userDetails.userId);

														localStorage
																.setItem(
																		"branchName",
																		$scope.userDetails.branch_name);
														window.location.href = "module/html/teacherDashboard.html#!/";
													} else if ($scope.userDetails.roleId == 4) {
														localStorage
																.setItem(
																		"PuserId",
																		$scope.userDetails.userId);
														localStorage
																.setItem(
																		"PRD",
																		$scope.userDetails.roleId);
														// localStorage.setItem("PuserId",
														// $scope.userDetails.userId);
														localStorage
																.setItem(
																		"PuserName",
																		$scope.userDetails.userName);
														localStorage
																.setItem(
																		"stuid",
																		$scope.userDetails.studentDetails[0].studentId);
														localStorage
																.setItem(
																		"stbrnchid",
																		$scope.userDetails.studentDetails[0].branchId);
														localStorage
																.setItem(
																		"stcrsid",
																		$scope.userDetails.studentDetails[0].courseId);
														localStorage
																.setItem(
																		"stsecid",
																		$scope.userDetails.studentDetails[0].classCourseSectionId);
														localStorage
																.setItem(
																		"stclsid",
																		$scope.userDetails.studentDetails[0].classId);
														localStorage
																.setItem(
																		"stclscrsid",
																		$scope.userDetails.studentDetails[0].classCourseId);
														localStorage
																.setItem(
																		"strole",
																		$scope.userDetails.studentDetails[0].role);
														localStorage
																.setItem(
																		"stnme",
																		$scope.userDetails.studentDetails[0].studentName);
														localStorage
																.setItem(
																		"stclsnme",
																		$scope.userDetails.studentDetails[0].className);
														localStorage
																.setItem(
																		"stcrsnme",
																		$scope.userDetails.studentDetails[0].courseName);
														localStorage
																.setItem(
																		"stsecnme",
																		$scope.userDetails.studentDetails[0].sectionName);
														localStorage
																.setItem(
																		"branchName",
																		$scope.userDetails.branch_name);
														localStorage
																.setItem(
																		"stUserProfilePic",
																		$scope.userDetails.studentDetails[0].profilePic);
														window.location.href = "module/html/parentdashboard.html#!/";
													} else {
														window.location.href = "module/html/learnHome.html#!/home";
													}
												} else {
													$scope.errorMsg = data.MESSAGE;
													$scope.invalidLogin = true;
												}
											}
											else if(data.StatusCode == 302){
												$scope.invalidLogin = true;
												$scope.errorMsg = "Your account is Disabled. Please contact your Admin"
												return;
											}
											else {
												$scope.invalidLogin = true;
												$scope.errorMsg = data.MESSAGE;
											}
										});
					}

					function loginStudent() {
						$scope.invalidLogin = false;
						var requestParams = {};
						requestParams["userId"] = $scope.userName;
						requestParams["password"] = $scope.password;
						requestParams["schemaName"] = localStorage
								.getItem("sname");
						requestParams["source"] = "web login";
						httpFactory
								.executePostLogin(
										"loginStudent",
										requestParams,
										function(data) {

											if (data.StatusCode == "200") {
												$scope.userDetails = data;
												console.log($scope.userDetails);
												$scope.rootVar = $scope.userDetails.StudentObj;
												//TODO : Redirect
												localStorage
														.setItem(
																"stuid",
																$scope.userDetails.StudentObj.studentId);
												localStorage
														.setItem(
																"stbrnchid",
																$scope.userDetails.StudentObj.branchId);
												localStorage
														.setItem(
																"stbrnchName",
																$scope.userDetails.StudentObj.branchName);
												localStorage
														.setItem(
																"stcrsid",
																$scope.userDetails.StudentObj.courseId);
												localStorage
														.setItem(
																"stsecid",
																$scope.userDetails.StudentObj.classCourseSectionId);
												localStorage
														.setItem(
																"stclsid",
																$scope.userDetails.StudentObj.classId);
												localStorage
														.setItem(
																"stclscrsid",
																$scope.userDetails.StudentObj.classCourseId);
												localStorage
														.setItem(
																"strole",
																$scope.userDetails.StudentObj.role);
												localStorage
														.setItem(
																"stnme",
																$scope.userDetails.StudentObj.studentName);
												localStorage
														.setItem(
																"stclsnme",
																$scope.userDetails.StudentObj.className);
												localStorage
														.setItem(
																"stcrsnme",
																$scope.userDetails.StudentObj.courseName);
												localStorage
														.setItem(
																"stsecnme",
																$scope.userDetails.StudentObj.sectionName);
												localStorage
														.setItem(
																"stProfilePic",
																$scope.userDetails.StudentObj.profilePic);
												localStorage
												.setItem(
														"inst_id",
														$scope.userDetails.StudentObj.instId);

												window.location.href = "module/html/studentdashboard.html";
											} else {
												//TODO : Show Error
												$scope.errorMsg = data.MESSAGE;
												$scope.invalidLogin = true;
											}
										});
					}

					function showLogin() {
						$scope.showDiv = true;
					}

					function showForgotPwd() {
						$scope.showDiv = false;
					}

					function requestForgotPwdAdmin() {
						//TODO : Send the below scope value in the Admin service
						//$scope.forgotAdminId
					}

					function requestForgotPwdStudent() {
						//TODO : Send the below scope value in the Student service
						//$scope.forgotStudentId
					}

				});
