projectModule.controller('adminStudentProfileController', function($scope, $location, $timeout, httpFactory, $window,$routeParams,$route) {
$scope.$ = $;
$scope.instituteId = 1;
$scope.Math = window.Math;
$scope.userId=localStorage.getItem("userId");
var requestParams = {
  "m_inst_id": $scope.instituteId
};
$scope.monthsArr=["January","February","March","April","May","June","July","August","September","October","November","December"];

$scope.schemaName=localStorage.getItem("sname");
$scope.sectionName=localStorage.getItem("stsecnme");
if ($routeParams.stuId) {
  $scope.studentId = $routeParams.stuId;
}else{
  $scope.studentId = localStorage.getItem("stuid");
}
$scope.studentProfileEdit = function(){
  $scope.studentDetailsById();
  $scope.getStudentOverallAttendance();
  $scope.getStudentPendingHomeWorkCount();
  $scope.getStudentHWSummary();
  //$scope.getStudentOverallHWForAnalysis();
  $scope.getStudentTestCountForAnalysis();
}
$scope.goToExamLogs=function(){
  $scope.examLogInit();
  $("#examLogsModal").modal("show");
//  $location.path("stuExmLog");
}
$scope.goToAttendance=function(){
  $scope.getTotalLeaveRequestsForStudent();
  $scope.getStudentAttendanceForAnalysis();
  $("#attendanceModal").modal("show");
}
$scope.goToHomework=function(){
    $("#pendingHomeworkModal").modal("hide");
	$scope.getCurrentAcademicYear();
//  $scope.getStudentHomesWorks();
  $scope.calToday();
  $scope.getStudentPendingHw();
//  $scope.getStudentPendingHw();
}
$scope.goToPendingHomework=function(){
//	$scope.getCurrentAcademicYear();
//  $scope.getStudentHomeWorks();
  $scope.getStudentPendingHw();
}
$scope.selectMonth=function(month){
	$scope.monthIndex=month.monthIndex;
	$scope.splitArr=month.monthName.split(" ");
	console.log($scope.splitArr);
	$scope.getStudentHomeWorks($scope.monthIndex,$scope.splitArr[1]);
}
$scope.getStudentPendingHw=function(){
	  httpFactory.getResult("getStudentPendingHW?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		    console.log(data);
		    if (data.StatusCode == 200) {
		    	$scope.pendingList=data.pendingHW;
		        //$("#pendingHomeworkModal").modal("show");
		    	console.log($scope.pendingList);
		        $scope.selectedPendingHomeWorkTypeList($scope.pendingList[0]);

		    } else {
//		      alert("Please try again!");
		    }
		  });

}
$scope.goToReportCard=function(){
  $scope.getInstTestGrades();
  $scope.getStudentReportCard();
  $("#reportCardsModal").modal("show");
}
$scope.resetStudentPassword=function(){
  httpFactory.getResult("resetStudentPassword?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName+"&userId="+$scope.userId, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
    	$("#resetStudentPassSMS").modal("show");
    } else {
      alert("Please try again!");
    }
  });
}

$scope.studentpath = "";
$scope.studentDetailsById = function(){
  httpFactory.getResult("studentDetailsById?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
		$scope.studentProfileData = data;
    $scope.classId = $scope.studentProfileData.classId;
    $scope.courseId = $scope.studentProfileData.courseId;
    $scope.sectionId = $scope.studentProfileData.courseId;
    $scope.studentPhoneNumber = $scope.studentProfileData.studentPhoneNumber;
    $scope.studentName = $scope.studentProfileData.studentName;
    $scope.admissionNumber = $scope.studentProfileData.admissionNumber;
    $scope.rollNumber = $scope.studentProfileData.rollNumber;
    $scope.loginName = $scope.studentProfileData.loginName;
    $scope.studentEmail = $scope.studentProfileData.studentEmail;
    $scope.homeAddress = $scope.studentProfileData.homeAddress;
    $scope.pincode = $scope.studentProfileData.pincode;
    $scope.gender = $scope.studentProfileData.gender;
    $scope.caste = $scope.studentProfileData.caste;
    $scope.subCaste = $scope.studentProfileData.subCaste;
    $scope.religion = $scope.studentProfileData.religion;
    $scope.motherTongue = $scope.studentProfileData.motherTongue;
    $scope.aadharNo = $scope.studentProfileData.aadharNo;
	$scope.mole = $scope.studentProfileData.mole;
    $scope.childId = $scope.studentProfileData.childId;
    $scope.govtChildId = $scope.studentProfileData.govtChildId;
    $scope.bankName = $scope.studentProfileData.bankName;
    $scope.bankAccNo = $scope.studentProfileData.bankAccNo;
    $scope.ifscCode = $scope.studentProfileData.ifscCode;
    $scope.joiningClassWithAccadamicYear = $scope.studentProfileData.joiningClassWithAccadamicYear;
    $scope.endingClassWithAccadamicYear = $scope.studentProfileData.endingClassWithAccadamicYear;
    
    $scope.parentName = $scope.studentProfileData.parentName;
    $scope.parentContact = $scope.studentProfileData.parentContact;
    $scope.parentemail = $scope.studentProfileData.parentEmail;
    $scope.parentAadhar = $scope.studentProfileData.parentAadhar;
    $scope.motherName = $scope.studentProfileData.motherName;
    $scope.motherContact = $scope.studentProfileData.motherContact;
    $scope.motherEmail = $scope.studentProfileData.motherEmail;
    $scope.motherAadhar = $scope.studentProfileData.motherAadhar;
    $scope.guardianName = $scope.studentProfileData.guardianName;
    $scope.guardianContact = $scope.studentProfileData.guardianContact;
    $scope.guardianEmail = $scope.studentProfileData.guardianEmail;
    $scope.guardianAadhar = $scope.studentProfileData.guardianAadhar;
    if($scope.studentProfileData.DOB == undefined){
    	$scope.DOB = "";
    }
    else{
    $scope.DOB = $scope.studentProfileData.DOB;
    }
    $scope.parentNumber = $scope.studentProfileData.contactNumber;
    $scope.parentEmail = $scope.studentProfileData.parentEmailId;
    $scope.studentpath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+$scope.studentProfileData.profilePic;
    console.log($scope.studentpath);
		} else {

		}
	});
}

$scope.changePwdModal=function(){
  $("#changePwdModal").modal("show");
}
$scope.changePassword=function(){
var params={
  "loginName":$scope.studentProfileData.loginName,
  "oldPassword":$scope.oldPwdVal,
  "newPassword":$scope.newPwdVal,
  "schemaName":$scope.schemaName,
  "updatedBy":localStorage.getItem("stuid")
}
  httpFactory.executePost("changeStudentPassword", params, function(data) {
		console.log(data);
	 if (data.STATUS == 'SUCCESS') {
		alert(data.MESSAGE);
		$("#changePwdModal").modal("hide");
	}
	else{
	}
});
}

$scope.uploadStudentProfile = function(){
  var files = document.getElementById("ProfileFile").files;
  if(files[0] == undefined){
    return true;
  }
  console.log(files);
  var fd = new FormData();

  fd.append("studentId", $scope.studentId);
  fd.append("admissionNo", $scope.studentProfileData.admissionNumber);
  fd.append("schemaName",$scope.schemaName)
  fd.append("file", files[0]);


  httpFactory.executeFileUpload("uploadStudentProfilePic", fd, function(data) {
    console.log(data);
    if (data.StatusCode==200) {
//      $route.reload();
    	  $scope.studentDetailsById();
    }else{
      alert("Please upload an image");
    }
    document.getElementById("ProfileFile").value = "";
  //	$scope.downLoadHw();
  });
}

$scope.downLoadHw = function(fPath){
  var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+fPath;
  $("#MyFrame").attr("src", path);
  //window.open("http://localhost:9000/HomeWorkFileDownLoad?filePath="+fPath)
}

$scope.getStudentOverallAttendance = function(){
  $scope.studentAttendance=[];
  httpFactory.getResult("getStudentOverallAttendance?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentAttendance = data;
        $scope.stuAtt = (($scope.studentAttendance.wokingDays - $scope.studentAttendance.studentLeaves)/$scope.studentAttendance.wokingDays)*100;
        $scope.presentDays = Number($scope.studentAttendance.attendanceTakenDays)-Number($scope.studentAttendance.studentLeaves);
        console.log($scope.presentDays);
        $scope.studentPresentPerc = (Number($scope.presentDays)/Number($scope.studentAttendance.attendanceTakenDays))*100;
        console.log($scope.studentPresentPerc);
		} else {
      $scope.studentAttendance=[];
		}
	});
}

$scope.getStudentOverallHWForAnalysis = function(){
  $scope.studentHomeWorks=[];
  httpFactory.getResult("getStudentOverallHWForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentHomeWorks = data;
        console.log($scope.studentHomeWorks);
		} else {
      $scope.studentHomeWorks=[];
      var obj = {
        "completedHW": 0,
        "pendingHW": 0,
        "totalHW": 0
      }
      $scope.studentHomeWorks=obj;
		}
	});
}
$scope.getStudentTestCountForAnalysis = function(){
  httpFactory.getResult("getStudentTestCountForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
        $scope.studentTests = data;
		} else {
      $scope.studentTests=[];
      var obj = {
        "testCompleted": 0
      }
      $scope.studentTests=obj;
		}
	});
}

$scope.getStudentPendingHomeWorkCount=function(){
  httpFactory.getResult("getStudentPendingHomeWorkCount?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.pendingHWCount = data;
    } else {
      // alert('No Branches Defined')
    }
  });
}

$scope.homeWorkSummaryTotal = {
  "completed":0,
  "pending":0,
  "total":0,
};
$scope.getStudentHWSummary=function(){
  httpFactory.getResult("getStudentHWSummary?studentId=" + $scope.studentId + "&schemaName=" + $scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.studentHWSummary = data.homeWorkSummary;

      for(var i=0; i<$scope.studentHWSummary.length; i++){
        $scope.homeWorkSummaryTotal.completed = $scope.homeWorkSummaryTotal.completed+$scope.studentHWSummary[i].submittedHW;
        $scope.homeWorkSummaryTotal.pending = $scope.homeWorkSummaryTotal.pending+$scope.studentHWSummary[i].pendingHW;
        $scope.homeWorkSummaryTotal.total = $scope.homeWorkSummaryTotal.total+$scope.studentHWSummary[i].totalHW;
      }
    } else {
      $scope.studentHWSummary = [{
        "submittedHW":0,
        "pendingHW":0,
        "totalHW":0
      }];
      $scope.homeWorkSummaryTotal = {
        "completed":0,
        "pending":0,
        "total":0,
      };
      // alert('No Branches Defined')
    }
  });
}


$scope.closePopUpHW = function(){
  $("#attendanceModal").modal("hide");
  $("#homeworkModal").modal("hide");
  $("#examLogsModal").modal("hide");
  $("#pendingHomeworkModal").modal("hide");

}


$scope.getStudentMonthWiseAttendanceDetails=function(){
  httpFactory.getResult("getStudentMonthWiseAttendanceDetails?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName+"&date="+$scope.selDate, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.stuMonthAttDetails = data.studentAttendance;
    }else{
      $scope.stuMonthAttDetails=[];
    }
  });
}
$scope.stuAttMonthClick=function(monthAtt){
  console.log(monthAtt);
  $scope.studentMonthAtt=monthAtt;
  $scope.studentPDays=parseInt($scope.studentMonthAtt.workingDays)-parseInt($scope.studentMonthAtt.absentCount);
  $scope.studentHolidays=parseInt($scope.studentMonthAtt.totalDays)-parseInt($scope.studentMonthAtt.workingDays);

  $scope.selDate= $scope.studentMonthAtt.MonthandYear +'-01';
  $scope.getStudentMonthWiseAttendanceDetails();
//  $scope.getTotalLeaveRequestsForStudent();
  console.log($scope.studentPDays);
}
$scope.getTotalLeaveRequestsForStudent=function(){
  httpFactory.getResult("getTotalLeaveRequestsForStudent?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.stuLeaveRequests = data.studentLeaveReqArray;
    }else{
    }
  });
}

$scope.getStudentAttendanceForAnalysis=function(){
  httpFactory.getResult("getStudentAttendanceForAnalysis?studentId="+$scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
    console.log(data);
    if (data.StatusCode == 200) {
      $scope.monthLables=[];
      $scope.absentlabels=[];
      $scope.lateLabels=[];
      $scope.lateCount=0;
      $scope.absentCount=0;
      $scope.studentAttAnalysis = data.studentAttendance;
      $scope.monthSel = $scope.studentAttAnalysis[$scope.studentAttAnalysis.length-1];
      for (var i = 0; i < $scope.studentAttAnalysis.length; i++) {
        $scope.monthLables.push($scope.studentAttAnalysis[i].MonthName);
        $scope.absentlabels.push($scope.studentAttAnalysis[i].absentCount);
        $scope.lateLabels.push($scope.studentAttAnalysis[i].lateCount);
        $scope.lateCount += Number($scope.studentAttAnalysis[i].lateCount);
        $scope.absentCount += Number($scope.studentAttAnalysis[i].absentCount);
      }
      console.log($scope.lateCount);
      console.log($scope.absentCount);
      console.log($scope.monthLables);
      console.log($scope.absentlabels);
      console.log($scope.lateLabels);
      $scope.lineChartData = {
            labels: $scope.monthLables,
            data : [
          $scope.absentlabels,
          $scope.lateLabels
        ]};
      $scope.stuAttMonthClick($scope.studentAttAnalysis[0]);
    }else{
      $scope.assignList=[];
    }
  });
}
$scope.closeHomework= function(){
  $("#homeworkModal").modal("hide");
}
$scope.selectedHomeWork = {};
$scope.todayHwDate = "";
$scope.yesterDayHwDate = "";
$scope.calToday = function(){
  var date = new Date();

	 monthId=date.getMonth()+1;
	 yearId=date.getFullYear();

  $scope.todayHwDate = yearId+"-"+monthId+"-"+date.getDate();
  if(date.getDate() == 1 || date.getDate() == "01"){

    if(date.getMonth() == 0){
      $scope.yesterDayHwDate = (yearId-1)+"-"+12+"-"+31;
    }else{
      var lastDay = new Date(date.getFullYear(), date.getMonth(), 0).getUTCDate();
      $scope.yesterDayHwDate = yearId+"-"+ date.getMonth()+"-"+lastDay;
    }

  }else{
    var yesdate = date.getDate()-1;
    if(yesdate < 10){
      yesdate = "0"+yesdate;
    }
    $scope.yesterDayHwDate = yearId+"-"+monthId+"-"+yesdate;
  }
  console.log($scope.todayHwDate);
  console.log($scope.yesterDayHwDate);
}
//$scope.calToday();
$scope.getStudentHomeWorks = function(monthId,yearId){
  var date = new Date();
  if(!monthId){
	 monthId=date.getMonth()+1;
	 yearId=date.getFullYear();
  }

  $scope.assignList=[];
  $scope.selectedHomeWorkDate="";
  httpFactory.getResult("getStudentHomeWorks?schemaName="+$scope.schemaName+"&studentId="+$scope.studentId+"&monthId="+monthId+"&yearId="+yearId, function(data) {
    console.log(data);
    if (data.StatusCode == 200){
      $scope.assignList = data.studentHomeWorkDetails;
      $scope.shwobj = {};
      $scope.selectedHomeWorkTypeList($scope.assignList[0]);

      console.log($scope.assignList);

    } else {
//      alert("No Homeworks assigned");
      console.log("No Homeworks assigned");
  //    $("#homeworkModal").modal("show");

    }
    $("#homeworkModal").modal("show");

  });
}

$scope.shwobj ;
$scope.selectedHomeWorkTypeList = function(shwob){
  console.log(shwob);
  $scope.shwobj = shwob;
  $scope.selectedHomeWorkDate = $scope.shwobj.HomeWorkDetails[0].HWdate;
  $scope.selectedHomeWork = $scope.shwobj.HomeWorkDetails[0].HomeWorkDetail[0];
  $scope.selectedHomeWorkId = $scope.shwobj.HomeWorkDetails[0].HomeWorkDetail[0].homeworkId;
  console.log($scope.shwobj);
}
$scope.pendingShwOb;
$scope.selectedPendingHomeWorkTypeList = function(pendingShwOb){
  console.log(pendingShwOb);
  $scope.pendingShwOb = pendingShwOb;
  $scope.selectedPendHomeWorkDate = $scope.pendingShwOb.HomeWorkDetails[0].HWdate;
  $scope.selectedPendHomeWork = $scope.pendingShwOb.HomeWorkDetails[0].HomeWorkDetail[0];
  $scope.pendingHomeWorkId = $scope.pendingShwOb.HomeWorkDetails[0].HomeWorkDetail[0].homeworkId;
}
$scope.selectedPendingHW = function(hwd,hw){
  $scope.pendingHomeWorkId = hw.homeworkId;
  $scope.selectedPendHomeWorkDate = hwd;
  $scope.selectedPendHomeWork = hw;
}

$scope.selectHomeWork =  function(hwd, hw){
  $scope.selectedHomeWorkId = hw.homeworkId;
  $scope.selectedHomeWorkDate = hwd;
  $scope.selectedHomeWork = hw;
}



$scope.closeReportCards = function(){
  $("#reportCardsModal").modal("hide");
}

$scope.getStudentReportCard = function(){
  var params= {
  "schemaName":$scope.schemaName,
  "courseId":$scope.courseId,
  "classId":$scope.classId,
  "sectionId":$scope.sectionId,
  "studentId":$scope.studentId
  }
  console.log(params);
  httpFactory.executePost("getStudentReportCard", params, function(data) {
  console.log(data);
  if (data.StatusCode == 200) {
      $scope.stuReportCard = data.studentReportCardDetails;

      for (var i = 0; i < $scope.stuReportCard.length; i++) {
        $scope.examTypeMarks=0;
        $scope.totalExamMarks=0;
        $scope.totalPercentage=0.0;
        for (var k = 0; k < $scope.stuReportCard[i].studentMarks.length; k++) {
          $scope.examTypeMarks+=Number($scope.stuReportCard[i].studentMarks[k].marks);
          $scope.totalExamMarks=(Number($scope.stuReportCard[i].totalMarks))*(Number($scope.stuReportCard[i].studentMarks.length));
        }
        $scope.totalPercentage = ($scope.examTypeMarks/$scope.totalExamMarks)*100;
        $scope.examGradeTotal = $scope.validateGrade($scope.totalPercentage);
        $scope.stuReportCard[i]["totalMarksSecured"]=$scope.examTypeMarks;
        $scope.stuReportCard[i]["totalExamTypeMarks"]=$scope.totalExamMarks;
        $scope.stuReportCard[i]["totalPercentage"]=$scope.totalPercentage;
        $scope.stuReportCard[i]["examGradeTotal"]=$scope.examGradeTotal;

        console.log($scope.examTypeMarks);
        console.log($scope.stuReportCard[i]);
      }

      $scope.creatingObject();
    }
  else{
    alert(data.MESSAGE);
    // alert("Please try agian after some time");
  }
  });

}
$scope.creatingObject=function(){
  $scope.instTestArr=[];
  $scope.instArr = [];
  $scope.instSubArr=[];
  $scope.instTermsArr=[];

  for (var i = 0; i < $scope.stuReportCard.length; i++) {
    if ($scope.instTermsArr.includes($scope.stuReportCard[i].termName)) {

    }else{
      $scope.instTermsArr.push($scope.stuReportCard[i].termName);
    }
  }
  for (var m = 0; m < $scope.instTermsArr.length; m++) {
    for (var i = 0; i < $scope.stuReportCard.length; i++) {
      if ($scope.instTermsArr[m] == $scope.stuReportCard[i].termName) {
          $scope.instArr.push($scope.stuReportCard[i]);
      }
    }
  var obj = {
      "term":$scope.instTermsArr[m],
      "tests":$scope.instArr
  }
$scope.instTestArr.push(obj);
$scope.instArr=[];
obj={};
}
console.log($scope.instTestArr);
$scope.termClick($scope.instTestArr[0])
}

$scope.termReport=[];
$scope.termClick=function(termOb){
  console.log(termOb);
  $scope.termReport=termOb.tests;
}

$scope.getInstTestGrades=function(){
  httpFactory.getResult("getInstGrades?schemaName="+$scope.schemaName, function(data) {
  console.log(data);
  if (data.StatusCode == 200) {
  $scope.instTestTypes = data.InstTestGrades;
  console.log($scope.instTestTypes);
  }
  });
}

$scope.validateGrade=function(perc){
	
	if($scope.instTestTypes){
	
    for(var i=0;i<$scope.instTestTypes.length;i++){
      console.log(perc);
      if (perc>=$scope.instTestTypes[i].gradeMarksPercenFrom && perc<=$scope.instTestTypes[i].gradeMarksPercenTo) {
        console.log($scope.instTestTypes[i].grade);
        return $scope.instTestTypes[i].grade;
      }
    }
	}
}
/* Student home work end*/



$scope.examLogInit=function(){
httpFactory.getResult("getStudentOnlineExamLogs?studentId="+ $scope.studentId+"&schemaName="+$scope.schemaName, function(data) {
  console.log(data);
  // alert("suresh section");
  if (data.StatusCode= 200) {
    //window.location.reload();
    $scope.stuExamLog = data.TestStudentArray;
  } else {
    // alert('No Branches Defined')
  }
});

}
$scope.roundedPercentage = function(myValue, totalValue){
   var result = ((myValue/totalValue)*100);
   return Math.round(result, 2);
}
$scope.Edit = false;
$scope.profileEdit=function(name,admissionNumber,rollno,loginname,email,studentPhoneNumber,homeadd,pin,dob,tag,gender,aadharNo,age,caste,subCaste,religion,motherTongue,mole,childId,govtChildId,bankName,bankAccNo,ifscCode,joiningClassWithAccadamicYear,endingClassWithAccadamicYear,pname,pnumber,pemail,parentAadhar,motherName,motherContact,motherEmail,motherAadhar,guardianName,guardianContact,guardianEmail,guardianAadhar){
	$scope.profileTag= name;
	$scope.profileTagpadmissionNumber = admissionNumber;
	$scope.profileTagprollno = rollno;
	
	$scope.profileTagloginname = loginname;
	$scope.profileTagemail = email;
	$scope.profileTagpno = studentPhoneNumber;
	$scope.profileTaghomeadd = homeadd;
	$scope.profileTagpin = pin;
	$scope.profileTagdob = dob;
	$scope.profileTaggender = gender;
	$scope.profileTagaadharNo = aadharNo;
	$scope.profileTagage = age;
	$scope.profileTagcaste = caste;
	$scope.profileTagsubCaste = subCaste;
	$scope.profileTagreligion = religion;
	$scope.profileTagmotherTongue = motherTongue;
	$scope.profileTagmole = mole;
	$scope.profileTagchildId = childId;
	$scope.profileTaggovtChildId = govtChildId;
	$scope.profileTagbankName = bankName;
	$scope.profileTagbankAccNo = bankAccNo;
	$scope.profileTagifscCode = ifscCode;
	$scope.profileTagjoiningClassWithAccadamicYear = joiningClassWithAccadamicYear;
	$scope.profileTagendingClassWithAccadamicYear = endingClassWithAccadamicYear;
	$scope.profileTagpname = pname;
	$scope.profileTagpcn=pnumber;
	$scope.profileTagpemail = pemail;
	$scope.profileTagparentAadhar = parentAadhar;
	$scope.profileTagmotherName = motherName;
	$scope.profileTagmotherContact = motherContact;
	$scope.profileTagmotherEmail = motherEmail;
	$scope.profileTagmotherAadhar = motherAadhar;
	$scope.profileTagguardianName = guardianName;
	$scope.profileTagguardianContact = guardianContact;
	$scope.profileTagguardianEmail = guardianEmail;
	$scope.profileTagguardianAadhar = guardianAadhar;
	$scope.Edit = true;
	if($scope.parentNumber[0] == 9 || $scope.parentNumber[0] == 8 || $scope.parentNumber[0] == 7 || $scope.parentNumber[0] == 6) {
		$scope.profileTagpcn = pnumber;
		$scope.isEdit = false
	}else{
		$scope.profileTagpcn = pnumber;
		$scope.isEdit = true;
	}
	//$scope.profileTagpemail = pemail;
	//$scope.Edit = true;
	/*var profileTag ={
		  "studentName":$scope.studentName;
		  "studentEmail"$scope.studentEmail;
  }*/
	var params={
			"schemaName":$scope.schemaName,
			"studentId":$scope.studentId,
			"updatedBy":$scope.userId
	}
	if (tag=='student') {
		params["studentName"]=$scope.studentName;
		params["parentName"]=$scope.parentName;
		params["rollNumber"]=$scope.rollNumber;
		params["loginName"]=$scope.loginName;
		params["studentEmail"]=$scope.studentEmail;
		params["studentPhoneNumber"]=$scope.studentPhoneNumber;
		params["homeAddress"]=$scope.homeAddress;
		params["pincode"]=$scope.pincode;
		params["DOB"]=$scope.DOB;
		params["gender"]=$scope.gender;
		params["parentNumber"]=$scope.parentNumber;
		params["parentEmail"]=$scope.parentEmail;
	}
	console.log(params);
}


$scope.editDetails = function () {
  var params = {
      "branchId": localStorage.getItem('bnchId'),
      "schemaName": $scope.schemaName,
      "studentList": [{
          "studentId": $scope.studentId,
      }]
  };

  var fieldsToCheck = [
      "studentName",
      "phoneNumber",
      "studentAdmissionNumber",
      "rollNumber",
      "homeAddress",
      "pincode",
      "DOB",
      "studentEmail",
      "gender",
      "caste",
      "subCaste",
      "religion",
      "motherTongue",
      "aadharNo",
      "mole",
      "childId",
      "govtChildId",
      "bankName",
      "bankAccNo",
      "ifscCode",
      "joiningClassWithAccadamicYear",
      "endingClassWithAccadamicYear",
      "parentName",
      "parentContact",
      "parentEmail",
      "parentAadhar",
      "motherName",
      "motherContact",
      "motherEmail",
      "motherAadhar",
      "guardianName",
      "guardianContact",
      "guardianEmail",
      "guardianAadhar"
  ];

  fieldsToCheck.forEach(function (field) {
      var element = document.getElementById(field);
      if (element && element.value != "" && $scope[field] != element.value) {
          params.studentList[0][field] = element.value;
      }
  });

  if (Object.keys(params.studentList[0]).length > 1) {
      httpFactory.executePost("updateStudentDetails", params, function (data) {
          console.log(data);
          if (data.StatusCode == 200) {
              alert("Details Updated Successfully");
              $scope.studentProfileEdit();
          } else if (data.StatusCode == 300) {
              alert(data.MESSAGE);
              $scope.studentProfileEdit();
          } else {
              alert("Something went wrong");
          }
      });
  } else {
      alert("Nothing Changed");
  }
}

$scope.secondsTohhmmss = function(totalSeconds) {
  console.log(totalSeconds);
  var hours   = Math.floor(totalSeconds / 3600);
  var minutes = Math.floor((totalSeconds - (hours * 3600)) / 60);
  var seconds = totalSeconds - (hours * 3600) - (minutes * 60);

  // round seconds
  seconds = Math.round(seconds * 100) / 100

  var result = (hours < 10 ? "0" + hours : hours);
      result += ":" + (minutes < 10 ? "0" + minutes : minutes);
      result += ":" + (seconds  < 10 ? "0" + seconds : seconds);
  return result;
}
$scope.getCurrentAcademicYear=function(){

	httpFactory.getResult("getCurrentAcademicYear?schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {

  		var startArr = data.startDate.split("-");
  		var endArr = data.endDate.split("-");

  		console.log(startArr);
  		console.log(endArr);
  		console.log(parseInt(startArr[1]));

  		console.log($scope.monthsArr[parseInt(startArr[1])]);

  		var str1 = $scope.monthsArr[parseInt(startArr[1])]+" "+startArr[0];
  		var str2 = $scope.monthsArr[parseInt(endArr[1])]+" "+endArr[0];
  		console.log(diff(str1, str2));
  		$scope.academicMonthArr=diff(str1,str2);
  		console.log($scope.academicMonthArr);
      var thisDate = new Date();
      for(var i=0; i<$scope.academicMonthArr.length; i++){
        if((thisDate.getMonth()+1) == $scope.academicMonthArr[i].monthIndex){
          $scope.selectMonObj = $scope.academicMonthArr[i];
          $scope.selectMonth($scope.selectMonObj);
          break;
        }
      }
		}else{

		}
	});
}


function diff(from, to) {
    var arr = [];
    var datFrom = new Date('1 ' + from);
    var datTo = new Date('1 ' + to);
    var fromYear =  datFrom.getFullYear();
    var toYear =  datTo.getFullYear();
    var diffYear = (12 * (toYear - fromYear)) + datTo.getMonth();

    for (var i = datFrom.getMonth(); i <= diffYear; i++) {
    	console.log(i);
    	if(i>11)
    		$scope.index=i-12;
    	else
    	$scope.index=i;

    	var params= {
    			"monthName":$scope.monthsArr[i%12] + " " + Math.floor(fromYear+(i/12)),
    			"monthIndex":$scope.index+1,
    	}
        arr.push(params);
    }

    return arr;
}

$scope.sendStudentNewPassSMS = function(){
	var sendxel = {
			messages: [],
			schemaName : localStorage.getItem("sname"),
			templateId : "1207161596251733453"
	}
		if($scope.studentPhone.length == 10){
			var tmpmsg = "Dear "+$scope.studentName +" EkaLavya is offering your New Password. To avail the services, please contact ekalavya.online at New Password: Welcome123$";
			sendxel.messages.push({
				"numbers":$scope.studentPhone,
				"message":tmpmsg
			})
		}else{
			alert("Student doesn't have phone Number");
			return;
		}
	httpFactory.executePost("sendSMSFromExcel", sendxel, function(data) {
		console.log(data);
		if(data.StatusCode == 200){
			alert("SMS Sent Successfully");
			$("#resetStudentPassSMS").modal("hide");
		}else{
			alert("Something went wrong");
		}

	});
} 


});
