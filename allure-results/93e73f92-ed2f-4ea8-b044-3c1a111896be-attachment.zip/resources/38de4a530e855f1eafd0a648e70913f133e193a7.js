projectModule.controller('editTestController', function($scope, $location, $timeout, $routeParams, commonFactory, httpFactory) {
 $scope.$ = $;
 $scope.instituteId = localStorage.getItem("inst_id");
 $scope.branchList = [];
 $scope.user_id = localStorage.getItem("userId");
$scope.editTestId=$routeParams.testId;
 var requestParams = {
   "m_inst_id": $scope.instituteId
 };

 $scope.generate = false;
 $scope.configComplete = true;
 $scope.showPreview = true;
 $scope.assignArr=[];
 //
 // if ($routeParams.courseId) {
 //   $scope.selectedCourse=$routeParams.courseId;
 // }

$scope.editTestInit=function() {
  $scope.getTestInfo();
  $scope.getTestSectionQuestion();
  $scope.getQuestionTypesService();
  $scope.getTestCategories();
  $scope.getCustomTestDetails();
}
 $scope.getBranchCourseClassSections = function(){
   httpFactory.getResult("getAllBranchClassCourseSections?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id"), function(data) {
 		console.log(data);
 		if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
 			// $scope.academicList = data.Classes;
       $scope.brnchSections=data.collegesInfo;
       console.log($scope.brnchSections);
 		}
 		 else {
 		}
 	});
 }

 $scope.getBranchCourseClassSectionsForTest = function(){
   httpFactory.getResult("getBranchCourseClassSectionsForTest?schemaName="+localStorage.getItem("sname")+"&instId="+localStorage.getItem("inst_id")+"&roleId="+localStorage.getItem("RD")+"&branchId="+localStorage.getItem("bnchId")+"&testId="+$routeParams.testId, function(data) {
 		console.log(data);
 		if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
 			// $scope.academicList = data.Classes;
       $scope.brnchSections=data.testSectionsObj;
       console.log($scope.brnchSections);
 		}
 		 else {
 		}
 	});
 }
 $scope.getTestSectionQuestion=function(){
     httpFactory.getResult("getTestSectionQuestion?testId=" + $routeParams.testId + "&schemaName="+localStorage.getItem("sname"), function(data) {
       console.log(data);
       if (data.StatusCode==200) {
         $scope.testSections=data.TestSectionQuestMarks;
        // $scope.studentId=$routeParams.sid;
       } else {
          // alert("Test sections unavailable");
       }
     });
   }
   $scope.getQuestionTypesService = function(){
     httpFactory.getResult("getQuestionTypes?schemaName="+$scope.schemaName, function(data) {
       console.log(data);
       if (data.StatusCode == 200) {
         $scope.questionTypeList = data.questionsArray;
       } else {
         // alert('No Courses Defined. ');
       }
     });
   }

   $scope.getTestCategories = function() {
 	  $scope.selectedCategory = "";
 	  $scope.subjectList =[];
 	  if($scope.courseList != undefined){
	 	  for(var i = 0;i <  $scope.courseList.length;i++){
	 		   if($scope.courseList[i].courseId == $scope.selectedCourse){
	 			   $scope.courseName = $scope.courseList[i].courseName;
	 		   }
	 	   }
 	  }
      httpFactory.getResult("getTestCategories?instId=" + localStorage.getItem("inst_id") + "&schemaName="+$scope.schemaName +"&courseId=" + $scope.selectedCourse, function(data) {
       console.log(data);
       if (data.STATUS == 'SUCCESS') {
         $scope.categoryList = data.TestCategories;
         console.log($scope.categoryList);
       }
     });
   }

 $scope.getContentOwner = function(){
   console.log($scope.selectedSchemaOb);
   httpFactory.getResult("selectContentOwner?schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       if ($scope.selInstCrs) {
         $scope.courseId=$scope.selInstCrs;
       }
       $scope.contentOwnerList=[];
       $scope.contentList = data.ContentOwner;
       console.log($scope.contentList);
       for (var i = 0; i < $scope.contentList.length; i++) {
         if ($scope.contentList[i].courseId == $scope.selectedCourse || $scope.contentList[i].courseId == 0) {
           $scope.contentOwnerList.push($scope.contentList[i]);
         }
       }
         console.log($scope.contentOwnerList);
     } else {
       console.log("No ContentList");
     }
   });
 }

 $scope.getSchemaContentOwner = function(){
   httpFactory.getResult("getSchemaContentOwner?schemaName="+$scope.schemaName, function(data) {
     console.log(data);
     if (data.StatusCode == 200) {
       $scope.schemaContent=[];
       $scope.schemaContent = data.schemaContent;
       console.log($scope.schemaContent);
       }
     else {
       console.log("No ContentList");
     }
   });
 }

 // $scope.getQuestionTypesService = function(){
 //   httpFactory.getResult("getQuestionTypes?schemaName="+$scope.schemaName, function(data) {
 //     console.log(data);
 //     if (data.StatusCode == 200) {
 //       $scope.questionTypeList = data.questionsArray;
 //     } else {
 //       // alert('No Courses Defined. ');
 //     }
 //   });
 // }
 // $scope.getQuestionTypesService();
 // $scope.getTestSectionQuestion=function(){
 //     httpFactory.getResult("getTestSectionQuestion?testId=" + $routeParams.testId + "&schemaName="+localStorage.getItem("sname"), function(data) {
 //       console.log(data);
 //       if (data.StatusCode==200) {
 //         $scope.testSections=data.TestSectionQuestMarks;
 //        // $scope.studentId=$routeParams.sid;
 //       } else {
 //          alert("Test sections unavailable");
 //       }
 //     });
 //   }
 //   $scope.getTestSectionQuestion();

 $scope.manualGenerationViewLoad = function(){
   // $scope.getSchemas();
 }
 $scope.totalTestQuesObj =[];
   $scope.getTestQuestions = function() {
     httpFactory.getResult("getTestQuestions?schemaName="+localStorage.getItem("sname") +"&testId="+ $routeParams.testId , function(data) {
       if (data.StatusCode == 200) {
         $scope.totalTestQuesObj = [];
         $scope.questionList=[];
           $scope.questionList = data.testQuestions;
           console.log($scope.questionList);
           if ($scope.testInfo.testCreationType == "AGT") {
             $scope.uniqueSubjectsMethodForAutoGenerate();
           }
       $scope.generateQuestionObj();
     }
       else if (data.StatusCode == 300){
         $scope.questionList=[];
         $scope.totalTestQuesObj=[];
         for(i=0;i<$scope.manualTestDetails.length;i++){
           for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions); j++){
           $scope.emptyObj=[];
           var quesObj = {
             'subjectName':$scope.manualTestDetails[i].subjectName,
             'questionIndex':j+1,
             'question':''
           }
             $scope.totalTestQuesObj.push(quesObj);
         }
     }
   }
       else {
 		console.log("Error Occured!");
       }
     });
   }

   $scope.uniqueSubjectsMethodForAutoGenerate = function(){
     $scope.subjArr = [];
     $scope.counter = 0;
     $scope.indexVal=0;
     for (var i = 0; i < $scope.questionList.length; i++) {
       if ($scope.subjArr.length==0) {
         var obj ={
           "subjectName":$scope.questionList[i].subjectName,
           "questionCount":0
         }
         $scope.subjArr.push(obj);
       }else{
          if ($scope.subjArr[$scope.indexVal].subjectName != $scope.questionList[i].subjectName) {
            $scope.subjArr[$scope.indexVal].questionCount=$scope.counter+1;
            $scope.counter=0;
            var obj ={
              "subjectName":$scope.questionList[i].subjectName,
              "questionCount":0
            }
            $scope.subjArr.push(obj);
              $scope.indexVal++;
          }else{
            if(i+1==$scope.questionList.length){
              $scope.subjArr[$scope.indexVal].questionCount=$scope.counter+1;

            }
            $scope.counter++;
          }
       }
     }
     console.log($scope.subjArr);
     $scope.manualTestDetails=$scope.subjArr;
     console.log($scope.manualTestDetails);
   }

   $scope.generateQuestionObj = function() {
       var quesObj;
       var count = 0;
       $scope.totalTestQuesObj=$scope.questionList.slice(0);
       console.log($scope.totalTestQuesObj);
       $scope.selQCount=0;
       for(i=0;i<$scope.manualTestDetails.length;i++){
    	   $scope.selQCount= $scope.selQCount+(Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount));
         console.log($scope.manualTestDetails[i].TotalQuestions);
         console.log($scope.manualTestDetails[i].selectedQuestionCount);

         for(var j=0; j<Number($scope.manualTestDetails[i].TotalQuestions) - Number($scope.manualTestDetails[i].selectedQuestionCount); j++){
         $scope.emptyObj=[];
          quesObj = {
           'subjectName':$scope.manualTestDetails[i].subjectName,
           'questionIndex':j+1,
           'question':''
         }
         $scope.totalTestQuesObj.push(quesObj);
       }
        console.log($scope.totalTestQuesObj);
     }
   }

   $scope.getCustomTestDetails = function() {
     httpFactory.getResult("getCustomTestDetails?schemaName="+localStorage.getItem("sname") +"&testId="+$routeParams.testId , function(data) {
       console.log(data);
       if (data.StatusCode == 200){
         $scope.totalTestQuestions = 0;
           $scope.manualTestDetails = data.TestDetails;
           for(i=0;i<$scope.manualTestDetails.length;i++){
             $scope.totalTestQuestions += parseInt($scope.manualTestDetails[i].TotalQuestions);
           }
           $scope.selectedCourse=$scope.manualTestDetails[0].courseId;
         

           $scope.getTestQuestions();
       } else {
     console.log("Error Occured!");
       }
     });
   }

   $scope.getTestInfo = function() {
     httpFactory.getResult("getTestInfo?schemaName="+localStorage.getItem("sname") +"&testId="+$routeParams.testId , function(data) {
       console.log(data);
       if (data.StatusCode == 200){
           $scope.testInfo = data;
           $scope.totalnumQuestions = $scope.testInfo.totalQuestions;
           $scope.courseName=$scope.testInfo.courseName;
           if ($scope.testInfo.testCreationType=="AGT") {
             $scope.getTestQuestions();

           }else if($scope.testInfo.testCreationType=="CGT"){
             $scope.getCustomTestDetails();
             $scope.getCustomTestDetails();
             $scope.getTestQuestions();
           }
       } else {
    	   console.log("Error Occured!");
       }
     });
   }

   $scope.checkTestType = function(){
     if($scope.testInfo.testCreationType == 'cgt' || $scope.totalnumQuestions == 'CGT' ){
           if($scope.totalnumQuestions > $scope.questionList.length){
          alert("Please add all questions");
        }else{
      $location.path("publishTest/"+$scope.testInfo.testId+"/"+$scope.testInfo.branchId+"/publish");
   }
   }else if($scope.testInfo.testCreationType == 'AGT'){
     if($scope.totalnumQuestions >= $scope.questionList.length && $scope.questionList.length>0){
       $location.path("publishTest/"+$scope.testInfo.testId+"/"+$scope.testInfo.branchId+"/publish");
     }else{
       $location.path("autoGenerateExamView");
     }
   }else {
     if ($scope.totalnumQuestions.length > $scope.questionList.length) {
       alert("question need to add");
     }else{
       $location.path("publishTest/"+$scope.testInfo.testId+"/"+$scope.testInfo.branchId+"/publish");
     }
    }
   }
   $scope.continueToSelectView = function(){
     localStorage.setItem("cgTestId",$scope.testInfo.testId );
     localStorage.setItem("cgTestSelQB",'CEDZ');
     localStorage.setItem("cgTestName",$scope.testInfo.testName );
     localStorage.setItem("cgTestContentType",$scope.manualTestDetails[0].testContentType);
     $location.path("customSelect");
   }

   //getdynamic schemas
  //  $scope.getSchemas = function() {
 	//   $scope.selectedSchema = "";
 	// $scope.selectedCategory = "";
 	// $scope.subjectList =[];
  //    httpFactory.getResult("selectContentOwner?schemaName="+localStorage.getItem("sname"), function(data) {
 	// 	if (data.StatusCode == 200) {
 	// 		$scope.schemaObject = data.ContentOwner;
 	// 	} else {
 	// 		// alert('No Courses Defined. ');
 	// 	}
  //    });
  //  }
$scope.addQuesMethod = function(){
  $scope.getSchemaContentOwner();
}
$scope.schemaChange = function(){
  // $scope.getTestCategories();
}

$scope.contentOwnerChanged = function(){
  // $scope.getTestCategories();
}
   $scope.selectedGroupSubj ="";
   $scope.showQuesbjWise = function(sbj){
     console.log(sbj);
   	$scope.selectedGroupSubj = sbj;
    console.log($scope.selectedGroupSubj);
   }

   $scope.selectedSubjectMethod=function(subject) {
	     $scope.selectedSubject = JSON.parse($scope.selectedSubjectOb);
	     $scope.selectedTestSubject=$scope.selectedSubject.subjectId;
	     if ($scope.selQB == 'null') {
	       alert("Schema not selected");
	     }else{
	     $scope.getSelectedChaptersBySubjectId($scope.selectedTestSubject);
	     }
   }

   $scope.getSelectedChaptersBySubjectId = function(subjectId){
	 var contentType = $scope.courseName+","+$scope.selectedContentType;
     httpFactory.getResult("getChapterTopicsBySubId?schemaName="+localStorage.getItem("sname") +"&subjectId="+subjectId+"&contentOwner="+$scope.selectedContentOwner+"&contentType="+contentType+"&branchId="+localStorage.getItem("bnchId")+"&courseId="+$scope.selectedCourse+"&instId="+$scope.instituteId, function(data){
       if(data.StatusCode == 200){
         $scope.selectedChapterDetails=data;
       }else if(data.StatusCode == 300){
         $scope.selectedChapterDetails=data;
       }
       else{
         alert("error");
       }
     });
   }
     $scope.selectedChapterMethod=function() {
       if ($scope.selectedChapter == 'null') {
         alert("Schema not selected");
       }else{
         $scope.topicList = $scope.selectedTestChapter.Topics;
       }
     }

     $scope.selectedTopicMethod=function(topic){
    	 $scope.topicId = $scope.selectedTestTopic.topicId;  
    	 $scope.topicOwner = $scope.selectedTestTopic.topicOwner;
         console.log($scope.selectedTestTopic);
         $scope.questionRepo = localStorage.getItem("sname");
       }

 $scope.selectedCat = function()
 {
 }

 $scope.addTestQuestion = function(){
   console.log($scope.question);
   console.log($scope.option1);
   console.log($scope.correctAnswer);
   console.log($scope.questionCat);
   console.log($scope.selectedTestTopic);
   console.log($scope.diffLevel);
   console.log($scope.selectedContentType);
   console.log($scope.selectedContentOwner);

     if (!$scope.explanation) {
         $scope.explanation="NA";
     }

 if (!$scope.question || !$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer  || !$scope.selectedTestTopic || !$scope.diffLevel || !$scope.selectedContentOwner) {
   alert("Enter all fields");
 }
 else{
 var quesParams = {
   "insertRecords": [{
     "testId": $scope.editTestId,
     "schemaName":localStorage.getItem("sname"),
     "instId":  $scope.instituteId,
     "branchId":$scope.testInfo.branchId,
     "repo":localStorage.getItem("sname"),
     "question": $scope.question,
     "option1": $scope.option1,
     "option2": $scope.option2,
     "option3": $scope.option3,
     "option4": $scope.option4,
     "explanation": $scope.explanation,
     "correctAnswer": $scope.correctAnswer,
     "questionType": $scope.selectedContentType,
     "topicId": $scope.selectedTestTopic,
     "chapterId": $scope.selectedTestChapter.chapterId,
     "difficultyLevel": $scope.diffLevel,
     "instQuestion": "Y",
     "createdBy": $scope.user_id,
     "contentOwner":"COLLEGE",
     "subjectId":$scope.selectedSubject.subjectId,
     "subjectName":$scope.selectedSubject.subjectName,
     "questType":"MCQ",
     "questionAppearedIn":""
        }]
 };

 console.log(quesParams);
 httpFactory.executePost("addTestQuestion", quesParams, function(data) {
   console.log(data);
  if (data.STATUS == 'SUCCESS') {
   alert("Success.Test question added");

   $scope.question = CKEDITOR.instances['question'].setData('');
   $scope.option1 = CKEDITOR.instances['option1'].setData('');
   $scope.option2 = CKEDITOR.instances['option2'].setData('');
   $scope.option3 = CKEDITOR.instances['option3'].setData('');
   $scope.option4 = CKEDITOR.instances['option4'].setData('');
   $scope.explanation = CKEDITOR.instances['explanation'].setData('');
   $('#correctAnswer').prop('selectedIndex', 0);
   // $('#questionCat').prop('selectedIndex',0);
   $('#diffLevel').prop('selectedIndex', 0);
   $('#testSubject').prop('selectedIndex', 0);
   $('#testChapter').prop('selectedIndex', 0);
   $('#testTopic').prop('selectedIndex', 0);

   window.scrollTo(0, 0);
   $("#addQuestion").modal("hide");
   $scope.questionList.push(quesParams.insertRecords[0]);
   $scope.getCustomTestDetails();
   $scope.generateQuestionObj();
 }
 else{
   alert("something went wrong");
 }
});
}
}
 $scope.generateNewTopicQuestion=function(questionObj,index){
   console.log(questionObj);
   console.log(index);
   httpFactory.getResult("getRandomTopicQuestion?schemaName="+localStorage.getItem("sname") +"&topicId="+questionObj.topicId+"&testId="+$routeParams.testId+"&questionId="+questionObj.questionId , function(data){
     console.log(data);
     if(data.StatusCode == 200){
       $scope.randomQuestion=data.Question;
       console.log($scope.questionList[index]);
       $scope.questionList[index].questionId=$scope.randomQuestion[0].questionId;
       $scope.questionList[index].question=$scope.randomQuestion[0].question;
       $scope.questionList[index].option1=$scope.randomQuestion[0].option1;
       $scope.questionList[index].option2=$scope.randomQuestion[0].option2;
       $scope.questionList[index].option3=$scope.randomQuestion[0].option3;
       $scope.questionList[index].option4=$scope.randomQuestion[0].option4;
     }else if(data.StatusCode == 300){
       $scope.randomQuestion=data;
     }
     else{
       alert("error");
     }
   });
 }

 $scope.editQuestion = function(question,index){
   $scope.questionOb = question;
  console.log($scope.questionOb);
   $scope.questId=question.questionId;
   $scope.questionAdv=question.question;
   console.log($scope.question);
   $scope.option1=question.option1;
   $scope.option2=question.option2;
   $scope.option3=question.option3;
   $scope.option4=question.option4;
   $scope.explanation=question.explanation;
   $scope.correctAnswer=question.correctAnswer;
   $scope.diffLevel=question.difficultyLevel;
   console.log(question.difficultyLevel);
   document.getElementById('diffLevel').value = question.difficultyLevel;

   $scope.questionType=question.questType;
   if($scope.questionType=='FIB'){
     $scope.FIBAnswer=question.correctAnswer;
   }else if($scope.questionType=='TOF'){
     $scope.correctAnswer=question.correctAnswer;
    }
    else if($scope.questionType=='MFQ'){
      console.log(question.questions);
      CKEDITOR.instances['editcolumn1a'].setData(question.questions[0].ColumnA);
      $scope.editcolumn1a = question.questions[0].ColumnA;
      CKEDITOR.instances['column2a'].setData(question.questions[1].ColumnA);
      $scope.column2a = question.questions[1].ColumnA;
      CKEDITOR.instances['column3a'].setData(question.questions[2].ColumnA);
      $scope.column3a = question.questions[2].ColumnA;
       if(question.questions.length > 3){
         CKEDITOR.instances['column4a'].setData(question.questions[3].ColumnA);
         $scope.column4a = question.questions[3].ColumnA;
     }
       if(question.questions.length > 4){
      CKEDITOR.instances['column5a'].setData(question.questions[4].ColumnA);
      $scope.column5a = question.questions[4].ColumnA;
    }
      console.log($scope.column4a);

      CKEDITOR.instances['column1b'].setData(question.questions[0].ColumnB);
      $scope.column1b = question.questions[0].ColumnB;
      CKEDITOR.instances['column2b'].setData(question.questions[1].ColumnB);
      $scope.column2b = question.questions[1].ColumnB;
      CKEDITOR.instances['column3b'].setData(question.questions[2].ColumnB);
      $scope.column3b = question.questions[2].ColumnB;
      if(question.questions.length > 3){
        CKEDITOR.instances['column4b'].setData(question.questions[3].ColumnB);
        $scope.column4b = question.questions[3].ColumnB;
      }
      if(question.questions.length > 4){
        CKEDITOR.instances['column5b'].setData(question.questions[4].ColumnB);
        $scope.column5b = question.questions[4].ColumnB;
      }

      $scope.correctAnswer = question.correctAnswer;
      var mfCrAnsList = question.correctAnswer.split(',');
      $scope.MFQ1 = mfCrAnsList[0].split('-')[1];
      if(mfCrAnsList.length>1){
        $scope.MFQ2 = mfCrAnsList[1].split('-')[1];
      }
      if(mfCrAnsList.length>2){
        $scope.MFQ3 = mfCrAnsList[2].split('-')[1];
      }
      if(mfCrAnsList.length>3){
        $scope.MFQ4 = mfCrAnsList[3].split('-')[1];
      }
      if(mfCrAnsList.length> 4){
        $scope.MFQ5 = mfCrAnsList[4].split('-')[1];
      }
      }else if($scope.questionType=='ITQ'){
        $scope.itqCorrectAns=question.correctAnswer;
      }
      $scope.diffLevel=question.difficultyLevel;
   $("#editAdvQuestion").modal("show");
 }

 $scope.selectedAnswerForTOF=function(opt){
   if (opt=='1') {
     $scope.TFOption='true';
   }else{
     $scope.TFOption='false';
   }
   console.log($scope.TFOption);
 }
 $scope.editQuestionTopic=function(){
 	console.log($scope.question);
 	console.log($scope.option1);
 	console.log($scope.correctAnswer);
 	console.log($scope.questionCat);
 	console.log($scope.selTopicId);
 	console.log($scope.diffLevel);
 	console.log($scope.selContentType);
 	console.log($scope.selectedContentOwner);
 		if (!$scope.explanation) {
 				$scope.explanation="NA";
 		}
 if (!$scope.question || !$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer  || !$scope.questionOb.topicId || !$scope.diffLevel) {
 	alert("Enter all fields");
 }
 else{
 var quesParams = {
 	"schemaName":localStorage.getItem("sname"),
 	"updatedRecords": [{
 		"questionId":$scope.questId,
 		"question": $scope.question,
 		"option1": $scope.option1,
 		"option2": $scope.option2,
 		"option3": $scope.option3,
 		"option4": $scope.option4,
 		"explanation": $scope.explanation,
 		"correctAnswer": $scope.correctAnswer,
 		"questionType": $scope.questionOb.questionType,
 		"topicId": $scope.questionOb.topicId,
 		"chapterId": $scope.questionOb.chapterId,
 		"difficultyLevel": $scope.diffLevel,
 		"instQuestion": "Y",
 		"createdBy": localStorage.getItem("userId"),
 		"contentOwner":"COLLEGE",
 		"subjectId":$scope.questionOb.subjectId,
 		"subjectName":$scope.questionOb.subjectName,
 		"questionOwner":"COLLEGE",
 	}]
 };

 console.log(quesParams);
 httpFactory.executePost("updateQuestions", quesParams, function(data) {
 	console.log(data);
  if (data.StatusCode == 200) {
 	alert("Success.Question added");

 	$scope.question = CKEDITOR.instances['question'].setData('');
 	$scope.option1 = CKEDITOR.instances['option1'].setData('');
 	$scope.option2 = CKEDITOR.instances['option2'].setData('');
 	$scope.option3 = CKEDITOR.instances['option3'].setData('');
 	$scope.option4 = CKEDITOR.instances['option4'].setData('');
 	$scope.explanation = CKEDITOR.instances['explanation'].setData('');
 	$('#correctAnswer').prop('selectedIndex', 0);
 	// $('#questionCat').prop('selectedIndex',0);
 	$('#diffLevel').prop('selectedIndex', 0);

 	window.scrollTo(0, 0);
 	$("#editQuestionModal").modal("hide");
 }
 else{
 	alert("Something went wrong");
 }
 });
 }
 }

 $scope.selectedTestSection = {};
 $scope.addAdvTestQuestion = function(){
	   console.log($scope.selectedTestSection);
	   if(typeof $scope.selectedTestSection == 'string'){
	     $scope.selectedTestSection = JSON.parse($scope.selectedTestSection);
	   }

	   $scope.questionAdv = CKEDITOR.instances['questionAdv'].getData();
	   $scope.option1 = "";
	   $scope.option2 = "";
	   $scope.option3 = "";
	   $scope.option4 = "";
	   $scope.explanation = CKEDITOR.instances['explanation'].getData();
	   if ($scope.questionType=='MAQ') {
	     $scope.maqCrct="";
	     for (var i = 0; i < $scope.multiCorrectAnswer.length; i++) {
	       if ($scope.maqCrct=="") {
	           $scope.maqCrct=$scope.multiCorrectAnswer[i];
	       }else{
	         $scope.maqCrct +=','+$scope.multiCorrectAnswer[i];
	       }
	       $scope.correctAnswer=$scope.maqCrct;
	     }
	   }else{
	     $scope.correctAnswer = $("#correctAnswer").val();
	   }
	   $scope.questionCat = $("#questionCat").val();
	   // $scope.diffLevel = $("#diffLevel").value;
	   // $scope.diffLevel =document.getElementById("diffLevel").value;

	   $scope.qstnAppeared = $("#questionAppeared").val();
	   $scope.selectedSchema=localStorage.getItem("addQuescontentOwner");
	   if ($scope.questionType == 'MCQ' || $scope.questionType == 'MAQ') {
	     $scope.option1 = CKEDITOR.instances['option1'].getData();
	     $scope.option2 = CKEDITOR.instances['option2'].getData();
	     $scope.option3 = CKEDITOR.instances['option3'].getData();
	     $scope.option4 = CKEDITOR.instances['option4'].getData();
	   }
	   else if ($scope.questionType == 'TOF') {
	     $scope.correctAnswer=$scope.TFOption;
	     console.log($scope.correctAnswer);
	   }else if($scope.questionType == 'ITQ'){
	     $scope.option1 = CKEDITOR.instances['option1'].getData();
	     $scope.correctAnswer=$scope.itqCorrectAns;
	     if (!$scope.option1) {
	       alert("Enter Values For Integer Type Question");
	       return true;
	     }else if(!$scope.correctAnswer){
	       alert("Enter Correct Answer For Integer Type Question");
	     }
	   }else if($scope.questionType=='FIB'){
	     $scope.correctAnswer=$scope.FIBAnswer;
	   }else if($scope.questionType == 'MFQ'){
	     $scope.correctAnswer="NA";
	     $scope.correctAnswer="1-"+$scope.MFQ1+","+"2-"+$scope.MFQ2+","+"3-"+$scope.MFQ3;
	     if($scope.MFQ4)
	     $scope.correctAnswer=$scope.correctAnswer+","+"4-"+$scope.MFQ4;

	     if($scope.MFQ5)
	     $scope.correctAnswer=$scope.correctAnswer+","+"5-"+$scope.MFQ5;

	     console.log($scope.correctAnswer);

	     $scope.column1a = CKEDITOR.instances['column1a'].getData();
	     $scope.column2a = CKEDITOR.instances['column2a'].getData();
	     $scope.column3a = CKEDITOR.instances['column3a'].getData();
	     $scope.column4a = CKEDITOR.instances['column4a'].getData();
	     $scope.column5a = CKEDITOR.instances['column5a'].getData();

	     console.log($scope.column4a);

	     $scope.column1b = CKEDITOR.instances['column1b'].getData();
	     $scope.column2b = CKEDITOR.instances['column2b'].getData();
	     $scope.column3b = CKEDITOR.instances['column3b'].getData();
	     $scope.column4b = CKEDITOR.instances['column4b'].getData();
	     $scope.column5b = CKEDITOR.instances['column5b'].getData();

	     if($scope.column1a.length<=0){
	       // $scope.column1a="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column1b.length<=0){
	       // $scope.column1b="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column2a.length<=0){
	       // $scope.column2a="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column2b.length<=0){
	       // $scope.column2b="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column3a.length<=0){
	       // $scope.column3a="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column3b.length<=0){
	       // $scope.column3b="NA";
	       alert("Enter Mininum 3 Matches");
	       return true;
	     }
	     if($scope.column4a.length<=0){
	         $scope.column4a="NA";
	     }
	     if($scope.column4b.length<=0){
	         $scope.column4b="NA";
	     }
	     if($scope.column5a.length<=0){
	         $scope.column5a="NA";
	     }
	     if($scope.column5b.length<=0){
	         $scope.column5b="NA";
	     }
	   }

	console.log($scope.diffLevel);
	   if($scope.questionAdv == undefined || $scope.questionAdv  == ""){
	     alert("Please Add question");
	     return true;
	   }
	   if($scope.correctAnswer == undefined || $scope.correctAnswer == ""){
	     alert("Please select correct answer");
	     return true;
	   }
	   if($scope.questionCat == undefined || $scope.questionCat == ""){
	     alert("Please select question type");
	     return true;
	   }
	   if($scope.diffLevel == undefined || $scope.diffLevel == ""){
	     alert("Please select Difficulty Level");
	     return true;
	   }

	   if (!$scope.qstnAppeared) {
	     $scope.qstnAppeared = "";
	   }

	console.log($scope.diffLevel);
	console.log($scope.questionCategory);
		var requestParams={};
	   if (!$scope.questionAdv || !$scope.correctAnswer  || !$scope.topicId || !$scope.diffLevel || !$scope.selectedContentOwner || !$scope.questionCategory) {
	     alert("Enter all fields");
	   }else{
	   if ($scope.questionType=='MFQ') {
	     if (!$scope.MFQ1) {
	       // $scope.MFQ1="NA";
	       alert("Enter Correct Answer");
	       return true;
	     }
	     if (!$scope.MFQ2) {
	       // $scope.MFQ2="NA";
	       alert("Enter Correct Answer");
	       return true;
	     }
	     if (!$scope.MFQ3) {
	       // $scope.MFQ3="NA";
	       alert("Enter Correct Answer");
	       return true;
	     }
	     if (!$scope.MFQ4) {
	       $scope.MFQ4="NA";
	     }
	     if (!$scope.MFQ5) {
	       $scope.MFQ5="NA";
	     }
	      requestParams = {
	       "schemaName":$scope.schemaName,
	       "insertRecords": [{
	         "testId": localStorage.getItem("mgTestId"),
	         "schemaName":localStorage.getItem("sname"),
	         "instId" :  $scope.instituteId,
	         "repo":$scope.questionRepo,
	         "question": $scope.questionAdv,
	         "explanation": $scope.explanation,
	         "correctAnswer": $scope.correctAnswer,
	         "questionType": $scope.questionCat,
	         "topicId": $scope.topicId ,
	         "subjectId": $scope.selectedTestSubject ,
	         "chapterId": $scope.selectedTestChapter.chapterId,
	         "difficultyLevel": $scope.diffLevel,
	         "contentOwner": $scope.topicOwner,
	         "questionOwner" : "COLLEGE",
	         "questionAppearedIn": $scope.qstnAppeared,
	         "questType": $scope.questionType,
	         "branchId" : localStorage.getItem("bnchId"),
			"contentType": $scope.selectedContentType,
			"subjectId": $scope.selectedSubject.subjectId,
	          // "testSectionName":$scope.selectedTestSection.testSectionName,
	          //"testSectionId":$scope.selectedTestSection.testSectionId,
	         "createdBy": localStorage.getItem("userId"),
	         "options":[
	       {
	         "columnA":$scope.column1a,
	         "columnB":$scope.column1b,
	         "correctAnswer":$scope.MFQ1
	       },
	       {
	         "columnA":$scope.column2a,
	         "columnB":$scope.column2b,
	         "correctAnswer":$scope.MFQ2
	       },	{
	         "columnA":$scope.column3a,
	         "columnB":$scope.column3b,
	         "correctAnswer":$scope.MFQ3
	       },	{
	           "columnA":$scope.column4a,
	           "columnB":$scope.column4b,
	           "correctAnswer":$scope.MFQ4
	         },	{
	             "columnA":$scope.column5a,
	             "columnB":$scope.column5b,
	             "correctAnswer":$scope.MFQ5
	             }
	         ]
	       }]
	     }
	     console.log(requestParams);
	   }
	   else
	   {
	     if ($scope.questionType=='MCQ' || $scope.questionType=='MAQ') {
	       if (!$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer) {
	         alert("Please enter all fields");
	         return true;
	       }
	     }
	      requestParams = {
	      "schemaName":$scope.schemaName,
	      "insertRecords": [{
	        "testId": localStorage.getItem("mgTestId"),
	        "schemaName":localStorage.getItem("sname"),
	        "instId": $scope.instituteId,
	        "repo":$scope.questionRepo,
	        "question": $scope.questionAdv,
	        "option1": $scope.option1,
	        "option2": $scope.option2,
	        "option3": $scope.option3,
	        "option4": $scope.option4,
	        "explanation": $scope.explanation,
	        "correctAnswer": $scope.correctAnswer,
	        "questionType": $scope.questionCat,
	        "topicId": $scope.topicId ,
	        "subjectId": $scope.selectedTestSubject ,
	        "chapterId": $scope.selectedTestChapter.chapterId,
	        "difficultyLevel": $scope.diffLevel,
	        "contentOwner": $scope.topicOwner,
	        "questionOwner" : "COLLEGE",
	        "questionAppearedIn": $scope.qstnAppeared,
	        "questType": $scope.questionType,
	        "branchId" : localStorage.getItem("bnchId"),
			"contentType": $scope.selectedContentType,
			"subjectId": $scope.selectedSubject.subjectId,
//	        "testSectionId":$scope.selectedTestSection.testSectionId,
	        "createdBy": localStorage.getItem("userId")
	      }]
	    }
	   }
	 //add testSectionName if sections available from select section Name selection
	   if($scope.selectedTestSection){
	       requestParams.insertRecords[0]["testSectionName"]=$scope.selectedTestSection.sectionName;
	   }
	   console.log(requestParams);
	 httpFactory.executePost("addTestQuestion", requestParams, function(data) {
	   console.log(data);
	  if (data.STATUS == 'SUCCESS') {
	   alert("Success.Test question added");

	   $scope.questionAdv = CKEDITOR.instances['question'].setData('');
	   $scope.option1 = CKEDITOR.instances['option1'].setData('');
	   $scope.option2 = CKEDITOR.instances['option2'].setData('');
	   $scope.option3 = CKEDITOR.instances['option3'].setData('');
	   $scope.option4 = CKEDITOR.instances['option4'].setData('');
	   $scope.explanation = CKEDITOR.instances['explanation'].setData('');
	   $('#correctAnswer').prop('selectedIndex', 0);
	   // $('#questionCat').prop('selectedIndex',0);
	   $('#diffLevel').prop('selectedIndex', 0);
	   $('#testSubject').prop('selectedIndex', 0);
	   $('#testChapter').prop('selectedIndex', 0);
	   $('#testTopic').prop('selectedIndex', 0);
	   $scope.TFOption="";
	   $scope.MFQ1="";
	   $scope.MFQ2="";
	   $scope.MFQ3="";
	   $scope.MFQ4="";
	   $scope.MFQ5="";
	   $scope.correctAnswer="";
	   $scope.itqCorrectAns="";
	   $scope.diffLevel="";
	   $scope.FIBAnswer="";
	   $scope.selectedTestSubject="";
	   $scope.topicId="";
	   $scope.trueOption="";
	   $scope.falseOption="";

	   window.scrollTo(0, 0);


	   $scope.questionList.push(requestParams.insertRecords[0]);
	   $scope.getCustomTestDetails();
	   $scope.generateQuestionObj();
	   if($scope.selQCount<=0){
	   $("#addAdvQuestion").modal("hide");
	 }
	 }
	 else{
	   alert("something went wrong");
	 }
	});
	}
	}


 $scope.manualTestPublish=function(){
   $scope.testId=$scope.editTestId;
   $location.path("publishTest/"+$scope.testId+"/"+$scope.testInfo.branchId+"/publish");
 }
   // manual genearation test methods end

});
