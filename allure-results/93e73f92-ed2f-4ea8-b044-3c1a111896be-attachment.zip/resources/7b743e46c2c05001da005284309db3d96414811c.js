projectModule.controller('adminCalendarController', function($scope, $location, commonFactory, httpFactory, $routeParams,$route) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.roleId = localStorage.getItem("RD");

	$scope.gotoEventAdd = function(){
		$location.path("calenderEvents");
	}
	$scope.calendarInitMethod=function(){
		var ndate = new Date();
		$scope.monthId=ndate.getMonth()+1;
		$scope.yearId=ndate.getFullYear();
		$scope.generateDateOfobj();
		$scope.currentpath=JSON.stringify(localStorage.getItem('location'));
		localStorage.setItem('location', JSON.stringify($location.path("adminCalendar")));
	}

	$scope.getEventsAndHolidaysMonth = function(){
		var params = {
			"monthId":$scope.monthId,
			"schemaName":$scope.schemaName,
			"yearId":$scope.yearId,
			"branchId":$scope.branchId,
			"roleId":$scope.roleId,
		};

		httpFactory.executePost("getEventsAndHolidaysMonth",params, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.EventsHolidays = data.EventsAndHolidays;
				$scope.thisMonthGeneration();
			}
		});

	}

	$scope.deleteEvent = function(eventId){

		var r = confirm("Do you want delete this event for this date");
		if(r == true){
			httpFactory.getResult("deleteEvent?schemaName="+$scope.schemaName+"&eventId="+eventId, function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
				//	$scope.eventListArray = [];
					for(var i=0;i<$scope.eventListArray.eventList.length;i++){
						for(var j=0;j<$scope.eventListArray.eventList[i].eventDetails.length;j++){
							if($scope.eventListArray.eventList[i].eventDetails[j].eventId == eventId){
								$scope.eventListArray.eventList[i].eventDetails.splice(j,1);
								j--;
							}
						}
					}
					$scope.getEventsAndHolidaysMonth();

					//$scope.thisMonthGeneration();
					alert("Deleted Successfully");
				}
			});
		}
	}


	$scope.weekday = new Array(7);

	$scope.weekday[0] = "Mon";
	$scope.weekday[1] = "Tue";
	$scope.weekday[2] = "Wed";
	$scope.weekday[3] = "Thu";
	$scope.weekday[4] = "Fri";
	$scope.weekday[5] = "Sat";
	$scope.weekday[6] = "Sun";

	$scope.weekDisplayDays = new Array(7);
	$scope.weekDisplayDays[0] = "Sun";
	$scope.weekDisplayDays[1] = "Mon";
	$scope.weekDisplayDays[2] = "Tue";
	$scope.weekDisplayDays[3] = "Wed";
	$scope.weekDisplayDays[4] = "Thu";
	$scope.weekDisplayDays[5] = "Fri";
	$scope.weekDisplayDays[6] = "Sat";


	$scope.cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.getViewMonth = "";
	$scope.getViewYear = "";
	$scope.getViewMonthNumber = 0;
	//console.log($scope.newDate);

	$scope.monthView = [];
	$scope.monthDaysList = [];
	$scope.monthDaysListView = [];



	$scope.goToNextMonth = function(){
		if($scope.getViewMonthNumber == 12){
		 $scope.getViewMonthNumber = 1;
		 $scope.getViewYear = parseInt($scope.getViewYear)+1;
		 $scope.getViewMonth = $scope.cal_months_labels[0];
		}
		else{

		 $scope.getViewMonth = $scope.cal_months_labels[$scope.getViewMonthNumber];
		 $scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)+1;
		}
		$scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
		$scope.monthId=$scope.newDate.getMonth()+1;
		$scope.yearId=$scope.newDate.getFullYear();
		$scope.eventListArray = "";
		$scope.getEventsAndHolidaysMonth();
		//$scope.thisMonthGeneration();
	}

	$scope.goToBeforeMonth = function(){
		if($scope.getViewMonthNumber == 1){
		 $scope.getViewMonthNumber = 12;
		 $scope.getViewYear = parseInt($scope.getViewYear)-1;
		 $scope.getViewMonth = $scope.cal_months_labels[11];
		}
		else{
			$scope.getViewMonthNumber = parseInt($scope.getViewMonthNumber)-1;
			$scope.getViewMonth = $scope.cal_months_labels[parseInt($scope.getViewMonthNumber)-1];
		}
		$scope.newDate = new Date($scope.getViewYear, $scope.getViewMonthNumber, 0);
		$scope.monthId=$scope.newDate.getMonth()+1;
		$scope.yearId=$scope.newDate.getFullYear();
		$scope.eventListArray = "";
		$scope.getEventsAndHolidaysMonth();
		//$scope.thisMonthGeneration();
	}

	$scope.generateDateOfobj = function(){
		var nDate = new Date();
		$scope.newDate = nDate;
		$scope.monthId=nDate.getMonth()+1;
		$scope.yearId=nDate.getFullYear();
		$scope.getViewMonth = $scope.cal_months_labels[nDate.getMonth()];
		$scope.getViewMonthNumber = parseInt(nDate.getMonth())+1;
		$scope.getViewYear = parseInt(nDate.getFullYear());
		$scope.getEventsAndHolidaysMonth();
	}

	$scope.thisMonthGeneration =  function(){
		var date = new Date($scope.newDate);
		var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();

		console.log(lastDay);

			var startDay = $scope.weekday[new Date(date.getFullYear(),date.getMonth(), 0).getDay()]
			var firstWeekStart = false;
			var weekIndex = 0;
			var dayStartedIndex = 0;
			var dateIndx = 1;
			$scope.monthDaysList = [];
			do{
				$scope.monthDaysList[weekIndex] = [];
				for(var j=0;j<$scope.weekDisplayDays.length;j++){
					wdayObj = {};
					if(firstWeekStart == false){
						if(startDay != $scope.weekDisplayDays[j] && dayStartedIndex == 0 ){
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],

							};
							console.log("entered");
						}
						else{
							wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
					}
					else{
						if(dayStartedIndex < lastDay+1){
							wdayObj = wdayObj = {
							   "date":dateIndx,
							   "weekday":$scope.weekDisplayDays[j],

							};
							dateIndx++;
							dayStartedIndex++;
						}
						else{
							wdayObj = {
							   "date":0,
							   "weekday":$scope.weekDisplayDays[j],
							};
							if($scope.weekDisplayDays.length-1 == j){
								dayStartedIndex++;
							}
						}

					}
					$scope.monthDaysList[weekIndex].push(wdayObj);
				}
				firstWeekStart = true;
				weekIndex++;

			}
			while(dayStartedIndex <= lastDay)
		console.log($scope.monthDaysList);
		//console.log(JSON.stringify($scope.monthDaysList));
		$scope.generateEventsWithMonth();
	}

	$scope.generateEventsWithMonth = function(){
		console.log($scope.EventsHolidays);
		for(var k=0;k<$scope.EventsHolidays.length;k++){
			for(var j=0;j<$scope.EventsHolidays[k].eventDetails.length; j++){

				if($scope.EventsHolidays[k].eventDetails[j].from == $scope.EventsHolidays[k].eventDetails[j].to){
					var ndate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
					var ndateEve = ndate.getDate();
					for(var i=0; i<$scope.monthDaysList.length; i++){
						for(var l=0; l<$scope.monthDaysList[i].length; l++){
							var ndateEveSel =$scope.monthDaysList[i][l].date;
							if(ndateEveSel == ndateEve){

								if($scope.monthDaysList[i][l].eventList == undefined){
									$scope.monthDaysList[i][l].eventList = [];
								}
								if($scope.monthDaysList[i][l].eventList.length == 0){
									var doopEventDet ={
										"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
										"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
										"eventDetails":[]
									};
									doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
									$scope.monthDaysList[i][l].eventList.push(doopEventDet);
								}else{
									var founIndx = 0;
									for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
										if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
											founIndx++;
											$scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										}
									}
									if(founIndx == 0){
										var doopEventDet ={
											"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
											"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
											"eventDetails":[]
										};
										doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										$scope.monthDaysList[i][l].eventList.push(doopEventDet);
									}
								}
							}
						}
					}
				}else{
					var nFromDate = new Date($scope.EventsHolidays[k].eventDetails[j].from);
					var nToDate = new Date($scope.EventsHolidays[k].eventDetails[j].to);
					var date = new Date($scope.newDate);
					var nstartDate = 0;
					var nendDate = 0;
					if(date.getMonth() == nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
						nstartDate = nFromDate.getDate();
						nendDate = nToDate.getDate();
					}else if(date.getMonth() == nFromDate.getMonth() && date.getMonth() != nToDate.getMonth()){
						var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getUTCDate();
						nstartDate = nFromDate.getDate();
						nendDate = lastDay+1;
					}else if(date.getMonth() != nFromDate.getMonth() && date.getMonth() == nToDate.getMonth()){
						nstartDate = 1;
						nendDate = nToDate.getDate();
					}else {
						var date1 = new Date($scope.newDate);
						var lastDay = new Date(date1.getFullYear(), date1.getMonth() + 1, 0).getUTCDate();
						nstartDate = 1;
						nendDate = lastDay+1;
					}

					for(var i=0; i<$scope.monthDaysList.length; i++){
						for(var l=0; l<$scope.monthDaysList[i].length; l++){
							var ndateEveSel =$scope.monthDaysList[i][l].date;
							if(ndateEveSel >= nstartDate && ndateEveSel <= nendDate){
								if($scope.monthDaysList[i][l].eventList == undefined){
									$scope.monthDaysList[i][l].eventList = [];
								}
									if($scope.monthDaysList[i][l].eventList.length == 0){
										var doopEventDet ={
											"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
											"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
											"eventDetails":[]
										};
										doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
										$scope.monthDaysList[i][l].eventList.push(doopEventDet);
									}else{
										var founIndx =0;
										for(var m=0; m<$scope.monthDaysList[i][l].eventList.length; m++){
											if($scope.monthDaysList[i][l].eventList[m].eventCategoryId == $scope.EventsHolidays[k].eventCategoryId){
												founIndx++;
												$scope.monthDaysList[i][l].eventList[m].eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
											}
										}
										if(founIndx == 0){
											var doopEventDet ={
												"eventCategoryName":$scope.EventsHolidays[k].eventCategoryName,
												"eventCategoryId":$scope.EventsHolidays[k].eventCategoryId,
												"eventDetails":[]
											};
											doopEventDet.eventDetails.push($scope.EventsHolidays[k].eventDetails[j]);
											$scope.monthDaysList[i][l].eventList.push(doopEventDet);
										}
									}
							}
						}
					}
				}
			}
		}
		console.log($scope.monthDaysList);
	}



$scope.calendarInitMethod();

	$scope.addEventPopup = function(wd){
		$scope.selectedEventObj = wd;
		$scope.evTitle = "";
		$scope.evStart = new Date();
		$scope.evEnd = new Date();
		$scope.evDesc = "";
		$scope.isHoliday = false ;
		$scope.isrecur = false;
		$scope.weekholid ={
			"weekDayId":"",
			"weekNum":""
		};
		$("#addEventsType").modal("show");
	}
	$scope.weekholid ={
		"weekDayId":"",
		"weekNum":""
	};
	$scope.weekTypeSelected = "";
	$scope.dayTypeSelected = "";
	$scope.insertHolidaysAndEvents = function(){
		console.log($scope.evTitle);
		console.log($scope.evStart);
		console.log($scope.evEnd);
		console.log($scope.evDesc);
		console.log($scope.isHoliday);

		var startDate = new Date($scope.evStart);
		var endDate = new Date($scope.evEnd);
		var startMonth = 0;
		var endMonth = 0;
		var finalStartDate = 0;
		var finalEndDate = 0;
		if(startDate.getDate() < 10){
			finalStartDate = "0"+startDate.getDate();
		}
		else{
			finalStartDate = startDate.getDate();
		}
		if(endDate.getDate() < 10){
			finalEndDate = "0"+endDate.getDate();
		}
		else{
			finalEndDate = endDate.getDate();
		}
		if(startDate.getMonth() < 9){
			startMonth = "0"+(startDate.getMonth()+1);
		}
		else{
			startMonth = startDate.getMonth()+1;
		}
		if(endDate.getMonth() < 9){
			endMonth = "0"+(endDate.getMonth()+1);
		}
		else{
			endMonth = endDate.getMonth()+1;
		}
		var isholy = 0;
		var isRecur = 0;
		var weekHolidays  = [];

		if($scope.isHoliday == true){
			isholy = 1;
		}

		if($scope.isrecur == true){
			isRecur = 1;
			weekHolidays.push($scope.weekholid);
		}

// if holidays are not recurring date.getFullYear(), date.getMonth() + 1,
	var params=	{
 			"schemaName":$scope.schemaName,
 			"eventCategoryId":$scope.eventTypeSelected,
 			"eventName":$scope.evTitle,
 			"eventDesc":$scope.evDesc,
 			"startDate":""+finalStartDate+"/"+startMonth+"/"+startDate.getFullYear(),
 			"endDate":""+finalEndDate+"/"+endMonth+"/"+endDate.getFullYear(),
 			"isRecurring":isRecur,
 			"isHoliday":isholy,
			"weekHolidays":weekHolidays
 		};
		console.log(params);


		// post url -- insertHolidaysAndEvents
		httpFactory.executePost("insertHolidaysAndEvents", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				$scope.getEventsAndHolidaysMonth();
				alert("Added Successfully");
				//$scope.thisMonthGeneration();
				$("#addEventsType").modal("hide");
			}
		});
	}
	$scope.eventTypeList = [
		{
			"eventTypeId":1,
			"eventTypeName":"Holidays"
		},
		{
			"eventTypeId":2,
			"eventTypeName":"Events"
		},
		{
			"eventTypeId":3,
			"eventTypeName":"Examinations"
		}
		,
		{
			"eventTypeId":4,
			"eventTypeName":"Week Ends"
		}
	];

	$scope.weeksListForMonth = [
		{
			"weekId":1,
			"weekName":"1st"
		},
		{
			"weekId":2,
			"weekName":"2nd"
		}
		,
		{
			"weekId":3,
			"weekName":"3rd"
		},
		{
			"weekId":4,
			"weekName":"4th"
		},
		{
			"weekId":5,
			"weekName":"5th"
		},
		{
			"weekId":6,
			"weekName":"6th"
		}
	];


	$scope.updateEventListArray = function(wdev){
		console.log(wdev);
		$scope.eventListArray = wdev;
	}

	$scope.gotoEdit = function(wdev){
		sessionStorage.setItem("eventToEditId", wdev);
		$location.path("editEvent");
	}

	$scope.checkDelDate = function(eed){
		var fromEed = eed.split(' ')[0];
		//var nstartDateObj = fromEed.split("-");
		var date1 = new Date(fromEed);
		var date2 = new Date();
		if(date1.getTime() < date2.getTime()){
			return false;
		}
		else{
			return true;
		}
	}
	$scope.checkEditDate = function(eed){
		var toEed = eed.split(' ')[0];
		//var nstartDateObj = toEed.split("-");
		var date1 = new Date(toEed);
		var date2 = new Date();
		if(date1.getTime() < date2.getTime()){
			return false;
		}
		else{
			return true;
		}
	}

	$scope.deleteEvent = function(wdev){
		var reqparams = {
			"schemaName":$scope.schemaName,
			"eventId":wdev.eventId,
			"startDate":wdev.from,
			"endDate":wdev.to,
			"branchId":$scope.branchId,
			"roleId":$scope.roleId
		}
		console.log(reqparams);
		httpFactory.executePost("deleteEvent", reqparams, function(data) {
			console.log(data);
			$scope.getEventsAndHolidaysMonth();
		});
	}
	
	$scope.goToHome = function(){
		$location.path("home");
	}

	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}


});
