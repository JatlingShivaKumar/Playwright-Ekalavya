projectModule.controller('editEventController', function($scope, $location, commonFactory, httpFactory, $routeParams,$route) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
  //$scope.schemaName = "events";
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.roleId = localStorage.getItem("RD");
	$scope.eventType = "";
	$scope.eventName = "";
	$scope.eventDesc = "";
	$scope.eventFrom = "";
	$scope.eventTo = "";
	$scope.isCom = 1;
	$scope.isComc = true;
	$scope.isRec = 0;
	$scope.isRecChck = false;
	$scope.weekMonthObj={

	};

	$scope.isMonthRecr = 0;
	$scope.isStudent = false;
	$scope.isStudentAll = true;
	$scope.isStudentAllChk = 1;
	$scope.isStaffS = false;
	$scope.isStaffAll = true;
	$scope.isStaffAllChk = 1;

  $scope.eventToEditId = sessionStorage.getItem("eventToEditId");
  if(sessionStorage.getItem("eventToEditId") == undefined){
    $location.path("adminCalendar");
  }
  sessionStorage.removeItem("eventToEditId");

	$scope.eventTypeList = [
		{
			"eventTypeId":1,
			"eventTypeName":"Holidays"
		},
		{
			"eventTypeId":2,
			"eventTypeName":"Events"
		},
		{
			"eventTypeId":3,
			"eventTypeName":"Examinations"
		}
 	];

  $scope.eventDetails = {};

  $scope.getEventandHolidaysDetailById = function(){
  		httpFactory.getResult("getEventandHolidaysDetailById?schemaName="+localStorage.getItem("sname")+"&eventId="+$scope.eventToEditId, function(data) {
  			console.log(data);
  			if(data.StatusCode == '200'){
  				$scope.eventDetails = data.eventDetais;
          $scope.updateDetails();
  			}
  		});
  	}


	$scope.isHoldSel = 0;
	$scope.gotoCalender = function(){
		$location.path("adminCalendar");
	}
	$scope.isHolidaySelCheck = function(evtyid){

		$scope.eventType = evtyid;
		if($scope.eventType == 1){
			$scope.isHoldSel = 1;
		}
		else{
			$scope.isHoldSel = 0;
		}
	}


	$scope.checkIsCom =  function(){
		if(document.getElementById("isCom").checked == false){
			$scope.isCom = 0;
		}
		else{
			$scope.isCom = 1;
		}
	}
	$scope.checkIsRecur =  function(mnck){
		if(mnck == 1){
			$scope.isMonthRecr = 1;
		}
		else{
			$scope.isMonthRecr = 0;
		}

	};
	$scope.isStuAllCheck = function(){
		if(document.getElementById("isS").checked == false){
			$scope.isStudentAllChk = 0;
		}
		else{
			$scope.isStudentAllChk = 1;
		}
	}
	$scope.isStaffAllCheck = function(){
		if(document.getElementById("isStaffAll").checked == false){
			$scope.isStaffAllChk = 0;
		}
		else{
			$scope.isStaffAllChk = 1;
		}
	}
	$scope.allBCCList = [];
	$scope.getAllBranchClassCourseSections = function(){
		httpFactory.getResult("getAllBranchClassCourseSections?schemaName="+localStorage.getItem("sname")+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if(data.StatusCode == '200'){
				$scope.allBCCList = data.collegesInfo;
			}
		});
	}
	$scope.allDeptList = [];
	$scope.getDeptByBranch = function(){
		httpFactory.getResult("getDeptByBranch?schemaName="+localStorage.getItem("sname")+"&roleId="+$scope.roleId+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			if(data.StatusCode == '200'){
				$scope.allDeptList = data.branchDept;
			}
		});
	}

	$scope.getDeptByBranch();
	$scope.getAllBranchClassCourseSections();


  $scope.updateDeptToDisplay = function(){
    if($scope.eventDetails.staffEvents != undefined && $scope.eventDetails.staffEvents.length > 0 ){
      $scope.isStaffS = true;
      if($scope.eventDetails.staffEvents[0].branchId == 0){
        $scope.isStaffAll = true;
        //document.getElementById("isStaffAll").checked = true;

        $scope.isStaffAllChk = 1;
      }else{
        $scope.isStaffAllChk = 0;
        for(var i=0; i<$scope.eventDetails.staffEvents.length; i++){
          for(var j=0; j<$scope.allDeptList.length;j++){
            if($scope.eventDetails.staffEvents[i].branchId == $scope.allDeptList[j].branchId){
              $scope.allDeptList[j].selected = true;
            }
          }
        }
      }
    }else{
      $scope.isStaffS = false;
    }
    console.log($scope.allDeptList);
  }

  $scope.updateStudentToDisplay = function(){
    if($scope.eventDetails.studentEvents != undefined && $scope.eventDetails.studentEvents.length > 0){
      $scope.isStudent = true;
      if($scope.eventDetails.studentEvents[0].branchId == 0){
        $scope.isStudentAll = true;
        //document.getElementById("isS").checked = true;
        $scope.isStudentAllChk = 1;
      }else{
        $scope.isStudentAll = false;
        $scope.isStudentAllChk = 0;
        for(var i=0; i<$scope.eventDetails.studentEvents.length;i++){
          for(var j=0;j<$scope.allBCCList.length;j++){
            if($scope.eventDetails.studentEvents[i].branchId ==  $scope.allBCCList[j].branchId){
              if($scope.eventDetails.studentEvents[i].branchDetails[0].courseId == 0){
                $scope.allBCCList[j].selected = true;
              }else{
                for(var k=0; k<$scope.allBCCList[j].courses.length;k++){
                  if($scope.eventDetails.studentEvents[i].branchDetails[0].courseId == $scope.allBCCList[j].courses[k].courseId){
                    if($scope.eventDetails.studentEvents[i].branchDetails[0].classId == 0){
                      $scope.allBCCList[j].courses[k].selected = true;
                    }else{
                      for(var l=0; l<$scope.allBCCList[j].courses[k].classes.length;l++){
                        if($scope.eventDetails.studentEvents[i].branchDetails[0].classId == $scope.allBCCList[j].courses[k].classes[l].classId){
                          $scope.allBCCList[j].courses[k].classes[l].selected = true;
                        }
                      }
                    }
                  }
                }
              }
            }

          }
        }

      }
    }else{
      $scope.isStudent = false;
    }
      console.log($scope.allBCCList);
  }

	$scope.selectDeptDetails = [];
	$scope.geenrateDeptDetails = function(){
		$scope.selectDeptDetails = [];
		for(var i=0; i<$scope.allDeptList.length; i++){
			if($scope.allDeptList[i].selected == true){
				var branchSelected = {
						"branchId":$scope.allDeptList[i].branchId,
						"staffDetails":
						[{
							"deptId" : 0,
  					}]
					};
					$scope.selectDeptDetails.push(branchSelected);
			}
			// else{
			// 	var branchSelected = {
			// 		"branchId":$scope.allDeptList[i].branchId,
			// 		"staffDetails":[]
			// 	};
			// 	for(var j=0; j<$scope.allDeptList[i].depts.length; j++){
			// 		if($scope.allDeptList[i].depts[j].selected == true){
			// 			branchSelected.staffDetails.push({"deptId":$scope.allDeptList[i].depts[j].deptId});
			// 		}
			// 	}
			// 	if(branchSelected.staffDetails.length > 0){
			// 		$scope.selectDeptDetails.push(branchSelected);
			// 	}
			// }
		}
		console.log($scope.selectDeptDetails);
	}
	$scope.selecStudentDetails = [];
	$scope.genrateStudentDetails = function(){
		$scope.selecStudentDetails = [];
		for(var i=0; i<$scope.allBCCList.length; i++){
			if($scope.allBCCList[i].selected == true){
					var branchSelected = {
						"branchId":$scope.allBCCList[i].branchId,
						"studentDetails":
						[{
							"courseId" : 0,
				      "classId":0
				    }]
					};
					$scope.selecStudentDetails.push(branchSelected);

			}
			else{
				var branchSelected = {
					"branchId":$scope.allBCCList[i].branchId,
					"studentDetails":[]
				};
				for(var j=0; j<$scope.allBCCList[i].courses.length; j++){
					if($scope.allBCCList[i].courses[j].selected == true){
						var courseSelected = {
							"courseId" : $scope.allBCCList[i].courses[j].courseId,
							"classId":0
						};
						branchSelected.studentDetails.push(courseSelected);
					}else{

						for(var k=0; k<$scope.allBCCList[i].courses[j].classes.length; k++){
							if($scope.allBCCList[i].courses[j].classes[k].selected == true){
								var courseSelected = {
									"courseId" : $scope.allBCCList[i].courses[j].courseId,
									"classId":""
								};
								courseSelected.classId = $scope.allBCCList[i].courses[j].classes[k].classId;
								branchSelected.studentDetails.push(courseSelected);
							}
						}

					}

				}
				if(branchSelected.studentDetails.length > 0){
					$scope.selecStudentDetails.push(branchSelected);
				}


			}

		}
		console.log($scope.selecStudentDetails);


	}


	$scope.addEvent = function(){
		if($scope.eventType == '' || $scope.eventName.trim() == '' || $scope.eventDesc.trim() == ''){
			alert(" Enter All Fields");
			return true;
		}

		if(document.getElementById("eventFrom").value == '' || document.getElementById("eventTo").value == ''){
			alert("Add Dates");
			return true;
		}
		var eventFromCk = new Date(document.getElementById("eventFrom").value);
		var eventToCk = new Date(document.getElementById("eventTo").value);
		if(eventFromCk.getTime() > eventToCk.getTime()){
			alert("Select Dates Properly");
			return true;
		}
		console.log(eventFromCk.getTime()+" "+eventToCk.getTime());

		//return true;
		var holdSel = 0;
		var isrecurring = 0;
		//$scope.eventType = document.getElementById("eventType").value;
		if($scope.isHoldSel == 1){
			holdSel = 1;
		}
		if($scope.isRecChck == true){
			isrecurring = 1;
		}
		/*if(document.getElementById("isCom").checked == false){
			$scope.isCom = 0;
			if(document.getElementById("isStudent").checked == true && $scope.isStudentAllChk == 0){
				$scope.genrateStudentDetails();
			}
		  if(document.getElementById("isStaff").checked == true && $scope.isStaffAllChk == 0){
				$scope.geenrateDeptDetails();
			}
		}*/
		console.log(document.getElementById("eventFrom").value);
		console.log(document.getElementById("eventTo").value);

		$scope.totalSectionObj=[];
		for(var i=0;i<$scope.allBCCList.length;i++){
			for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
				for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
						if($scope.allBCCList[i].courses[j].classes[k].selected==true){
								var object = {
										"branchId":$scope.allBCCList[i].branchId,
										"courseId":$scope.allBCCList[i].courses[j].courseId,
										"classId":$scope.allBCCList[i].courses[j].classes[k].classId,
										
								}
							$scope.totalSectionObj.push(object);
						}
				}
			}
		}
		var stucheck = document.getElementById("stucheck").checked;
		var stacheck = document.getElementById("stacheck").checked;
		/*$scope.totalDeptObj=[];
		for(var i=0;i<$scope.allDeptList.length;i++){
			for(var j=0;j<$scope.allDeptList[i].depts.length;j++){
						if($scope.allDeptList[i].depts[j].selected==true){
								var deptobject = {
										"branchId":$scope.allDeptList[i].branchId,
										"deptId":$scope.allDeptList[i].depts[j].deptId
								}
							$scope.totalDeptObj.push(deptobject);
						}
			}
		}
		params["deptOb"]=$scope.totalDeptObj;*/
		
		
		/*if($scope.selectedTemplt == undefined){
			alert("Please Select Template.");
			return;
		}*/
		if(stucheck == false && stacheck == false){
			alert("Please Select Student or Staff.");
			return;
		}

		var params = {
 			"schemaName": $scope.schemaName,
			"updatedBy": $scope.userId,
      "createdBy": $scope.userId,
      "eventId":$scope.eventToEditId,
 			"eventType": $scope.eventType,
 			"eventName": $scope.eventName,
 			"eventDesc": $scope.eventDesc,
			"startDate":document.getElementById("eventFrom").value,
			"endDate":document.getElementById("eventTo").value,
			"eventUsers":"",
			"isDefault": $scope.isCom,
 			"isRecurring":isrecurring,
 			"isHoliday": holdSel,
 		};

		if(stucheck == true && stacheck == true){
			params.eventUsers = "All";
		}
		else if(stucheck == true && stacheck == false){
			params.eventUsers = "Students";
		}
		else if(stucheck == false && stacheck == true){
			params.eventUsers = "Staff";
		}
		$scope.classStr = "";
		$scope.courseStr="";
		$scope.courseIdArr=[];
		//console.log($scope.classStr);
		//console.log($scope.courseStr);
		params["branches"]=$scope.totalSectionObj;
		//console.log($scope.totalSectionObj);
		if(params.branches == undefined|| params.branches.length ==0 ){
			alert("Select to whom it need to apply.");
			return true;
		}
		if(isrecurring == 1){
			var weekHolidays = [];
				if($scope.isMonthRecr == 1){
					weekHolidays.push({"weekDayId":document.getElementById("selWeekDay").value,"weekNum":document.getElementById("slWeek").value});
					params.holidayList = weekHolidays;
				}else{
					for(var i=1; i<6;i++){
						weekHolidays.push({"weekDayId":document.getElementById("selWeekDay").value,"weekNum":""+i});
					}
					params.holidayList = weekHolidays;
				}
		}

		/*if($scope.isCom == 0){
			if(document.getElementById("isStudent").checked == true && document.getElementById("isStaff").checked == true) {
				params.eventUsers = "All";
				if($scope.isStudentAllChk == 1 && $scope.isStaffAllChk == 1){
					params.branches = [{
						"branchId":0,
						"staffDetails":
						[{
							"deptId":0,
						}],
						"studentDetails":
						[{
							"courseId" : 0,
							"classId":0
						}]
					}];
				}
				else if($scope.isStaffAllChk == 1 && $scope.isStudentAllChk == 0){
						if($scope.selecStudentDetails.length > 0){
							params.branches = $scope.selecStudentDetails;
						}
							params.branches.push({
								"branchId":0,
								"staffDetails":
								[{
									"deptId":0,
								}]
							});
					}
				else if($scope.isStudentAllChk == 1 && $scope.isStaffAllChk == 0){
						if($scope.selectDeptDetails.length > 0){
							params.branches = $scope.selectDeptDetails;
						}
						params.branches.push({
							"branchId":0,
							"studentDetails":
							[{
								"courseId" : 0,
								"classId":0
							}]
						});
					}
				else if($scope.isStudentAllChk == 0 && $scope.isStaffAllChk == 0){
						if($scope.selectDeptDetails.length > 0 && $scope.selecStudentDetails.length == 0){
							params.branches = $scope.selectDeptDetails;
						}
						else if($scope.selectDeptDetails.length == 0 && $scope.selecStudentDetails.length > 0){
							params.branches = $scope.selecStudentDetails;
						}else if($scope.selectDeptDetails.length > 0 && $scope.selecStudentDetails.length > 0){
							var combList = $scope.selecStudentDetails.slice();

							for(var i=0; i<$scope.selectDeptDetails.length;i++){
								var found = 0;
								for(var j=0; j<$scope.selecStudentDetails.length;j++){
									if($scope.selecStudentDetails[j].branchId == $scope.selectDeptDetails[i].branchId ){
										combList[j].staffDetails = $scope.selectDeptDetails[i].staffDetails.slice();
										found = 1;
									}
								}
								if(found == 0){
									combList.push($scope.selectDeptDetails[i]);
								}
							}
							params.branches = combList;
						}
			  }


			}
			else if(document.getElementById("isStaff").checked == true && document.getElementById("isStudent").checked == false){
				params.eventUsers = "Staff";
				if($scope.isStaffAllChk == 0){
					params.branches = $scope.selectDeptDetails;
				}
				else{
					params.branches = [{
						"branchId":0,
						"staffDetails":
						[{
							"deptId":0,
						}]
					}];
				}
			}
			else if(document.getElementById("isStudent").checked == true && document.getElementById("isStaff").checked == false){
				params.eventUsers = "Students";
				if($scope.isStudentAllChk == 0){
					params.branches = $scope.selecStudentDetails
				}
				else{
					params.branches = [{
						"branchId":0,
						"studentDetails":
						[{
							"courseId" : 0,
							"classId":0
						}]
					}];
				}
			}
		}else if($scope.isCom == 1){
			params.eventUsers = "All";
			params.branches = [{
				"branchId":0,
				"staffDetails":
				[{
					"deptId":0,
				}],
				"studentDetails":
				[{
					"courseId" : 0,
					"classId":0
				}]
			}];
		}*/
		console.log(params);

		if(params.branches == undefined|| params.branches.length ==0 ){
			alert("Select to whom it need to apply.");
			return true;
		}
    //return true;
		httpFactory.executePost("updateEvent", params, function(data) {
			console.log(data);
			if(data.StatusCode == 200){
				alert("Add Successfully");
				$scope.gotoCalender();
				$scope.eventType = "";
				$scope.eventFrom = "";
				$scope.eventTo = "";
				$scope.eventName = "";
				$scope.eventDesc = "";
				$scope.isRecChck = false;
				$scope.isComc = true;
			}else{
				alert("Something went wrong");
			}

		});
	}


  $scope.updateDetails = function(){

    $scope.eventType = $scope.eventDetails.eventType;
    $scope.eventDesc = $scope.eventDetails.eventdesc;
    $scope.eventName = $scope.eventDetails.eventName;

    if($scope.eventDetails.isDefault == 1){
      $scope.isComc = true;
      $scope.isCom = 1;
      document.getElementById("isCom").checked = true;
    }else{
      document.getElementById("isCom").checked = false;
      $scope.isComc = false;
      $scope.isCom = 0;
      $scope.updateDeptToDisplay();
      $scope.updateStudentToDisplay();
    }

		if($scope.eventDetails.isHoliday == "1"){
			$scope.isHoldSel = 1;
			if($scope.eventDetails.isRecurring == "1"){
				$scope.isRecChck = true;
				if($scope.eventDetails.weekDayNum != undefined){
					if($scope.eventDetails.weekDayNum.length > 1){
						$scope.isMonthRecr = 0;
					}else{
						$scope.isMonthRecr = 1;
						$scope.slWeek = $scope.eventDetails.weekDayNum;
					}
					$scope.selWeekDay = $scope.eventDetails.weekDayId;
				}
	    }else{
				$scope.isRecChck = false;
	    }
		}else{
			$scope.isHoldSel = 0;
		}

    var nstartDate = $scope.eventDetails.startDate.split(' ')[0];
    var nstartDateObj = nstartDate.split("-");
    var nendDate = $scope.eventDetails.endDate.split(' ')[0];
    var nendDateObj = nendDate.split('-');
    $scope.eventFrom = nstartDateObj[2]+"/"+nstartDateObj[1]+"/"+nstartDateObj[0];
    $scope.eventTo = nendDateObj[2]+"/"+nendDateObj[1]+"/"+nendDateObj[0];
		var entFromCk = new Date(nstartDate);
		var entFromCk1 = new Date();
		var entoCk = new Date(nendDate);
		if(entFromCk.getTime() >= entFromCk1.getTime()){
			$('#eventFrom').datepicker({
				  startDate:new Date(),
					format: "dd/mm/yyyy",
					autoclose: true
			}).on('changeDate', function(ev){
				$('#eventTo').datepicker({
						format: "dd/mm/yyyy",
						autoclose: true,
						startDate:new Date(ev.date)
				});
			});
		}
		if(entoCk.getTime() >= entFromCk1.getTime()){
			$('#eventTo').datepicker({
					format: "dd/mm/yyyy",
					autoclose: true,
					startDate:new Date()
			});
		}
  }
	$scope.getEventandHolidaysDetailById();






	  $(".btn-select").each(function (e) {
	      var value = $(this).find("ul li.selected").val();
				var selHtml = $(this).find("ul li.selected").html()
	      if (value != undefined) {
	          $(this).find(".btn-select-input").val(value);
	          $(this).find(".btn-select-value").html(selHtml);
	      }
	  });


	$(document).on('click', '.btn-select', function (e) {
	  e.preventDefault();
	  var ul = $(this).find("ul");
	  if ($(this).hasClass("active")) {
	      if (ul.find("li").is(e.target)) {
	          var target = $(e.target);
	          target.addClass("selected").siblings().removeClass("selected");
	          var value = target.val();
						var selHtml = target.html();
	          $(this).find(".btn-select-input").val(value);
	          $(this).find(".btn-select-value").html(selHtml);
	      }
	      ul.hide();
	      $(this).removeClass("active");
	  }
	  else {
	      $('.btn-select').not(this).each(function () {
	          $(this).removeClass("active").find("ul").hide();
	      });
	      ul.slideDown(300);
	      $(this).addClass("active");
	  }
	});

	$(document).on('click', function (e) {
	  var target = $(e.target).closest(".btn-select");
	  if (!target.length) {
	      $(".btn-select").removeClass("active").find("ul").hide();
	  }
	});

	$scope.generateStudentObj=function(ob,brInd,crInd,clsInd,secInd){
		if(ob=='stuAll'){
			if($scope.stuAll==true){
//				$scope.isStuAll=false;
				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=false;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						//console.log($scope.allBCCList[i]);
						$scope.allBCCList[i].courses[j].selected=false;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=false;;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=false;
							}
						}
					}
				}
			}else{
//				$scope.isStuAll=true;

				for(var i=0;i<$scope.allBCCList.length;i++){
					$scope.allBCCList[i].selected=true;
					for(var j=0;j<$scope.allBCCList[i].courses.length;j++){
						$scope.allBCCList[i].courses[j].selected=true;
						for(var k=0;k<$scope.allBCCList[i].courses[j].classes.length;k++){
							$scope.allBCCList[i].courses[j].classes[k].selected=true;
							//console.log($scope.allBCCList[i].courses[j].classes[k]);
							for(var l=0;l<$scope.allBCCList[i].courses[j].classes[k].sections.length;l++){
								$scope.allBCCList[i].courses[j].classes[k].sections[l].selected=true;
							}
						}
					}
				}
			}

		}else if(ob=='branch'){
			if($scope.allBCCList[brInd].selected==true){
			$scope.allBCCList[brInd].selected=false;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=false;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=false;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=false;
					}
				}
			}
		}else{
			$scope.allBCCList[brInd].selected=true;
			for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
				$scope.allBCCList[brInd].courses[j].selected=true;
				for(var k=0;k<$scope.allBCCList[brInd].courses[j].classes.length;k++){
					$scope.allBCCList[brInd].courses[j].classes[k].selected=true;
					for(var l=0;l<$scope.allBCCList[brInd].courses[j].classes[k].sections.length;l++){
						$scope.allBCCList[brInd].courses[j].classes[k].sections[l].selected=true;
					}
				}
			}
		}
			var isBranchFound=0;
		for(var i=0;i<$scope.allBCCList.length;i++){
//			alert($scope.allBCCList[i].selected);
			if($scope.allBCCList[i].selected==false){
				// $scope.stuAll=false;
				isBranchFound++;
			}
	}
	if(isBranchFound>0){
	$scope.stuAll=false;
	}
	else{
	$scope.stuAll=true;
}
}
	else if(ob=='course'){
		if($scope.allBCCList[brInd].courses[crInd].selected==true){
		$scope.allBCCList[brInd].courses[crInd].selected=false;
		for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
			$scope.allBCCList[brInd].courses[crInd].classes[k].selected=false;
			//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=false;
			}
		}
	}else{
//		$scope.allBCCList[brInd].selected=false;
		$scope.allBCCList[brInd].courses[crInd].selected=true;
		for(var k=0;k<$scope.allBCCList[brInd].courses[crInd].classes.length;k++){
			$scope.allBCCList[brInd].courses[crInd].classes[k].selected=true;
			//console.log($scope.allBCCList[brInd].courses[crInd].classes[k]);
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[k].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[k].sections[l].selected=true;
			}
		}
	}

		var isCourseFound=0;

		for(var j=0;j<$scope.allBCCList[brInd].courses.length;j++){
			if($scope.allBCCList[brInd].courses[j].selected==false){
				isCourseFound++;
				//branchIndex=i;
			}
		}

	if(isCourseFound>0){
		$scope.allBCCList[brInd].selected=false;
		$scope.stuAll=false;
	}
	else{
		$scope.allBCCList[brInd].selected=true;
		//$scope.stuAll=true;
	}
	//$scope.checkBranchSelect();
}
	else if(ob=='class'){
		if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected==true){
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected=false;
			}
			$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
	}else{
//		$scope.allBCCList[brInd].courses[crInd].selected=true;
			for(var l=0;l<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;l++){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[l].selected=true;
			}
			$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
		}

			var isCourseFound=0;
			//var branchIndex=-1;
			for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes.length;j++){
				if($scope.allBCCList[brInd].courses[crInd].classes[j].selected==true){
					isCourseFound++;
				}
			}

		if(isCourseFound == $scope.allBCCList[brInd].courses[crInd].classes.length){
			$scope.allBCCList[brInd].courses[crInd].selected = true;
		}
		else
		{
			$scope.allBCCList[brInd].courses[crInd].selected = false;
			$scope.allBCCList[brInd].selected=false;
			$scope.stuAll=false;
		}
		$scope.checkBranchCourseClassSelect(brInd,crInd);
		//$scope.checkBranchCourseSelect(brInd);
	}
	else if(ob=='section'){
		if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected==true){
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=false;
	}else{
				$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[secInd].selected=true;
		}


		var isCourseFound=0;
		//var branchIndex=-1;
		for(var j=0;j<$scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections.length;j++){
			if($scope.allBCCList[brInd].courses[crInd].classes[clsInd].sections[j].selected==false){
				isCourseFound++;
			}
		}

	if(isCourseFound>0){
		$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = false;
		$scope.allBCCList[brInd].courses[crInd].selected = false;
		$scope.allBCCList[brInd].selected=false;
		$scope.stuAll=false;
	}
	else{
		$scope.allBCCList[brInd].courses[crInd].classes[clsInd].selected = true;
	}
	$scope.checkBranchCourseClassSelect(brInd,crInd);

	}
	}
});
