projectModule.controller('flip', function($scope, $location, commonFactory, httpFactory, $routeParams) {


    //]]>

});