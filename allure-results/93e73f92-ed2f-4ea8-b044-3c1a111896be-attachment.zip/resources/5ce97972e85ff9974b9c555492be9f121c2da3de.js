projectModule.controller('adminStoreContentHomeController', function($scope, $location, commonFactory, httpFactory, $routeParams) {
	
	$scope.$ = $;
    $scope.courseOb = "";
    $scope.classOb = "";
    $scope.userRoleId = localStorage.getItem("RD");
    $scope.userId = localStorage.getItem("userId");
    $scope.domainUrl = localStorage.getItem("domain");

    $scope.gotoLoc = function(loc,subj) {
        sessionStorage.setItem("selsubId", JSON.parse(subj).subjectId);
        sessionStorage.setItem("selclassId", $scope.classOb.classId);
        sessionStorage.setItem("selsubName", JSON.parse(subj).subjectName);
        sessionStorage.setItem("selclassName", $scope.classOb.className);
        sessionStorage.setItem("selcourseId", $scope.courseOb.courseId);
        sessionStorage.setItem("selcourseName", $scope.courseOb.courseName);
    	$location.path(loc);
    }

	$scope.goBackToHome = function(){
		$location.path("adminStoreHome");
	}
    
    $scope.ekalavyaStoreInit = function() {
        $scope.getAllClasses();
    }
    
    $scope.fromHomeScreen = false;
    if (sessionStorage.getItem("fromHomeScreen") == 'true') {
        $scope.fromHomeScreen = true;
    }
    
    $scope.redirectToDashboard = function() {
        $location.path("home");
    }
    
    $scope.getAllCourses = function(selectCls) {
		$scope.courseList=JSON.parse(selectCls).courseData.filter(course => course.isActive === 1);
    }
    
    $scope.getAllClasses = function() {
    	$scope.classOb = "";
        $scope.subjectList = [];
        httpFactory.getResult("getAllClassesForStore?schemaName=ekalavya_store", function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' && data.StatusCode == 200) {
                $scope.classList = data.Classes;
            } else {
            	
            }
        });
    }
    
    $scope.getSubjectsByCourse = function(selectedCourse) {
        $scope.courseOb = JSON.parse(selectedCourse);
		$scope.classOb = JSON.parse($scope.classSelect);
        $scope.subjectList=[];
        var courseId = $scope.courseOb.courseId;
        if($scope.classOb.classId != undefined && courseId != undefined) {
        	httpFactory.getResult("getStoreSubjectsByCourse?schemaName=ekalavya_store" + "&courseId=" + courseId + "&classId=" + $scope.classOb.classId, function(data) {
        		console.log(data);
        		if (data.STATUS == 'SUCCESS' && data.StatusCode == 200) {
        			$scope.subjectList = data.Subjects.filter(subject => subject.isActive === 1);
        		}else{

        		}
        	});
        }
    }
});




