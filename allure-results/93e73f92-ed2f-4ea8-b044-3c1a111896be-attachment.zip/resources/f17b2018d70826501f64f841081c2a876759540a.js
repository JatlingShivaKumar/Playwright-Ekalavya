var projectModule = angular.module('rankrModule', ['ngRoute', 'httpFactory', 'commonFactory', 'ngSanitize','ngCkeditor','angular.filter','chart.js','ngJsonExportExcel','rzSlider','btorfs.multiselect'])

  .config(function($routeProvider) {
    $routeProvider
      .when('/home', {
        templateUrl: 'homeDashboard.html',
        controller: 'rankrDashboardController'
      })
      .when('/exams', {
        templateUrl: 'rankrDashboardView.html',
        controller: 'rankrDashboardController',
      })
      .when("/examCategory", {
        templateUrl: "examCategoryView.html",
        controller: "examGenerationController"
      })
      .when("/examGeneration",{
        templateUrl: "examGenerationView.html",
        controller: "examGenerationController"
      })
      .when("/autoGenerateExamView",{
        templateUrl: "autoGenerateTestView.html",
        controller: "examAutoGenerationController"
      })
      .when("/examType",{
        templateUrl: "examTypeSelection.html",
        controller: "examAutoGenerationController"
      })
      .when("/settings", {
        templateUrl: "instSettings.html",
        controller: "instSettingsController"
      })
      .when("/branchSettings", {
        templateUrl: "branchSettings.html",
        controller: "instSettingsController"
      })
      .when("/payments", {
        templateUrl: "payments.html",
        controller: "instSettingsController"
      })

            .when("/boardSettings", {
        templateUrl: "boardSettings.html",
        controller: "boardSettingsController"
      })
         .when("/boardbcmmap", {
        templateUrl: "boardMediumCourseMap.html",
        controller: "boardSettingsController"
      })
      .when("/subjectSettings", {
        templateUrl: "branchMappings.html",
        controller: "instSettingsController"
      })
      .when("/electiveStudents", {
        templateUrl: "electiveSubjectAssignStudents.html",
        controller: "instSettingsController"
      })
      .when("/acadamicChart", {
        templateUrl: "acadamicChart.html",
        controller: "instSettingsController"
      })
	  .when("/rankrPlus", {
        templateUrl: "rankrPlus.html",
        controller: "rankrPlusController"
      })
      .when('/adminStoreContent', {
         templateUrl: 'adminStoreContentHome.html',
         controller: 'adminStoreContentHomeController'
      })
      .when('/adminStoreContentManagement', {
         templateUrl: 'adminStoreContentManagementView.html',
         controller: 'adminStoreContentManagementController'
      })
      .when("/adminStoreHome", {
        templateUrl: "adminStoreStudentDashboard.html",
        controller: "adminStoreStudentDashboard"
      })
      .when("/branchEkalavyaStore", {
        templateUrl: "ekalavyaStoreCourseClassView.html",
        controller: "liveDashboardController"
      })
      .when('/teacherRankrPlus', {
        templateUrl: 'teacherRankrPlus.html',
        controller: 'teacherRankrPlusController'
      })
	  .when("/attendance", {
        templateUrl: "attendance.html",
        controller: "attendanceController"
      })
      .when("/rankrClasses", {
          templateUrl: "adminRankrClasses.html",
          controller: "rankrClassesController"
        })
       .when("/staffAttendance",{
	     templateUrl:"staffAttendance.html",
	     controller:"staffAttendanceController"
        })
      .when("/timeTable", {
          templateUrl: "timeTable.html",
          controller: "timeTableController"
       })
        .when("/publishTest/:testId/:branchId/:status", {
        templateUrl: "examPublish.html",
        controller: "publishTestController"
      })
      .when("/editTest/:testId/:branchId", {
        templateUrl: "editTestView.html",
        controller: "editTestController"
      })
      .when("/customTest/:courseId/:testId", {
        templateUrl: "customTestGenerationView.html",
        controller: "manualTestGenerationController"
      })
	     .when("/soqExamSetupView", {
        templateUrl: "selectOwnQuestionTestSetup.html",
        controller: "selectOwnExamQuestionController"
      })
      .when("/maqExamSetupView", {
          templateUrl: "manualTestGenerationView.html",
          controller: "selectOwnExamQuestionController"
        })
       .when("/unqExamSetupView", {
          templateUrl: "uploadNQPView.html",
          controller: "examAutoGenerationController"
        })
      .when("/customSelect", {
        templateUrl: "selectOwnExamQuestions.html",
        controller: "selectOwnExamQuestionController"
      })
      .when("/uploadQuesPaper", {
        templateUrl: "uploadQuesPaper.html",
        controller: "selectOwnExamQuestionController"
      })
      .when("/manageStudent", {
        templateUrl: "studentManageView.html",
        controller: "manageStudentsController"
      })
      .when("/selectFields", {
        templateUrl: "selectStudentFields.html",
        controller: "manageStudentsController"
      })
      .when("/studentBulkUpdate", {
        templateUrl: "studentBulkEdit.html",
        controller: "manageStudentsController"
      })
      .when('/content', {
        templateUrl: 'contentManagementView.html',
        controller: 'contentManagementController',
      })
        .when('/contentEdit/:topicId/:own', {
        templateUrl: 'editContentView.html',
        controller: 'contentManagementController',
      })
      .when('/testResult/:testId/:brchId', {
        templateUrl: 'adminTestAnalysisReport.html',
        controller: 'reportController'
      })
      .when('/newTimeTable', {
        templateUrl: 'newTimeTable.html',
        controller: 'timeTableController'
      })
      .when('/registerView/:secId/:courseId/:classId', {
        templateUrl: 'registerView.html',
        controller: 'attendanceController'
      })
	  .when('/assignment', {
        templateUrl: 'assignment.html',
        controller: 'assignmentController'
      })
      .when('/liveclass', {
        templateUrl: 'liveclass.html',
        controller: 'liveclassController'
      })
	  .when("/members",{
		  templateUrl: "manageMembers.html",
	  controller: "manageMembersController"
	  })
    .when("/courseContent",{
    templateUrl: "contentChaptersView.html",
    controller: "contentManagementController"
    })
    .when("/newQuestion",{
    templateUrl: "collegeQuestionAddView.html",
    controller: "contentManagementController"
    })
    .when("/questions",{
    templateUrl: "collegeQuestionsView.html",
    controller: "contentManagementController"
    })
    .when("/contentManagement",{
    templateUrl: "totalContentManagementView.html",
    controller: "totalContentManagementController"
    })
    .when("/moveContent",{
    templateUrl: "moveContent.html",
    controller: "moveContentController"
    })
      .when("/teacherTT/:userId/:branchId",{
    templateUrl: "teacherTimetable.html",
    controller: "teacherTimeTableController"
    })
    .when("/analytics",{
    templateUrl: "adminAnalytics.html",
    controller: "adminAnalyticsController"
    })
    .when('/adminReport', {
      templateUrl: 'adminStudentReport.html',
      controller: 'reportController'
    })
    .when('/addReport/:testType/:testName/:courseId/:classId', {
      templateUrl: 'addReportCardView.html',
      controller: 'rankrPlusController'
    })
    .when('/reportAnalysis', {
      //templateUrl: 'adminreportCardAnalysis.html',
    	templateUrl: 'reportCardDashboard.html',
      controller: 'rankrPlusController'
    })
    .when('/addReportCardTestDetails', {
      templateUrl: 'testTypesForReportCard.html',
      controller: 'reportCardController'
    })
    .when('/reportCardAttendanceManagement', {
      templateUrl: 'attendanceManagementForReportCard.html',
      controller: 'reportCardAttController'
    })
    .when('/reportCardSubjectManagement', {
      templateUrl: 'subjectsListForReportCard.html',
      controller: 'reportCardController'
    })
    .when('/generateReportCard', {
      templateUrl: 'generateReportCardDashboard.html',
      controller: 'rankrPlusController'
    })
    .when('/reportCardTemplate', {
      templateUrl: 'reportCardTemplate.html',
      controller: 'reportCardController'
    })
    .when('/reportCardGeneration', {
      templateUrl: 'generateReportCard.html',
      controller: 'reportCardController'
    })
    .when('/reportCardMap', {
        templateUrl: 'reportCardMapping.html',
        controller: 'reportCardController'
      })
    .when('/sectionReport/:courseId/:classId', {
      templateUrl: 'sectionReportCardView.html',
      controller: 'rankrPlusController'
    })
    
    .when('/sectionStudents', {
      templateUrl: 'sectionStudentsView.html',
      controller: 'rankrSectionStudents'
    })
    .when('/addStuRprt/:classId/:courseId/:sectionId', {
      templateUrl: 'studentReportCardAdd.html',
      //controller: 'rankrPlusController'
      controller: 'reportCardPreviewController'
    })
    .when('/adminCalendar', {
      templateUrl: 'adminCalendarView.html',
      controller: 'adminCalendarController'
    })
    .when('/calenderEvents', {
      templateUrl: 'calendarEvents.html',
      controller: 'calendarEventsController'
    })
    .when('/editEvent', {
      templateUrl: 'editEvent.html',
      controller: 'editEventController'
    })
    .when('/globalSMS', {
      templateUrl: 'globalSMSView.html',
      controller: 'globalSMSController'
    })
   .when('/messaging', {
	      templateUrl: 'messagingView.html',
	      controller: 'messagingController'
	})
    .when('/profile/:userId/:roleId/:branchId', {
      templateUrl: 'profileView.html',
      controller: 'profileController'
    })
    .when('/teacherHw/:userId/:branchId', {
      templateUrl: 'adminTeacherHomework.html',
      controller: 'profileController'
    })
    .when('/testStudentStatus/:testId/:branchId', {
      templateUrl: 'studentExamStatusView.html',
      controller: 'rankrDashboardController'
    })
    .when('/studentDetails/:stuId', {
      templateUrl: 'studentProfile.html',
      controller: 'adminStudentProfileController'
    })
     .when('/messages/:messages', {
        templateUrl: 'adminMessagesView.html',
        controller: 'adminMessagesController'
      })
    .when('/timetabletemplate', {
      templateUrl: 'generalSettings.html',
      controller: 'generalSettingsController'
    })
    /*.when('/feeSettings', {
      templateUrl: 'discount.html',
      controller: 'feeSettingsController'
    })*/
    .when('/feeStructure', {
      templateUrl: 'feeStructure.html',
      controller: 'feeStructureController'
    })
    .when('/feeAssignment',{
      templateUrl: 'feeassignment.html',
      controller: 'feeAssignmentController'
    })
    .when('/feeReceiptsHistory',{
      templateUrl: 'feeReceiptsHistory.html',
      controller: 'feeReportController'
    })
    .when('/feeDetails',{
      templateUrl: 'feeDetailAssignment.html',
      controller: 'feeDetailsAssignmentController'
    })
      .when('/classReports',{
      templateUrl: 'classwiseInstituteTests.html',
      controller: 'instituteReportCardController'
    })

      .when('/instExamsettings',{
      templateUrl: 'addTestTermsExams.html',
      controller: 'instituteReportCardController'
    })

      .when('/circulars',{
      templateUrl: 'circularDetailsView.html',
      controller: 'circularController'
    })

////      .when('/testCategoryManagement',{
////      templateUrl: 'testCategoryTemplate.html',
////      controller: 'testCategoriesController'
////    })
//

       .when('/activities',{
      templateUrl: 'activitiesView.html',
      controller: 'activitiesController'
    })
     .when('/wordSearch',{
      templateUrl: 'wordSearch.html',
      controller: 'wordSearchPuzzle'
    })

      .when('/matching',{
      templateUrl: 'matching.html',
      controller: 'matchingPuzzuleController'
    })
        .when('/matchTheImage',{
      templateUrl: 'matchTheImage.html',
      controller: 'matchTheImageController'
    })
     .when('/flashCards',{
      templateUrl: 'flip.html',
      controller: 'flashCards'
    })
    .when('/questionPuzzle',{
      templateUrl: 'questionPuzzle.html',
      controller: 'matchingPuzzuleController'
    })
     .when('/hangman',{
      templateUrl: 'hangman.html',
      controller: 'matchingPuzzuleController'
    })

     .when('/chopchop',{
      templateUrl: 'chopped.html',
      controller: 'choppedController'
    })

     .when('/wordScramble',{
      templateUrl: 'wordScramble.html',
      controller: 'matchingPuzzuleController'
    })

       .when('/activateUrl/:id',{
      templateUrl: 'clg_registration2.html',
      controller: 'collegeRegistrationController'
    })
       .when('/gallery',{
      templateUrl: 'gallery.html',
      controller: 'rankrPlusController'
    })

       .when('/feemanagement',{
      //templateUrl: 'feeManage.html',
      templateUrl: 'adminFeeManagement.html',
      controller: 'rankrPlusController'
    })
    .when('/storeContent',{
        templateUrl: 'storeContentManagementView.html',
        controller: 'storeContentManagementController'
      })
   .when('/liveDashboard/:classId/:courseId',{
        templateUrl: 'liveDashStudentList.html',
        controller: 'liveDashboardController'
      })
       .when('/transport',{
      templateUrl: 'transport.html',
      controller: 'rankrPlusController'
    })
     .when('/balanceRequests',{
      templateUrl: 'balanceRequests.html',
      controller: 'globalSMSController'
       })
        .when('/transportRoute',{
      templateUrl: 'transportRoute.html',
      controller: 'rankrPlusController'
    })
    .when("/manualExamsView",{
        templateUrl: "adminManualExamsView.html",
        controller: "adminManualExamsController"
      })
      .when("/studentsForManualTest/:studentManualTestId",{
        templateUrl: "manualTestStudentListView.html",
        controller: "adminManualExamsController"
      })
      .when("/ekalavyaStore",{
        templateUrl: "ekalavyaStore.html",
        controller: "ekalavyaStoreController"
      })
      .when("/feeAllocation",{
        templateUrl: "feeAllocation.html",
        controller: "feeAllocationController"
      })
      .when("/feeReceipt",{
        templateUrl: "adminFeeReceipt.html",
        controller: "feeReceiptController"
      })
      .when("/feeReport",{
        templateUrl: "adminFeeReport.html",
        controller: "feeReportController"
      })
      .when("/feeCancellation",{
        templateUrl: "adminFeeCancellation.html",
        controller: "rankrPlusController"
      })
      .when("/feeRefundHistory",{
        templateUrl: "feeRefundHistory.html",
        controller: "feeReceiptController"
      })
      .when("/pushNotifications", {
      templateUrl: 'customPushNotifications.html',
      controller: 'customPushNotificationsController'
    })
    .when('/certificates', {
      templateUrl: 'certificates.html',
      controller: 'certificatesController'
    })
    
     .when('/studentLiveDashboard', {
      templateUrl: 'studentLiveDashboardReport.html',
      controller: 'liveDashboardController'
    })
    .when('/studentReport', {
      templateUrl: 'studentReports.html',
      controller: 'liveDashboardController'
    })
    .when('/hallticket', {
        templateUrl: 'halltickets.html',
        controller: 'rankrPlusController'
      })
      .when('/hallTicketCreation', {
        templateUrl: 'hallTicketCreation.html',
        controller: 'hallTicketCreationController'
      }) 
      .when('/hallTicketAllotment', {
          templateUrl: 'hallTicketAllocation.html',
          controller: 'hallTicketAllocationController'
        }) 
      .when('/whatsAppTemplate',{
          templateUrl: 'globalWhatsAppView.html',
          controller: 'globalWhatsAppController'
           })
      .when('/whatsAppMessaging',{
                   templateUrl: 'whatsAppMessagingView.html',
                   controller: 'whatsAppMessagingController'
           })
    .otherwise({	
      redirectTo: '/',
      templateUrl: 'homeDashboard.html',
      controller: 'rankrDashboardController'
    });

  });

projectModule.run(['$rootScope', '$location', '$routeParams', function($rootScope, $location, $routeParams) {
  var currentPath = $location.path();
  console.log('Current route name: ' + $location.path());
  var currentPaths = currentPath.split('/');
  $rootScope.latestCurrentPath = currentPaths[1];
  console.log('Current route name: ' + $rootScope.latestCurrentPath);
  $rootScope.latestCurrentPathTab = "";
  $rootScope.$on('$routeChangeSuccess', function(e, current, pre) {

    var currentPath = $location.path();
    var currentPaths = currentPath.split('/');
    console.log(currentPaths[1]);

  	if(currentPaths[1] != 'acadamicChart'){
  		sessionStorage.setItem("fromHomeScreen", false);
  	}
    $rootScope.latestCurrentPath = currentPaths[1];
    if($rootScope.latestCurrentPath == '' || $rootScope.latestCurrentPath == 'home'){
      $rootScope.latestCurrentPathTab = 'home';
    }else if($rootScope.latestCurrentPath == 'exams' || $rootScope.latestCurrentPath == 'examType'|| $rootScope.latestCurrentPath == 'autoGenerateExamView'|| $rootScope.latestCurrentPath == 'soqExamSetupView'|| $rootScope.latestCurrentPath == 'maqExamSetupView' || $rootScope.latestCurrentPath == 'unqExamSetupView' || $rootScope.latestCurrentPath == 'customSelect'|| $rootScope.latestCurrentPath == 'customTest' || $rootScope.latestCurrentPath == 'publishTest' || $rootScope.latestCurrentPath == 'testResult'){
      $rootScope.latestCurrentPathTab = 'exams';
    }else if($rootScope.latestCurrentPath == 'content' || $rootScope.latestCurrentPath == 'contentManagement'){
      $rootScope.latestCurrentPathTab = 'contentManagement';
    }else if($rootScope.latestCurrentPath == 'manageStudent'){
      $rootScope.latestCurrentPathTab = 'manageStudent';
    }else if($rootScope.latestCurrentPath == 'analytics'){
      $rootScope.latestCurrentPathTab = 'analytics';
    }else if($rootScope.latestCurrentPath == 'settings' || $rootScope.latestCurrentPath == 'acadamicChart' || $rootScope.latestCurrentPath == 'branchSettings' || $rootScope.latestCurrentPath == 'generalSettings'){
      $rootScope.latestCurrentPathTab = 'settings';
    }else if($rootScope.latestCurrentPath == 'rankrPlus' || $rootScope.latestCurrentPath == 'rankrClasses' || $rootScope.latestCurrentPath == 'attendance'|| $rootScope.latestCurrentPath == 'assignment' || $rootScope.latestCurrentPath == 'timeTable' || $rootScope.latestCurrentPath == 'members' || $rootScope.latestCurrentPath == 'staffAttendance' || $rootScope.latestCurrentPath == 'registerView' || $rootScope.latestCurrentPath == 'reportAnalysis' || $rootScope.latestCurrentPath == 'adminCalendar'|| $rootScope.latestCurrentPath == 'calenderEvents' || $rootScope.latestCurrentPath == 'messages' || $rootScope.latestCurrentPath == 'globalSMS' || $rootScope.latestCurrentPath == 'circulars' || $rootScope.latestCurrentPath == 'feemanagement' || $rootScope.latestCurrentPath == 'gallery' || $rootScope.latestCurrentPath == 'transportRoute'){
      $rootScope.latestCurrentPathTab = 'rankrPlus';
    }else if($rootScope.latestCurrentPath == 'adminStoreHome'){
      $rootScope.latestCurrentPathTab = 'branchEkalavyaStore';
    }

    if ($rootScope.latestCurrentPath == 'adminReport') {
        $('#mainheader').hide();
        $('#tabsDiv').hide();
    }
    else{
      $('#mainheader').show();
      $('#tabsDiv').show();
    }
    if ($rootScope.latestCurrentPath == 'teacherRankrPlus' || $rootScope.latestCurrentPath == 'rankrPlus'  ) {

    }else{
     	sessionStorage.removeItem("profuserid");
		  sessionStorage.removeItem("profroleid");
		  sessionStorage.removeItem("profnav");
    }
  });
}]);
projectModule.factory('Excel', function($window) {
  var uri = 'data:application/vnd.ms-excel;base64,',
    template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
    base64 = function(s) {
      return $window.btoa(unescape(encodeURIComponent(s)));
    },
    format = function(s, c) {
      return s.replace(/{(\w+)}/g, function(m, p) {
        return c[p];
      })
    };
  return {
    tableToExcel: function(tableId, worksheetName) {
      var table = $(tableId),
        ctx = {
          worksheet: worksheetName,
          table: table.html()
        },
        href = uri + base64(format(template, ctx));
      return href;
    }
  };
});
projectModule.config(['$compileProvider', function ($compileProvider) {
$compileProvider.debugInfoEnabled(false);
}]);
