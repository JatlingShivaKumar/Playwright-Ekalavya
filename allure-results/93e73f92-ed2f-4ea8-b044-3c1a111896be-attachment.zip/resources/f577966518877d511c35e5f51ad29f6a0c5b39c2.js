projectModule.controller('generalSettingsController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {

  $scope.$ = $;
  $scope.instituteId = "";
  $scope.userId = localStorage.getItem("userId");
  $scope.schemaName = localStorage.getItem("sname");
  $scope.branchId = localStorage.getItem("bnchId");
  $scope.ttTemplateList = [];
  $scope.getWeekDaysList = [];
  $scope.periodDesc = "";
  $scope.pstarttime = "";
  $scope.pendtime = "";
  $scope.tempName = "";
  $scope.templateMode = '1';
  $scope.selectedTemplate = "";
  $scope.changeTemplateMode = function(indx){
    $scope.templateMode = indx;
  }
  $scope.getTTTemplateNames = function(){
    httpFactory.getResult("getTimeTableTemplateNames?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.ttTemplateList = data.timeTableTemplate.slice();
        $scope.getTemplateToUse($scope.ttTemplateList[0]);
      }
    });
  }

  $scope.getTemplateToUse = function(stf){
    $scope.selectedTemplate = stf;
    if($scope.selectedTemplate != ""){
      httpFactory.getResult("getGenericWDPT?templateId="+$scope.selectedTemplate.templateId+"&schemaName="+$scope.schemaName, function(data) {
        console.log(data);
        if (data.StatusCode == 200) {
          $scope.workingDaysObj = data.workingDays.slice();
          $scope.ttperiods=data.periodArray.slice();
          //$scope.ttTemplateToUse = data.timeTableTemplate.slice();
            $scope.changeTemplateMode('1');
        }
      });
    }
  }
  $scope.getTTTemplateNames();
  $scope.getWeekDays = function(){
    httpFactory.getResult("getWeekDays?schemaName="+$scope.schemaName, function(data) {
      console.log(data);
      if (data.StatusCode == 200) {
        $scope.getWeekDaysList = data.sectionTimeTable.slice();
      }
    });
  }
  $scope.periods= [];
  $scope.addNewHour = function(){
    console.log($scope.periodDesc);
    console.log(document.getElementById('timepicker1').value);
    console.log(document.getElementById('timepicker2').value);

    var startTime=document.getElementById('timepicker1').value;
    var endTime = document.getElementById('timepicker2').value;
    // $scope.startMinutes=minutesForTime(document.getElementById('timepicker1').value);
    // $scope.endMinutes = minutesForTime(document.getElementById('timepicker2').value);
    console.log(startTime);
    console.log(endTime);


    // var minutes = minutesForTime(startTime,endTime);
    var sts = startTime.split(":");
    var ets = endTime.split(":");
    if($scope.periodDesc.trim() == "" || startTime == "" || endTime == "" || sts.length != 2 || ets.length != 2){
        alert("Period Name, Start Time and End Time are Mandatory.");
        return true;
    }
    var stMin = (parseInt(sts[0]) * 60 + parseInt(sts[1]));
    var etMin = (parseInt(ets[0]) * 60 + parseInt(ets[1]));
    $scope.found=0;
    for (var i = 0; i < $scope.periods.length; i++) {
      // $scope.periods[i].
      console.log(stMin);
      console.log($scope.periods[i].startMins);
      console.log(etMin);
      console.log($scope.periods[i].endMins);
      if (stMin>etMin) {
          alert("Start time cannot be greater than end time");
          break;
      }
      // if($scope.periods[i].startMins>stMin && $scope.periods[i].endMins<etMin){
      //   // alert("start in between");
      //   $scope.found=1;
      //   break;
      // }
      // if(stMin>$scope.periods[i].startMins && $scope.periods[i].endMins<etMin){
      //   // alert("start in between");
      //   $scope.found=1;
      //   break;
      // }
      // if($scope.periods[i].endMins >stMin && $scope.periods[i].endMins<etMin){
      //   // alert("end in between");
      //   $scope.found=1;
      //   break;
      // }
      // if($scope.periods[i].startMins>stMin && $scope.periods[i].startMins<etMin){
      //   // alert("start in between");
      //   $scope.found=1;
      //   break;
      // }
      // if($scope.periods[i].startMins>stMin && $scope.periods[i].endMins<etMin){
      //   // alert("start in between");
      //   $scope.found=1;
      //   break;
      // }

      if (stMin<$scope.periods[i].startMins-1 && etMin>$scope.periods[i].endMins-1) {
          $scope.found=1;
          break;
      }
      if (stMin<$scope.periods[i].startMins-1 && etMin>$scope.periods[i].startMins-1 && etMin<$scope.periods[i].endMins-1) {
          $scope.found=1;
          break;
      }
      if (stMin>$scope.periods[i].startMins-1 && etMin<$scope.periods[i].endMins-1) {
          $scope.found=1;
          break;
      }
      if (stMin>$scope.periods[i].startMins-1 && stMin<$scope.periods[i].endMins-1) {
          $scope.found=1;
          break;
      }
      if (stMin<$scope.periods[i].startMins-1 && etMin>$scope.periods[i].endMins-1) {
          $scope.found=1;
          break;
      }
    }
    if ($scope.found) {
      alert("Time Conflicting");
    }else{
      var prObj = {
          "periodDesc":$scope.periodDesc,
          "startTime":document.getElementById('timepicker1').value,
          "endTime":document.getElementById('timepicker2').value,
          "startMins":stMin,
          "endMins":etMin
      }
  if(document.getElementById('isassignBreakprd').checked == true){
      prObj.isBreak = 1;
      prObj.breakDesc = document.getElementById('brdesc').value;
    }
      $scope.periods.push(prObj);
    }
    console.log($scope.periods);
    $scope.periodDesc = "";
    document.getElementById('timepicker1').value  = document.getElementById('timepicker2').value;
    document.getElementById('timepicker2').value = "";
    document.getElementById('isassignBreakprd').checked = false;
    document.getElementById('brdesc').value = "";
  }

    $scope.editNewHour = {
      "periodId":0,
      "periodDesc":"",
      "periodStartTime":"",
      "periodEndTime":"",
      "startMins":0,
      "endMins":0,
    }



    $scope.changedPeriodList = [];
    $scope.periodForEdit = function(){
      console.log($scope.doopPeroidForEdit);
      $scope.doopPeroidForEdit.periodStartTime = document.getElementById('timepicker5').value;
      $scope.doopPeroidForEdit.periodEndTime = document.getElementById('timepicker6').value;

      var startTime=$scope.doopPeroidForEdit.periodStartTime;
      var endTime = $scope.doopPeroidForEdit.periodEndTime;
      // $scope.startMinutes=minutesForTime(document.getElementById('timepicker1').value);
      // $scope.endMinutes = minutesForTime(document.getElementById('timepicker2').value);
      console.log(startTime);
      console.log(endTime);
      // var minutes = minutesForTime(startTime,endTime);
      var sts = startTime.split(":");
      var ets = endTime.split(":");
      var stMin = (parseInt(sts[0]) * 60 + parseInt(sts[1]));
      var etMin = (parseInt(ets[0]) * 60 + parseInt(ets[1]));
      $scope.doopPeroidForEdit.startMins = stMin;
      $scope.doopPeroidForEdit.endMins = etMin;
      $scope.found=0;
      $scope.doopttperiods = [];
      $scope.doopttperiods = $scope.ttperiods.slice();

      for(var j=0; j<$scope.doopttperiods.length;j++){
        if($scope.doopttperiods[j].periodId == $scope.doopPeroidForEdit.periodId){
          $scope.doopttperiods.splice(j,1);
          break;
        }
      }

        $scope.found=0;
      for (var i = 0; i < $scope.doopttperiods.length; i++) {
        var stsdoop = $scope.doopttperiods[i].periodStartTime.split(":");
        var etsdoop = $scope.doopttperiods[i].periodEndTime.split(":");
        var stMindoop = (parseInt(stsdoop[0]) * 60 + parseInt(stsdoop[1]));
        var etMindoop = (parseInt(etsdoop[0]) * 60 + parseInt(etsdoop[1]));
        $scope.doopttperiods[i].startMins = stMindoop;
        $scope.doopttperiods[i].endMins = etMindoop;
        // $scope.periods[i].
        console.log(stMin);
        console.log($scope.doopttperiods[i].startMins);
        console.log(etMin);
        console.log($scope.doopttperiods[i].endMins);

        if (stMin>etMin) {
            alert("Start time cannot be greater than end time");
            $scope.found = 1;
            break;
        }

        if (stMin<$scope.doopttperiods[i].startMins-1 && etMin>$scope.doopttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin<$scope.doopttperiods[i].startMins-1 && etMin-1>$scope.doopttperiods[i].startMins && etMin<$scope.doopttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin>$scope.doopttperiods[i].startMins-1 && etMin<$scope.doopttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin>$scope.doopttperiods[i].startMins-1 && stMin<$scope.doopttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin<$scope.doopttperiods[i].startMins-1 && etMin>$scope.doopttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
      }

      if ($scope.found == 1) {
        alert("Time Conflicting");
      }else{

        $scope.doopPeroidForEdit.startMins = stMin;
        $scope.doopPeroidForEdit.endMins = etMin;

        if(document.getElementById('isEditBreakprd').checked == true){
          $scope.doopPeroidForEdit.isBreak = 1;
          $scope.doopPeroidForEdit.breakDesc = document.getElementById('brPrEditdesc').value;
        }else{
          $scope.doopPeroidForEdit.isBreak = 0;
          $scope.doopPeroidForEdit.breakDesc = "";
        }

          $scope.changedPeriodList = [];
          $scope.changedPeriodList.push($scope.doopPeroidForEdit);
          $scope.editTemplate();
      }
        //console.log($scope.ttperiods);
    }

    $scope.addNewHourForEdit = function(){
      $scope.editNewHour.periodStartTime = document.getElementById('timepicker3').value;
      $scope.editNewHour.periodEndTime = document.getElementById('timepicker4').value;
      console.log($scope.editNewHour);
      var startTime=$scope.editNewHour.periodStartTime;
      var endTime = $scope.editNewHour.periodEndTime;
      // $scope.startMinutes=minutesForTime(document.getElementById('timepicker1').value);
      // $scope.endMinutes = minutesForTime(document.getElementById('timepicker2').value);
      console.log(startTime);
      console.log(endTime);
      // var minutes = minutesForTime(startTime,endTime);
      var sts = startTime.split(":");
      var ets = endTime.split(":");
      var stMin = (parseInt(sts[0]) * 60 + parseInt(sts[1]));
      var etMin = (parseInt(ets[0]) * 60 + parseInt(ets[1]));
      $scope.editNewHour.startMins = stMin;
      $scope.editNewHour.endMins = etMin;
      $scope.found=0;
      for (var i = 0; i < $scope.ttperiods.length; i++) {
        var stsdoop = $scope.ttperiods[i].periodStartTime.split(":");
        var etsdoop = $scope.ttperiods[i].periodEndTime.split(":");
        var stMindoop = (parseInt(stsdoop[0]) * 60 + parseInt(stsdoop[1]));
        var etMindoop = (parseInt(etsdoop[0]) * 60 + parseInt(etsdoop[1]));
        $scope.ttperiods[i].startMins = stMindoop;
        $scope.ttperiods[i].endMins = etMindoop;
        // $scope.periods[i].
        console.log(stMin);
        console.log($scope.ttperiods[i].startMins);
        console.log(etMin);
        console.log($scope.ttperiods[i].endMins);

        if (stMin>etMin) {
            alert("Start time cannot be greater than end time");ttperiods
            break;
        }

        if (stMin<$scope.ttperiods[i].startMins-1 && etMin>$scope.ttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin<$scope.ttperiods[i].startMins-1 && etMin>$scope.ttperiods[i].startMins-1 && etMin<$scope.ttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin>$scope.ttperiods[i].startMins-1 && etMin<$scope.ttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin>$scope.ttperiods[i].startMins-1 && stMin<$scope.ttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
        if (stMin<$scope.ttperiods[i].startMins-1 && etMin>$scope.ttperiods[i].endMins-1) {
            $scope.found=1;
            break;
        }
      }
      if ($scope.found) {
        alert("Time Conflicting");
      }else{

        $scope.editNewHour.startMins = stMin;
        $scope.editNewHour.endMins = etMin;

        if(document.getElementById('isassignEditBreakprd').checked == true){
          $scope.editNewHour.isBreak = 1;
          $scope.editNewHour.breakDesc = document.getElementById('brEditdesc').value;
        }
        else{
          $scope.editNewHour.isBreak = 0;
          $scope.editNewHour.breakDesc = "";
        }
          $scope.ttperiods.push($scope.editNewHour);
          $scope.changedPeriodList.push($scope.editNewHour);
        }
        console.log($scope.ttperiods);
        $scope.editNewHour = {
          "periodId":0,
          "periodDesc":"",
          "periodStartTime":$scope.editNewHour.periodEndTime,
          "periodEndTime":"",
          "startMins":0,
          "endMins":0,
        }
      document.getElementById('isassignEditBreakprd').checked = false;
      document.getElementById('brEditdesc').value = "";
    }

    $scope.doopPeroidForEdit = {};
    $scope.editPeroidOfTemplate = function(prd){
      $scope.doopPeroidForEdit = prd;
      $("#setEditTimePopup").modal("show");
    }

    $scope.prdEdChk = true;
    $scope.editTemplate = function(){
      console.log($scope.ttperiods);
      var reqParams =    {
          "schemaName":$scope.schemaName,
          "templateId":$scope.selectedTemplate.templateId,
          "createdBy":$scope.userId,
          "branchId":$scope.branchId,
          "isActive":1,
          "periodDetails":$scope.changedPeriodList
        }
        console.log(reqParams);
        $scope.prdEdChk = false;
        alert("Any changes Done ?\nDelete the TimeTable of that class and Re-assign it");
        httpFactory.executePost("editTimeTableTemplate", reqParams, function(data) {
    			console.log(data);
    			if (data.StatusCode == 200) {
            $scope.prdEdChk = true;
    				alert("successfully saved");
    				$scope.getTemplateToUse($scope.selectedTemplate);
            $scope.changedPeriodList=[];
            $("#setEditTimePopup").modal("hide");
    			} else {
            $scope.prdEdChk = true;
    				//TODO : Show Error
    				$scope.errorMsg = data.message;
    			}
    		});

    }
    $scope.dayChk = false;
  $scope.removeDayName = function(dayId){
    for(var i=0; i<$scope.getWeekDaysList.length;i++){
      if($scope.getWeekDaysList[i].weekDayId == dayId){
        $scope.getWeekDaysList[i].isActive = '0';
        $scope.dayChk = true;
        break;
      }
    }
  }
  
  $scope.selectedAddDayId = "";
  $scope.addDayName = function(){
    var dayCheck = 1;
    for(var i=0; i<$scope.getWeekDaysList.length;i++){
      if($scope.getWeekDaysList[i].weekDayId == $scope.selectedAddDayId){
        $scope.getWeekDaysList[i].isActive = '1';
        $scope.selectedAddDayId = "";

        $("#addDayNameModal").modal("hide");
        //break;
      }
      if($scope.getWeekDaysList[i].isActive == '0'){
        dayCheck = 0;
      }
    }
    if(dayCheck == 0){
      $scope.dayChk = true;
    }else{
      $scope.dayChk = false;
    }

  }
  $scope.selectAddDayName = function(dayId){
    $scope.selectedAddDayId = dayId;
  }

  $scope.dayChk = false;
  $scope.openAddDayName = function(){
    var dayCheck = 1;
    for(var i=0; i<$scope.getWeekDaysList.length;i++){
      if($scope.getWeekDaysList[i].isActive == '0'){
        dayCheck = 0;

      }
    }
    if(dayCheck == 1){
      alert("You cannot add more than a week");
    }
    else{
      $("#addDayNameModal").modal("show");
    }
  }
  $scope.addnewTempChk = true;
  $scope.addnewTemplate = function(){
	    $scope.templateName= document.getElementById("tempName").value;

	  	console.log($scope.templateName);
	  if($scope.templateName.trim().length>0){
    var getWeekDaysListGenerated = [];
    for(var i=0; i<$scope.getWeekDaysList.length;i++){
      if($scope.getWeekDaysList[i].isActive == '1'){
          var dayobj = {
              "weekDayId" : $scope.getWeekDaysList[i].weekDayId,
              "weekDayName":$scope.getWeekDaysList[i].dayName,
              "startTime":$scope.periods[0].startTime,
              "endTime":$scope.periods[$scope.periods.length -1].endTime
          }
          getWeekDaysListGenerated.push(dayobj);
      }
    }


    var reqParams = {
        "schemaName":$scope.schemaName,
        "templateName":$scope.templateName,
        "createdBy":$scope.userId,
        "branchId":$scope.branchId,
        "isActive":1,
        "workingDays":getWeekDaysListGenerated,
        "periodDetails":$scope.periods
    }
    console.log(reqParams);
    $scope.addnewTempChk = false;
    httpFactory.executePost("saveTimeTableTemplate", reqParams, function(data) {
			console.log(data);
      $scope.addnewTempChk = true;
			if (data.StatusCode == 200) {
				alert("successfully saved");
        $scope.getTTTemplateNames();
        $scope.templateMode == '1'
        //$scope.getTemplateToUse($scope.ttTemplateList[0]);
			} else {
				//TODO : Show Error
				$scope.errorMsg = data.message;
			}
		});
    $scope.getWeekDays();
  }else{
	  alert("Enter Template Name");
  }

  }
  $scope.getWeekDays();
  
$scope.deleteTimeTableTemplate=function(templateId){
 var r = confirm("Do you really want to delete?!");
    if (r == true) {
       var params = {
	  			"schemaName":$scope.schemaName,
	  			"templateId": templateId
	  	}
	  	httpFactory.executePost("deleteTimeTableTemplate", params , function(data) {
				console.log(data);
				if (data.StatusCode == 200) {
					alert("successfully Deleted");
					$scope.getTTTemplateNames();
				} else {
					alert("Template is already assigned\nPlease delete it.");
				}
			});
    } else {
      return;
    }
	  	
 }
	  
  $scope.deletePeroid = function(prd,selectedTemplate){
  	var params ={
  			"schemaName":$scope.schemaName,
  			"periodId": prd.periodId
  	}
  	httpFactory.executePost("deletePeroid", params , function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert("Successfully Deleted");
				$scope.getTemplateToUse(selectedTemplate)
			} else {
				alert("This Peroid is already assigned to a Class\nSo, Delete that TimeTable first");
			}
		});
  }

	$scope.goToDashbord = function(){
		$location.path("rankrPlus");
	}


  });
