projectModule.controller('assignmentController', function($scope, $location, $timeout, httpFactory, $window,$routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.userId = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.branchId = localStorage.getItem("bnchId");
	$scope.branchName = localStorage.getItem("bnchnme");

	var requestParams = {
		"m_inst_id": $scope.instituteId
	};

	$scope.monthsArr=["January","February","March","April","May","June","July","August","September","October","November","December"];

	$scope.navCourseId=sessionStorage.getItem("navCourseId");
	$scope.navClassId=sessionStorage.getItem("navClassId");
	$scope.myClasses=sessionStorage.getItem("myClasses");
	$scope.navSectionId=sessionStorage.getItem("navSectionId");

	sessionStorage.removeItem("navCourseId");
	sessionStorage.removeItem("navClassId");
	sessionStorage.removeItem("navSectionId");
	sessionStorage.removeItem("myClasses");


	$scope.getCourseByBranchId=function(){
		httpFactory.getResult("getCourseBranchId?branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
	    console.log(data);
	    if (data.StatusCode == 200) {
	      $scope.courseList = data.Courses;
	      if( $scope.courseList.length==1) {
	    	  $scope.selCourse = JSON.stringify($scope.courseList[0]);
	    	  $scope.courseSelect($scope.selCourse);
	      }	     
				if($scope.navCourseId){
					for (var i = 0; i < $scope.courseList.length; i++) {
						if($scope.courseList[i].courseId==$scope.navCourseId){
							$scope.selectedCourseOb=JSON.stringify($scope.courseList[i]);
							$scope.courseSelect($scope.selectedCourseOb);
							break;
						}
					}
				}
			}
		});
	}

	$scope.courseSelect = function(selectedCourse){
		if (typeof selectedCourse=='string')
			$scope.selectedCourseOb = JSON.parse(selectedCourse);
			else
			$scope.selectedCourseOb = selectedCourse;

		$scope.selectedCourse=$scope.selectedCourseOb.courseId;
		$scope.selCourseName=$scope.selectedCourseOb.courseName;
		httpFactory.getResult("getCLassesByCourse?courseId="+$scope.selectedCourse+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
			console.log(data);
			$scope.selCourse=selectedCourse;
			if (data.StatusCode == 200) {
				$scope.classList = data.Classes;
				if($scope.navCourseId){
					for (var i = 0; i < $scope.classList.length; i++) {
						if($scope.classList[i].classId==$scope.navClassId){
							$scope.selectedClassOb=JSON.stringify($scope.classList[i]);
							$scope.selectedCCId=$scope.classList[i].classCourseId;
							$scope.courseClassSelect($scope.selectedClassOb);
							break;
					}
				}
			}
			}
		});
	}

	$scope.courseClassSelect = function(){
		console.log($scope.selectedClassOb);
		$scope.selectedClsOb=$scope.selectedClassOb;
		$scope.sectionList=[];
		if (typeof $scope.selectedClassOb=='string')
			$scope.selectedClsObject = JSON.parse($scope.selectedClassOb);
			else
			$scope.selectedClsObject = $scope.selectedClassOb;

		$scope.selectedClassId=$scope.selectedClsObject.classId;
		$scope.selectedCCId=$scope.selectedClsObject.classCourseId;
		$scope.selClassName=$scope.selectedClsObject.className;
		httpFactory.getResult("selectSectionsByBranchCourseClass?branchId="+$scope.branchId+"&classCourseId="+$scope.selectedCCId+"&schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
					if ($scope.myClasses) {
						for (var i = 0; i < $scope.sectionList.length; i++) {
							if($scope.sectionList[i].sectionId==$scope.navSectionId){
								$scope.sectionOb=$scope.sectionList[i];
								break;
							}
						}
					}else{
						$scope.sectionOb=$scope.sectionList[0];
					}
					$scope.selectedSection=$scope.sectionOb.sectionId;
				if(sessionStorage.getItem("hwadd")){
					$scope.selectedCourse=$scope.navCourseId;
					$scope.selectedSection=sessionStorage.getItem("hwadd");
					sessionStorage.removeItem("hwadd");
					$scope.studentList=[];
					$scope.selectStudentsBySection();
					$scope.homeworkpopup();
				}else{
					$scope.getSectionHomeWork($scope.sectionOb);
				}
				$scope.getCurrentAcademicYear();
			}
		});
	}

$scope.homeworkpopup=function(){
	$scope.selectedHWType="";
	$scope.subj="";
	$scope.Description="";
	
	document.getElementById("submissionDate").value="";
	console.log($scope.selectedCourse);
	console.log($scope.selectedSection);
	console.log($scope.selectedCCId);
	$scope.chap = {};
	$scope.topic = {};
	if ($scope.selectedCourse && $scope.selectedSection && $scope.selectedCCId) {
		if ($scope.studentList.length>0) {
			$scope.getAllCourseClassSubjects();
			$scope.getHomeWorkTypes();
			$("#addHomeWork").modal("show");
		}else{
			alert("Section : "+ $scope.selectedSectionOb.sectionName +"  does not have students.Please add students to add homework");
		}
	} else{
		alert("Plese select class,course and section");
	}
}

$scope.subjectSelectModal = function(){
	$scope.getAllCourseClassSubjects();
	$("#subjectModal").modal("show");
}
$scope.getAllCourseClassSubjects=function(){
	httpFactory.getResult("getAllCourseClassSubjects?courseId="+$scope.selectedCourse+"&classId="+$scope.selectedClassId+"&schemaName="+$scope.schemaName+"&branchId="+$scope.branchId, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
			$scope.generalSubj = [];
			$scope.electiveSubj = [];
				$scope.subjList = data.Subjects;
				for (var i = 0; i < $scope.subjList.length; i++) {
					if ($scope.subjList[i].electiveGroupId == 0) {
						for (var k = 0; k < $scope.subjList[i].subjects.length; k++) {
						$scope.subjList[i].subjects[k]["isElective"]="0";
						$scope.generalSubj.push($scope.subjList[i].subjects[k]);
					}
				}else{
						$scope.electiveSubj.push($scope.subjList[i]);
					}
				}
				for (var k = 0; k < $scope.electiveSubj.length; k++) {
					for (var l = 0; l < $scope.electiveSubj[k].subjects.length; l++) {
					console.log($scope.electiveSubj[k].subjects[l]);
					$scope.electiveSubj[k].subjects[l]["electiveGroupName"]=$scope.electiveSubj[k].electiveGroupName;
					$scope.electiveSubj[k].subjects[l]["electiveGroupId"]=$scope.electiveSubj[k].electiveGroupId;
					$scope.electiveSubj[k].subjects[l]["isElective"]=$scope.electiveSubj[k].isElective;
					$scope.generalSubj.push($scope.electiveSubj[k].subjects[l]);
				}
			}
	}
	});
}
$scope.selectMonth=function(month){
	var selMonDoopObj = {};
	if(typeof month== 'string' ){
		selMonDoopObj = JSON.stringify(month);
	}else{
		selMonDoopObj = month;
	}
	$scope.monthIndex=selMonDoopObj.monthIndex;
	$scope.splitArr=selMonDoopObj.monthName.split(" ");
	$scope.totalMonthName=$scope.splitArr[0]+","+$scope.splitArr[1];
	console.log($scope.splitArr);
		$scope.getSectionHomeWork($scope.selectedSectionOb,$scope.monthIndex,$scope.splitArr[1]);
}

	$scope.selectMonthFromCal = function(month) {
		var monthId = month.getMonth() + 1;
		var yearId = month.getFullYear();
		console.log(month);
		$scope.getSectionHomeWork($scope.selectedSectionOb,monthId, yearId);
	}

$scope.selectedHomeWorksList = {};
$scope.showSlectedHomeWorkCategory =  function(homeCate){
	$scope.selectedHomeWorksList = homeCate;
}



$scope.selectStudentsBySection = function(){
	httpFactory.getResult("selectStudentsBySection?sectionId="+$scope.selectedSection+"&branchId="+$scope.branchId+"&schemaName="+$scope.schemaName, function(data) {
		console.log(data);
		if (data.StatusCode == 200) {
			$scope.studentList=data.sectionStudents;
			$("#subjectModal").modal("hide");
	}else{
		$scope.studentList=[];
	}
	});
}
$scope.closeSubjectPopup=function(){
	$("#subjectModal").modal("hide");
}
	$scope.getStudentsForHomeworkBySubject=function(){
		httpFactory.getResult("getStudentsForHomeworkBySubject?sectionId="+$scope.selectedSection+"&branchId="+$scope.branchId+"&isElective="+$scope.isElectiveVal+"&subjectId="+$scope.selectedSubjId+"&schemaName="+$scope.schemaName, function(data) {
		if (data.StatusCode == 200) {
		$scope.studentListHW=data.studentHomeWork;
				for (var i = 0; i < $scope.studentListHW.length; i++) {
					$scope.studentListHW[i]["checked"]="0";
					if($scope.studentListHW[i].profilePic == 'NA'){
						$scope.studentListHW[i].profilePicPath = "";
					}
					else{
						$scope.studentListHW[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+$scope.studentListHW[i].profilePic;
					}
				}
				console.log($scope.studentListHW);
			}else{
				$scope.studentListHW=[];
				alert("No students for elective");
			}
		});
	}
	$scope.checking=function(){
		alert("cheked");
	}
	$scope.selectAllStudentsForHW = function(){
		$scope.studentsArr=[];
		for (var i = 0; i < $scope.studentListHW.length; i++) {
			$scope.studentListHW[i].checked=1;
			$scope.studentsArr.push($scope.studentListHW[i].studentId);
		}
	}
	
	$scope.individualStudentsForHw=function(){
		for (var i = 0; i < $scope.studentListHW.length; i++) {
			$scope.studentListHW[i].checked=0;
		}
		$scope.studentsArr=[];
		console.log($scope.studentsArr);
	}
	$scope.getHomeWorkTypes=function(){
		httpFactory.getResult("getHomeWorkTypes?schemaName="+$scope.schemaName, function(data) {
		if (data.StatusCode == 200) {
		$scope.homeworkTypes=data.HomeWorkTypes;
		console.log($scope.homeworkTypes);

		}else{
		}
		});
	}
	$scope.selectedSubject=function(subj,isElective){
		console.log(subj);
		if (typeof subj=='string')
		$scope.selSubj = JSON.parse(subj);
		else
		$scope.selSubj=subj;

		$scope.isElectiveVal = $scope.selSubj.isElective;;
		$scope.selectedSubjId=$scope.selSubj.subjectId;
		$scope.selectedSubjectName = $scope.selSubj.subjectName;
		$scope.getChapterTopicsBySubjectChange($scope.selSubj);
		$scope.getStudentsForHomeworkBySubject();
	}

	$scope.insertHomework=function(){
		$scope.descriptionVal = document.getElementById("Description").value;
		$scope.submissionDate=document.getElementById("submissionDate").value;
		if(!$scope.descriptionVal || !$scope.submissionDate || !$scope.selectedSubjId || $scope.studentsArr.length==0){
			alert("Enter all fields");
		}else{
			$scope.saveHomework();
		}
	}

	$scope.studentsArr=[];
	$scope.studentSelected=function(studentStatus){
		console.log(studentStatus);
		if ($scope.studentsArr.includes(studentStatus.studentId)) {
			const index = $scope.studentsArr.indexOf(studentStatus.studentId);
			if (index !== -1) {
				$scope.studentsArr.splice(index, 1);
			}
		}else{
			$scope.studentsArr.push(studentStatus.studentId);
		}
		console.log($scope.studentsArr);
		if($scope.studentsArr.length!=0){
		  if($scope.studentsArr.length == $scope.studentListHW.length){
			 $('#allRadioId').prop("checked", true);
		  }else{
			 $('#individualRadioId').prop("checked", true);
		  }
		}else{
		   $('#allRadioId').prop("checked", false);
		   $('#individualRadioId').prop("checked", false);
		}
	}


	$scope.fileSizeCheck = function(){
		var files = document.getElementById("choosenFile").files;
		if(files[0] == undefined){
			return false;
		}else{
		for(var i=0; i<files.length; i++){
				if (((files[i].size)/1024) >= 4096) {
					alert("File "+files[i].name +" is too Big, please select a file less than 4mb");
					return  true;
				}
			}
		}
	}
 $scope.editfileSizeCheck = function(){
		var files = document.getElementById("choosenEditFile").files;
		if(files[0] == undefined){
			return false;
		}else{
		for(var i=0; i<files.length; i++){
				if (((files[i].size)/1024) >= 4096) {
					alert("File "+files[i].name +" is too Big, please select a file less than 4mb");
					return  true;
				}
			}
		}
	}

	$scope.uploadHW = function(){
		var files = document.getElementById("choosenFile").files;
		if(files[0] == undefined){
			return true;
		}
		console.log(files);
		var fd = new FormData();

		fd.append("HWID", $scope.HWID);
		fd.append("schemaName",$scope.schemaName)
		for(var i=0; i<files.length; i++){
			var blob = files[i].slice(0, files[i].size, files[i].type); 
	    	var newFile = new File([blob], files[i].name.replaceAll(/[^a-zA-Z0-9.]/g,"-"), {type: files[i].type});
			fd.append("file", newFile);
		}
		httpFactory.executeFileUpload("uploadHomeWork", fd, function(data) {
			console.log(data);
			document.getElementById("choosenFile").value = "";
		});
	}
		$scope.uploadEditHW = function(){
			var files = document.getElementById("choosenEditFile").files;
			if(files[0] == undefined){
				return true;
			}
			console.log(files);
			var fd = new FormData();

			fd.append("HWID", $scope.HWID);
			fd.append("schemaName",$scope.schemaName)
			for(var i=0; i<files.length; i++){
				var blob = files[i].slice(0, files[i].size, files[i].type); 
		    	var newFile = new File([blob], files[i].name.replaceAll(/[^a-zA-Z0-9.]/g,"-"), {type: files[i].type});
				fd.append("file", newFile);
			}

			console.log(fd);

			httpFactory.executeFileUpload("uploadHomeWork", fd, function(data) {
				console.log(data);
				document.getElementById("choosenEditFile").value = "";
			//	$scope.downLoadHw();
			});
		}

	$scope.downLoadHw = function(fPath, ftype){
		    if(typeof fPath == 'string'){
		       var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+fPath+"&embedded=true";
		       window.open(path);
		    }
		    else{
			for(i=0;i<fPath.length;i++){
				var path = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/HomeWorkFileDownLoad?filePath="+fPath[i]+"&embedded=true";
				window.open(path);
			}
			}
		}
	$scope.closeDownloadHw = function(){
			$("#homeworkModalPopup").modal("hide");
	}
	$scope.downLoadHw1 = function(){
		window.open((localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/fileDownLoad1");
	}

	$scope.removeAttchmentConformation = function(attachId, HwId){
		var r = confirm("Do you want delete HomeWork Permanently");
		if(r == true){
				httpFactory.getResult("HWFileDelete?schemaName="+$scope.schemaName+"&homeworkId="+ HwId +"&attachementId="+attachId, function(data) {
					console.log(data);
				if (data.StatusCode == 200) {
					for(var i=0; i<$scope.editHomeworkOb.filesDetails.length;i++){
						if($scope.editHomeworkOb.filesDetails[i].attachmentId == attachId){
							$scope.editHomeworkOb.filesDetails.splice(i,1);
							i--;
						}
					}
					console.log($scope.editHomeworkOb);
					alert("Deleted successfully");
					$scope.getSectionHomeWork($scope.selectedSectionOb);
				}else{
					// $scope.homeworkTypes=[];
				}
				});
		}
		else{
			alert("Cancelled");
		}
	}

	$scope.AllowAdding = true;
	$scope.saveHomework = function(){
		if($scope.fileSizeCheck() == true){
			return true;
		}
		debugger;
		$scope.AllowAdding = false;
		//alert("hot here");
		var requestParams = {
		"schemaName":$scope.schemaName,
		"sectionId":$scope.selectedSection,
		"subjectId":$scope.selectedSubjId,
		"branchId":$scope.branchId,
		"homeWorktypeId":$scope.selectedHWType,
		"homeworkDetail":$scope.descriptionVal,
		"submissionDate":$scope.submissionDate,
		"createdBy":localStorage.getItem("userId"),
		"studentArray":$scope.studentsArr
		}

		if($scope.selTopicId){
			requestParams["chapterId"]=$scope.selectedChpId;
			requestParams["topicId"]=$scope.selTopicId;
		}

		httpFactory.executePost("insertSectionHomework", requestParams, function(data) {
		 // alert("in");
		 console.log(data);
			if (data.StatusCode == "200") {
				$scope.respose1 = data;
				$scope.HWID = data.HWID;
				$scope.uploadHW();
				console.log($scope.respose1);
				$scope.submissionDate="";
				$scope.descriptionVal="";
				document.getElementById("Description").value="";
				document.getElementById("submissionDate").value="";
				$scope.studentsArr=[];
				$scope.selectedSubjId=[];
				alert("HomeWork successfully Added");
				$scope.closePopUpHW();
				if(!$scope.myClasses)
				$scope.getSectionHomeWork($scope.selectedSectionOb);

			} else {
				// $scope.closePopUpHW();
				alert(data.MESSAGE);

			}
			$scope.AllowAdding = true;
		});
	}
	
	$scope.selectedHWTypeedit = {};
	$scope.updateHomework=function(){
		//$scope.editfileSizeCheck();
		if($scope.editfileSizeCheck() == true){
			return true;
		}
		var requestParams = {
		"schemaName":$scope.schemaName,
		"homeworkId":$scope.editHomeworkOb.homeworkId,
		"homeWorktypeId":$scope.selectedHWTypeedit.homeTypeId,
		"homeworkDetail":$scope.Description.trim(),
		"submissionDate":document.getElementById("editsubmissionDate").value,
		"updatedBy":localStorage.getItem("userId"),
		}
		httpFactory.executePost("updateSectionHomeworkDetails", requestParams, function(data) {
		 // alert("in");
		 console.log(data);
			if (data.StatusCode == "200") {
				$scope.HWID = $scope.editHomeworkOb.homeworkId;
				$scope.uploadEditHW();
				$scope.respose1 = data;
				$scope.submissionDate="";
				$scope.descriptionVal="";
				document.getElementById("Description").value="";
				document.getElementById("submissionDate").value="";
				$scope.studentsArr=[];
				$scope.selectedSubjId=[];
				$scope.getSectionHomeWork($scope.selectedSectionOb);
				alert("HomeWork successfully Updated");
				$scope.closePopUpHW();
			} else {
				// $scope.closePopUpHW();
				alert(data.MESSAGE);

			}
		});
	}

	$scope.closePopUpHW = function(){
		$("#addHomeWork").modal("hide");
		$("#editHomeWork").modal("hide");
		$("#ViewHomeWork").modal("hide");
		console.log($scope.navCourseId);
		if($scope.myClasses){
			sessionStorage.setItem("navCourseId",$scope.selectedCourse);
			sessionStorage.setItem("navClassId",$scope.selectedClassId);
			// sessionStorage.setItem("myClasses","myClasses");
			$location.path("/rankrClasses");
		}

	}
	$scope.goToMyClasses=function(){
		sessionStorage.setItem("navCourseId",$scope.selectedCourse);
		sessionStorage.setItem("navClassId",$scope.selectedClassId);
		$location.path("/rankrClasses");
	 }
// $scope.Description="";
	$scope.editHomeworkModal=function(){
		$("#ViewHomeWork").modal("hide");
		$("#editHomeWork").modal("show");
		$scope.Description = $scope.editHomeworkOb.homeworkDetail.trim();
		$scope.submDate=new Date($scope.editHomeworkOb.submissionDate);
		//$scope.selectedHWType = $scope.editHomeworkOb.homeworkId;
		console.log($scope.homeworkTypes);
		for(var i=0; i<$scope.homeworkTypes.length;i++){
			if($scope.homeworkTypes[i].homeTypeId == $scope.edithomeworkTypeId){
				$scope.selectedHWTypeedit = $scope.homeworkTypes[i];
				console.log($scope.selectedHWTypeedit);
			}
		}
	}


	$scope.getSectionHomeWork=function(section,month,yearId){
		console.log(section);
		console.log(month);
		$scope.assignList=[];
		$scope.selectedSectionOb=section;
		$scope.selectedSection=section.sectionId;
		var	year;
		var date=new Date();
		if(!yearId)
		 year = date.getFullYear();
		else
			year=yearId;

		if(!month)
		 month = date.getMonth()+1;

		httpFactory.getResult("getSectionHomeworkDetails?branchId="+$scope.branchId+"&sectionId="+$scope.selectedSection+"&schemaName="+$scope.schemaName+"&monthId="+month+"&yearId="+year, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.assignList = data.homeWorkDetails;
				console.log($scope.assignList);
				$scope.showSlectedHomeWorkCategory($scope.assignList[0]);
			}else{
				$scope.assignList=[];
			}
		});
		$scope.selectStudentsBySection();
	}

	$scope.viewHomeWork=function(homework,hometypId){
		console.log(homework);
		$scope.editHomeworkOb=homework;
		console.log($scope.editHomeworkOb);
	    $scope.hwDesc = [];
	    document.getElementById("hwDetail").innerHTML = "";
		hwDesc = $scope.editHomeworkOb.homeworkDetail.split(/\s+/);
		for(i=0;i<hwDesc.length;i++){
			if(new RegExp("([a-zA-Z0-9]+://)?([a-zA-Z0-9_]+:[a-zA-Z0-9_]+@)?([a-zA-Z0-9.-]+\\.[A-Za-z]{2,4})(:[0-9]+)?(/.*)?").test(hwDesc[i])){
				if(hwDesc[i].contains("https://")|| hwDesc[i].contains("http://")){
					var a = document.createElement('a');
					var linkText = document.createTextNode(hwDesc[i]);
					a.appendChild(linkText);
					a.title = "HomeWork Description";
					a.target = "_blank";
					a.href = hwDesc[i];
					document.getElementById("hwDetail").appendChild(a);
					document.getElementById("hwDetail").append(" ");
				}
				else{
				     hwDesc[i] = "https://" + hwDesc[i];
				     var a = document.createElement('a');
						var linkText = document.createTextNode(hwDesc[i]);
						a.appendChild(linkText);
						a.title = "HomeWork Description";
						a.target = "_blank";
						a.href = hwDesc[i];
						document.getElementById("hwDetail").appendChild(a);
						document.getElementById("hwDetail").append(" ");
				}
			}
			else{
				document.getElementById("hwDetail").append(hwDesc[i]);
				document.getElementById("hwDetail").append(" ");
			}
		}
		$scope.edithomeworkTypeId = hometypId;
		$("#ViewHomeWork").modal("show");
		$scope.getHomeWorkTypes();
		$scope.getStudentsForHomework();
	}
		
	$scope.getCurrentAcademicYear=function(){

		httpFactory.getResult("getCurrentAcademicYear?schemaName="+$scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {

			var startArr = data.startDate.split("-");
			var endArr = data.endDate.split("-");

			console.log(startArr);
			console.log(endArr);
			console.log(parseInt(startArr[1]));

			console.log($scope.monthsArr[parseInt(startArr[1])]);

			var str1 = $scope.monthsArr[parseInt(startArr[1])]+" "+startArr[0];
			var str2 = $scope.monthsArr[parseInt(endArr[1])]+" "+endArr[0];
			console.log(diff(str1, str2));
			$scope.academicMonthArr=diff(str1,str2);
			console.log($scope.academicMonthArr);
			var thisDate = new Date();
			for(var i=0; i<$scope.academicMonthArr.length; i++){
				if((thisDate.getMonth()+1) == $scope.academicMonthArr[i].monthIndex){
					$scope.selectMonObj = $scope.academicMonthArr[i];
					$scope.selectMonth($scope.selectMonObj);
					break;
				}
			}

			}else{
			}
		});
	}


	function diff(from, to) {
	    var arr = [];
	    var datFrom = new Date('1 ' + from);
	    var datTo = new Date('1 ' + to);
	    var fromYear =  datFrom.getFullYear();
	    var toYear =  datTo.getFullYear();
	    var diffYear = (12 * (toYear - fromYear)) + datTo.getMonth();

	    for (var i = datFrom.getMonth(); i <= diffYear; i++) {
	    	console.log(i);
	    	/*if(i>11)*/
	    		$scope.index=i%12;
	    		
	    	/*else
	    	$scope.index=i;*/

	    	var params= {
	    			"monthName":$scope.monthsArr[i%12] + " " + Math.floor(fromYear+(i/12)),
	    			"monthIndex":$scope.index+1,
	    	}
	        arr.push(params);
	    }

	    return arr;
	}

	$scope.getStudentsForHomework=function(){

		httpFactory.getResult("getStudentsForHomework?branchId="+$scope.branchId+"&sectionId="+$scope.selectedSection+"&schemaName="+$scope.schemaName+"&homeworkId="+$scope.editHomeworkOb.homeworkId, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.editHwStuList = data.homeworkStudentsStatus;
				for(var i=0; i<$scope.editHwStuList.length; i++){
          if($scope.editHwStuList[i].profilePic == 'NA'){
            $scope.editHwStuList[i].profilePicPath = "";
          }
          else{
            $scope.editHwStuList[i].profilePicPath = (localStorage.getItem("domain").includes('ekalavya.online')?'https://':'http://')+localStorage.getItem("domain")+"/studentProfileDownload?filePath="+$scope.editHwStuList[i].profilePic;
          }
        }
			}else{
				$scope.editHwStuList=[];
			}
		});
	}
	$scope.studentHWupdateList = [];
	$scope.updateSubmitHW = function(stu,deleteFlag){
		console.log(stu);
		var found =0;
		var index=0;
		for (var i = 0; i < $scope.studentHWupdateList.length; i++) {
			if($scope.studentHWupdateList[i].studentId == stu.studentId){
				found=1;
				index=i;
				break;
			}
		}
		if (found==1) {
			if(deleteFlag){
				$scope.studentHWupdateList[index]["isSubmitted"]=0;
				$scope.studentHWupdateList[index]["isCompleted"]=0;
				$scope.studentHWupdateList[index]["isDeleted"]=1;

				$scope.studentHWupdateList[index]["submittedDate"]="2019-06-10";
				$scope.studentHWupdateList[index]["studentHomeWorkId"]=stu.studentHWId;
				$scope.studentHWupdateList[index]["teacherComments"]="IDK";
			}else{
			if($scope.studentHWupdateList[index].completed==0){
				$scope.studentHWupdateList[index]["isSubmitted"]=1;
				$scope.studentHWupdateList[index]["isCompleted"]=1;

				$scope.studentHWupdateList[index]["submittedDate"]="2019-06-10";
				$scope.studentHWupdateList[index]["studentHomeWorkId"]=stu.studentHWId;
				$scope.studentHWupdateList[index]["teacherComments"]="IDK";
			}else{
				$scope.studentHWupdateList[index]["isSubmitted"]=0;
				$scope.studentHWupdateList[index]["isCompleted"]=0;

				$scope.studentHWupdateList[index]["submittedDate"]="2019-06-10";
				$scope.studentHWupdateList[index]["studentHomeWorkId"]=stu.studentHWId;
				$scope.studentHWupdateList[index]["teacherComments"]="IDK";
			}
		}
		}else{
			console.log(stu.completed);
			if(deleteFlag){
				var ob = {
					"studentHomeWorkId":stu.studentHWId,
					"studentId":stu.studentId,
					"teacherComments":"IDK",
					"submittedDate":"2019-06-06",
					"isSubmitted":0,
					"isCompleted":0,
					"isDeleted":1
				}
				console.log(ob);
				$scope.studentHWupdateList.push(ob);
				console.log($scope.studentHWupdateList);
			}else{
			if(stu.completed==1){
				var ob = {
					"studentHomeWorkId":stu.studentHWId,
					"studentId":stu.studentId,
					"teacherComments":"IDK",
					"submittedDate":"2019-06-06",
					"isSubmitted":1,
					"isCompleted":1
				}
				console.log(ob);
				$scope.studentHWupdateList.push(ob);
				console.log($scope.studentHWupdateList);
			}
		else{
				var ob = {
					"studentHomeWorkId":stu.studentHWId,
					"studentId":stu.studentId,
					"teacherComments":"IDK",
					"submittedDate":"2019-06-06",
					"isSubmitted":0,
					"isCompleted":0
				}
				console.log(ob);
				$scope.studentHWupdateList.push(ob);
				console.log($scope.studentHWupdateList);
			}
			console.log($scope.studentHWupdateList);
			}
		}

	}

	$scope.updateCompletehw=function(stu){
		console.log(stu);
		var found =0;
		var index=0;
		for (var i = 0; i < $scope.studentHWupdateList.length; i++) {
			if($scope.studentHWupdateList[i].studentId == stu.studentId){
				found=1;
				index=i;
				break;
			}
		}
		if (found==1) {
			$scope.studentHWupdateList[index]["isSubmitted"]=1;
			$scope.studentHWupdateList[index]["isSubmitted"]="2019-06-10";
		}else{
		var ob = {
			"studentHomeWorkId":stu.studentHWId,
			"studentId":stu.studentId,
			"studentId":stu.studentId,
			"teacherComments":"IDK",
			"submittedDate":"2019-06-06",
			"isSubmitted":1,
			"isCompleted":1
		}
		console.log(ob);
		$scope.studentHWupdateList.push(ob);
	 }
	 console.log($scope.studentHWupdateList);
   }

    $scope.updateAssignHW = function(stu){
    	var ob ={
           "studentHomeWorkId":stu.studentHWId,
           "studentId":stu.studentId
        }
		console.log(ob);
		if($scope.studentHWupdateList.length>0){
			var index = $scope.studentHWupdateList.findIndex(x => x.studentId==stu.studentId);
			if (index == -1){
			  $scope.studentHWupdateList.push(ob);
			}else{
			  $scope.studentHWupdateList.splice(index, 1);
			  $scope.studentHWupdateList.push(ob);		
			}
		}else{
		  $scope.studentHWupdateList.push(ob);	
		}
		console.log($scope.studentHWupdateList);
	}

	$scope.updateSubmitHWApi = function(){
		var params = {
	"schemaName" : $scope.schemaName,
	 "updatedBy":$scope.userId,
	 "sectionId":$scope.selectedSection,
	 "branchId":$scope.branchId,
	"homeWorkId":$scope.editHomeworkOb.homeworkId,
 	"updateRecords":$scope.studentHWupdateList
	}
	console.log(params);
	httpFactory.executePost("updateStudentHomeworkStatus", params, function(data) {
	 console.log(data);
		if (data.StatusCode == "200") {
			$scope.respose1 = data;
			alert("Homework successfully updated");
			$scope.studentHWupdateList=[];
			$scope.getSectionHomeWork($scope.selectedSectionOb);
		} else {
			alert("Something went wrong.try again!");
			//TODO : Show Error

		}
	});
	}
	$scope.sectionWiseSendSMS=function(homework,tag,lang){
		var params= {
				"sectionId":$scope.selectedSection,
				"branchId":$scope.branchId,
				"schemaName":$scope.schemaName,
				"chapterName":homework.chapterName,
				"topicName":homework.topicName,
				"homeworkDetail":homework.homeworkDetail,
				"subjectName":homework.subjectName,
				"submissionDate": homework.submissionDate,
				"homeworkId": homework.homeworkId
		}
		if (tag=="sms") {
			params["SMSNotification"]=1;
		}else if(tag=="notif"){
			params["pushNotification"]=1;
		}
		else if(tag=="whatsApp"){
			params["whatsApp"]=1;
			params["lang"] = lang;
		}

		httpFactory.executePost("sendStudentHomeworkSMSNotificationBySection", params, function(data) {
			console.log(data);
			if (data.StatusCode == "200") {
				alert(data.MESSAGE);
				//					$scope.studentHWupdateList=[];
				//					$scope.getSectionHomeWork($scope.selectedSectionOb);
			} else {
				alert(data.MESSAGE);
				//TODO : Show Error

			}
		});
	}

	$scope.classWiseSMS=function(){
		var today = new Date();
		var params = {
					"classId":$scope.selectedClassId,
					"branchId":$scope.branchId,
					"courseId":$scope.selectedCourse,
					"schemaName":$scope.schemaName,
					"date":today.getFullYear()+"-"+(today.getMonth()+1)+"-"+today.getDate(),
					"SMSNotification":"YES",
					"pushNotification":"YES"
		}
		httpFactory.executePost("sendStudentHomeworkSMSNotificationByClass", params, function(data) {
			 console.log(data);
				if (data.StatusCode == "200") {
					alert(data.MESSAGE);
//					$scope.studentHWupdateList=[];
//					$scope.getSectionHomeWork($scope.selectedSectionOb);
				} else {
					alert("Something went wrong.try again!");
					//TODO : Show Error
				}
			});
	}

	$scope.getChapterTopicsBySubjectChange = function(selSubj){
		console.log(selSubj);
		var contentType = $scope.selCourseName+","+selSubj.contentType;
		httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selectedClassId + "&subjectId="+selSubj.subjectId+"&schemaName="+$scope.schemaName+"&contentOwner=CEDZ,COLLEGE&contentType="+contentType+"&branchId="+$scope.branchId+"&courseId="+$scope.selectedCourse+"&instId="+$scope.instituteId, function(data) {
			console.log(data);
			if (data.STATUS == 'SUCCESS' || data.StatusCode==200) {
				$scope.chapterListBySub = data.Chaptertopics;
				console.log($scope.chapterListBySub);
			}
		});
	}

	$scope.selectedChapter=function(chap){
		console.log(chap);
		if(typeof chap=='string')
		$scope.topicList=JSON.parse(chap);
		else
		$scope.topicList=chap;

			$scope.selectedChpId=$scope.topicList.chapterId;
		console.log($scope.topicList);
	}

	$scope.selectedTopic=function(tpc){
		console.log(tpc);

		if(typeof tpc=='string')
			$scope.selTopicList=JSON.parse(tpc);
			else
			$scope.selTopicList=tpc;

			console.log($scope.selTopicList);
			$scope.selTopicId=$scope.selTopicList.topicId;

		}


	function monthDiff(d1, d2) {
	    var months;
	    months = (d2.getFullYear() - d1.getFullYear()) * 12;
	    months -= d1.getMonth() + 1;
	    months += d2.getMonth();
	    return months <= 0 ? 0 : months;
	}

$scope.deleteHomework = function(homework) {
		httpFactory.getResult("deleteHomework?homeworkId="+ homework.homeworkId +"&schemaName=" + $scope.schemaName, function(data) {
			console.log(data);
			if (data.StatusCode == 200) {
				alert(data.MESSAGE);
				$scope.getSectionHomeWork($scope.selectedSectionOb)
			} else{
				alert(data.MESSAGE);
			}
		});
	}
/*var hwDescClickable = document.createElement('hwDetail');
hwDescClickable.id =" "+hwDescription;
hwDescClickable.href = " "+hwDesc[i]; 
document.getElementById('hwDescription').click();*/

$scope.goToDashbord = function(){
	$location.path("rankrPlus");
}


});
