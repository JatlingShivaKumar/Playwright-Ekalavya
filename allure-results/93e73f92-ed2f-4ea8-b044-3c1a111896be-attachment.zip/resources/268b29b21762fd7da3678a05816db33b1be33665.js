projectModule.controller('totalContentManagementController', function ($scope, $location, commonFactory, httpFactory, $routeParams, $sce) {
    $scope.$ = $;
    $scope.roleId = localStorage.getItem("RD");
    $scope.instituteId = localStorage.getItem("inst_id");
    $scope.schemaName = localStorage.getItem("sname");
    $scope.selInstCrsCls = localStorage.getItem("classId");
    $scope.selSubjId = localStorage.getItem("subId")
    $scope.branchId = localStorage.getItem("bnchId");
    $scope.userId = localStorage.getItem("userId");
    $scope.roleId = localStorage.getItem("RD");
    $scope.courseList = [];
    $scope.categoryList = [];
    $scope.localDomain = localStorage.getItem("domain");
    $scope.contentChapterInit = function () {
        $scope.changeBranch();

    }
    // $scope.destChapterList = localStorage.getItem("domain");
    // $scope.chapterList;

    $scope.changeQuesTag = 0;
    $scope.ownerCont = "COLLEGE";

    $scope.redirectToAddQuestionsContent = function () {
        console.log($scope.contentOwnerList);
        $("#addquesModal").modal("show");
    }
    $scope.changeBranch = function () {
        httpFactory.getResult("getCourseBranchId?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.courseList = data.Courses;
                if ($scope.courseList.length == 1) {
                    $scope.courseSelect = $scope.courseList[0];
                }
                console.log($scope.courseList);
                $scope.courseChange($scope.courseSelect);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.courseChange = function (course) {
        $scope.chapterList = [];
        $scope.courseId = course.courseId;
        $scope.courseName = course.courseName;
        $scope.getClassByCourseId();
        $scope.getContentOwner();
        $scope.subjList = [];
        $scope.selectedSbj = "";
        $scope.selInstCrsCls = 0;
        $scope.selSubjId = 0;
        $scope.contentOb = {};
        $scope.selContentType = "";
    }

    $scope.classChange = function (classObj) {
        $scope.chapterList = [];
        $scope.classId = classObj.classId;
        $scope.selInstCrsCls = $scope.classId;
        $scope.displayLessonPlan = classObj.isLPAssigned==1?true:false;
        $scope.classCourseId = classObj.classCourseId;
        $scope.selSubjId = 0;
        $scope.selContentType = "";
        $scope.contentOb = {};
        $scope.getSubjectsByClassChange();
    }

    $scope.subjectChange = function () {
        $scope.chapterList = [];
        console.log($scope.selectedSbj);
        $scope.selSubjId = $scope.selectedSbj.subjectId;
        console.log($scope.selSubjId);
        $scope.selContentType = "";
        $scope.contentOb = {};
        $scope.getSuperAdminUserId();
    }

    $scope.getClassByCourseId = function () {
        httpFactory.getResult("getClassByCoursesID?branchId=" + $scope.branchId + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.classList = data.Classes;
                var classes = data.Classes;
                $scope.classList = [];
                for (var i = 0; i < classes.length; i++) {
                    if (classes[i].isActive == 1) {
                        $scope.classList.push(classes[i]);
                    }
                }
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.getContentOwner = function () {
        httpFactory.getResult("selectContentOwner?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentOwnerList = [];
                $scope.contentList = data.ContentOwner;
                for (var i = 0; i < $scope.contentList.length; i++) {
                    if ($scope.contentList[i].courseId == "" + $scope.courseId) {
                        $scope.contentOwnerList.push($scope.contentList[i]);
                    }
                }
            } else {
                console.log("No ContentList");
            }
        });
    }



    $scope.getSubjectsByClassChange = function () {
        httpFactory.getResult("getCourseClassSubjects?classId=" + $scope.classId + "&courseId=" + $scope.courseId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + localStorage.getItem("bnchId"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.subjList = data.Classes;
            } else { }
        });
    }


    $scope.destClassChange = function (classObj) {
        $scope.destChapterList = [];
        $scope.destclassId = classObj.classId;
        $scope.destClassCourseId = classObj.classCourseId;
        $scope.getDestSubjectsByClassChange();
    }
    $scope.getDestSubjectsByClassChange = function () {
        httpFactory.getResult("getCourseClassSubjects?classId=" + $scope.destclassId + "&courseId=" + $scope.courseId + "&schemaName=" + localStorage.getItem("sname") + "&branchId=" + localStorage.getItem("bnchId"), function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.destsubjList = data.Classes;
                console.log($scope.destsubjList);
            } else { }
        });
    }
    $scope.getDestChapterTopicsBySubject = function (subjectId) {
        $scope.cedzDb = "CEDZ";
        $scope.contentOwner = "COLLEGE" + ',' + $scope.cedzDb;
        var contentType = $scope.courseName + "," + $scope.selContentType;
        httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selInstCrsCls + "&subjectId=" + subjectId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&contentType= " + contentType + "&branchId=" + localStorage.getItem("bnchId") + "&courseId=" + $scope.courseId + "&instId=" + $scope.instituteId, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.destChapterList = data.Chaptertopics;
                if ($scope.destChapterList.length > 0) {
                    console.log("CHAPTER LIST--> " + $scope.destsubjList);
                } else {
                    alert("No Chapters");
                }
            } else {
                alert("No Chapters");
            }
        });
    }

    $scope.contentSelectMethod = function (content) {
        console.log(content);
        $scope.chapterList = [];
        $scope.contentType = content.contentType;
        $scope.selContentType = content.contentType;
        $scope.selContentSchema = content.contentSchema;
        console.log($scope.contentType);
    }
    $scope.getChapterTopicsBySubjectChangeques = function (subjectId) {
        angular.element("#smallLoader").show();
        console.log("class ID " + $scope.selInstCrsCls);
        console.log("subject ID " + $scope.selSubjId);
        console.log("ContentType " + $scope.selContentType);
        console.log("courseId" + $scope.courseId);
        setTimeout(function () {
            $scope.cedzDb = "CEDZ";
            $scope.contentOwner = "COLLEGE" + ',' + $scope.cedzDb;
            var contentType = $scope.courseName + "," + $scope.selContentType;
            if ($scope.selInstCrsCls > 0 && $scope.selSubjId > 0 && $scope.selContentType.length > 0) {
                httpFactory.getResult("getChapterTopicsBySubId?classId=" + $scope.selInstCrsCls + "&subjectId=" + $scope.selSubjId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&contentType=" + contentType + "&branchId=" + localStorage.getItem("bnchId") + "&courseId=" + $scope.courseId + "&instId=" + $scope.instituteId, function (data) {
                    console.log(data);
                    if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                        $scope.chapterListByClassSubject = data.Chaptertopics;
                        $scope.chapterList = data.Chaptertopics;
                        if ($scope.chapterList.length > 0) {
                            $scope.chapterClick($scope.chapterList[0]);
                            var topic = $scope.chapterList[0].Topics[0];
                            $scope.chapterTopicClick($scope.chapterList[0].chapterschemaName, $scope.chapterList[0].Topics[0]);
                            $scope.activeTpcTab = 'video';
                            console.log($scope.chapterListByClassSubject);
                        } else {
                            angular.element("#smallLoader").hide();
                            alert("No Chapters");
                        }
                    } else {
                        angular.element("#smallLoader").hide();
                        alert("No Chapters");
                    }
                });
            } else {
                angular.element("#smallLoader").hide();
                alert("Please Enter Fields");
            }
        }, 100)
    }
    $scope.chapterClick = function (chapter) {
        $scope.selChapterId = chapter.chapterId;
        $scope.selChpterName = chapter.chapterName;
    }
    $scope.chapterTopicClick = function (chapterSCN, topic) {
        if (topic == undefined) {
            angular.element("#smallLoader").hide();
            $scope.$apply();
        } else {
            $scope.selTopicId = topic.topicId;
            $scope.topicSchemaName = chapterSCN;
            $scope.seltopicName = topic.topicName;
            $scope.selTpcOwnr = topic.topicOwner;
            angular.element("#smallLoader").show();
            setTimeout(function () {
                if (!$scope.lessonPlanTabs) {
                    $scope.getTopicVideos();
                    $scope.getTopicContent();
                    $scope.getQAIDsList();
                    //$scope.getQuestionAndAnswers();
                    $scope.getChapterAnnexure();
                    $scope.getQuestionsByTopicId();
                    $scope.getTextbookFilesByTopic();
                } else {
                    $scope.getLessonPlanDetails();
                }
                angular.element("#smallLoader").hide();
                $scope.$apply();

            }, 500);
        }
    }
    $scope.lviewexpand = true;
    $scope.toogleSide = function () {
        $('.togglesidebar').toggleClass('is-collapsed');
        $('.togglecontent').toggleClass('is-full-width');
        // $('.togglebtn').toggleClass('fa-chevron-right');
        $scope.lviewexpand = !$scope.lviewexpand;
    }

    $scope.lviewstate = true;
    $scope.expandToggle = function (lview) {
        $scope.lviewstate = lview;

    }



    $scope.closePopUp = function () {
        $scope.getQuestionsByTopicId();
    }
    $scope.getChapterAnnexure = function () {
        httpFactory.getResult("getChapterAnnexure?chapterId=" + $scope.selChapterId + "&contentOwner=" + $scope.selTpcOwnr + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = data.chapterAnnexure[0];
                console.log($scope.annexureOb);
                $scope.annexureObEdit = data.chapterAnnexure[0];

                $scope.annexContent = $scope.annexureOb.annexureContent;


            } else {
                $scope.annexureOb = {};
                $scope.annexureObEdit = {};
                $scope.annexContent = '';
                // alert(data.MESSAGE);
            }
        });
    }
    $scope.annexureOb = {};
    $scope.openAnnextureEdit = function () {
        $("#openAnnextureEdit").modal("show");
    }
    $scope.openAnnextureAdd = function () {
        $scope.annexureOb = {
            "annexureContent": ''
        };
        $("#openAnnextureAdd").modal("show");
    }

    //$scope.annextureAdd
    $scope.annextureAdd = function () {
        var quesParams = {
            "schemaName": $scope.schemaName,
            "insertRecords": [{
                "chapterId": $scope.selChapterId,
                "topicId": $scope.selTopicId,
                "subjectId": $scope.selSubjId,
                "annexureContent": $scope.annexureOb.annexureContent,
                "contentOwner": $scope.selTpcOwnr,
                "contentType": $scope.selContentType,
                "createdBy": localStorage.getItem("userId"),
            }]
        };
        httpFactory.executePost("addChapterAnnexure", quesParams, function (data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = $scope.annexureObEdit;

                $scope.annexContent = $scope.annexureObEdit.annexureContent

                alert("added Successfully");
                $("#openAnnextureAdd").modal("hide");
                $scope.getChapterAnnexure();

            } else {
                alert("Please Try Again");
            }

        });
    }
    $scope.annextureEdit = function () {
        var quesParams = {
            //"schemaName": $scope.ownerCont,
            "schemaName": $scope.schemaName,
            "updateRecords": [{
                "annexureId": $scope.annexureObEdit.annexureId,
                "annexureContent": $scope.annexureObEdit.annexureContent,
                "contentOwner": $scope.selTpcOwnr,
                "updatedBy": localStorage.getItem("userId")
            }]
        }
        httpFactory.executePost("updateChapterAnnexure", quesParams, function (data) {
            console.log(data);
            if (data.StatusCode == "200") {
                $scope.annexureOb = $scope.annexureObEdit;
                $scope.annexContent = $scope.annexureObEdit.annexureContent
                alert("Updated Successfully");
                $("#openAnnextureEdit").modal("hide");
            } else {
                alert("Please Try Again");
            }

        });
    }

    $scope.deleteChapterAnnexureModal = function () {
        $("#deleteChapterAnnexureModal").modal("show");
    }

    $scope.deleteChapterAnnexure = function () {
        httpFactory.getResult("deleteChapterAnnexure?annexureId=" + $scope.annexureObEdit.annexureId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.getChapterAnnexure($scope.annexureOb);
                alert(data.MESSAGE);
                $("#deleteChapterAnnexureModal").modal("hide");
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.getTopicContent = function () {
        $scope.contentData = [];
        httpFactory.getResult("getTopicContent?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.contentData = data;
                console.log($scope.contentData);
                $scope.topicContent = $scope.contentData.TextBookContent;
                console.log($scope.topicContent.length);
                console.log($scope.contentData);
            } else {
                console.log("No branches");
            }
        });
    }
    $scope.getTopicVideos = function () {
        $scope.videoContent = [];
        $scope.activeVideosCOTab = "PRIMARY";
        httpFactory.getResult("getTopicVideos?topicId=" + $scope.selTopicId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + $scope.courseId + "&courseName=" + $scope.courseName + "&instId=" + $scope.instituteId + "&subjectId=" + $scope.selSubjId, function (data) {
            console.log(data);
            if (data.StatusCode == 200 && data.TopicVideos.length > 0) {
                $scope.isContentOptional = data.TopicVideos[0].isContentOptional;
                if ($scope.isContentOptional == "1") {
                    $scope.pVideoContent = [];
                    $scope.sVideoContent = [];
                    for (i = 0; i < data.TopicVideos.length; i++) {
                        if (data.TopicVideos[i].videoContentType == 'PRIMARY') {
                            $scope.pVideoContent.push(data.TopicVideos[i]);
                        } else {
                            $scope.sVideoContent.push(data.TopicVideos[i]);
                        }
                    }
                    $scope.getBilingualLanguages();
                    /*$scope.activeVideosCOTab = "PRIMARY";*/
                    if ($scope.pVideoContent.length > 0) {
                        $scope.videoContent = $scope.pVideoContent;
                    }
                    else {
                        $scope.videoContent = $scope.sVideoContent;
                    }
                }
                else {
                    $scope.videoContent = data.TopicVideos;
                }
                if ($scope.videoContent[0] != undefined && $scope.videoContent[0].videoLink != 'NA') {
                    $scope.getVideoPlay($scope.videoContent[0]);
                }
                console.log($scope.videoContent);
            } else {
                $scope.pVideoContent = [];
                $scope.sVideoContent = [];
                $scope.videoContent = [];
                console.log("No Videos");
            }
        });
    }
    $scope.getVideoPlay = function (video) {
        console.log(video);
        $scope.videoLinkToPlay = video.videoLink;
        if ($scope.videoLinkToPlay.indexOf('youtu') >= 0) {
            $scope.videoLinkToPlay = "https://youtube.com/embed/" + $scope.videoLinkToPlay.substr($scope.videoLinkToPlay.lastIndexOf('/') + 1);
        }
        //$scope.videoLinkToPlay = "https://www.youtube.com/embed/wCnUAKzAmVo";
        console.log($scope.videoLinkToPlay);
    }
    $scope.trustSrc = function (src) {
        return $sce.trustAsResourceUrl(src);
    }

    /*$scope.deleteQuestion = function(question, ind) {
        console.log(question);
        httpFactory.getResult("deleteQuestion?questionId=" + question.questionId + "&schemaName=" + $scope.schemaName, function(data) {
            console.log(data);
            if (data.StatusCode == "200") {
                alert("Success");
            } else {
                alert(data.MESSAGE);
            }
        });

    }*/

    $scope.getTextbookFilesByTopic = function () {
        $scope.studentToipicFilesDetails = [];
        httpFactory.getResult("getTextbookFilesByTopic?contentOwner='CEDZ','COLLEGE'&schemaName=" + $scope.schemaName + "&topicId=" + $scope.selTopicId + "&branchId=" + $scope.branchId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.studentToipicFilesDetails = data.files;
                console.log($scope.studentToipicFilesDetails);
                for (i = 0; i < $scope.studentToipicFilesDetails.length; i++) {
                    var filepath = $scope.studentToipicFilesDetails[i].filePath;
                    $scope.studentToipicFilesDetails[i]["filename"] = filepath.substr(filepath.lastIndexOf('_') + 1);
                    if (filepath.contains(".doc") || filepath.contains(".docx")) {
                        $scope.studentToipicFilesDetails[i]["fileimage"] = "../../assets/img/doc.png"
                    } else if (filepath.contains(".pdf")) {
                        $scope.studentToipicFilesDetails[i]["fileimage"] = "../../assets/img/pdf-icon.png"
                    } else if (filepath.contains(".pptx") || filepath.contains(".ppt")) {
                        $scope.studentToipicFilesDetails[i]["fileimage"] = "../../assets/img/pptx_icon.png"
                    } else {
                        $scope.studentToipicFilesDetails[i]["fileimage"] = "../../assets/img/img.png"
                    }
                }
            } else {
                // alert(data.MESSAGE);
            }
        });
    }
    $scope.viewTopicPdf = function (pdfIndx) {
        if (confirm('The file will be downloaded.')) {
            window.open((localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.studentToipicFilesDetails[pdfIndx].filePath);
        }
        //  	console.log(path);
        //  	$('#pdfFrameView').attr("src", path);
    }

    $scope.addPdfForTopicView = function () {
        $('#addPDfView').modal("show");
    }
    $scope.closeAddPdfForTopicView = function () {
        $('#addPDfView').modal("hide");
    }

    $scope.saveNewPdfFile = function () {
        var files = document.getElementById("pdfFile").files;
        console.log(files[0]);
        if (files[0] == undefined) {
            return true;
        }
        console.log(files);
        var blob = files[0].slice(0, files[0].size, files[0].type);
        //    	var newFile = new File([blob], files[0].name.replaceAll(/[&;*:?#%,~|]/g,"-"), {type: files[0].type});
        var newFile = new File([blob], files[0].name.replaceAll(/[^a-zA-Z0-9.]/g, "-"), { type: files[0].type });
        var fd = new FormData();
        //    	fd.append("PdfID", $scope.pdfTitleName);
        fd.append("schemaName", $scope.schemaName);
        fd.append("topicId", $scope.selTopicId);
        fd.append("chapterId", $scope.selChapterId);
        fd.append("contentOwner", "COLLEGE");
        fd.append("createdBy", localStorage.getItem("userId"));
        fd.append("file", newFile);
        if ($scope.roleId == 1) {
            fd.append("branchId", 0);
        }
        else {
            fd.append("branchId", $scope.branchId);
        }
        console.log(fd);
        if (newFile.name.contains(".pdf") || newFile.name.contains(".pptx") || newFile.name.contains(".ppt") || newFile.name.contains(".doc") || newFile.name.contains(".docx") || newFile.name.contains(".png") || newFile.name.contains(".jpg") || newFile.name.contains(".jpeg")) {
            if (files[0].size < 10485760) {
                httpFactory.executeFileUpload("uploadTextbookFile", fd, function (data) {
                    console.log(data);
                    document.getElementById("pdfFile").value = "";
                    //    				$scope.pdfTitleName = "";
                    alert("File added Successfully");
                    $scope.getTextbookFilesByTopic();
                    $('#addPDfView').modal("hide");
                });
            } else {
                alert("The file should be less than 10MB");
            }
        } else {
            alert("File not supported");
        }
    }

    $scope.showOnlineDiv = function (tab) {
        $scope.activeTpcTab = tab;
        if(tab == 'lessonPlanDocuments'){
            angular.element("#lessonPlanDocuments").show();
        }
    }
    $scope.questionsArray = [];
    $scope.getQuestionsByTopicId = function (subjectId) {
        $scope.collegeDb = localStorage.getItem("sname");
        $scope.cedzDb = "CEDZ";
        var branchId = $scope.branchId + "," + "0";
        $scope.contentOwner = $scope.cedzDb + ',' + $scope.collegeDb;
        console.log($scope.contentOwner);
        httpFactory.getResult("getQuestionsByTopicId?topicId=" + $scope.selTopicId + "&schemaName=" + localStorage.getItem("sname") + "&contentOwner=" + $scope.contentOwner + "&branchId=" + branchId, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS' || data.StatusCode == 200) {
                $scope.quest = data.Questions;
                $scope.ques = [
                    {
                        "questionArray": [],
                        "isCollege": 'false',
                        "contentOwner": $scope.cedzDb
                    },
                    {
                        "questionArray": [],
                        "isCollege": 'true',
                        "contentOwner": $scope.collegeDb
                    }
                ];
                console.log($scope.ques);
                $scope.activeCOTab = $scope.quest[0].contentOwner;
                for (var i = 0; i < $scope.quest.length; i++) {
                    for (var j = 0; j < $scope.quest[i].questionArray.length; j++) {
                        if ("CEDZ" == $scope.quest[i].questionArray[j].questionOwner) {
                            $scope.ques[0].questionArray.push($scope.quest[i].questionArray[j]);
                        } else {
                            $scope.ques[1].questionArray.push($scope.quest[i].questionArray[j]);
                        }
                    }
                }

                $scope.showCODiv($scope.ques[0].contentOwner, 0);
                $scope.coQues = 0;
            } else { }
        });
    }

    $scope.showCODiv = function (tab, indx) {
        $scope.activeCOTab = tab;
        console.log($scope.activeCOTab);
        $scope.coQues = indx;

        if (tab == 'EKALAVYA') {
            //$scope.selSchema = 'rankr';
            $scope.selSchema = $scope.schemaName;
        } else {
            $scope.selSchema = $scope.schemaName;
        }
        console.log($scope.selSchema);

        $scope.selectionQuesObject = [];
        $scope.destChapter = "";
        $scope.destTopic = "";
        $scope.selQuesToMove = [];
        $scope.changeQuesTag = 0;
    }
    $scope.showVideosCODiv = function (tab) {
        $scope.activeVideosCOTab = tab;
        $scope.selVideoType = tab;
        if (tab == "PRIMARY") {
            $scope.videoContent = $scope.pVideoContent;
            $scope.getVideoPlay($scope.videoContent[0]);
        }
        else if (tab == "SECONDARY") {
            $scope.videoContent = $scope.sVideoContent;
            $scope.getVideoPlay($scope.videoContent[0]);
        }
    }

    $scope.getBilingualLanguages = function () {
        $scope.videoContent = [];
        httpFactory.getResult("getBilingualLanguages?schemaName=" + $scope.schemaName + "&instId=" + $scope.instituteId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.bilingualLangDetails = data.BilingualLanguageDetails;
                $scope.primaryLanguageName = "English";
                $scope.secondaryLanguageName = $scope.bilingualLangDetails.bilingualLanguageName;
            }
        });
    }

    $scope.addQuestion = function () {
        console.log($scope.selChapterId);
        console.log($scope.selTopicId);
        console.log($scope.selectedSbj.subjectId);
        console.log($scope.selContentType);
        $("#addQuestion").modal("show");
        $scope.getSchemaContentOwner();
    }

    $scope.selAdvQuestion = {};
    $scope.editAdvanceQuestion = function (question) {
        console.log(question);
        $scope.selAdvQuestion = question;
        if ($scope.selAdvQuestion.questType == 'TOF') {
            if ($scope.selAdvQuestion.correctAnswer == 'true') {
                $scope.selAdvQuestion.correctAnswer = true;
            } else if ($scope.selAdvQuestion.correctAnswer == 'false') {
                $scope.selAdvQuestion.correctAnswer = false;
            }

            if ($scope.selAdvQuestion.correctAnswer == true) {
                $scope.trueOptionedit = true;
                $scope.falseOptionedit = false;
            } else {
                $scope.trueOptionedit = false;
                $scope.falseOptionedit = true;
            }
        }
        console.log($scope.selAdvQuestion);
        $("#editAdvanceQuestionModal").modal("show");
    }


    $scope.editQuestion = function (question) {
        console.log(question);
        console.log($scope.selChapterId);
        console.log($scope.selTopicId);
        console.log($scope.selectedSbj.subjectId);
        console.log($scope.selContentType);
        $scope.questId = question.questionId;
        $scope.question = question.question;
        console.log($scope.question);
        $scope.option1 = question.option1;
        $scope.option2 = question.option2;
        $scope.option3 = question.option3;
        $scope.option4 = question.option4;
        $scope.explanation = question.explanation;
        $scope.correctAnswer = question.correctAnswer;
        $scope.diffLevel = question.difficultyLevel;
        $("#editQuestionModal").modal("show");
    }

    $scope.getSchemaContentOwner = function () {
        httpFactory.getResult("getSchemaContentOwner?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.schemaContent = [];
                $scope.schemaContent = data.schemaContent;
                console.log($scope.schemaContent);
            } else {
                console.log("No ContentList");
            }
        });
    }

    $scope.getTestCategories = function () {
        $scope.selectedCategory = "";
        $scope.subjectList = [];
        if ($scope.categoryList.length == 0) {
            httpFactory.getResult("getTestCategories?instId=" + localStorage.getItem("inst_id") + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId, function (data) {
                console.log(data);
                if (data.STATUS == 'SUCCESS') {
                    $scope.categoryList = data.TestCategories;
                }
            });
        }
    }

    $scope.addQuestionForTopic = function () {
        console.log($scope.question);
        console.log($scope.option1);
        console.log($scope.correctAnswer);
        console.log($scope.questionCat);
        console.log($scope.selTopicId);
        console.log($scope.diffLevel);
        console.log($scope.selContentType);
        console.log($scope.selectedContentOwner);
        if (!$scope.explanation) {
            $scope.explanation = "NA";
        }

        if (!$scope.question || !$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer || !$scope.selTopicId || !$scope.diffLevel) {
            alert("Enter all fields");
        } else {
            var quesParams = {
                "schemaName": localStorage.getItem("sname"),
                "insertRecords": [{
                    "question": $scope.question,
                    "option1": $scope.option1,
                    "option2": $scope.option2,
                    "option3": $scope.option3,
                    "option4": $scope.option4,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "questionType": $scope.selContentType,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "instQuestion": "Y",
                    "createdBy": localStorage.getItem("userId"),
                    "contentOwner": "COLLEGE",
                    "subjectId": $scope.selectedSbj.subjectId,
                    "subjectName": $scope.selectedSbj.subjectName,
                    "questionOwner": "COLLEGE",
                }]
            };

            console.log(quesParams);
            httpFactory.executePost("addQuestion", quesParams, function (data) {
                console.log(data);
                if (data.STATUS == 'SUCCESS') {
                    alert("Success.Question added");

                    $scope.question = CKEDITOR.instances['question'].setData('');
                    $scope.option1 = CKEDITOR.instances['option1'].setData('');
                    $scope.option2 = CKEDITOR.instances['option2'].setData('');
                    $scope.option3 = CKEDITOR.instances['option3'].setData('');
                    $scope.option4 = CKEDITOR.instances['option4'].setData('');
                    $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                    $('#correctAnswer').prop('selectedIndex', 0);
                    // $('#questionCat').prop('selectedIndex',0);
                    $('#diffLevel').prop('selectedIndex', 0);
                    $('#testSubject').prop('selectedIndex', 0);
                    $('#testChapter').prop('selectedIndex', 0);
                    $('#testTopic').prop('selectedIndex', 0);
                    window.scrollTo(0, 0);
                    $("#addQuestion").modal("hide");
                } else {
                    alert("something went wrong");
                }
            });
        }
    }

    $scope.getQuestionTypesService = function () {
        httpFactory.getResult("getQuestionTypes?schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.questionTypeList = data.questionsArray;
            } else {
                // alert('No Courses Defined. ');
            }
        });
    }
    $scope.getQuestionTypesService();

    $scope.addAdvnceQuestion = function () {
        $scope.questionType = "";
        $("#addAdvanceQuestionModal").modal("show");
    }

    $scope.optionsArr = [];
    $scope.saveLocalParagraphQues = function () {
        var param = {
            "question": $scope.cpqquestion,
            "option1": $scope.option1,
            "option2": $scope.option2,
            "option3": $scope.option3,
            "option4": $scope.option4,
            "correctAnswer": $scope.correctAnswer

        };

        var exp;
        if ($scope.explanation == undefined) {
            exp = "NA";
        } else if ($scope.explanation.length == 0) {
            exp = "NA";
        } else {
            exp = $scope.explanation;
            $scope.explanation = "";
        }
        param["explanation"] = exp;
        console.log(param);
        $scope.optionsArr.push(param);
        console.log($scope.optionsArr);

        $scope.cpqquestion = "";
        $scope.option1 = "";
        $scope.option2 = "";
        $scope.option3 = "";
        $scope.option4 = "";
    }

    $scope.selectedAnswerForTOF = function (opt) {
        if (opt == '1') {
            $scope.TFOption = 'true';
        } else {
            $scope.TFOption = 'false';
        }
        console.log($scope.TFOption);
    }
    $scope.insertFoundationQuestion = function () {
        $scope.questionAdv = CKEDITOR.instances['questionAdv'].getData();
        $scope.option1 = "";
        $scope.option2 = "";
        $scope.option3 = "";
        $scope.option4 = "";
        $scope.explanation = CKEDITOR.instances['explanation'].getData();
        if ($scope.questionType == 'MAQ') {
            $scope.maqCrct = "";
            for (var i = 0; i < $scope.multiCorrectAnswer.length; i++) {
                if ($scope.maqCrct == "") {
                    $scope.maqCrct = $scope.multiCorrectAnswer[i];
                } else {
                    $scope.maqCrct += ',' + $scope.multiCorrectAnswer[i];
                }
                $scope.correctAnswer = $scope.maqCrct;
            }
        } else {
            $scope.correctAnswer = $("#correctAnswer").val();
        }
        $scope.questionCat = $("#questionCat").val();
        $scope.diffLevel = $("#diffLevel1").val();
        $scope.qstnAppeared = $("#questionAppeared").val();
        $scope.selectedSchema = localStorage.getItem("addQuescontentOwner");
        if ($scope.questionType == 'MCQ' || $scope.questionType == 'MAQ') {
            $scope.option1 = CKEDITOR.instances['option1'].getData();
            $scope.option2 = CKEDITOR.instances['option2'].getData();
            $scope.option3 = CKEDITOR.instances['option3'].getData();
            $scope.option4 = CKEDITOR.instances['option4'].getData();
        } else if ($scope.questionType == 'TOF') {
            $scope.correctAnswer = $scope.TFOption;
            console.log($scope.correctAnswer);
        } else if ($scope.questionType == 'ITQ') {
            $scope.option1 = CKEDITOR.instances['option1'].getData();
            $scope.correctAnswer = $scope.itqCorrectAns;
        } else if ($scope.questionType == 'FIB') {
            $scope.correctAnswer = $scope.FIBAnswer;
        } else if ($scope.questionType == 'MFQ') {

            $scope.correctAnswer = "NA";

            $scope.column1a = CKEDITOR.instances['column1a'].getData();
            $scope.column2a = CKEDITOR.instances['column2a'].getData();
            $scope.column3a = CKEDITOR.instances['column3a'].getData();
            $scope.column4a = CKEDITOR.instances['column4a'].getData();
            $scope.column5a = CKEDITOR.instances['column5a'].getData();

            console.log($scope.column4a);

            $scope.column1b = CKEDITOR.instances['column1b'].getData();
            $scope.column2b = CKEDITOR.instances['column2b'].getData();
            $scope.column3b = CKEDITOR.instances['column3b'].getData();
            $scope.column4b = CKEDITOR.instances['column4b'].getData();
            $scope.column5b = CKEDITOR.instances['column5b'].getData();

            if ($scope.column4a.length <= 0) {
                $scope.column4b = "NA";
                $scope.column4a = "NA";
            }
            if ($scope.column5a.length <= 0) {
                $scope.column5b = "NA";
                $scope.column5a = "NA";
            }
        }

        if ($scope.questionAdv == undefined || $scope.questionAdv == "") {
            alert("Please Add question");
            return true;
        }
        if ($scope.correctAnswer == undefined || $scope.correctAnswer == "") {
            alert("Please select correct answer");
            return true;
        }
        if ($scope.questionCat == undefined || $scope.questionCat == "") {
            alert("Please select question type");
            return true;
        }
        if ($scope.diffLevel == undefined || $scope.diffLevel == "") {
            alert("Please select Difficulty Level");
            return true;
        }



        if (!$scope.qstnAppeared) {
            $scope.qstnAppeared = "";
        }

        if ($scope.questionType == 'MFQ') {
            if (!$scope.MFQ4) {
                $scope.MFQ4 = "NA";
            }
            if (!$scope.MFQ5) {
                $scope.MFQ5 = "NA";
            }
            var requestParams = {
                "schemaName": $scope.schemaName,
                "instId": $scope.instituteId,
                "insertRecords": [{
                    "question": $scope.questionAdv,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "questionType": $scope.questionCat,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "contentOwner": $scope.selTpcOwnr,
                    "questionOwner": "COLLEGE",
                    "questionAppearedIn": $scope.qstnAppeared,
                    "questType": $scope.questionType,
                    "createdBy": localStorage.getItem("userId"),
                    "branchId": $scope.branchId,
                    "contentType": $scope.contentType,
                    "subjectId": $scope.selectedSbj.subjectId,
                    "options": [{
                        "columnA": $scope.column1a,
                        "columnB": $scope.column1b,
                        "correctAnswer": $scope.MFQ1
                    },
                    {
                        "columnA": $scope.column2a,
                        "columnB": $scope.column2b,
                        "correctAnswer": $scope.MFQ2
                    }, {
                        "columnA": $scope.column3a,
                        "columnB": $scope.column3b,
                        "correctAnswer": $scope.MFQ3
                    }, {
                        "columnA": $scope.column4a,
                        "columnB": $scope.column4b,
                        "correctAnswer": $scope.MFQ4
                    }, {
                        "columnA": $scope.column5a,
                        "columnB": $scope.column5b,
                        "correctAnswer": $scope.MFQ5
                    }
                    ]
                }]
            }
            console.log(requestParams);
        } else if ($scope.questionType == 'CPQ') {
            var requestParams = {
                "schemaName": $scope.schemaName,
                "instId": $scope.instituteId,
                "insertRecords": [{
                    "question": $scope.questionAdv,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "questionType": $scope.questionCat,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "contentOwner": $scope.selTpcOwnr,
                    "questionOwner": "COLLEGE",
                    "questionAppearedIn": $scope.qstnAppeared,
                    "questType": $scope.questionType,
                    "createdBy": localStorage.getItem("userId"),
                    "branchId": $scope.branchId,
                    "contentType": $scope.contentType,
                    "subjectId": $scope.selectedSbj.subjectId,
                    "options": $scope.optionsArr
                }]
            }
            console.log(requestParams);
        } else {
            var requestParams = {
                "schemaName": $scope.schemaName,
                "instId": $scope.instituteId,
                "insertRecords": [{
                    "question": $scope.questionAdv,
                    "option1": $scope.option1,
                    "option2": $scope.option2,
                    "option3": $scope.option3,
                    "option4": $scope.option4,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "questionType": $scope.questionCat,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "contentOwner": $scope.selTpcOwnr,
                    "questionOwner": "COLLEGE",
                    "questionAppearedIn": $scope.qstnAppeared,
                    "questType": $scope.questionType,
                    "createdBy": localStorage.getItem("userId"),
                    "contentType": $scope.contentType,
                    "subjectId": $scope.selectedSbj.subjectId,
                    "branchId": $scope.branchId
                }]
            }
        }
        console.log(requestParams);
        httpFactory.executePost("insertTopicQuestion", requestParams, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                // $(".modal-backdrop").remove();
                alert("inserted successfully")
                $scope.question = CKEDITOR.instances['question'].setData('');
                $scope.option1 = CKEDITOR.instances['option1'].setData('');
                $scope.option2 = CKEDITOR.instances['option2'].setData('');
                $scope.option3 = CKEDITOR.instances['option3'].setData('');
                $scope.option4 = CKEDITOR.instances['option4'].setData('');
                $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                $scope.questionAdv = "";
                if ($scope.questionType == "MFQ") {
                    $scope.column1a = CKEDITOR.instances['column1a'].setData('');
                    $scope.column2a = CKEDITOR.instances['column2a'].setData('');
                    $scope.column3a = CKEDITOR.instances['column3a'].setData('');
                    $scope.column4a = CKEDITOR.instances['column4a'].setData('');
                    $scope.column5a = CKEDITOR.instances['column5a'].setData('');

                    $scope.column1b = CKEDITOR.instances['column1b'].setData('');
                    $scope.column2b = CKEDITOR.instances['column2b'].setData('');
                    $scope.column3b = CKEDITOR.instances['column3b'].setData('');
                    $scope.column4b = CKEDITOR.instances['column4b'].setData('');
                    $scope.column5b = CKEDITOR.instances['column5b'].setData('');
                }
                $scope.correctAnswer = 0;
                document.getElementById("correctAnswer").value = 0;
                $('#diffLevel').prop('selectedIndex', 0);
                window.scrollTo(0, 0);
                $scope.optionsArr = [];
            } else { }
        });
    }



    $scope.insertFoundationQuestionContent = function () {
        console.log($scope.selAdvQuestion);
        console.log($scope.selAdvQuestion.question);
        var requestParams = {};
        if ($scope.selAdvQuestion.questType == 'MFQ') {
            requestParams = {
                "schemaName": $scope.schemaName,
                "insertRecords": [{
                    "questionId": $scope.selAdvQuestion.questionId,
                    "question": "Match the following",
                    "explanation": $scope.selAdvQuestion.explanation,
                    "correctAnswer": $scope.selAdvQuestion.correctAnswer,
                    "questionType": $scope.selAdvQuestion.questionType,
                    "difficultyLevel": $scope.selAdvQuestion.difficultyLevel,
                    "questType": $scope.selAdvQuestion.questType,
                    "updatedBy": localStorage.getItem("userId"),
                    "options": $scope.selAdvQuestion.questions
                }]
            }
            console.log(requestParams);
        } else {
            console.log($scope.selAdvQuestion);
            console.log($scope.selAdvQuestion.question);
            requestParams = {
                "schemaName": $scope.schemaName,

                "insertRecords": [{
                    "questionId": $scope.selAdvQuestion.questionId,
                    "question": $scope.selAdvQuestion.question,
                    "option1": $scope.selAdvQuestion.option1,
                    "option2": $scope.selAdvQuestion.option2,
                    "option3": $scope.selAdvQuestion.option3,
                    "option4": $scope.selAdvQuestion.option4,
                    "explanation": $scope.selAdvQuestion.explanation,
                    "correctAnswer": $scope.selAdvQuestion.correctAnswer,
                    "questionType": $scope.selAdvQuestion.questionType,
                    "difficultyLevel": $scope.selAdvQuestion.difficultyLevel,
                    "questType": $scope.selAdvQuestion.questType,
                    "updatedBy": localStorage.getItem("userId")
                }]
            }
        }
        console.log(requestParams);
        //updateTopicQuestions
        httpFactory.executePost("updateTopicQuestions", requestParams, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Success.Question Updated");
                // $scope.question = CKEDITOR.instances['question'].setData('');
                // $scope.option1 = CKEDITOR.instances['option1'].setData('');
                // $scope.option2 = CKEDITOR.instances['option2'].setData('');
                // $scope.option3 = CKEDITOR.instances['option3'].setData('');
                // $scope.option4 = CKEDITOR.instances['option4'].setData('');
                $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                $('#correctAnswer').prop('selectedIndex', 0);
                // $('#questionCat').prop('selectedIndex',0);
                $('#diffLevel').prop('selectedIndex', 0);

                window.scrollTo(0, 0);
                $("#editAdvanceQuestionModal").modal("hide");
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.editQuestionTopic = function () {
        console.log($scope.question);
        console.log($scope.option1);
        console.log($scope.correctAnswer);
        console.log($scope.questionCat);
        console.log($scope.selTopicId);
        console.log($scope.diffLevel);
        console.log($scope.selContentType);
        console.log($scope.selectedContentOwner);
        if (!$scope.explanation) {
            $scope.explanation = "NA";
        }
        if (!$scope.question || !$scope.option1 || !$scope.option2 || !$scope.option3 || !$scope.option4 || !$scope.correctAnswer || !$scope.selTopicId || !$scope.diffLevel) {
            alert("Enter all fields");
        } else {
            var quesParams = {
                "schemaName": localStorage.getItem("sname"),
                "updatedRecords": [{
                    "questionId": $scope.questId,
                    "question": $scope.question,
                    "option1": $scope.option1,
                    "option2": $scope.option2,
                    "option3": $scope.option3,
                    "option4": $scope.option4,
                    "explanation": $scope.explanation,
                    "correctAnswer": $scope.correctAnswer,
                    "questionType": $scope.selContentType,
                    "topicId": $scope.selTopicId,
                    "chapterId": $scope.selChapterId,
                    "difficultyLevel": $scope.diffLevel,
                    "instQuestion": "Y",
                    "createdBy": localStorage.getItem("userId"),
                    "contentOwner": "COLLEGE",
                    "subjectId": $scope.selectedSbj.subjectId,
                    "subjectName": $scope.selectedSbj.subjectName,
                    "questionOwner": "COLLEGE",
                }]
            };

            console.log(quesParams);
            httpFactory.executePost("updateQuestions", quesParams, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    alert("Success.Question added");

                    $scope.question = CKEDITOR.instances['question'].setData('');
                    $scope.option1 = CKEDITOR.instances['option1'].setData('');
                    $scope.option2 = CKEDITOR.instances['option2'].setData('');
                    $scope.option3 = CKEDITOR.instances['option3'].setData('');
                    $scope.option4 = CKEDITOR.instances['option4'].setData('');
                    $scope.explanation = CKEDITOR.instances['explanation'].setData('');
                    $('#correctAnswer').prop('selectedIndex', 0);
                    $('#diffLevel').prop('selectedIndex', 0);

                    window.scrollTo(0, 0);
                    $("#editQuestionModal").modal("hide");
                } else {
                    alert("something went wrong");
                }
            });
        }
    }
    $scope.addChapter = function () {
        $("#addChapterModal").modal("show");
    }

    $scope.addNewChapter = function () {
        var chapParams = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "instId": localStorage.getItem("inst_id"),
                "classId": $scope.classId,
                "contentType": $scope.courseName,
                "subjectId": $scope.selectedSbj.subjectId,
                "chapterName": $scope.chapterName,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId"),
                "chapterOwner": "COLLEGE",
                "branchId": localStorage.getItem("bnchId")
            }]
        };

        console.log(chapParams);
        httpFactory.executePost("addChapters", chapParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $scope.clearNgModels();
                $("#addChapterModal").modal("hide");
                alert("Successfully Chapter added");
                $scope.getChapterTopicsBySubjectChangeques();
            } else {
                alert("something went wrong, Please Try again Later");
            }
        });
    }

    $scope.updateChapter = function (chapterId, chapterName, chapIndex) {
        $("#updateChapterModal").modal("show");
        $scope.chapterName = chapterName;
        $scope.chapId = chapterId;
        $scope.updateChapIndex = chapIndex;
    }

    $scope.lockChapter = function (chapterId) {
        $scope.chapId = chapterId;
        httpFactory.getResult("lockChapter?isActive=0&chapterId=" + $scope.chapId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&updatedBy=" + $scope.userId + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            }
            $scope.clearNgModels();
            $scope.getChapterTopicsBySubjectChangeques();
        });
    }

    $scope.lockOrUnlockAllChapter = function (isActive) {
        var chaptersIDS = [];
        for (var i = 0; i < $scope.chapterList.length; i++) {
            if (isActive == 1) {
                if ($scope.chapterList[i].isChapterActive == 0) {
                    chaptersIDS.push($scope.chapterList[i].chapterId);
                }
            }
            else {
                if ($scope.chapterList[i].isChapterActive == 1) {
                    chaptersIDS.push($scope.chapterList[i].chapterId);
                }
            }
        }
        //var chaptersIds = chaptersIDS.join(",");
        var params = {
            "branchId": $scope.branchId,
            "chapterIds": chaptersIDS,
            "updatedBy": $scope.userId,
            "courseId": $scope.courseId,
            "schemaName": $scope.schemaName,
            "isActive": isActive
        }
        if (chaptersIDS.length > 0) {
            httpFactory.executePost("lockOrUnlockAllChapter?", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    alert("Chapters Locked/Unlocked Succesfully");
                }
                else {
                    alert(data.MESSAGE);
                }
                $scope.clearNgModels();
                $scope.getChapterTopicsBySubjectChangeques();
            });
        }
        else {
            alert("Nothing to update");
        }
    }

    $scope.unlockChapter = function (chapterId) {
        $scope.chapId = chapterId;
        httpFactory.getResult("lockChapter?isActive=1&chapterId=" + $scope.chapId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&updatedBy=" + $scope.userId + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            }
            $scope.clearNgModels();
            $scope.getChapterTopicsBySubjectChangeques();
        });
    }

    $scope.videoViewsById = function (videoLinkId) {
        var videoViewParams = {
            "schemaName": localStorage.getItem("sname"),
            "branchId": $scope.branchId,
            "videoLinkId": videoLinkId
        };
        httpFactory.executePost("videoViewsById", videoViewParams, function (data) {
            if (data.StatusCode == 200) {
                $scope.views_table = data.StudentViews;
                $("#videoViews").modal("show");
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.updateChapterName = function () {
        var chapParams = {
            "schemaName": localStorage.getItem("sname"),
            "updatedRecords": [{
                "chapterId": $scope.chapId,
                "chapterName": $scope.chapterName
            }]
        };

        console.log(chapParams);
        httpFactory.executePost("updateChapters", chapParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $("#updateChapterModal").modal("hide");
                alert("Chapter Updated Succesfully");
                console.log($scope.chapterList[$scope.updateChapIndex]["chapterName"]);
                $scope.chapterList[$scope.updateChapIndex]["chapterName"] = $scope.chapterName;
                $scope.clearNgModels();

                // $scope.getChapterTopicsBySubjectChangeques();

            } else {
                alert("Something went wrong");
            }
        });
    }

    $scope.addTopic = function (chapterId) {
        $scope.chapId = chapterId;
        $("#addTopicModal").modal("show");
    }
    $scope.addNewTopic = function () {
        var chapParams = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "instId": localStorage.getItem("inst_id"),
                "classId": $scope.classId,
                "chapterId": $scope.chapId,
                "topicName": $scope.topicName,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId"),
                "contentOwner": "COLLEGE",
                "contentType": $scope.courseName,
                "courseId": $scope.courseId
            }]
        };

        console.log(chapParams);
        httpFactory.executePost("addTopic", chapParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $("#addTopicModal").modal("hide");
                alert("Successfully Topic added");
                $scope.clearNgModels();
                $scope.getChapterTopicsBySubjectChangeques();
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.updateTopic = function (topicId, topicName, chapIndex, topicIndex) {
        $scope.topcId = topicId;
        $scope.topicName = topicName;
        $scope.updateChapIndex = chapIndex;
        $scope.updateTopicIndex = topicIndex;
        $("#updateTopicModal").modal("show");

    }
    $scope.updateTopicName = function () {
        var chapParams = {
            "schemaName": localStorage.getItem("sname"),
            "updatedRecords": [{
                "topicId": $scope.topcId,
                "topicName": $scope.topicName
            }]
        };
        console.log(chapParams);
        httpFactory.executePost("updateTopics", chapParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                $("#updateTopicModal").modal("hide");
                alert("Success. Topic Updated");
                // $scope.getChapterTopicsBySubjectChangeques();
                console.log($scope.chapterList[$scope.updateChapIndex]["Topics"][$scope.updateTopicIndex]["topicName"]);
                console.log($scope.topicName);
                $scope.chapterList[$scope.updateChapIndex]["Topics"][$scope.updateTopicIndex]["topicName"] = $scope.topicName;
                $scope.clearNgModels();

            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.addNewVideoLink = function (chapterid, topicId) {
        $("#addNewVideo").modal("show");
    }

    $scope.addVideo = function () {
        if (!$scope.lessonPlanTabs)
            $scope.saveNewVideoLink();
        else
            $scope.saveLessonPlanVideoLink();
    }

    $scope.saveNewVideoLink = function () {
        var vidParams = {
            "schemaName": localStorage.getItem("sname"),
            "insertRecords": [{
                "topicId": $scope.selTopicId,
                "chapterId": $scope.selChapterId,
                "videoName": $scope.videoName,
                "videoLink": $scope.videoLink,
                "videoType": $scope.videoType,
                "isActive": "1",
                "createdBy": localStorage.getItem("userId"),
                "courseName": $scope.courseName,
                "videoContentType": $scope.activeVideosCOTab
            }]
        };
        console.log(vidParams);
        httpFactory.executePost("addTopicVideos", vidParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success.Video Added");
                $scope.clearNgModels();
                $("#addNewVideo").modal("hide");
                $scope.getTopicVideos();
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.updateVideoLink = function () {
            var vidParams = {
                "schemaName": localStorage.getItem("sname"),
                "videoId": $scope.delTpcVidId,
                "videoName": $scope.videoName,
                "videoLink": $scope.videoLink,
                "updatedBy": localStorage.getItem("userId")
            };
            console.log(vidParams);
            httpFactory.executePost("updateTopicVideo", vidParams, function(data) {
                console.log(data);
                if (data.STATUS == 'SUCCESS') {
                    alert("Video Updated Successfully.");
                    $scope.clearNgModels();
                    $("#updateTopicVideo").modal("hide");
                    $scope.getTopicVideos();
                } else {
                    alert("something went wrong");
                }
            });
        }

    $scope.updateVideoLinkModal = function (video) {
        $scope.videoName = video.videoName;
        $scope.videoLink = video.videoLink;
        $scope.delTpcVidId = video.videoLinkId;
        $("#updateTopicVideo").modal("show");
    }

    $scope.updateLessonPlanVideo = function () {
        var vidParams = {
            "schemaName": localStorage.getItem("sname"),
            "videoId": $scope.delTpcVidId,
            "videoName": $scope.videoName,
            "videoLink": $scope.videoLink,
            "updatedBy": localStorage.getItem("userId")
        };
        console.log(vidParams);
        httpFactory.executePost("updateLessonPlanVideo", vidParams, function(data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Video Updated Successfully.");
                $scope.clearNgModels();
                $("#updateTopicVideo").modal("hide");
                $scope.getLessonPlanVideo();
            } else {
                alert("something went wrong");
            }
        });
    }
    $scope.contentEdit = function (topicId, chapterName) {
        console.log($scope.contentOwnerList.contentSchema);
        localStorage.setItem('selChpterName', $scope.selChpterName);
        $location.path("/contentEdit/" + $scope.selTopicId + "/" + $scope.selTpcOwnr);
    }

    $scope.deleteChapterModal = function (chapter) {
        console.log(chapter);
        $scope.delChapId = chapter.chapterId;
        $scope.delChapName = chapter.chapterName;
        $("#deleteChapterModal").modal("show");
    }
    $scope.deleteChapter = function () {
        httpFactory.getResult("deleteChapter?chapterId=" + $scope.delChapId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&courseId=" + $scope.courseId + "&createdBy=" + localStorage.getItem("userId") + "&courseName=" + $scope.courseName, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $("#deleteChapterModal").modal("hide");
                alert(data.MESSAGE);
            } else {
                alert(data.MESSAGE);
            }
            $scope.clearNgModels();
            $scope.getChapterTopicsBySubjectChangeques();
        });
    }
    $scope.clearNgModels = function () {
        $scope.videoName = "";
        $scope.videoLink = "";
        $scope.topicId = "";
        $scope.topicName = "";
        $scope.chapterId = "";
        $scope.chapterName = "";
    }
    $scope.deleteTopicModal = function (topic) {
        console.log(topic);
        $scope.delTpcId = topic.topicId;
        $scope.delTpcName = topic.topicName;
        $("#deleteTopicModal").modal("show");
    }
    $scope.deleteTopic = function () {
        httpFactory.getResult("deleteTopic?topicId=" + $scope.delTpcId + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId + "&courseName=" + $scope.courseName + "&updatedBy=" + localStorage.getItem("userId"), function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            } else if (data.StatusCode == 300) {
                alert(data.MESSAGE);
            } else {
                alert("Something went wrong.Please try again!");
            }
            $("#deleteTopicModal").modal("hide");
            $scope.clearNgModels();
            $scope.getChapterTopicsBySubjectChangeques();
        });
    }

    $scope.QAIDsList = [];
    $scope.pgstartIndx = 0;
    $scope.pgendIndx = 9;

    $scope.goDownToQaList = function () {
        if ($scope.pgstartIndx >= 9) {
            $scope.pgstartIndx = $scope.pgstartIndx - 10;
            $scope.pgendIndx = $scope.pgendIndx - 10;
        } else {
            $scope.pgstartIndx = 0;
            $scope.pgendIndx = 9
        }
    }
    $scope.goUpToQaList = function () {
        if ($scope.pgendIndx >= 9) {
            $scope.pgstartIndx = $scope.pgstartIndx + 10;
            $scope.pgendIndx = $scope.pgendIndx + 10;
        } else {
            $scope.pgstartIndx = 0;
            $scope.pgendIndx = 9;
        }
    }

    $scope.getQAIDsList = function () {
        $scope.QAIDsList = [];
        httpFactory.getResult("getQuestionAndAnswerIds?topicId=" + $scope.selTopicId + "&contentOwner=" + $scope.selTpcOwnr + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&instId=" + $scope.instituteId, function (data) {
            if (data.StatusCode == 200) {
                $scope.QAIDsList = data.Questions;
                /*if ( $scope.QAIDsList.length == 1 && $scope.QAIDsList[0]) {
                    $scope.new_question_and_answers =$scope.QAIDsList[0];
                } else*/
                if ($scope.QAIDsList.length > 0) {
                    $scope.pgstartIndx = 0;
                    $scope.pgendIndx = 9;
                    $scope.getQAIDDetails($scope.QAIDsList[0].questionAnswerId);
                    $scope.$apply();
                }
            } else {
                $scope.QAIDsList = [];
            }
        });
    }
    $scope.selectedQAId = "";
    $scope.getQAIDDetails = function (quId) {
        $scope.selectedQAId = quId;
        httpFactory.getResult("getQuestionAndAnswers?topicId=" + $scope.selTopicId + "&contentOwner=" + $scope.selTpcOwnr + "&schemaName=" + $scope.schemaName + "&questionAnswerId=" + quId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.QAContent = data.Questions;
                $scope.QAQuestion = $scope.QAContent[0].question;
                $scope.QAAnswer = $scope.QAContent[0].answer;
                $scope.QADiffLevel = $scope.QAContent[0].difficultyLevel;
            } else {
                $scope.QAContent = [];
                $scope.QAQuestion = "";
                $scope.QAAnswer = "";
                $scope.QADiffLevel = "";
            }
        });
    }

    $scope.getQuestionAndAnswers = function () {
        httpFactory.getResult("getQuestionAndAnswers?topicId=" + $scope.selTopicId + "&contentOwner=" + $scope.selTpcOwnr + "&schemaName=" + $scope.schemaName, function (data) {
            $scope.QACount = 0;
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.QAContent = data.Questions;
                $scope.mainQACount = $scope.QAContent.length;
                if ($scope.QAContent.length > 0) {
                    $scope.showQA();
                }
            } else {
                $scope.QAContent = [];
            }
        });
    }
    $scope.editQASel = {};
    $scope.previousQA = function () {
        $scope.QACount = $scope.QACount - 1;
        $scope.showQA();
    }
    $scope.nextQA = function () {
        $scope.QACount = $scope.QACount + 1;
        $scope.showQA();
    }
    $scope.showQA = function () {
        $scope.editQASel = $scope.QAContent[$scope.QACount];
        $scope.QAQuestion = $scope.QAContent[$scope.QACount].question;
        $scope.QAAnswer = $scope.QAContent[$scope.QACount].answer;
        $scope.QADiffLevel = $scope.QAContent[$scope.QACount].difficultyLevel;
    }

//    $scope.deleteTopicVideoModal = function (video) {
//        console.log(video);
//        $scope.videoName = video.videoName;
//        $scope.videoLink = video.videoLink;
//        $scope.delTpcVidId = video.videoLinkId;
//        $scope.topicId = video.topicId;
//        $("#deleteTopicVideo").modal("show");
//    }

    $scope.deleteTopicVideo = function () {
        if (!confirm('Are you sure you want to delete?')) {
            return;
        }
        httpFactory.getResult("deleteTopicVideo?videoId=" + $scope.delTpcVidId + "&schemaName=" + $scope.schemaName + "&courseId=" + $scope.courseId + "&courseName=" + $scope.courseName + "&topicId=" + $scope.selTopicId + "&updatedBy=" + localStorage.getItem("userId") + "&branchId = " + $scope.branchId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $("#deleteTopicVideo").modal("hide");
                alert(data.MESSAGE);
                $scope.clearNgModels();
                $scope.getTopicVideos();
            } else {
                alert(data.MESSAGE);
            }
        });
    }

    $scope.openAddQa = function () {
        $("#addQAModal").modal("show");
    }
    $scope.openEditQa = function (questionAnswerId) {
        $scope.editQAQuestion = $scope.QAQuestion;
        $scope.editQAAnswer = $scope.QAAnswer;
        $("#editQAModal").modal("show");
    }

    $scope.addQuestionAns = function () {

        $scope.question = CKEDITOR.instances['questionQa'].getData();
        $scope.answer = CKEDITOR.instances['ansQa'].getData();

        // $scope.questionCat = $("#questionCat").val();
        //	    $scope.diffLevel = $("#diffLevel").val();

        if ($scope.question.length == 0 || $scope.answer.length == 0) {
            return true;
        }

        $scope.qstnAppeared = $("#questionAppeared").val();
        if (!$scope.qstnAppeared) {
            $scope.qstnAppeared = "";
        }

        var requestParams = {
            "schemaName": $scope.schemaName,
            "insertRecords": [{
                "question": $scope.question,
                "answer": $scope.answer,
                "contentType": $scope.selContentType,
                "topicId": $scope.selTopicId,
                "chapterId": $scope.selChapterId,
                "difficultyLevel": $scope.diffLevel,
                "contentOwner": $scope.selTpcOwnr,
                "questType": "QA",
                "questionAppearedIn": $scope.qstnAppeared,
                "createdBy": localStorage.getItem("userId")
            }]
        }

        console.log(requestParams);
        httpFactory.executePost("addQuestionAnswer", requestParams, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert("Inserted successfully")
                $scope.question = CKEDITOR.instances['questionQa'].setData('');
                $scope.answer = CKEDITOR.instances['ansQa'].setData('');
                $('#diffLevel').prop('selectedIndex', 0);
                window.scrollTo(0, 0);
            } else { }
        });
    }
    $scope.editQuestionAns = function () {
        var requestParams = {
            "schemaName": $scope.schemaName,
            "updateRecords": [{
                "questionAnswerId": $scope.selectedQAId,
                "question": $scope.editQAQuestion,
                "answer": $scope.editQAAnswer,
                "contentOwner": $scope.selTpcOwnr,
                "difficultyLevel": $scope.QADiffLevel,
                "updatedBy": localStorage.getItem("userId")
            }]
        };
        console.log(requestParams);
        httpFactory.executePost("updateTopicQuestionAnswer", requestParams, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.getQAIDDetails($scope.selectedQAId);
                alert("Updated Sucessfully");
                $("#editQAModal").modal("hide");
            }
        });
    }

    $scope.deleteQandA = function (questionAnswerId) {
        $scope.selectedQAId = questionAnswerId;
        $("#deleteQAModal").modal("show");
    }

    $scope.deleteQa = function (questionAnswerId) {
        var requestParams = {
            "schemaName": $scope.schemaName,
            "questionAnswerId": $scope.selectedQAId,
            "branchId": $scope.branchId
        };
        console.log(requestParams);
        httpFactory.executePost("deleteTopicQuestionAnswer", requestParams, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $scope.getQAIDsList();
                alert("Deleted Sucessfully");
                $("#deleteQAModal").modal("hide");
            }
        });
    }

    $scope.viewAnswerForQues = function (quesId) {
        $scope.viewAnswerForQuesId = quesId;
    }

    $scope.displayOrder = function () {
        $scope.displayChapterList = [];
        for (var i = 0; i < $scope.chapterList.length; i++) {
            var obj = {
                "chapterId": $scope.chapterList[i].chapterId,
                "chapterName": $scope.chapterList[i].chapterName,
                "displayOrder": $scope.chapterList[i].displayOrder
            }
            $scope.displayChapterList.push(obj);
        }

        console.log($scope.displayChapterList);
    }
    $scope.submitDisplayOrder = function () {
        var params = {
            "schemaName": $scope.schemaName,
            "updatedBy": $scope.userId,
            "chapterOrder": $scope.displayChapterList
        }
        console.log(params);
        httpFactory.executePost("updateChapterDisplayOrder", params, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                $("#myPop").modal("hide");
            }
        });
    }

    $scope.deleteQuestion = function (question, index) {
        if (confirm('Are you sure you want to delete?')) {
            $scope.deleteQuestionApi(question, index);
        }
    }

    $scope.deleteQuestionApi = function (question, index) {
        httpFactory.getResult("deleteQuestion?questionId=" + question.questionId + "&topicId=" + question.topicId + "&schemaName=" + $scope.selSchema, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                console.log("success");
                console.log($scope.ques[1].questionArray[index]);
                $scope.ques[1].questionArray.splice($scope.ques[1].questionArray[index], 1);
                alert("Successfully deleted");
            } else {
                console.log(data.MESSAGE);
                alert(data.MESSAGE);

            }
        });
    }

    $scope.redirectToQuestionAnswer = function () {
        if ($scope.selectedTopic.length > 0 && $scope.selectedChapter > 0) {
            localStorage.setItem("addQuesSubjId", $scope.selectedSubject);
            localStorage.setItem("addQuesclassId", $scope.practiceClass);
            localStorage.setItem("addQuesChapterId", $scope.practiceChapter);
            localStorage.setItem("addQuescontentOwner", $scope.selectedSchema);
            $location.path("/collegeQuestionAndAnswer/" + $scope.selectedTopic + "/" + $scope.selectedChapter);
        } else {
            alert("Select Chapter and Topic");
        }
    }

    $scope.redirectToAddAnnexure = function () {
        alert($scope.selectedSubject);
        alert($scope.selectedChapter);
        if ($scope.selectedSubject > 0 && $scope.selectedChapter > 0) {
            localStorage.setItem("addQuesSubjId", $scope.selectedSubject);
            localStorage.setItem("addQuesclassId", $scope.practiceClass);
            localStorage.setItem("addQuesChapterId", $scope.practiceChapter);
            localStorage.setItem("addQuescontentOwner", $scope.selectedSchema);
            $location.path("/chapterAnnexure/" + $scope.selectedSubject + "/" + $scope.selectedChapter);

        } else {
            alert("Select Chapter and subject");
        }
    }

    $scope.changeQuestions = function () {

        $scope.changeQuesTag = 1;
    }

    $scope.selQuesToMove = [];
    $scope.selectionQuesObject = [];

    $scope.selectedQuestions = function (selQues) {
        console.log(selQues);
        if ($scope.selQuesToMove.includes(selQues.questionId)) {
            for (var i = $scope.selQuesToMove.length - 1; i >= 0; i--) {
                if ($scope.selQuesToMove[i] === selQues.questionId) {
                    $scope.selQuesToMove.splice(i, 1);
                    $scope.selectionQuesObject.splice(i, 1);
                    break; //<-- Uncomment  if only the first term has to be removed
                }
            }

        } else {
            $scope.selQuesToMove.push(selQues.questionId);
            $scope.selectionQuesObject.push(selQues);
        }

        console.log($scope.selQuesToMove);
    }


    $scope.moveQuestions = function () {
        //		$scope.changeQuesTag=0;
        if ($scope.selQuesToMove.length == 0) {
            alert("Select Questions to move");
            return true;
        }
        $("#moveQuesModal").modal("show");
    }

    $scope.destChapterSel = function (chapter) {
        console.log(chapter);
        if (typeof chapter == 'string') {
            $scope.destTopc = JSON.parse(chapter);
        } else {
            $scope.destTopc = chapter;
        }
        if ($scope.destTopc) {
            $scope.destinationChapterId = $scope.destTopc.chapterId;
            $scope.destTopicList = $scope.destTopc.Topics;
        }
    }
    $scope.destTopicSel = function (topic) {
        console.log(topic);
        if (typeof topic == 'string') {
            $scope.destTopcSel = JSON.parse(topic);
        } else {
            $scope.destTopcSel = topic;
        }
        if ($scope.destTopcSel)
            $scope.destinationTopicId = $scope.destTopcSel.topicId;
    }

    $scope.moveQuestionsToChapter = function () {
        $scope.finalSendObj = [];
        for (var i = 0; i < $scope.selectionQuesObject.length; i++) {
            var ob = {
                "chapterId": $scope.destinationChapterId,
                "topicId": $scope.destinationTopicId,
                "updatedBy": $scope.userId,
                "questionId": $scope.selectionQuesObject[i].questionId
            }
            console.log(ob);
            $scope.finalSendObj.push(ob);
        }

        var params = {
            "schemaName": $scope.selSchema,
            "questions": $scope.finalSendObj
        }
        console.log(params);

        httpFactory.executePost("changeQuestionTopicChapter", params, function (data) {
            console.log(data);
            if (data.StatusCode == "200") {
                alert("Moved Successfully");
                $scope.getQuestionsByTopicId();
                $('#moveQuesModal').modal('hide');
            } else {
                alert("Please Try Again");
            }
        });
    }

    $scope.lockVideo = function (videoLinkId) {
        $scope.videoLinkId = videoLinkId;
        httpFactory.getResult("lockVideo?isActive=0&videoLinkId=" + $scope.videoLinkId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&updatedBy=" + $scope.userId + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            }
            else {
                alert(data.MESSAGE);
            }
            $scope.clearNgModels();
            $scope.getTopicVideos();
        });
    }

    $scope.unLockVideo = function (videoLinkId) {
        $scope.videoLinkId = videoLinkId;
        httpFactory.getResult("lockVideo?isActive=1&videoLinkId=" + $scope.videoLinkId + "&schemaName=" + $scope.schemaName + "&branchId=" + $scope.branchId + "&updatedBy=" + $scope.userId + "&courseId=" + $scope.courseId, function (data) {
            console.log(data);
            if (data.StatusCode == 200) {
                alert(data.MESSAGE);
            }
            else {
                alert(data.MESSAGE);
            }
            $scope.clearNgModels();
            $scope.getTopicVideos();
        });
    }

    $scope.lockOrUnlockAllVideo = function (isActive) {
        var videosIDS = [];
        for (var i = 0; i < $scope.videoContent.length; i++) {
            if (isActive == 1) {
                if ($scope.videoContent[i].isActive == 0) {
                    videosIDS.push($scope.videoContent[i].videoLinkId);
                }
            }
            else {
                if ($scope.videoContent[i].isActive == 1) {
                    videosIDS.push($scope.videoContent[i].videoLinkId);
                }
            }
        }

        var params = {
            "branchId": $scope.branchId,
            "videosIds": videosIDS,
            "updatedBy": $scope.userId,
            "courseId": $scope.courseId,
            "schemaName": $scope.schemaName,
            "isActive": isActive
        }
        if (videosIDS.length > 0) {
            httpFactory.executePost("lockOrUnlockAllVideo?", params, function (data) {
                console.log(data);
                if (data.StatusCode == 200) {
                    alert("Videos Locked/Unlocked Succesfully");
                }
                else {
                    alert(data.MESSAGE);
                }
                $scope.clearNgModels();
                $scope.getChapterTopicsBySubjectChangeques();
            });
        }
        else {
            alert("Nothing to update");
        }
    }


    $scope.getSuperAdminUserId = function () {
        httpFactory.getResult("getSuperAdminUserId?instId=" + $scope.instituteId + "&schemaName=" + $scope.schemaName, function (data) {
            console.log(data);
            if (data.statusCode = 200) {
                $scope.superAdminUserId = data.UserObject.userId;
            }
            else {
                $scope.superAdminUserId = "";
            }
        });
    }

    $scope.fullScreen = function () {
        $("#lessonPlanDocument").toggleFullScreen();
    }

    $scope.displayPPT = function () {
        var config = {
            pptxFileUrl: (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.clickedPPTUrl + "&embedded=true",
            slidesScale: "100%",
            slideMode: false,
            keyBoardShortCut: true,
            mediaProcess: true,
            jsZipV2: "../../assets/js/jszip.min.js",
            themeProcess: true,
            incSlide: { height: 1, width: 1 },
            slideType: "divs2slidesjs",
            slideModeConfig: {
                first: 1,
                nav: true,
                navTxtColor: "white",
                showPlayPauseBtn: true,
                keyBoardShortCut: true,
                showSlideNum: true,
                showTotalSlideNum: true,
                autoSlide: 2,
                randomAutoSlide: false,
                loop: false,
                background: false,
                transition: "default",
                transitionTime: 1
            },
            revealjsConfig: {
                transition: 'zoom',
                slideNumber: true
            }
        };
        $("#lessonPlanDocument").pptxToHtml(config);
    }

    $scope.lessonPlanTabs = false;
    $scope.getLessonPlanDetails = function () {
        $scope.lessonPlanTabs = !$scope.lessonPlanTabs;
        if ($scope.lessonPlanTabs) {
            $scope.getLessonPlanVideo();
            $scope.getLessonPlanDocsByTopic();
            $scope.getVideoPlay($scope.videoContent[0]);
        } else {
            $scope.getTopicVideos();
        }
    }

    $scope.openLessonPlanDoc = function (doc) {
        $scope.enableSlides=false;
        $scope.fsButton=false;
        $scope.clickedPPTUrl = doc.filePath;
        $scope.docName = doc.filename;
        $("#lessonPlanDocument").empty();
        $('#displayDocuments').modal("show");
        if (!doc.filePath.includes('.pdf')) {
            $scope.displayPPT();
        }else{
            $scope.clickedPPTUrl=(localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/viewFiles?filePath="+$scope.clickedPPTUrl+"#toolbar=0";
            const pdfContainer = document.getElementById("pdfContainer");
              const loadDynamicPDF = () => {
                const dynamicPDFUrl = $scope.clickedPPTUrl; // Get the dynamic URL here
                const pdfObject = `<object width="100%" height="100%" type="application/pdf" data="${dynamicPDFUrl}" id="pdf_content"><p>Document load was not successful.</p></object>`;
                pdfContainer.innerHTML = pdfObject;
              };
              loadDynamicPDF();
        }
    }

    $scope.enableSlideShow = function(){
        $scope.enableSlides=!$scope.enableSlides;
        if($scope.enableSlides)
            $scope.fsButton=true;
        else
            $scope.fsButton=false;
        $("#lessonPlanDocument").empty();
        var config = {
                    pptxFileUrl: (localStorage.getItem("domain").includes('ekalavya.online') ? 'https://' : 'http://') + localStorage.getItem("domain") + "/HomeWorkFileDownLoad?filePath=" + $scope.clickedPPTUrl + "&embedded=true",
                    slidesScale: "100%",
                    slideMode: $scope.enableSlides,
                    keyBoardShortCut: $scope.enableSlides,
                    mediaProcess: true,
                    jsZipV2: "../../assets/js/jszip.min.js",
                    themeProcess: true,
                    incSlide: { height: 1, width: 1 },
                    slideType: "divs2slidesjs",
                    slideModeConfig: {
                        first: 1,
                        nav: true,
                        navTxtColor: "white",
                        showPlayPauseBtn: true,
                        keyBoardShortCut: true,
                        showSlideNum: true,
                        showTotalSlideNum: true,
                        autoSlide: 2,
                        randomAutoSlide: false,
                        loop: false,
                        background: false,
                        transition: "random",
                        transitionTime: 1
                    },
                    revealjsConfig: {
                        transition: 'zoom',
                        slideNumber: true
                    }
                };
        $("#lessonPlanDocument").pptxToHtml(config);
    }

    $scope.closeLessonPlanDocs = function(){
        $("#lessonPlanDocument").empty();
        $("#pdfContainer").empty();
    }

    $scope.getLessonPlanVideo = function () {
        $scope.videoContent = [];
        httpFactory.getResult("getLessonPlanVideos?schemaName=" + $scope.schemaName + "&topicId=" + $scope.selTopicId, function (data) {
            console.log(data);
            if (data.statusCode = 200 && data.lessonPlanVideos.length > 0) {
                $scope.videoContent = data.lessonPlanVideos;
            } else {

            }
        });
    }

    $scope.saveLessonPlanVideoLink = function () {
        var vidParams = {
            "schemaName": localStorage.getItem("sname"),
            "topicId": $scope.selTopicId,
            "videoName": $scope.videoName,
            "videoLink": $scope.videoLink,
            "videoType": $scope.videoType,
            "createdBy": localStorage.getItem("userId")
        };
        console.log(vidParams);
        httpFactory.executePost("addLessonPlanVideos", vidParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success.Video Added");
                $scope.clearNgModels();
                $("#addNewVideo").modal("hide");
                $scope.getLessonPlanVideo();
            } else {
                alert("something went wrong");
            }
        });
    }


    $scope.getLessonPlanDocsByTopic = function () {
        $scope.studentToipicFilesDetails = [];
        $scope.lessonPlanDocs = [];
        httpFactory.getResult("getLessonPlanDocsByTopic?schemaName=" + $scope.schemaName + "&topicId=" + $scope.selTopicId, function (data) {
            console.log(data);
            if (data.StatusCode == 200 && data.files.length > 0) {
                $scope.lessonPlanDocs = data.files;
                $scope.lessonPlanSrc = '';
                //                $scope.lessonPlanSrc="http://localhost:8083/HomeWorkFileDownLoad?filePath=/data/eka5398/LessonPlan/2023-06-12/1_DemoPPT.pptx&embedded=true";
                //                $scope.lessonPlanSrc="https://docs.google.com/gview?url=http://ekalavya.hopto.org:8083/HomeWorkFileDownLoad?filePath=/data/eka5398/LessonPlan/2023-06-12/1_DemoPPT.pptx&embedded=true";
                //                $scope.lessonPlanSrc="https://view.officeapps.live.com/op/embed.aspx?src=http://ekalavya.hopto.org:8083/HomeWorkFileDownLoad?filePath=/data/eka5398/LessonPlan/2023-06-12/1_DemoPPT.pptx";

                for (i = 0; i < $scope.lessonPlanDocs.length; i++) {
                    var filepath = $scope.lessonPlanDocs[i].filePath;
                    $scope.lessonPlanDocs[i]["filename"] = filepath.substr(filepath.lastIndexOf('_') + 1);
                    if (filepath.contains(".doc") || filepath.contains(".docx")) {
                        $scope.lessonPlanDocs[i]["fileimage"] = "../../assets/img/doc.png";
                    } else if (filepath.contains(".pdf")) {
                        $scope.lessonPlanDocs[i]["fileimage"] = "../../assets/img/pdf-icon.png";
                    } else if (filepath.contains(".pptx") || filepath.contains(".ppt")) {
                        $scope.lessonPlanDocs[i]["fileimage"] = "../../assets/img/pptx_icon.png";
                    } else {
                        $scope.lessonPlanDocs[i]["fileimage"] = "../../assets/img/img.png";
                    }
                }
            } else {
                // alert(data.MESSAGE);
            }
        });
    }

    $scope.addDocs = function () {
        if (!$scope.lessonPlanTabs)
            $scope.saveNewPdfFile();
        else
            $scope.saveLessonPlanFile();
    }

    $scope.updateVideo = function () {
            if (!$scope.lessonPlanTabs)
                $scope.updateVideoLink();
            else
                $scope.updateLessonPlanVideo();
    }

    $scope.deleteVideo = function (videoId) {
        $scope.delTpcVidId = videoId;
            if (!$scope.lessonPlanTabs)
                $scope.deleteTopicVideo();
            else
                $scope.deleteLessonPlanVideo();
    }

    $scope.deleteLessonPlanVideo = function() {
        if (!confirm('Are you sure you want to delete?')) {
            return;
        }
            var vidParams = {
                "schemaName": localStorage.getItem("sname"),
                "topicId": $scope.topicId,
                "lpVideoLinkId": $scope.delTpcVidId,
                "userId": localStorage.getItem("userId")
            };
            httpFactory.executePost("deleteLessonPlanVideo", vidParams, function(data) {
                console.log(data);
                if (data.STATUS == 'SUCCESS') {
                    alert("Video deleted Successfully.");
                    $scope.clearNgModels();
                    $scope.getLessonPlanVideo();
                } else {
                    alert("Something went wrong");
                }
            });
    }

//    Office.initialize = function () {
//        var element = document.getElementById('lessonPlanDocument');
//        var options = {
//            width: '100%',
//            height: '600px',
//            host: 'https://view.officeapps.live.com',
//            onReady: function () {
//                console.log('PowerPoint viewer is ready');
//            },
//            onError: function (error) {
//                console.log('Error:', error);
//            }
//        };
//
//        var pptUrl = 'http://localhost:8083/HomeWorkFileDownLoad?filePath=/data/eka5398/LessonPlan/2023-06-12/1_DemoPPT.pptx&embedded=true';
//
//        var pptHandler = new Office.WebView.PdfOrPngPageHandler(element, options);
//        pptHandler.load(pptUrl);
//    };

    $scope.saveLessonPlanFile = function () {
        var files = document.getElementById("pdfFile").files;
        console.log(files[0]);
        if (files[0] == undefined) {
            return true;
        }
        console.log(files);
        var blob = files[0].slice(0, files[0].size, files[0].type);
        var newFile = new File([blob], files[0].name.replaceAll(/[^a-zA-Z0-9.]/g, "-"), { type: files[0].type });
        var fd = new FormData();
        fd.append("schemaName", $scope.schemaName);
        fd.append("topicId", $scope.selTopicId);
        fd.append("createdBy", localStorage.getItem("userId"));
        fd.append("file", newFile);
        if($scope.editDocCall){
            fd.append("updatedBy", localStorage.getItem("userId"));
            fd.append("oldFile", $scope.editLpDocDetails.filePath);
            fd.append("lpFileId", $scope.editLpDocDetails.lpFileId); 
        }
        console.log(fd);
        if (newFile.name.contains(".pdf") || newFile.name.contains(".pptx") || newFile.name.contains(".ppt")) {
            //    		if(files[0].size<10485760){
            if(!$scope.editDocCall){
                httpFactory.executeFileUpload("uploadLessonPlanFile", fd, function (data) {
                    console.log(data);
                    if (data.StatusCode == 200) {
                        document.getElementById("pdfFile").value = "";
                        alert("File added Successfully");
                        $scope.getLessonPlanDocsByTopic();
                        $('#addPDfView').modal("hide");
                    } else {
                        alert("Something went wrong");
                    }
                });
            }else{
                httpFactory.executeFileUpload("updateLessonPlanDoc", fd, function (data) {
                    console.log(data);
                    if (data.StatusCode == 200) {
                        document.getElementById("pdfFile").value = "";
                        alert("File updated Successfully");
                        $scope.clearNgModels();
                        // $scope.getLessonPlanDocsByTopic();
                        $scope.getTopicVideos();
                        $scope.getLessonPlanVideo();
                        $scope.getLessonPlanDocsByTopic();
                        $scope.editDocCall = false;
                        $('#addPDfView').modal("hide");
                    } else {
                        alert("Something went wrong");
                        $('#addPDfView').modal("hide");
                    }
                });
            }
        } else {
            alert("File not supported");
        }
    }

    $scope.deleteDoc = function (lessonPlanFileId) {
        if (!confirm('Are you sure you want to delete?')) {
            return;
        }
        var docParams = {
            "schemaName": localStorage.getItem("sname"),
            "topicId": $scope.selTopicId,
            "lpFileId": lessonPlanFileId,
            "userId": localStorage.getItem("userId")
        };
        console.log(docParams);
        httpFactory.executePost("deleteLessonPlanDoc", docParams, function (data) {
            console.log(data);
            if (data.STATUS == 'SUCCESS') {
                alert("Success.Document Deleted");
                $scope.clearNgModels();
                $scope.getLessonPlanVideo();
                $scope.getLessonPlanDocsByTopic();
            } else {
                alert("something went wrong");
            }
        });
    }

    $scope.editDocCall = false;

    $scope.editDoc = function (lpDocDetails) {
        $scope.editLpDocDetails = lpDocDetails;
        $scope.editDocCall = true;
        $('#addPDfView').modal("show");
    }

});