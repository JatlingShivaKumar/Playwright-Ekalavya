projectModule.controller('feeAllocationController', function ($scope, $location, commonFactory, httpFactory, $routeParams) {

	$scope.$ = $;
	$scope.instituteId = localStorage.getItem("inst_id");
	$scope.user_id = localStorage.getItem("userId");
	$scope.schemaName = localStorage.getItem("sname");
	$scope.selectedBranch = localStorage.getItem("bnchId");

	$scope.goToFeeStructure = function () {
		$location.path("feeStructure");
	}

	$scope.getCoursesByBranch = function () {
		$scope.courseList = [];
		$scope.courseClasses = [];
		$scope.selectedCourse = "";
		$scope.selectedCourseName = "";
		$scope.selectedCourseOb = "";
		$scope.selectedClassObj = "";
		$scope.selectedClass = "";
		httpFactory.getResult("getCourseBranchId?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseList = data.Courses;
				if ($scope.courseList.length == 1) {
					$scope.selectedCourseOb = JSON.stringify($scope.courseList[0]);
				}
				$scope.getClassesByCourse();
				console.log($scope.courseList);
			} else {
				$scope.courseList = [];
				console.log("No courses");
			}
		});
	}

	$scope.getClassesByCourse = function () {
		console.log($scope.selectedCourseOb);
		if ($scope.selectedCourseOb == null || $scope.selectedCourseOb == "") {
			return true;
		}
		$scope.selectedCourseObj = JSON.parse($scope.selectedCourseOb);
		$scope.selectedCourse = $scope.selectedCourseObj.courseId;
		$scope.selectedCourseName = $scope.selectedCourseObj.courseName;
		$scope.selectedClass = "";
		$scope.courseClasses = [];
		httpFactory.getResult("getClassByCoursesID?schemaName=" + $scope.schemaName + "&branchId=" + $scope.selectedBranch + "&courseId=" + $scope.selectedCourse, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.courseClasses = data.Classes;
				console.log($scope.courseClasses);
			} else {
				console.log("No classes found");
			}
		});
	}

	$scope.getCoursesByBranch();


	$scope.goToDashbord = function () {
		$location.path("feemanagement");
	}

	$scope.getSectionByClassId = function (selectedClassObj) {
		if (typeof selectedClassObj === "string") {
			$scope.classObj = JSON.parse(selectedClassObj);
		} else {
			$scope.classObj = selectedClassObj;
		}
		httpFactory.getResult("selectSectionsByBranchCourseClass?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&branchId=" + $scope.selectedBranch, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.sectionList = data.Sections;
			}
			else {
				alert("Got Error");
			}
		});
	}

	$scope.updateCrsClsSec = function (selectedSectionObj) {
		if (typeof selectedSectionObj === "string") {
			$scope.sectionObj = JSON.parse(selectedSectionObj);
		} else {
			$scope.sectionObj = selectedSectionObj;
		}
		$scope.sectionId = $scope.sectionObj.sectionId;
	}

	$scope.getStudentFeeAllocatedStructureDetails = function () {
		$scope.feeStructureDetailsArray = [];
		$scope.selectedSubCategory=[];
		httpFactory.getResult("getStudentFeeAllocatedStructureDetails?schemaName=" + $scope.schemaName + "&classCourseId=" + $scope.classObj.classCourseId + "&classCourseSectionId=" + $scope.sectionId, function (data) {
			console.log(data);
			if (data.StatusCode == 200) {
				$scope.showStudents = true;
				$scope.studentFeeAllocatedStructureDetails = data.data;
				if ($scope.studentFeeAllocatedStructureDetails.length > 0) {
					$scope.feeCategoryDetails = $scope.studentFeeAllocatedStructureDetails[0].studentFeeStructureDetails;
					for (i = 0; i < $scope.feeCategoryDetails.length; i++) {
						feeCategoryId = $scope.feeCategoryDetails[i].feeStructureDetailId;
						var count = 0;
						for (j = 0; j < $scope.studentFeeAllocatedStructureDetails.length; j++) {
							for (k = 0; k < $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails.length; k++) {
								if (feeCategoryId == $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].feeStructureDetailId && $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].studentAllocatedFeeDetailId > 0) {
									count++;
								}
								for (l = 0; l < $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].subCategoryArray.length; l++) {
								    $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k]["studentAllocatedFeeDetailId"]='0';
								    if($scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].subCategoryArray[l].studentAllocatedFeeDetailId>0){
								      $scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].studentAllocatedFeeDetailId=$scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[k].subCategoryArray[l].studentAllocatedFeeDetailId;
                                        break;
                                    }
								}
							}
							$scope.studentFeeAllocatedStructureDetails[j]["tempAmount"]=Number($scope.studentFeeAllocatedStructureDetails[j].totalFeeAmount);
						}
						if (count == $scope.studentFeeAllocatedStructureDetails.length) {
							$scope.feeCategoryDetails[i]["checked"] = true;
						} else {
							$scope.feeCategoryDetails[i]["checked"] = false;
						}
					}
					console.log($scope.feeCategoryDetails);
				}
			} else {
				alert("Error while retrieving the data");
			}
		});
	}

	$scope.allocateFeeDetails = function () {
		var formStudentList = [];
		for (i = 1; i < document.getElementsByTagName("tr").length; i++) {
			studentDetails = $scope.studentFeeAllocatedStructureDetails[i - 1];
			var updateAllocatedFeeArr = [];
			var deleteAllocatedFeeArr = [];
			var stuObj = {
				"studentId": studentDetails.studentId,
				"feeStructureId": studentDetails.feeStructureId,
				"classCourseId": $scope.classObj.classCourseId,
				"createdBy": $scope.user_id,
				"studentFeePaymentDetailId": studentDetails.studentFeePaymentDetailId,
				"totalFeeAmount": studentDetails.totalFeeAmount,
				"netAmount": studentDetails.netAmount,
				"paidAmount": studentDetails.paidAmount
			}
			var studentTotalAmount = studentDetails.totalFeeAmount;
			for (j = 2; j < (document.getElementsByTagName("tr")[i].getElementsByTagName("td").length - 1); j++) {
				feeStructureDetails = studentDetails.studentFeeStructureDetails[j - 2];

				if (j == document.getElementsByTagName("tr")[i].getElementsByTagName("td").length - 2) {
					if (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").displayOldDue != undefined && studentDetails.displayOldDue != document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").displayOldDue.checked) {
						if (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").oldDue != undefined && document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").oldDue.value == 0 && document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").displayOldDue.checked == true) {
							alert("Enter a valid amount to assign");
							document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").displayOldDue.checked = false;
							return;
						}
						stuObj["displayOldDue"] = document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").displayOldDue.checked;
					}
					if (document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").oldDue != undefined && studentDetails.oldDue != document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").oldDue.value)
						stuObj["oldDue"] = document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").oldDue.value;
					break;
				}
				if (feeStructureDetails.studentAllocatedFeeDetailId == 0 &&
					document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").feeCategoryName.checked == true) {
					var feeObj = {
						"feeStructureDetailId": feeStructureDetails.feeStructureDetailId,
						"feeCategoryName": feeStructureDetails.feeCategoryName,
						"feeAmount": feeStructureDetails.feeCategoryAmount,
						"isSubCategorised": feeStructureDetails.isSubCategorised
					};
					if(feeStructureDetails.isSubCategorised==1){
					    for(m=0;m<feeStructureDetails.subCategoryArray.length;m++){
					        for(n=0;n<$scope.selectedSubCategory.length;n++){
                                if(studentDetails.studentId==$scope.selectedSubCategory[n].studentId && feeStructureDetails.subCategoryArray[m].subCategoryId==$scope.selectedSubCategory[n].subCategoryId){
                                    feeObj["subCategoryId"]=feeStructureDetails.subCategoryArray[m].subCategoryId;
                                    feeObj.feeAmount=feeStructureDetails.subCategoryArray[m].subCategoryAmount;
                                    updateAllocatedFeeArr.push(feeObj);
                                    studentTotalAmount = Number(studentTotalAmount) + Number(feeStructureDetails.subCategoryArray[m].subCategoryAmount);
                                    break;
                                }
                            }
                        }
					}
					if(feeStructureDetails.isSubCategorised==0){
					    updateAllocatedFeeArr.push(feeObj);
					    studentTotalAmount = Number(studentTotalAmount) + Number(feeStructureDetails.feeCategoryAmount);
					}
				} else if (feeStructureDetails.studentAllocatedFeeDetailId > 0 &&
					document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").feeCategoryName.checked == false) {
					var feeObj = {
						"feeStructureDetailId": feeStructureDetails.feeStructureDetailId,
						"feeCategoryName": feeStructureDetails.feeCategoryName,
						"feeAmount": feeStructureDetails.feeCategoryAmount,
						"studentAllocatedFeeDetailId": feeStructureDetails.studentAllocatedFeeDetailId,
						"isSubCategorised": feeStructureDetails.isSubCategorised
					};
					if(feeStructureDetails.isSubCategorised==1){
                        for(m=0;m<feeStructureDetails.subCategoryArray.length;m++){
                            for(n=0;n<$scope.selectedSubCategory.length;n++){
                                if(studentDetails.studentId==$scope.selectedSubCategory[n].studentId && feeStructureDetails.subCategoryArray[m].subCategoryId==$scope.selectedSubCategory[n].subCategoryId){
                                feeObj["subCategoryId"]=feeStructureDetails.subCategoryArray[m].subCategoryId;
                                feeObj.feeAmount=feeStructureDetails.subCategoryArray[m].subCategoryAmount;
                                deleteAllocatedFeeArr.push(feeObj);
                                studentTotalAmount = Number(studentTotalAmount) + Number(feeStructureDetails.subCategoryArray[m].subCategoryAmount);
                                break;
                                }
                            }
                        }
                    }

                    if(feeStructureDetails.isSubCategorised==0){
                        deleteAllocatedFeeArr.push(feeObj);
                    	studentTotalAmount = Number(studentTotalAmount) - Number(feeStructureDetails.feeCategoryAmount);
                    }
				}else if(feeStructureDetails.isSubCategorised == 1 && feeStructureDetails.studentAllocatedFeeDetailId > 0 &&
                         	document.getElementsByTagName("tr")[i].getElementsByTagName("td")[j].getElementsByTagName("input").feeCategoryName.checked == true){
                    var feeObj = {
						"feeAmount": feeStructureDetails.feeCategoryAmount,
						"studentAllocatedFeeDetailId": feeStructureDetails.studentAllocatedFeeDetailId,
						"isSubCategorised": feeStructureDetails.isSubCategorised
					};
					if(feeStructureDetails.isSubCategorised==1){
					    for(m=0;m<feeStructureDetails.subCategoryArray.length;m++){
					        for(n=0;n<$scope.selectedSubCategory.length;n++){
                                if(studentDetails.studentId==$scope.selectedSubCategory[n].studentId && feeStructureDetails.subCategoryArray[m].subCategoryId==$scope.selectedSubCategory[n].subCategoryId){
                                        feeObj["subCategoryId"]=feeStructureDetails.subCategoryArray[m].subCategoryId;
                                        feeObj.feeAmount=feeStructureDetails.subCategoryArray[m].subCategoryAmount;
                                        updateAllocatedFeeArr.push(feeObj);
                                        studentTotalAmount = Number(studentTotalAmount) + Number(feeStructureDetails.subCategoryArray[m].subCategoryAmount);
                                        break;
                                }
                            }
                        }
					}
					if(feeStructureDetails.isSubCategorised==0)
					    studentTotalAmount = Number(studentTotalAmount) + Number(feeStructureDetails.feeCategoryAmount);
                }
			}
			if (updateAllocatedFeeArr.length > 0) {
				stuObj["updateStudentFeeArr"] = updateAllocatedFeeArr;
			}
			if (deleteAllocatedFeeArr.length > 0) {
				stuObj["deleteStudentAllocatedFeeArr"] = deleteAllocatedFeeArr;
			}
			var tempDiscount = document.getElementsByTagName("tr")[i].getElementsByTagName("td")[document.getElementsByTagName("tr")[i].getElementsByTagName("td").length - 1].getElementsByTagName("input").discount.value;
			if (tempDiscount != studentDetails.discount) {
				if (Number(tempDiscount) > Number(studentTotalAmount)) {
					alert("Discount is greater than the Total amount");
					return;
				} else if (tempDiscount == "") {
					document.getElementsByTagName("tr")[i].getElementsByTagName("td")[document.getElementsByTagName("tr")[i].getElementsByTagName("td").length - 1].getElementsByTagName("input").discount.value = 0;
					var discount = 0;
				} else {
					var discount = tempDiscount;
				}
			} else {
				var discount = studentDetails.discount;
			}

			if (stuObj.hasOwnProperty("updateStudentFeeArr") || stuObj.hasOwnProperty("deleteStudentAllocatedFeeArr") || discount != studentDetails.discount) {
				stuObj["discount"] = discount;
			}

			if (stuObj.hasOwnProperty("updateStudentFeeArr") || stuObj.hasOwnProperty("deleteStudentAllocatedFeeArr") || stuObj.hasOwnProperty("discount") || stuObj.hasOwnProperty("displayOldDue") || stuObj.hasOwnProperty("oldDue")) {
				formStudentList.push(stuObj);
			}
		}
		var params = {
			"schemaName": $scope.schemaName,
			"insertRecords": formStudentList
		};
		if (formStudentList.length > 0) {
			httpFactory.executePost("allocateFeeForStudents", params, function (data) {
				console.log(data);
				if (data.StatusCode == 200) {
					$scope.searchStr = '';
					document.getElementById("searchfeedetails").value = '';
					alert("Updated");
					var formStudentList = [];
					$scope.getStudentFeeAllocatedStructureDetails();
				} else {
					alert("Error while updating the records");
				}
			});
		} else {
			alert("Nothing changed");
		}
	}

	$scope.selectCategory=function(j,inx,selectedAmount,studentId,status){
	    if(selectedAmount==null){
            if(selectedAmount==undefined && status!='dropDown'){
                if(document.getElementsByTagName("tr")[j+1].getElementsByTagName("td")[inx+2].getElementsByTagName("input").feeCategoryName.checked == true){
                    document.getElementsByTagName("tr")[j+1].getElementsByTagName("td")[inx+2].getElementsByTagName("input").feeCategoryName.checked = false;
                    alert("Select sub-category first");
                }else{
                    $scope.selectedSubCategory.splice($scope.selectedSubCategory.findIndex(item => item.studentId === studentId),1);
                    document.getElementsByTagName("tr")[j+1].getElementsByTagName("td")[inx+2].getElementsByTagName("select")[0].selectedIndex=0;
                }
            }
	        return;
	    }
        var selectedSubCat={};
        if(typeof selectedAmount === "string" && selectedAmount.includes("subCategoryId")){
            selectedSubCat=JSON.parse(selectedAmount);
            selectedAmount="";
        }else{
            selectedSubCat=selectedAmount;
            selectedAmount="";
        }
	    if(selectedAmount==""){
	        if(($scope.selectedSubCategory.findIndex(item => item.studentId === studentId && item.subCategoryId === selectedSubCat.subCategoryId)) === -1){
                $scope.selectedSubCategory.push(selectedSubCat);
                $scope.selectedSubCategory[$scope.selectedSubCategory.length-1]["studentId"]=studentId;
            }else{
	            $scope.selectedSubCategory.splice($scope.selectedSubCategory.findIndex(item => item.studentId === studentId && item.subCategoryId === selectedSubCat.subCategoryId),1);
	            $scope.selectedSubCategory.push(selectedSubCat);
	            $scope.selectedSubCategory[$scope.selectedSubCategory.length-1]["studentId"]=studentId;
	        }
	        selectedAmount=selectedSubCat.subCategoryAmount;
	    }
	    $scope.studentFeeAllocatedStructureDetails[j].tempAmount=0;
        for (k = 2; k < (document.getElementsByTagName("tr")[j+1].getElementsByTagName("td").length - 2); k++) {
            if($scope.studentFeeAllocatedStructureDetails[j].studentFeeStructureDetails[inx].isSubCategorised==1 && status=='dropDown'){
                document.getElementsByTagName("tr")[j+1].getElementsByTagName("td")[inx+2].getElementsByTagName("input").feeCategoryName.checked = true;
            }
            if(document.getElementsByTagName("tr")[j+1].getElementsByTagName("td")[k].getElementsByTagName("input").feeCategoryName.checked == true){
                $scope.studentFeeAllocatedStructureDetails[j].tempAmount +=Number(selectedAmount);
                break;
            }
        }
	}

	$scope.selectAll = function (index) {
		if (document.getElementsByTagName("tr")[0].getElementsByTagName("th")[index].getElementsByTagName("input").selectAll.checked == true) {
			for (j = 1; j < document.getElementsByTagName("tr").length; j++) {
				document.getElementsByTagName("tr")[j].getElementsByTagName("td")[index].getElementsByTagName("input").feeCategoryName.checked = true;
			}
		} else if (document.getElementsByTagName("tr")[0].getElementsByTagName("th")[index].getElementsByTagName("input").selectAll.checked == false) {
			for (j = 1; j < document.getElementsByTagName("tr").length; j++) {
				document.getElementsByTagName("tr")[j].getElementsByTagName("td")[index].getElementsByTagName("input").feeCategoryName.checked = false;
			}
		}
	}

});
